"""
App Handlers Module - REFACTORED
Contains all tab/function handlers for Streamlit app.

Module này đã được tối ưu hóa và chia nhỏ:
- app_ui.py: UI rendering functions  
- app_data.py: Data loading/caching functions
- app_handlers.py: Core handlers (file này)
"""

# Apply import fixes and warning suppression FIRST
import warnings
warnings.filterwarnings("ignore")
import os
os.environ['PYTHONWARNINGS'] = 'ignore'

try:
    from config.logging_config import apply_compatibility_fixes
    apply_compatibility_fixes()
except:
    pass

# Suppress streamlit warnings before import
import logging
logging.getLogger('streamlit.runtime.scriptrunner_utils.script_run_context').setLevel(logging.ERROR)
logging.getLogger('streamlit.runtime.state.session_state_proxy').setLevel(logging.ERROR)

import streamlit as st
import pandas as pd
import threading
import time
from datetime import datetime, timedelta
from typing import Dict, Any, Optional

from config.settings import MODEL_DIR, DATA_DIR, TIMEFRAMES
from config.logging_config import get_logger

# Import refactored modules
from app_ui import (
    render_sidebar, create_chart, show_startup_msg, show_price_widget,
    show_realtime_clock, show_prediction_eta, show_model_performance_table,
    show_training_progress_card, show_market_analysis_card,
    show_prediction_confidence_gauge, format_time_ago, format_eta, format_price
)
from app_data import (
    fetch_current_price, load_cached_chart, load_training_results,
    reload_data, log_function_data, cache_prediction_result,
    load_cached_prediction, get_market_data_summary, get_data_freshness_info
)

# Import new utility modules
from utilities.coin_screener import get_coin_screener, scan_market_sync, get_market_overview
from utilities.order_executor import get_order_executor, format_balance_display, format_order_history_display
from utilities.zalo_sender import ZaloSender

logger = get_logger(__name__)

# ==================== STREAMLIT CONTEXT UTILITIES ====================

def has_streamlit_context():
    """Check if we're running in a proper Streamlit context"""
    try:
        from streamlit.runtime.scriptrunner import get_script_run_ctx
        return get_script_run_ctx() is not None
    except:
        try:
            import streamlit as st_check
            _ = st_check.session_state
            return True
        except:
            return False

def safe_session_state_get(key: str, default=None):
    """Safely get value from Streamlit session state"""
    if has_streamlit_context():
        try:
            return st.session_state.get(key, default)
        except Exception as e:
            logger.debug(f"Could not access session state key '{key}': {e}")
            return default
    return default

def safe_session_state_set(key: str, value):
    """Safely set value in Streamlit session state"""
    if has_streamlit_context():
        try:
            st.session_state[key] = value
            return True
        except Exception as e:
            logger.debug(f"Could not set session state key '{key}': {e}")
            return False
    return False

def safe_session_state_update(updates: dict):
    """Safely update multiple session state values"""
    if has_streamlit_context():
        try:
            for key, value in updates.items():
                st.session_state[key] = value
            return True
        except Exception as e:
            logger.debug(f"Could not update session state: {e}")
            return False
    return False

# Import resource manager
from ai_optimizer.unified_resource_manager import (
    get_resource_manager,
    training_status
)

def init_training_status():
    """Initialize training status if needed"""
    if not training_status.get('initialized', False):
        training_status.update({
            'training': False,
            'predicting': False,
            'initialized': True
        })

def initialize_session_state():
    """Initialize session state variables"""
    defaults = {
        'symbol': 'BTCUSDT',
        'timeframe': '15m',
        'chart_data': None,
        'prediction': None,
        'tp_sl': None,
        'last_update': None,
        'auto_refresh': False,
        'prediction_history': [],
        'model_performance': {},
        'training_in_progress': False
    }
    
    for key, default_value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = default_value

def eta(start_time: float, done: int, total: int) -> str:
    """Calculate ETA for progress"""
    try:
        if done <= 0 or total <= 0:
            return "N/A"
            
        elapsed = time.time() - start_time
        rate = done / elapsed if elapsed > 0 else 0
        
        if rate > 0:
            remaining = (total - done) / rate
            return format_eta(remaining)
        else:
            return "N/A"
            
    except Exception:
        return "N/A"

def run_enhanced_prediction_thread(symbol: str, timeframe: str):
    """Run AI prediction in background thread"""
    try:
        def prediction_worker():
            try:
                logger.info(f"🔮 Starting AI prediction for {symbol}@{timeframe}")
                
                # Update status
                training_status.update({
                    'predicting': True,
                    'prediction_symbol': symbol,
                    'prediction_timeframe': timeframe,
                    'prediction_start_time': time.time()
                })
                
                # Load chart data
                chart_data = load_cached_chart(symbol)
                if chart_data is None or chart_data.empty:
                    # Try to reload data
                    reload_result = reload_data(symbol, timeframe)
                    chart_data = reload_result.get('data')
                
                if chart_data is None or chart_data.empty:
                    raise ValueError("No chart data available")
                
                # Check for cached prediction first
                cached_pred = load_cached_prediction(symbol, timeframe, max_age=300)
                if cached_pred:
                    logger.info(f"📋 Using cached prediction for {symbol}@{timeframe}")
                    prediction_result = cached_pred
                else:
                    # Make fresh prediction using MetaAI
                    from ai_models.ai_logic import get_meta_ai
                    meta_ai = get_meta_ai()
                    
                    prediction_result = meta_ai.predict_smart(
                        data=chart_data,
                        symbol=symbol,
                        timeframe=timeframe,
                        use_patterns=True,
                        use_ensemble=True
                    )
                    
                    # Cache the result
                    cache_prediction_result(symbol, timeframe, prediction_result)
                
                # Update session state
                safe_session_state_update({
                    'prediction': prediction_result,
                    'tp_sl': prediction_result.get('tp_sl'),
                    'last_update': datetime.now(),
                    'prediction_confidence': prediction_result.get('confidence', 0.0)
                })
                
                logger.info(f"✅ AI prediction completed for {symbol}@{timeframe}")
                
            except Exception as e:
                logger.error(f"❌ Prediction failed: {e}")
                safe_session_state_update({
                    'prediction': {'error': str(e), 'direction': 'ERROR'},
                    'tp_sl': None
                })
            finally:
                # Clear status
                training_status.update({
                    'predicting': False,
                    'prediction_symbol': None,
                    'prediction_timeframe': None
                })
        
        # Start prediction thread
        thread = threading.Thread(target=prediction_worker, daemon=True)
        thread.start()
        
        logger.info(f"🚀 Prediction thread started for {symbol}@{timeframe}")
        
    except Exception as e:
        logger.error(f"❌ Failed to start prediction thread: {e}")

# ==================== MAIN HANDLERS ====================

def handle_trade_view():
    """Handle the main trading view with AI predictions - FULL WIDTH OPTIMIZED"""
    try:
        # Add custom CSS for this tab
        st.markdown("""
        <style>
        /* Full-width optimization for trade view */
        .trade-view-container {
            width: 100% !important;
            max-width: none !important;
        }
        
        .main-chart-area {
            width: 100% !important;
            max-width: none !important;
        }
        
        /* Ensure charts use full available width */
        .js-plotly-plot {
            width: 100% !important;
        }
        </style>
        """, unsafe_allow_html=True)
        
        st.markdown('<div class="trade-view-container">', unsafe_allow_html=True)
        st.markdown("# 🎯 AI Trading Assistant")
        
        # Sidebar controls (already handled by sidebar)
        symbol = st.session_state.get('symbol', 'BTCUSDT')
        timeframe = st.session_state.get('timeframe', '15m')
        
        # Top status row - FULL WIDTH
        status_col1, status_col2, status_col3, status_col4 = st.columns(4)
        
        with status_col1:
            # Current price
            try:
                current_price = fetch_current_price(symbol)
                if current_price:
                    st.metric("💰 Current Price", format_price(current_price))
                else:
                    st.metric("💰 Current Price", "Loading...")
            except:
                st.metric("💰 Current Price", "Error")
        
        with status_col2:
            # Market time
            current_time = datetime.now().strftime("%H:%M:%S")
            st.metric("🕐 Market Time", current_time)
        
        with status_col3:
            # Data freshness
            data_freshness = get_data_freshness_info(symbol)
            if data_freshness:
                last_update = data_freshness.get('last_update_ago', 'Unknown')
                st.metric("🔄 Data Age", last_update)
            else:
                st.metric("🔄 Data Age", "Unknown")
        
        with status_col4:
            # Quick prediction button
            if st.button("🔮 Quick Predict", type="primary", use_container_width=True):
                run_enhanced_prediction_thread(symbol, timeframe)
                st.rerun()
        
        # Main content area - OPTIMIZED LAYOUT
        chart_col, prediction_col = st.columns([3, 1])  # 3:1 ratio for better space usage
        
        with chart_col:
            st.markdown('<div class="main-chart-area">', unsafe_allow_html=True)
            
            # Load chart data
            if st.session_state.get('chart_data') is None:
                with st.spinner("📊 Loading chart data..."):
                    chart_data = load_cached_chart(symbol)
                    st.session_state['chart_data'] = chart_data
            else:
                chart_data = st.session_state['chart_data']
            
            # Display chart
            if chart_data is not None and not chart_data.empty:
                prediction = st.session_state.get('prediction')
                tp_sl = st.session_state.get('tp_sl')
                
                chart_fig = create_chart(chart_data, prediction, tp_sl)
                if chart_fig:
                    st.plotly_chart(chart_fig, use_container_width=True)
                    
                # Market summary - FULL WIDTH
                market_summary = get_market_data_summary(chart_data)
                if market_summary:
                    with st.expander("📊 Market Summary", expanded=False):
                        sum_col1, sum_col2, sum_col3, sum_col4 = st.columns(4)
                        with sum_col1:
                            st.metric("Current Price", format_price(market_summary['price_stats']['current']))
                        with sum_col2:
                            change_24h = market_summary['price_stats']['change_24h']
                            st.metric("24h Change", f"{change_24h:.2f}%", delta=f"{change_24h:.2f}%")
                        with sum_col3:
                            st.metric("24h Volume", f"{market_summary['volume_stats']['total_24h']:,.0f}")
                        with sum_col4:
                            volatility = market_summary.get('regime', {}).get('volatility', 'NORMAL')
                            st.metric("Volatility", volatility)
            else:
                st.warning("📊 No chart data available")
                show_startup_msg(chart_loaded=False)
            
            st.markdown('</div>', unsafe_allow_html=True)
        
        with prediction_col:
            # AI Prediction section
            st.markdown("### 🤖 AI Prediction")
            
            # Show prediction status/ETA
            show_prediction_eta()
            
            # Display prediction results
            prediction = st.session_state.get('prediction')
            if prediction:
                if 'error' in prediction:
                    st.error(f"❌ Prediction Error: {prediction['error']}")
                else:
                    direction = prediction.get('direction', 'HOLD')
                    confidence = prediction.get('confidence', 0.0)
                    
                    # Direction indicator
                    if direction == 'LONG':
                        st.success(f"📈 **{direction}** Signal")
                    elif direction == 'SHORT':
                        st.error(f"📉 **{direction}** Signal")
                    else:
                        st.info(f"➡️ **{direction}** Signal")
                    
                    # Confidence gauge
                    show_prediction_confidence_gauge(confidence)
                    
                    # Signal explanation
                    explanation = prediction.get('signal_explanation', '')
                    if explanation:
                        st.info(f"💡 {explanation}")
                    
                    # TP/SL information
                    tp_sl = prediction.get('tp_sl')
                    if tp_sl and tp_sl.get('TP') and tp_sl.get('SL'):
                        with st.expander("🎯 TP/SL", expanded=True):
                            st.metric("Take Profit", format_price(tp_sl['TP']))
                            st.metric("Stop Loss", format_price(tp_sl['SL']))
                            
                            rr_ratio = tp_sl.get('risk_reward_ratio', 0)
                            if rr_ratio:
                                st.metric("Risk/Reward", f"{rr_ratio:.2f}")
            
            # Model performance (advanced)
            show_advanced = st.session_state.get('show_advanced', False)
            if show_advanced:
                with st.expander("🔧 Model Performance", expanded=False):
                    try:
                        from ai_models.ai_logic import get_ensemble_predictor
                        predictor = get_ensemble_predictor()
                        model_info = predictor.get_model_info(symbol)
                        show_model_performance_table(model_info)
                    except Exception as e:
                        st.error(f"Model info error: {e}")
        
        # Bottom section - FULL WIDTH
        st.markdown("---")
        
        # Real-time data refresh section
        refresh_col1, refresh_col2, refresh_col3 = st.columns(3)
        
        with refresh_col1:
            if st.button("🔄 Refresh Data", use_container_width=True):
                with st.spinner("🔄 Reloading data..."):
                    reload_result = reload_data(symbol, timeframe)
                    if reload_result['success']:
                        st.session_state['chart_data'] = reload_result['data']
                        st.success(f"✅ Data reloaded: {reload_result['rows']} rows")
                        st.rerun()
                    else:
                        st.error(f"❌ Data reload failed: {reload_result.get('error', 'Unknown error')}")
        
        with refresh_col2:
            auto_refresh = st.checkbox("🔄 Auto Refresh", value=st.session_state.get('auto_refresh', False))
            st.session_state['auto_refresh'] = auto_refresh
        
        with refresh_col3:
            if auto_refresh:
                refresh_interval = st.slider("Refresh Interval (sec)", 10, 300, 60)
                st.session_state['refresh_interval'] = refresh_interval
        
        # Auto refresh logic
        if st.session_state.get('auto_refresh', False):
            time.sleep(st.session_state.get('refresh_interval', 60))
            st.rerun()
        
        st.markdown('</div>', unsafe_allow_html=True)
            
    except Exception as e:
        logger.error(f"❌ Trade view handler error: {e}")
        st.error(f"Trade view error: {e}")

def handle_technical_analysis():
    """Handle technical analysis view"""
    try:
        st.markdown("# 📊 Technical Analysis")
        
        symbol = st.session_state.get('symbol', 'BTCUSDT')
        timeframe = st.session_state.get('timeframe', '15m')
        
        # Load data
        chart_data = st.session_state.get('chart_data')
        if chart_data is None:
            chart_data = load_cached_chart(symbol)
            st.session_state['chart_data'] = chart_data
        
        if chart_data is None or chart_data.empty:
            st.warning("No data available for technical analysis")
            return
        
        # Technical indicators
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 📈 Price Indicators")
            
            # RSI
            if 'rsi' in chart_data.columns:
                current_rsi = chart_data['rsi'].iloc[-1]
                st.metric("RSI (14)", f"{current_rsi:.2f}")
                
                if current_rsi > 70:
                    st.warning("⚠️ Overbought condition")
                elif current_rsi < 30:
                    st.success("✅ Oversold condition")
                else:
                    st.info("ℹ️ Neutral RSI")
            
            # Moving averages
            if 'ma_10' in chart_data.columns and 'ma_50' in chart_data.columns:
                ma_10 = chart_data['ma_10'].iloc[-1]
                ma_50 = chart_data['ma_50'].iloc[-1]
                
                st.metric("MA 10", format_price(ma_10))
                st.metric("MA 50", format_price(ma_50))
                
                if ma_10 > ma_50:
                    st.success("📈 Bullish MA crossover")
                else:
                    st.error("📉 Bearish MA crossover")
        
        with col2:
            st.markdown("### 🔄 Momentum Indicators")
            
            # MACD
            if 'macd' in chart_data.columns:
                current_macd = chart_data['macd'].iloc[-1]
                macd_signal = chart_data.get('macd_signal', pd.Series([0])).iloc[-1]
                
                st.metric("MACD", f"{current_macd:.6f}")
                st.metric("MACD Signal", f"{macd_signal:.6f}")
                
                if current_macd > macd_signal:
                    st.success("📈 Bullish MACD")
                else:
                    st.error("📉 Bearish MACD")
            
            # Volume analysis
            recent_volume = chart_data['volume'].tail(5).mean()
            avg_volume = chart_data['volume'].tail(20).mean()
            volume_ratio = recent_volume / avg_volume
            
            st.metric("Volume Ratio", f"{volume_ratio:.2f}")
            
            if volume_ratio > 1.5:
                st.success("📊 High volume activity")
            elif volume_ratio < 0.5:
                st.warning("📊 Low volume activity")
            else:
                st.info("📊 Normal volume")
        
        # Pattern analysis
        st.markdown("### 🔍 Pattern Analysis")
        
        try:
            from ai_models.ai_patterns import get_all_patterns
            
            with st.spinner("Analyzing patterns..."):
                patterns_data = get_all_patterns(chart_data, symbol)
                
                # Check for active patterns
                pattern_columns = [col for col in patterns_data.columns 
                                 if any(pattern.lower().replace(' ', '_') in col.lower() 
                                       for pattern in ['triangle', 'flag', 'wedge', 'double', 'triple'])]
                
                active_patterns = []
                for col in pattern_columns:
                    if patterns_data[col].iloc[-1] == 1:
                        pattern_name = col.replace('_', ' ').title()
                        active_patterns.append(pattern_name)
                
                if active_patterns:
                    st.success(f"🔍 Active patterns detected: {', '.join(active_patterns)}")
                else:
                    st.info("🔍 No significant patterns detected")
                    
        except Exception as e:
            st.warning(f"Pattern analysis error: {e}")
        
        # Market regime analysis
        st.markdown("### 🌍 Market Regime")
        
        try:
            from ai_models.ai_logic import get_meta_ai
            meta_ai = get_meta_ai()
            
            regime_data = meta_ai.analyze_market_regime(chart_data, symbol)
            show_market_analysis_card({'regime': regime_data})
            
        except Exception as e:
            st.warning(f"Market regime analysis error: {e}")
            
    except Exception as e:
        logger.error(f"❌ Technical analysis handler error: {e}")
        st.error(f"Technical analysis error: {e}")

def handle_news():
    """Handle news and sentiment analysis"""
    try:
        st.markdown("# 📰 News & Sentiment")
        
        st.info("📰 News integration coming soon...")
        
        # Placeholder for news features
        with st.expander("🔧 News Sources Configuration", expanded=False):
            st.multiselect(
                "Select news sources:",
                ["CoinDesk", "CoinTelegraph", "Decrypt", "The Block"],
                default=["CoinDesk", "CoinTelegraph"]
            )
            
            st.slider("News relevance threshold", 0.0, 1.0, 0.7, 0.1)
            
        with st.expander("📊 Sentiment Analysis", expanded=False):
            st.info("Sentiment analysis will be integrated with AI predictions")
            
            # Mock sentiment data
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Overall Sentiment", "Neutral", "0.2%")
            with col2:
                st.metric("News Volume", "124", "15")
            with col3:
                st.metric("Sentiment Score", "0.52", "0.05")
                
    except Exception as e:
        logger.error(f"❌ News handler error: {e}")
        st.error(f"News handler error: {e}")

def handle_training():
    """Handle AI model training"""
    try:
        st.markdown("# 🎯 AI Model Training")
        
        # Training status
        show_training_progress_card(training_status)
        
        # Training controls
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.markdown("### ⚙️ Training Configuration")
            
            # Symbol selection
            training_symbol = st.selectbox(
                "Training Symbol:",
                ["BTCUSDT", "ETHUSDT", "ADAUSDT", "DOTUSDT", "LINKUSDT"],
                index=0
            )
            
            # Training mode
            training_mode = st.selectbox(
                "Training Mode:",
                ["quick", "standard", "deep"],
                index=1,
                help="Quick: 2 models, Standard: 4-5 models, Deep: All models"
            )
            
            # Timeframes
            selected_timeframes = st.multiselect(
                "Timeframes:",
                ["5m", "15m", "30m", "1h", "4h", "1d"],
                default=["15m", "1h"],
                help="Select multiple timeframes for ensemble training"
            )
            
            # Advanced options
            with st.expander("🔧 Advanced Options", expanded=False):
                force_reload = st.checkbox("Force data reload", value=False)
                use_gpu = st.checkbox("Use GPU acceleration", value=True)
                save_checkpoints = st.checkbox("Save training checkpoints", value=True)
        
        with col2:
            st.markdown("### 🚀 Training Actions")
            
            # Training button
            if not training_status.get('training', False):
                if st.button("🎯 Start Training", type="primary", use_container_width=True):
                    try:
                        # Start training in background
                        def start_training():
                            try:
                                from ai_models.unified_trainer import UnifiedTrainer
                                
                                config = {
                                    'symbol': training_symbol,
                                    'timeframes': selected_timeframes,
                                    'training_mode': training_mode,
                                    'force_reload': force_reload,
                                    'use_gpu': use_gpu,
                                    'save_checkpoints': save_checkpoints
                                }
                                
                                trainer = UnifiedTrainer(config)
                                result = trainer.train()
                                
                                logger.info(f"✅ Training completed: {result}")
                                
                            except Exception as e:
                                logger.error(f"❌ Training failed: {e}")
                        
                        thread = threading.Thread(target=start_training, daemon=True)
                        thread.start()
                        
                        st.success("🚀 Training started!")
                        st.rerun()
                        
                    except Exception as e:
                        st.error(f"Failed to start training: {e}")
            else:
                st.info("🔄 Training in progress...")
                
                # Stop training button
                if st.button("⏹️ Stop Training", type="secondary", use_container_width=True):
                    training_status['training'] = False
                    st.warning("Training stopped by user")
                    st.rerun()
        
        # Training results
        st.markdown("### 📊 Training Results")
        
        training_results = load_training_results()
        if training_results.get('models_found', 0) > 0:
            col_a, col_b, col_c = st.columns(3)
            
            with col_a:
                st.metric("Models Found", training_results['models_found'])
            with col_b:
                st.metric("Best Accuracy", f"{training_results['best_accuracy']:.3f}")
            with col_c:
                if training_results.get('latest_training'):
                    time_ago = datetime.now() - training_results['latest_training']
                    st.metric("Last Training", format_time_ago(time_ago.total_seconds()))
            
            # Model details
            if training_results.get('models'):
                with st.expander("📋 Model Details", expanded=False):
                    models_df = pd.DataFrame([
                        {
                            'Model': name,
                            'Accuracy': f"{info['accuracy']:.3f}",
                            'Type': info['type'],
                            'Size (MB)': f"{info['file_size'] / (1024*1024):.1f}",
                            'Modified': info['modified'].strftime('%Y-%m-%d %H:%M')
                        }
                        for name, info in training_results['models'].items()
                    ])
                    st.dataframe(models_df, use_container_width=True)
        else:
            st.info("No trained models found. Start training to create AI models.")
            
    except Exception as e:
        logger.error(f"❌ Training handler error: {e}")
        st.error(f"Training handler error: {e}")

def handle_training_with_mode(training_mode: str, training_controls: dict):
    """Handle training with specific mode and controls"""
    try:
        st.info(f"🚀 Bắt đầu huấn luyện với mode: {training_mode}")
        
        # Get training configuration based on mode
        symbol = st.session_state.get('symbol', 'BTCUSDT')
        timeframes = ["15m", "1h"]  # Default timeframes
        
        # Map training mode to actual config
        mode_mapping = {
            "quick_24h": "quick",
            "standard_7d": "standard", 
            "full_data": "deep"
        }
        
        actual_mode = mode_mapping.get(training_mode, "standard")
        
        # Create training config
        config = {
            'symbol': symbol,
            'timeframes': timeframes,
            'training_mode': actual_mode,
            'force_reload': False,
            'use_gpu': True,
            'save_checkpoints': training_controls.get('save_checkpoint', True),
            'use_ensemble': training_controls.get('use_ensemble', True),
            'optimize_hyperparams': training_controls.get('optimize_hyperparams', False),
            'cross_validation': training_controls.get('cross_validation', True)
        }
        
        # Start training in background
        def start_training():
            try:
                from ai_models.unified_trainer import UnifiedTrainer
                
                # Update training status
                training_status['training'] = True
                training_status['symbol'] = symbol
                training_status['mode'] = actual_mode
                training_status['start_time'] = time.time()
                
                # Initialize trainer with config
                trainer = UnifiedTrainer(config)
                result = trainer.train()
                
                # Update status on completion
                training_status['training'] = False
                training_status['last_result'] = result
                training_status['completion_time'] = time.time()
                
                logger.info(f"✅ Training completed: {result}")
                
            except Exception as e:
                training_status['training'] = False
                training_status['error'] = str(e)
                logger.error(f"❌ Training failed: {e}")
        
        # Start training thread
        import threading
        thread = threading.Thread(target=start_training, daemon=True)
        thread.start()
        
        st.success(f"🚀 Đã bắt đầu huấn luyện {actual_mode} cho {symbol}")
        
        # Show progress
        progress_placeholder = st.empty()
        status_placeholder = st.empty()
        
        # Real-time progress updates
        for i in range(100):
            if not training_status.get('training', False):
                break
                
            progress_placeholder.progress(i + 1)
            status_placeholder.text(f"Đang huấn luyện... {i+1}%")
            time.sleep(0.1)  # Simulate progress
            
        if training_status.get('error'):
            st.error(f"❌ Lỗi huấn luyện: {training_status['error']}")
        elif not training_status.get('training', False):
            st.success("✅ Huấn luyện hoàn thành!")
        
    except Exception as e:
        logger.error(f"Training with mode handler error: {e}")
        st.error(f"Lỗi huấn luyện: {e}")

def handle_training_results():
    """Handle display of training results"""
    try:
        st.subheader("📊 Kết quả huấn luyện")
        
        # Get training results
        training_results = load_training_results()
        
        if training_results.get('models_found', 0) > 0:
            # Summary metrics
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Số models", training_results['models_found'])
            with col2:
                st.metric("Accuracy tốt nhất", f"{training_results.get('best_accuracy', 0):.1%}")
            with col3:
                latest = training_results.get('latest_training')
                if latest:
                    time_ago = datetime.now() - latest
                    st.metric("Lần cuối", format_time_ago(time_ago.total_seconds()))
            
            # Model performance table
            if training_results.get('models'):
                st.markdown("### 📋 Chi tiết models")
                
                model_data = []
                for name, info in training_results['models'].items():
                    model_data.append({
                        'Model': name,
                        'Accuracy': f"{info.get('accuracy', 0):.1%}",
                        'F1 Score': f"{info.get('f1_score', 0):.3f}",
                        'Type': info.get('type', 'Unknown'),
                        'Kích thước': f"{info.get('file_size', 0) / (1024*1024):.1f} MB",
                        'Ngày tạo': info.get('created', 'N/A')
                    })
                
                if model_data:
                    import pandas as pd
                    df_models = pd.DataFrame(model_data)
                    st.dataframe(df_models, use_container_width=True)
                
                # Performance charts
                st.markdown("### 📈 Biểu đồ hiệu suất")
                
                # Create sample performance chart
                import plotly.graph_objects as go
                import plotly.express as px
                
                # Model comparison chart
                models = list(training_results['models'].keys())[:5]  # Top 5 models
                accuracies = [training_results['models'][m].get('accuracy', 0) for m in models]
                
                fig = px.bar(
                    x=models, 
                    y=accuracies,
                    title="So sánh Accuracy của Models",
                    labels={'x': 'Models', 'y': 'Accuracy'}
                )
                fig.update_layout(showlegend=False)
                st.plotly_chart(fig, use_container_width=True)
                
            # Training history
            st.markdown("### 📜 Lịch sử huấn luyện")
            
            history = training_results.get('training_history', [])
            if history:
                import pandas as pd
                df_history = pd.DataFrame(history)
                st.dataframe(df_history, use_container_width=True)
            else:
                st.info("Chưa có lịch sử huấn luyện")
                
        else:
            st.warning("⚠️ Chưa có models nào được huấn luyện")
            
            # Quick start guide
            st.markdown("### 🚀 Bắt đầu huấn luyện")
            st.markdown("""
            1. **Chọn coin**: Nhập mã coin trong sidebar (ví dụ: BTCUSDT)
            2. **Chọn khung thời gian huấn luyện**: Nhanh, Tiêu chuẩn, hoặc Toàn bộ dữ liệu
            3. **Nhấn 'Bắt đầu huấn luyện'**: Trong tab Huấn luyện AI
            4. **Chờ hoàn thành**: Quá trình có thể mất vài phút đến vài giờ
            """)
            
            if st.button("🎯 Đi tới tab Huấn luyện", key="go_to_training"):
                st.info("Vui lòng chuyển sang tab 'Huấn luyện AI' để bắt đầu")
        
    except Exception as e:
        logger.error(f"Training results handler error: {e}")
        st.error(f"Lỗi hiển thị kết quả: {e}")

def handle_zalo():
    """Tích hợp trực tiếp class ZaloSender vào UI (không qua app_ui)"""
    import streamlit as st
    from utilities.zalo_sender import ZaloSender
    import base64

    if 'zalo_sender' not in st.session_state:
        st.session_state['zalo_sender'] = ZaloSender()
    zalo = st.session_state['zalo_sender']

    st.markdown("## 🤖 Zalo Official Account (OA) Management")

    # --- 1. Login via QR (PKCE) ---
    if 'zalo_pkce' not in st.session_state:
        st.session_state['zalo_pkce'] = None
    if 'zalo_authenticated' not in st.session_state:
        st.session_state['zalo_authenticated'] = False

    if not zalo.access_token or not st.session_state['zalo_authenticated']:
        st.info("### Đăng nhập Zalo OA để sử dụng các tính năng gửi tin nhắn.")
        if st.button("🔑 Tạo mã QR đăng nhập", key="zalo_gen_qr") or st.session_state['zalo_pkce'] is None:
            code_verifier, code_challenge, state = zalo.generate_pkce()
            auth_url = zalo.build_auth_url(code_challenge, state)
            st.session_state['zalo_pkce'] = {
                'code_verifier': code_verifier,
                'state': state,
                'auth_url': auth_url
            }
        pkce = st.session_state['zalo_pkce']
        st.markdown("#### 1. Quét mã QR bằng app Zalo để đăng nhập OA:")
        qr_bytes = zalo.get_qr_code_bytes(pkce['auth_url'])
        st.image(qr_bytes, caption="Scan QR with Zalo app", width=220)
        st.markdown(f"[Hoặc bấm vào đây để mở link đăng nhập]({pkce['auth_url']})")
        st.markdown("#### 2. Sau khi quét, nhập mã xác thực (code) trả về trên trình duyệt:")
        auth_code = st.text_input("Nhập mã xác thực (code):", key="zalo_auth_code")
        if st.button("Xác thực", key="zalo_auth_submit") and auth_code:
            success, msg = zalo.exchange_code_for_token(auth_code, pkce['code_verifier'])
            if success:
                st.success("Đăng nhập thành công!")
                st.session_state['zalo_authenticated'] = True
            else:
                st.error(f"Đăng nhập thất bại: {msg}")
        st.stop()

    # --- 2. Show OA Info ---
    st.success("Đã đăng nhập Zalo OA!")
    oa_info = zalo.get_oa_profile()
    if 'error' not in oa_info:
        st.markdown(f"**OA Name:** {oa_info.get('name', 'N/A')}")
        st.markdown(f"**OA ID:** {oa_info.get('oa_id', 'N/A')}")
        st.markdown(f"**Description:** {oa_info.get('description', '')}")
    else:
        st.warning(f"Không lấy được thông tin OA: {oa_info['error']}")

    # --- 3. Contact Management ---
    st.markdown("---")
    st.markdown("### 👥 Quản lý danh bạ OA")
    contacts = zalo.contacts
    if contacts:
        st.table([{k: v for k, v in c.items() if k in ['name', 'phone', 'last_sent', 'send_count']} for c in contacts])
    else:
        st.info("Chưa có contact nào.")
    with st.form("add_contact_form"):
        st.markdown("**Thêm contact mới**")
        phone = st.text_input("Số điện thoại (user_id)", key="zalo_add_phone")
        name = st.text_input("Tên (tùy chọn)", key="zalo_add_name")
        submitted = st.form_submit_button("Thêm contact")
        if submitted and phone:
            ok, msg = zalo.add_contact(phone, name)
            if ok:
                st.success(msg)
                st.experimental_rerun()
            else:
                st.error(msg)
    remove_phone = st.text_input("Nhập số điện thoại để xóa contact:", key="zalo_remove_phone")
    if st.button("Xóa contact", key="zalo_remove_btn") and remove_phone:
        ok, msg = zalo.remove_contact(remove_phone)
        if ok:
            st.success(msg)
            st.experimental_rerun()
        else:
            st.error(msg)

    # --- 4. Send/Broadcast Message ---
    st.markdown("---")
    st.markdown("### ✉️ Gửi tin nhắn OA")
    with st.form("send_msg_form"):
        user_id = st.selectbox("Chọn contact để gửi", [c['phone'] for c in contacts], key="zalo_send_user") if contacts else ""
        message = st.text_area("Nội dung tin nhắn", key="zalo_msg_content")
        send_btn = st.form_submit_button("Gửi tin nhắn")
        if send_btn and user_id and message:
            ok, msg = zalo.send_text_message(user_id, message)
            if ok:
                st.success(msg)
            else:
                st.error(msg)
    st.markdown("#### Hoặc gửi broadcast cho nhiều người:")
    with st.form("broadcast_form"):
        b_msg = st.text_area("Nội dung broadcast", key="zalo_broadcast_content")
        group = st.selectbox("Nhóm nhận:", ["all", "recent", "frequent"], key="zalo_broadcast_group")
        b_btn = st.form_submit_button("Gửi broadcast")
        if b_btn and b_msg:
            result = zalo.broadcast_message(b_msg, group)
            st.success(f"Đã gửi thành công: {result['success']} | Thất bại: {result['failed']}")
            if result['errors']:
                st.error("\n".join(result['errors']))

    # --- 5. Contact Stats ---
    st.markdown("---")
    st.markdown("### 📊 Thống kê OA & liên hệ")
    stats = zalo.get_contact_stats()
    st.json(stats)

# ==================== INITIALIZATION ====================

# Initialize session state and training status on module load
init_training_status()

if has_streamlit_context():
    initialize_session_state()

# Log module initialization
logger.info("✅ App handlers module initialized with refactored architecture")

# Export main components for backward compatibility
__all__ = [
    # Core handlers
    'handle_trade_view', 'handle_technical_analysis', 'handle_news', 
    'handle_training', 'handle_long_term_forecast',
    'handle_training_with_mode', 'handle_training_results',
    
    # Session state utilities
    'initialize_session_state', 'safe_session_state_get', 'safe_session_state_set',
    
    # UI utilities 
    'has_streamlit_context', 'eta', 'init_training_status',
    
    # Re-exported from app_ui
    'render_sidebar', 'create_chart', 'show_startup_msg', 'show_price_widget',
    'show_realtime_clock', 'show_prediction_eta', 'show_model_performance_table',
    'show_training_progress_card', 'show_market_analysis_card',
    'show_prediction_confidence_gauge', 'format_time_ago', 'format_eta', 'format_price',
    
    # Re-exported from app_data
    'fetch_current_price', 'load_cached_chart', 'load_training_results',
    'reload_data', 'log_function_data', 'cache_prediction_result',
    'load_cached_prediction', 'get_market_data_summary', 'get_data_freshness_info'
]
