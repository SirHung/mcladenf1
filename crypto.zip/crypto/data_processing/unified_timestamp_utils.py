# data_processing/unified_timestamp_utils.py
"""
Unified Timestamp Utilities Module
Consolidates timestamp handling logic scattered across multiple files:
1. unified_data_loader.py (6+ locations) - timestamp conversion and validation
2. data_validator.py - timestamp creation and cleaning
3. unified_data_validator.py - timestamp validation logic

This module eliminates code duplication while maintaining backward compatibility.
"""

import pandas as pd
import numpy as np
from typing import Optional, Union, Tuple, Dict, Any
from datetime import datetime, timezone, timedelta
from config.logging_config import get_logger

logger = get_logger('unified_timestamp_utils')

class TimestampUtils:
    """Unified timestamp handling utilities"""
    
    @staticmethod
    def ensure_timestamp_column(df: pd.DataFrame, 
                               preferred_column: str = 'timestamp',
                               fallback_columns: list = None,
                               unit: str = 'ms',
                               utc: bool = True) -> pd.DataFrame:
        """
        Ensure DataFrame has a properly formatted timestamp column
        
        Args:
            df: Input DataFrame
            preferred_column: Primary timestamp column name to use/create
            fallback_columns: List of columns to try if preferred doesn't exist
            unit: Unit for timestamp conversion (if needed)
            utc: Whether to convert to UTC timezone
            
        Returns:
            DataFrame with ensured timestamp column
        """
        if fallback_columns is None:
            fallback_columns = ['close_time', 'time', 'open_time']
            
        df_work = df.copy()
        
        # Check if preferred column already exists and is valid
        if preferred_column in df_work.columns:
            try:
                df_work[preferred_column] = pd.to_datetime(df_work[preferred_column], 
                                                         utc=utc, errors='coerce')
                if not df_work[preferred_column].isna().all():
                    return df_work
            except Exception as e:
                logger.warning(f"Failed to convert existing {preferred_column}: {e}")
        
        # Try fallback columns
        for col in fallback_columns:
            if col in df_work.columns:
                try:
                    if unit == 'ms':
                        df_work[preferred_column] = pd.to_datetime(df_work[col], 
                                                                 unit='ms', utc=utc, errors='coerce')
                    else:
                        df_work[preferred_column] = pd.to_datetime(df_work[col], 
                                                                 utc=utc, errors='coerce')
                    
                    if not df_work[preferred_column].isna().all():
                        logger.info(f"Created {preferred_column} from {col}")
                        return df_work
                except Exception as e:
                    logger.warning(f"Failed to convert {col} to timestamp: {e}")
                    continue
        
        # Last resort: create from index or current time
        if df_work.index.dtype.kind in ['i', 'u', 'f']:  # Numeric index
            try:
                df_work[preferred_column] = pd.to_datetime(df_work.index, 
                                                         unit=unit, utc=utc, errors='coerce')
                if not df_work[preferred_column].isna().all():
                    logger.warning(f"Created {preferred_column} from numeric index")
                    return df_work
            except Exception:
                pass
        
        # Final fallback: create timestamp range
        if len(df_work) > 0:
            now = datetime.now(timezone.utc) if utc else datetime.now()
            df_work[preferred_column] = pd.date_range(
                end=now, periods=len(df_work), freq='1H', tz='UTC' if utc else None
            )
            logger.warning(f"Created artificial {preferred_column} column with hourly intervals")
        
        return df_work
    
    @staticmethod
    def clean_timestamp_data(df: pd.DataFrame, 
                           timestamp_col: str = 'timestamp',
                           remove_duplicates: bool = True,
                           sort_data: bool = True,
                           drop_invalid: bool = True) -> Tuple[pd.DataFrame, Dict[str, int]]:
        """
        Clean timestamp data by removing invalid entries, duplicates, and sorting
        
        Args:
            df: Input DataFrame
            timestamp_col: Name of timestamp column
            remove_duplicates: Whether to remove duplicate timestamps
            sort_data: Whether to sort by timestamp
            drop_invalid: Whether to drop rows with invalid timestamps
            
        Returns:
            Tuple of (cleaned_df, cleaning_stats)
        """
        df_work = df.copy()
        stats = {
            'original_rows': len(df_work),
            'invalid_timestamps_removed': 0,
            'duplicates_removed': 0,
            'final_rows': 0
        }
        
        if timestamp_col not in df_work.columns:
            logger.error(f"Timestamp column '{timestamp_col}' not found")
            stats['final_rows'] = len(df_work)
            return df_work, stats
        
        # Remove invalid timestamps
        if drop_invalid:
            original_count = len(df_work)
            df_work = df_work.dropna(subset=[timestamp_col])
            stats['invalid_timestamps_removed'] = original_count - len(df_work)
        
        # Remove duplicates
        if remove_duplicates and len(df_work) > 0:
            original_count = len(df_work)
            df_work = df_work.drop_duplicates(subset=[timestamp_col], keep='last')
            stats['duplicates_removed'] = original_count - len(df_work)
        
        # Sort by timestamp
        if sort_data and len(df_work) > 0:
            df_work = df_work.sort_values(timestamp_col).reset_index(drop=True)
        
        stats['final_rows'] = len(df_work)
        
        if stats['invalid_timestamps_removed'] > 0 or stats['duplicates_removed'] > 0:
            logger.info(f"Timestamp cleaning: {stats['invalid_timestamps_removed']} invalid, "
                       f"{stats['duplicates_removed']} duplicates removed")
        
        return df_work, stats
    
    @staticmethod
    def parse_timeframe_to_timedelta(timeframe: str) -> timedelta:
        """
        Parse timeframe string to timedelta object
        
        Args:
            timeframe: Timeframe string (e.g., '15m', '1h', '4h', '1d')
            
        Returns:
            Corresponding timedelta object
        """
        if not timeframe:
            raise ValueError("Timeframe cannot be empty")
            
        timeframe = timeframe.lower().strip()
        
        try:
            # Extract numeric part and unit
            if timeframe[-1] == 'm':
                minutes = int(timeframe[:-1])
                return timedelta(minutes=minutes)
            elif timeframe[-1] == 'h':
                hours = int(timeframe[:-1])
                return timedelta(hours=hours)
            elif timeframe[-1] == 'd':
                days = int(timeframe[:-1])
                return timedelta(days=days)
            elif timeframe[-1] == 'w':
                weeks = int(timeframe[:-1])
                return timedelta(weeks=weeks)
            else:
                # Try pandas Timedelta as fallback
                return pd.Timedelta(timeframe)
                
        except (ValueError, KeyError) as e:
            logger.warning(f"Could not parse timeframe '{timeframe}': {e}")
            # Return default 1 hour interval
            return timedelta(hours=1)
    
    @staticmethod
    def check_timestamp_continuity(df: pd.DataFrame, 
                                 timeframe: str,
                                 timestamp_col: str = 'timestamp',
                                 tolerance_factor: float = 1.1) -> Dict[str, Any]:
        """
        Check for missing intervals in timestamp data
        
        Args:
            df: DataFrame with timestamp data
            timeframe: Expected timeframe interval
            timestamp_col: Name of timestamp column
            tolerance_factor: Factor for interval tolerance (1.1 = 10% tolerance)
            
        Returns:
            Dictionary with continuity analysis results
        """
        result = {
            'is_continuous': True,
            'missing_count': 0,
            'expected_delta': None,
            'actual_deltas': [],
            'issues': []
        }
        
        if timestamp_col not in df.columns or len(df) < 2:
            result['issues'].append("Insufficient data for continuity check")
            return result
        
        try:
            ts = df[timestamp_col]
            
            # Handle timezone-aware timestamps
            if pd.api.types.is_datetime64tz_dtype(ts.dtype):
                ts = ts.dt.tz_localize(None)
            
            if timeframe.endswith('M'):
                # Monthly data - special handling
                expected_periods = pd.period_range(
                    ts.iloc[0].to_period('M'),
                    ts.iloc[-1].to_period('M'),
                    freq='M'
                )
                actual_periods = ts.dt.to_period('M').unique()
                missing_count = len(expected_periods) - len(actual_periods)
                result['missing_count'] = missing_count
                result['is_continuous'] = (missing_count == 0)
            else:
                # Regular intervals
                expected_delta = TimestampUtils.parse_timeframe_to_timedelta(timeframe)
                result['expected_delta'] = expected_delta
                
                # Calculate actual deltas
                deltas = ts.diff().dropna()
                result['actual_deltas'] = deltas.tolist()
                
                # Find missing intervals (with tolerance)
                tolerance = expected_delta * tolerance_factor
                missing_intervals = deltas[
                    (deltas < expected_delta * 0.9) | (deltas > tolerance)
                ]
                result['missing_count'] = len(missing_intervals)
                result['is_continuous'] = (len(missing_intervals) == 0)
                
                if len(missing_intervals) > 0:
                    result['issues'].append(f"{len(missing_intervals)} irregular intervals found")
            
        except Exception as e:
            result['issues'].append(f"Continuity check failed: {e}")
            logger.warning(f"Timestamp continuity check error: {e}")
        
        return result
    
    @staticmethod
    def calculate_interval_from_timeframe(timeframe: str, 
                                        current_time: Optional[datetime] = None) -> Tuple[datetime, int]:
        """
        Calculate start time and timestamp for data fetching based on timeframe
        
        Args:
            timeframe: Timeframe string
            current_time: Current time (defaults to now)
            
        Returns:
            Tuple of (start_datetime, start_timestamp_ms)
        """
        if current_time is None:
            current_time = datetime.now(timezone.utc)
            
        delta = TimestampUtils.parse_timeframe_to_timedelta(timeframe)
        start_time = current_time - delta
        start_timestamp_ms = int(start_time.timestamp() * 1000)
        
        return start_time, start_timestamp_ms
    
    @staticmethod
    def is_data_current(last_timestamp: pd.Timestamp, 
                       timeframe: str,
                       current_time: Optional[datetime] = None) -> bool:
        """
        Check if data is current based on last timestamp and timeframe
        
        Args:
            last_timestamp: Last timestamp in the data
            timeframe: Expected data timeframe
            current_time: Current time (defaults to now)
            
        Returns:
            True if data is current, False if update needed
        """        
        if current_time is None:
            current_time = datetime.now(timezone.utc) 
            
        try:
            interval_delta = TimestampUtils.parse_timeframe_to_timedelta(timeframe)
            
            # FIXED: Đồng bộ timezone để tránh lỗi so sánh
            last_dt = last_timestamp.to_pydatetime()
            
            # Nếu một có timezone mà một không có, chuyển cả 2 về naive 
            if (current_time.tzinfo is not None) and (last_dt.tzinfo is None):
                current_time = current_time.replace(tzinfo=None)
            elif (current_time.tzinfo is None) and (last_dt.tzinfo is not None):
                last_dt = last_dt.replace(tzinfo=None)
            
            # Data is current if we're within the expected interval
            time_since_last = current_time - last_dt
            return time_since_last < interval_delta
            
        except Exception as e:
            logger.warning(f"Error checking data currency: {e}")
            return False
    
    @staticmethod
    def standardize_timezone(df: pd.DataFrame, 
                           timestamp_col: str = 'timestamp',
                           target_tz: str = 'UTC') -> pd.DataFrame:
        """
        Standardize timezone for timestamp column
        
        Args:
            df: Input DataFrame
            timestamp_col: Name of timestamp column
            target_tz: Target timezone (default: UTC)
            
        Returns:
            DataFrame with standardized timezone
        """
        df_work = df.copy()
        
        if timestamp_col not in df_work.columns:
            logger.warning(f"Timestamp column '{timestamp_col}' not found")
            return df_work
        
        try:
            ts_col = df_work[timestamp_col]
            
            if pd.api.types.is_datetime64tz_dtype(ts_col.dtype):
                # Already timezone-aware, convert to target
                if target_tz == 'UTC':
                    df_work[timestamp_col] = ts_col.dt.tz_convert('UTC')
                else:
                    df_work[timestamp_col] = ts_col.dt.tz_convert(target_tz)
            else:
                # Timezone-naive, localize to target
                if target_tz == 'UTC':
                    df_work[timestamp_col] = ts_col.dt.tz_localize('UTC')
                else:
                    df_work[timestamp_col] = ts_col.dt.tz_localize(target_tz)
                    
            logger.debug(f"Standardized timezone to {target_tz}")
            
        except Exception as e:
            logger.warning(f"Timezone standardization failed: {e}")
        
        return df_work

# Global instance for easy access
timestamp_utils = TimestampUtils()

# ========== BACKWARD COMPATIBILITY FUNCTIONS ==========

def ensure_timestamp_column(df: pd.DataFrame, **kwargs) -> pd.DataFrame:
    """Backward compatibility wrapper"""
    return timestamp_utils.ensure_timestamp_column(df, **kwargs)

def clean_timestamp_data(df: pd.DataFrame, **kwargs) -> Tuple[pd.DataFrame, Dict[str, int]]:
    """Backward compatibility wrapper"""
    return timestamp_utils.clean_timestamp_data(df, **kwargs)

def parse_timeframe_to_timedelta(timeframe: str) -> timedelta:
    """Backward compatibility wrapper"""
    return timestamp_utils.parse_timeframe_to_timedelta(timeframe)

def check_timestamp_continuity(df: pd.DataFrame, timeframe: str, **kwargs) -> Dict[str, Any]:
    """Backward compatibility wrapper"""
    return timestamp_utils.check_timestamp_continuity(df, timeframe, **kwargs)

def is_data_current(last_timestamp: pd.Timestamp, timeframe: str, **kwargs) -> bool:
    """Backward compatibility wrapper"""
    return timestamp_utils.is_data_current(last_timestamp, timeframe, **kwargs)

# Export main classes and functions
__all__ = [
    'TimestampUtils', 'timestamp_utils',
    'ensure_timestamp_column', 'clean_timestamp_data', 'parse_timeframe_to_timedelta',
    'check_timestamp_continuity', 'is_data_current'
]
