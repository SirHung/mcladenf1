# File: AI_Crypto_Project/data_processing/event_labeler.py
# Nhiệm vụ: Gắn nhãn sự kiện “spike” trên dữ liệu OHLCV để AI training

import pandas as pd
from data_processing.unified_data_loader import unified_loader
from config.settings import DEFAULT_symbol

def label_spikes(df: pd.DataFrame,
                 price_col: str = 'close',
                 horizon: int = 12,
                 threshold: float = 0.01) -> pd.DataFrame:
    """
    Hàm gắn nhãn sự kiện spike dựa trên biến động giá tương lai (horizon).

    Input:
        - df: DataFrame có dữ liệu giá ['open','high','low','close','volume'] và cột thời gian
        - price_col: Cột giá dùng để tính toán biến động, mặc định là 'close'
        - horizon: Số nến tương lai để kiểm tra biến động giá (mặc định 12 nến)
        - threshold: Ngưỡng biến động giá tương lai (vd: 0.01 = 1%)

    Output:
        - DataFrame gốc bổ sung hai cột mới:
          + 'future_change': Phần trăm thay đổi giá trong tương lai sau số nến horizon
          + 'spike': Nhãn spike (+1, -1, hoặc 0)
    """
    df = df.copy()
    
    # Tìm cột thời gian - ưu tiên timestamp, sau đó close_time, time, hoặc sử dụng index
    time_col = None
    for col_name in ['timestamp', 'close_time', 'time']:
        if col_name in df.columns:
            time_col = col_name
            break
    
    # Sắp xếp theo cột thời gian nếu có, nếu không thì giữ nguyên thứ tự
    if time_col:
        df = df.sort_values(time_col).reset_index(drop=True)
    else:
        # Nếu không có cột thời gian, giả định dữ liệu đã được sắp xếp theo thời gian
        df = df.reset_index(drop=True)
    
    # Tính giá trị tương lai horizon nến
    future_price = df[price_col].shift(-horizon)

    # Tính biến động giá tương lai so với hiện tại
    df['future_change'] = (future_price - df[price_col]) / df[price_col]    # Gắn nhãn spike dựa trên ngưỡng threshold
    df['spike'] = 0
    df.loc[df['future_change'] >= threshold, 'spike'] = 1
    df.loc[df['future_change'] <= -threshold, 'spike'] = -1

    # Loại bỏ các dòng cuối không đủ horizon dữ liệu tương lai
    df.dropna(subset=['future_change'], inplace=True)
    df['future_pct_change'] = df['future_change']
    
    # Convert [-1, 0, 1] to [0, 1, 2] for ML compatibility (XGBoost requirement)
    label_mapping = {-1: 0, 0: 1, 1: 2}
    df['label'] = df['spike'].map(label_mapping)
    return df

def collect_spike_events(symbols=None,
                         timeframe: str = '15m',
                         pct_threshold: float = 0.05) -> pd.DataFrame:
    """
    - Input:
      • symbols: str hoặc list[str]; nếu None thì lấy [DEFAULT_symbol]
      • timeframe: khung thời gian (VD '15m')
      • pct_threshold: ngưỡng spike (VD 0.05 = 5%)
    - Output: DataFrame các sự kiện spike với cột
      ['symbol','timestamp','close','pct_change','spike']
    - Logic:
      1. Chuẩn hóa symbols thành list
      2. Với mỗi symbol:
         a) fetch data bằng update_data
         b) gắn nhãn spike qua label_spikes
         c) lọc các dòng spike ≠ 0
      3. Gộp tất cả vào một DataFrame duy nhất
    """
    # Chuẩn hóa danh sách symbols
    if symbols is None:
      symbol_list = [DEFAULT_symbol]
    elif isinstance(symbols, str):
      symbol_list = [symbols]
    else:
      symbol_list = list(symbols)
    
    all_events = []
    for symbol in symbol_list:
        df = unified_loader.update_data(symbol, timeframe)
        if df is None or df.empty:
            continue
        labeled = label_spikes(df, threshold=pct_threshold)
        spikes = labeled[labeled['spike'] != 0][
            ['timestamp','close','pct_change','spike']
        ].copy()
        if not spikes.empty:
            spikes['symbol'] = symbol
            all_events.append(spikes)

    if not all_events:
        return pd.DataFrame(columns=['symbol','timestamp','close','pct_change','spike'])
    return pd.concat(all_events, ignore_index=True)
