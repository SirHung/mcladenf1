"""
Unified Data Loader Module - Consolidates all data loading functions
This module provides a single, optimized interface for loading crypto data from Binance.
Replaces duplicate functions across data_loader.py, data_processor.py, and binance_api.py
"""

# Import config to ensure TensorFlow environment variables are set
from config import settings
import logging

# Get logger for this module first
logger = logging.getLogger(__name__)

# Import AI Parameter Calculator for dynamic data processing
# AI Parameter Calculator will be imported later to avoid circular imports
AI_PARAMETER_CALCULATOR_AVAILABLE = False
ai_parameter_calculator = None

def _get_ai_parameter_calculator():
    """Lazy import AI Parameter Calculator to avoid circular imports"""
    global ai_parameter_calculator, AI_PARAMETER_CALCULATOR_AVAILABLE
    if not AI_PARAMETER_CALCULATOR_AVAILABLE:
        try:
            from ai_models.ai_parameters import get_parameter_calculator
            ai_parameter_calculator = get_parameter_calculator()
            AI_PARAMETER_CALCULATOR_AVAILABLE = True
            logger.info("✅ AI Parameter Calculator lazy-loaded in data loader")
        except ImportError:
            logger.debug("AI Parameter Calculator not available in data loader")
    return ai_parameter_calculator

# Import resource manager for threading optimization
try:
    from ai_optimizer.unified_resource_manager import get_resource_manager
    _resource_manager = get_resource_manager()
except:
    class DummyThreadManager:
        def get_optimal_workers(self, task_type='general'):
            return min(6, os.cpu_count() or 4) 
    _resource_manager = DummyThreadManager()

import os
import gzip
import pickle
import requests
import numpy as np 
import pandas as pd 
from datetime import datetime, timedelta, timezone
from typing import Optional, Dict, Any, List, Union, Tuple
import gc
import time
import json
import logging

import time
import json

from pathlib import Path
import threading
from threading import RLock
from multiprocess import Pool
from config.settings import HISTORY_REQUIREMENTS, TIMEZONE, DATA_DIR, BINANCE_BASE_URL, DEFAULT_QUOTE_BINANCE
from data_processing.unified_timestamp_utils import timestamp_utils

# Ensure data directory exists
os.makedirs(DATA_DIR, exist_ok=True)

# Standard Binance klines columns
KLINES_COLUMNS = [
    "open_time", "open", "high", "low", "close", "volume",
    "close_time", "quote_asset_volume", "number_of_trades",
    "taker_buy_base_asset_volume", "taker_buy_quote_asset_volume", "ignore"
]

# Training mode configurations
TRAINING_MODES = {
    'quick': {
        'days': 7,
        'description': 'Quick 7-day training for rapid updates',
        'max_sentiment_calls': 1,
        'cache_timeout': 3600,  # 1 hour
        'parallel_processing': False
    },
    'standard': {
        'days': 30,
        'description': 'Standard 30-day training',
        'max_sentiment_calls': 3,
        'cache_timeout': 1800,  # 30 minutes  
        'parallel_processing': True
    },
    'deep': {
        'days': 365,
        'description': 'Deep 365-day training with full feature set',
        'max_sentiment_calls': 5,
        'cache_timeout': 900,  # 15 minutes
        'parallel_processing': True
    },
    'full': {
        'days': 365,
        'description': 'Full 1-year training with all features',
        'max_sentiment_calls': 10,
        'cache_timeout': 600,  # 10 minutes
        'parallel_processing': True
    }
}

# Cache lock to prevent concurrent modifications
_data_cache_lock = RLock()
_data_cache = {}
_last_cache_cleanup = datetime.now()

# Data format conversion helpers
def _convert_to_float(x: Any) -> float:
    """Convert value to float with error handling"""
    try:
        return float(x)
    except (ValueError, TypeError):
        return 0.0

def _safe_convert_df_types(df: pd.DataFrame) -> pd.DataFrame:
    """Safely convert DataFrame column types with error handling"""
    if df is None or df.empty:
        return pd.DataFrame()
    
    try:
        # Convert numeric columns
        numeric_cols = ["open", "high", "low", "close", "volume", 
                       "quote_asset_volume", "taker_buy_base_asset_volume", 
                       "taker_buy_quote_asset_volume"]
        
        for col in numeric_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        
        # Convert timestamp columns
        time_cols = ["open_time", "close_time"]
        for col in time_cols:
            if col in df.columns:
                df[col] = pd.to_datetime(df[col], unit='ms', utc=True)
                
        # Drop the 'ignore' column if present
        if 'ignore' in df.columns:
            df = df.drop(columns=['ignore'])
            
        return df
    except Exception as e:
        logger.error(f"Error converting DataFrame types: {e}")
        return df

class UnifiedDataLoader:
    """
    Unified data loader that consolidates all data loading functionality
    """
    def __init__(self, training_mode: str = 'standard'):
        self.default_quote = DEFAULT_QUOTE_BINANCE
        self.base_url = BINANCE_BASE_URL
        self.training_mode = training_mode
        self.mode_config = TRAINING_MODES.get(training_mode, TRAINING_MODES['standard'])
        
        # Initialize cache management
        self.cache_lock = RLock()
        self.last_cache_cleanup = datetime.now()
        self.local_cache = {}
        self.max_cache_size = 10  # Maximum number of datasets to keep in memory
        
        # Connection settings
        self.request_timeout = 30  # seconds
        self.max_retries = 3
        self.retry_delay = 5  # seconds
        
        logger.info(f"Initialized UnifiedDataLoader in {training_mode} mode: {self.mode_config['description']}")
        
    def _normalize_symbol(self, symbol: str) -> str:
        """Normalize symbol to include quote currency"""
        symbol = symbol.upper()
        if not symbol.endswith(self.default_quote):
            symbol = f"{symbol}{self.default_quote}"
        return symbol
    
    def _get_file_path(self, symbol: str, timeframe: str) -> str:
        """Get pickle file path for symbol and timeframe"""
        normalized_symbol = self._normalize_symbol(symbol)
        return os.path.join(DATA_DIR, f"{normalized_symbol}@{timeframe}.pkl.gz")
    
    def _clean_cache(self, force: bool = False):
        """Clean memory cache if too large or outdated"""
        with self.cache_lock:
            now = datetime.now()
            # Clean cache every 10 minutes or if forced
            if force or (now - self.last_cache_cleanup).total_seconds() > 600:
                # If cache is too large, remove oldest items
                if len(self.local_cache) > self.max_cache_size:
                    # Sort by last access time and keep only the newest max_cache_size
                    sorted_cache = sorted(
                        [(k, v.get('last_access', datetime.min)) for k, v in self.local_cache.items()],
                        key=lambda x: x[1], 
                        reverse=True
                    )
                    # Keep only the newest items
                    keys_to_keep = [k for k, _ in sorted_cache[:self.max_cache_size]]
                    # Remove the rest
                    self.local_cache = {k: v for k, v in self.local_cache.items() if k in keys_to_keep}
                    
                self.last_cache_cleanup = now
                # Force garbage collection
                gc.collect()
    
    def fetch_from_binance(self, symbol: str, timeframe: str, start_time: Optional[int] = None, 
                          end_time: Optional[int] = None, limit: int = 1000) -> pd.DataFrame:
        """
        Unified function to fetch data from Binance API
        Replaces: fetch_klines, fetch_new_data_from_binance, fetch_candles, 
                 fetch_binance_data, get_historical_data
        """
        symbol = self._normalize_symbol(symbol)
        endpoint = f"{self.base_url}/api/v3/klines"
          # Calculate start_time if not provided
        if start_time is None and timeframe in HISTORY_REQUIREMENTS:
            days = HISTORY_REQUIREMENTS[timeframe]
            if days >= 3650:
                start_dt = datetime(2017, 1, 1, tzinfo=timezone.utc)
            else:
                start_dt = datetime.now(timezone.utc) - timedelta(days=days)
            start_time = int(start_dt.timestamp() * 1000)
            
        # Setup cache key for this request
        cache_key = f"{symbol}_{timeframe}_{start_time}_{end_time}_{limit}"
        
        # Check if we have a recent cached result
        with self.cache_lock:
            if cache_key in self.local_cache:
                cache_entry = self.local_cache[cache_key]
                age_seconds = (datetime.now() - cache_entry.get('timestamp', datetime.min)).total_seconds()
                # Use cache if less than 5 minutes old
                if age_seconds < 300:  
                    logger.debug(f"Using cached data for {symbol} {timeframe} ({age_seconds:.1f}s old)")
                    self.local_cache[cache_key]['last_access'] = datetime.now()
                    return cache_entry['data'].copy()
        
        all_klines = []
        current_start = start_time
        retry_count = 0
        
        while True:
            params = {
                "symbol": symbol,
                "interval": timeframe,
                "limit": limit
            }
            
            if current_start is not None:
                params["startTime"] = current_start
            if end_time is not None:
                params["endTime"] = end_time            
            try:
                response = requests.get(endpoint, params=params, timeout=self.request_timeout)
                response.raise_for_status()
                data = response.json()
                
                # Reset retry counter on success
                retry_count = 0
            except requests.RequestException as e:
                retry_count += 1
                logger.warning(f"Request error fetching {symbol}@{timeframe}: {e}, retry {retry_count}/{self.max_retries}")
                
                # Implement exponential backoff
                if retry_count <= self.max_retries:
                    backoff_time = self.retry_delay * (2 ** (retry_count - 1))
                    logger.info(f"Retrying in {backoff_time} seconds...")
                    time.sleep(backoff_time)
                    continue
                else:
                    logger.error(f"Max retries reached for {symbol}@{timeframe}")
                    break
            except Exception as e:
                logger.error(f"Unexpected error fetching {symbol}@{timeframe}: {e}")
                break
            
            if not data:
                logger.debug(f"No more data available for {symbol}@{timeframe}")
                break
            
            all_klines.extend(data)
            
            # If we got less than requested, we've reached the end
            if len(data) < limit:
                logger.debug(f"Reached end of data for {symbol}@{timeframe}, got {len(data)} < {limit} records")
                break
                
            # Update start time for next batch
            last_close_time = data[-1][6]  # close_time is at index 6
            current_start = last_close_time + 1
            
            # Rate limiting - Binance allows 1200 requests per minute, so 200ms is safe
            time.sleep(0.2)
            
        # Return empty DataFrame if no data retrieved
        if not all_klines:
            logger.warning(f"No data retrieved for {symbol}@{timeframe}")
            return pd.DataFrame()
        
        # Create DataFrame with proper column names
        df = pd.DataFrame(all_klines, columns=KLINES_COLUMNS)
        
        # Convert timestamps using unified utilities
        df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
        df["close_time"] = pd.to_datetime(df["close_time"], unit="ms", utc=True)
        df = timestamp_utils.ensure_timestamp_column(df, preferred_column='timestamp', 
                                                   fallback_columns=['close_time'])
          # Convert numeric columns
        numeric_cols = ["open", "high", "low", "close", "volume", "quote_asset_volume",
                       "taker_buy_base_asset_volume", "taker_buy_quote_asset_volume", "ignore"]
        df[numeric_cols] = df[numeric_cols].apply(pd.to_numeric, errors="coerce")
        df["number_of_trades"] = df["number_of_trades"].astype(int, errors="ignore")
        
        return df.reset_index(drop=True)
        
    def load_cached_data(self, symbol: str, timeframe: str) -> Optional[pd.DataFrame]:
        """Load data from cached pickle file, kiểm soát RAM thông minh nếu file lớn"""
        file_path = self._get_file_path(symbol, timeframe)
        if not os.path.exists(file_path):
            return None
        try:
            # Nếu file lớn hơn 30% RAM, dùng resource_manager.safe_load_dataframe
            file_size_mb = os.path.getsize(file_path) / 1e6
            from ai_optimizer.unified_resource_manager import get_resource_manager
            resource_manager = get_resource_manager()
            total_mem_gb = resource_manager.get_system_stats().memory_available_gb + resource_manager.get_system_stats().memory_percent/100
            if file_size_mb > 0.3 * total_mem_gb * 1024:
                logger.warning(f"⚠️ File cache lớn ({file_size_mb:.1f} MB), nạp kiểm soát RAM qua resource_manager")
                df = resource_manager.safe_load_dataframe(file_path, filetype='pkl', chunk_size=100_000)
            else:
                import gzip, pickle
                with gzip.open(file_path, "rb") as f:
                    df = pickle.load(f)
            
            # Ensure timestamp column exists using unified utilities
            df = timestamp_utils.ensure_timestamp_column(df)
            
            # CRITICAL FIX: Ensure required OHLCV columns exist
            required_columns = ['open', 'high', 'low', 'close', 'volume']
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                logger.warning(f"Missing columns {missing_columns} in cached data, attempting to fix...")
                
                # Try to map common alternative column names
                column_mapping = {
                    'Open': 'open', 'HIGH': 'high', 'Low': 'low', 'Close': 'close', 'Volume': 'volume',
                    'o': 'open', 'h': 'high', 'l': 'low', 'c': 'close', 'v': 'volume'
                }
                
                # Apply column mapping
                for old_name, new_name in column_mapping.items():
                    if old_name in df.columns and new_name not in df.columns:
                        df = df.rename(columns={old_name: new_name})
                        logger.info(f"Mapped column {old_name} -> {new_name}")
                
                # Final check
                still_missing = [col for col in required_columns if col not in df.columns]
                if still_missing:
                    logger.error(f"Cannot fix missing columns {still_missing} in {file_path}")
                    return None
            
            logger.info(f"Loaded cached data for {symbol}@{timeframe}: {len(df)} rows")
            return df
        except Exception as e:
            logger.error(f"Error loading cached data from {file_path}: {e}")
            return None
    
    def save_data(self, df: pd.DataFrame, symbol: str, timeframe: str) -> bool:
        """Save DataFrame to pickle file"""
        file_path = self._get_file_path(symbol, timeframe)
        
        try:
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            with gzip.open(file_path, "wb") as f:
                pickle.dump(df, f)
            logger.info(f"Saved {len(df)} rows to {file_path}")
            return True
        except Exception as e:
            logger.error(f"Error saving data to {file_path}: {e}")
            return False

    def update_data(self, symbol: str, timeframe: str = None, deep_train: bool = False, training_mode: str = None) -> pd.DataFrame:
        """
        Consolidated data update function with training mode support
        Replaces: update_data from data_loader.py and update_data_with_mode (eliminates duplication)
        """
        # Set up training mode configuration if provided
        if training_mode:
            self.training_mode = training_mode
            self.mode_config = TRAINING_MODES.get(training_mode, TRAINING_MODES['standard'])
            logger.info(f"Switched to {training_mode} mode: {self.mode_config['description']}")
            days = self.mode_config['days']
            deep_train = (training_mode == 'deep')
        else:
            days = None  # Will use HISTORY_REQUIREMENTS
            
        symbol = self._normalize_symbol(symbol)
        
        # Determine intervals based on training mode
        if training_mode == 'quick' and timeframe is None:
            intervals = ['15m', '1h']  # Only essential timeframes for quick mode
        elif training_mode == 'test' and timeframe is None:
            intervals = ['15m']  # Only one timeframe for test
        else:
            intervals = [timeframe] if timeframe else list(HISTORY_REQUIREMENTS.keys())
            
        result_frames = []
        
        for tf in intervals:
            mode_info = f" ({self.training_mode} mode)" if training_mode else ""
            logger.info(f"Updating data for {symbol}@{tf}{mode_info}")
            
            # Load existing data
            df_old = self.load_cached_data(symbol, tf)
            start_time = None
            
            if df_old is not None and not df_old.empty and not deep_train:
                # Check if we need to fetch new data using unified utilities
                df_old = timestamp_utils.ensure_timestamp_column(df_old)
                last_timestamp = df_old["timestamp"].max()
                        
                # Calculate minimum interval for new data using unified utilities
                if last_timestamp is not None:
                    now = datetime.now(timezone.utc)
                    if timestamp_utils.is_data_current(last_timestamp, tf, now):
                        logger.info(f"Data for {symbol}@{tf} is up to date, skipping fetch")
                        df_new = pd.DataFrame()
                    else:
                        start_time = int(last_timestamp.timestamp() * 1000) + 1
                        df_new = self.fetch_from_binance(symbol, tf, start_time)
                else:
                    # No valid timestamp, use mode-specific or default days
                    if days:
                        start_dt = datetime.now(timezone.utc) - timedelta(days=days)
                        logger.info(f"Fetching {days}-day history from {start_dt}")
                    else:
                        default_days = HISTORY_REQUIREMENTS.get(tf, 30 if not deep_train else 365)
                        start_dt = datetime.now(timezone.utc) - timedelta(days=default_days)
                        logger.info(f"Fetching full history from {start_dt}")
                    start_time = int(start_dt.timestamp() * 1000)
                    df_new = self.fetch_from_binance(symbol, tf, start_time)
            else:
                # First time or deep training - fetch full history
                if days:
                    start_dt = datetime.now(timezone.utc) - timedelta(days=days)
                    logger.info(f"Fetching {'full history' if deep_train else f'{days}-day data'} from {start_dt}")
                else:
                    default_days = HISTORY_REQUIREMENTS.get(tf, 30 if not deep_train else 365)
                    start_dt = datetime.now(timezone.utc) - timedelta(days=default_days)
                    logger.info(f"Fetching {'full history' if deep_train else 'initial data'} from {start_dt}")
                start_time = int(start_dt.timestamp() * 1000)
                df_new = self.fetch_from_binance(symbol, tf, start_time)
            
            # Combine old and new data
            if df_new.empty:
                df_combined = df_old.copy() if df_old is not None else pd.DataFrame()
            else:
                if df_old is not None and not df_old.empty and not deep_train:
                    df_combined = pd.concat([df_old, df_new], ignore_index=True)
                    df_combined = df_combined.drop_duplicates(subset="close_time", keep="last")
                    df_combined = df_combined.sort_values("close_time").reset_index(drop=True)
                else:
                    df_combined = df_new.copy()
                  # Data cleanup for old data (disabled for deep training to use ALL data)
                # For deep training, we want to use ALL available historical data
                if deep_train and len(df_combined) > 500000:
                    logger.info(f"🔬 Deep training mode: using ALL {len(df_combined)} rows (no limit)")
                    # Keep all data for deep training - no tail() limitation
                elif not deep_train and len(df_combined) > 50000:
                    logger.info(f"⚡ Fast mode: keeping last 50000 rows from {len(df_combined)}")
                    df_combined = df_combined.tail(50000).copy()
                
                # Save updated data
                self.save_data(df_combined, symbol, tf)
            
            if df_combined.empty:
                logger.warning(f"No data available for {symbol}@{tf}")
                continue
            
            # Prepare data for AI processing
            essential_columns = ["timestamp", "open", "high", "low", "close", "volume"]
            df_ai = df_combined[essential_columns].copy()
            
            # Add timeframe column for compatibility
            df_ai["timeframe"] = tf
            result_frames.append(df_ai)
            
            # Memory cleanup
            del df_combined, df_new
            if df_old is not None:
                del df_old
            gc.collect()
        
        if not result_frames:
            logger.warning(f"No data updated for {symbol}")
            return pd.DataFrame()
        
        # Combine all timeframes
        combined_df = pd.concat(result_frames, ignore_index=True)
        
        # Save combined CSV for compatibility
        try:
            csv_path = os.path.join(DATA_DIR, f"{symbol}_combined.csv")
            combined_df.to_csv(csv_path, index=False)
            logger.info(f"Saved combined CSV for {symbol}")
        except Exception as e:
            logger.error(f"Error saving combined CSV: {e}")
        
        mode_info = f" ({self.training_mode} mode)" if training_mode else ""
        logger.info(f"Data update completed for {symbol}{mode_info}: {len(combined_df)} total rows")          
        return combined_df

    def load_and_process_data(self, symbol: str, timeframe: str,
                           
                            apply_labels: bool = True, horizon: int = 12, 
                            threshold: float = 0.003, force_reload: bool = False) -> Optional[pd.DataFrame]:
        """
        Unified data loading and processing function - PARALLEL OPTIMIZED VERSION
        Replaces: load_and_process_data from data_processor.py
        """
        try:
            logger.info(f"🚀 Loading and processing data for {symbol}@{timeframe} with PARALLEL processing")
            
            # Load raw data
            if force_reload:
                df = self.update_data(symbol, timeframe)
            else:
                df = self.load_cached_data(symbol, timeframe)
                if df is None or df.empty:
                    df = self.update_data(symbol, timeframe)
            
            if df is None or df.empty:
                logger.error(f"No data available for {symbol}@{timeframe}")
                return None
            
            # Ensure required columns exist
            required_columns = ["timestamp", "open", "high", "low", "close", "volume"]
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                logger.error(f"Missing required columns: {missing_columns}")
                return None            # PARALLEL PROCESSING: Run validation,  labels simultaneously
            # USE BOTH THREADS AND PROCESSES FOR MAXIMUM CPU UTILIZATION
            from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
            import time
            
            start_time = time.time()
            processing_results = {}
            
              # Get optimal worker count from resource manager - ENHANCED FOR FULL CPU USAGE
            try:
                # Request CPU-intensive workers instead of generic 'processing'
                optimal_workers = _resource_manager.get_optimal_workers('cpu')
                # For data processing, use more aggressive threading
                max_workers = min(optimal_workers * 2, 16)  # Up to 16 workers for high CPU usage
                logger.info(f"🚀 Resource manager suggests {optimal_workers}, using {max_workers} for intensive processing")
            except:
                # Fallback: use more threads based on CPU count
                import os
                cpu_count = os.cpu_count() or 4
                max_workers = min(cpu_count, 12)  # More aggressive fallback
                logger.info(f"⚠️ Fallback: using {max_workers} workers (CPU count: {cpu_count})")
            
            logger.info(f"⚡ Starting parallel processing with {max_workers} workers")
            
            def validate_data_task():
                """Validation task"""
                try:
                    from data_processing.unified_data_validator import unified_validator
                    validation_result = unified_validator.validate_comprehensive(
                        df, symbol=symbol, timeframe=timeframe, validation_types=['timestamp', 'quality']
                    )
                    return ('validation', validation_result.cleaned_data if validation_result.is_valid else df)
                except Exception as e:
                    logger.warning(f"Data validation error: {e}")
                    return ('validation', df)
           
            def compute_labels_task():
                """Labels computation task (with fallback to future price movement)."""
                if not apply_labels:
                    return ('labels', None)
                try:
                    logger.info("🏷️ Computing labels in parallel thread")
                    from data_processing.event_labeler import label_spikes
                    import numpy as np

                    # 1) Compute spikes-based labels
                    if len(df) > 50000:
                        logger.info(f"Large dataset: using last 50k rows for labeling")
                        df_subset = df.tail(50000).copy()
                    else:
                        df_subset = df.copy()
                    df_labeled = label_spikes(df_subset, horizon=horizon, threshold=threshold)

                    # 2) Fallback: nếu chỉ có 1 lớp (toàn 0), gán nhãn bằng biến động giá kế tiếp
                    labels = df_labeled.get('label')
                    if labels is None or labels.nunique() < 2:
                        logger.warning("⚠️ No spike events found; fallback labeling via price movement")
                        # next_price - current_price
                        future_price = df_subset['close'].shift(-horizon)
                        raw = future_price - df_subset['close']
                        df_labeled['label'] = np.sign(raw).fillna(0).astype(int)

                    return ('labels', df_labeled)
                except Exception as e:
                    logger.error(f"Labels computation error: {e}")
                    return ('labels', None)
                
            task_fns = []
            task_keys = []

            # 1) I/O-bound: validation
            task_fns.append(validate_data_task)
            task_keys.append('validation')

            # 2) CPU-bound:  labels
           
           
            if apply_labels:
                task_fns.append(compute_labels_task);     task_keys.append('labels')

            # Execute all tasks in separate processes
            with Pool(processes=len(task_fns)) as pool:
                results = pool.map(lambda fn: fn(), task_fns)

            # Collect and log outcomes
            for key, res in zip(task_keys, results):
                if res is None:
                    logger.error(f"❌ {key} failed or returned None")
                    processing_results[key] = None
                else:
                    result_type, result_data = res
                    processing_results[result_type] = result_data
                    logger.info(f"✅ {result_type} completed")            
            parallel_time = time.time() - start_time
            logger.info(f"⚡ Parallel processing completed in {parallel_time:.2f}s")
            
            # Merge results back to main dataframe
            final_df = processing_results.get('labels', df)
           
            # Merge labels
            if processing_results.get('labels') is not None:
                labels_df = processing_results['labels']
                label_cols = [col for col in labels_df.columns if col not in final_df.columns and 'label' in col.lower()]
                if label_cols:
                    if len(labels_df) < len(final_df):
                        # Labels computed on subset, map back
                        for col in label_cols:
                            final_df[col] = 0  # Default value
                            final_df.loc[final_df.tail(len(labels_df)).index, col] = labels_df[col].values
                    else:
                        for col in label_cols:
                            final_df[col] = labels_df[col]
                    logger.info(f"🏷️ Added {len(label_cols)} label columns")
                    
                    # Create target column
                    if 'label' in final_df.columns and 'target' not in final_df.columns:
                        final_df['target'] = final_df['label']            
            total_time = time.time() - start_time
            logger.info(f"🎯 Data processing completed in {total_time:.2f}s - Final shape: {final_df.shape}")
            
            gc.collect()
            # Remove duplicate columns
            final_df = final_df.loc[:, ~final_df.columns.duplicated()]
            logger.info(f"Data processing completed for {symbol}@{timeframe}: {len(final_df)} rows, {len(final_df.columns)} columns")
            return final_df
            
        except Exception as e:
            logger.error(f"Error in load_and_process_data: {e}", exc_info=True)
            return None

    def cleanup_old_data(self, days_to_keep: int = 90):
        """
        Cleanup old cached data files
        """
        try:
            cleanup_count = 0
            cutoff_time = datetime.now() - timedelta(days=days_to_keep)
            
            for filename in os.listdir(DATA_DIR):
                if filename.endswith('.pkl.gz'):
                    file_path = os.path.join(DATA_DIR, filename)
                    file_time = datetime.fromtimestamp(os.path.getmtime(file_path))
                    
                    if file_time < cutoff_time:
                        os.remove(file_path)
                        cleanup_count += 1
                        logger.info(f"Cleaned up old cache file: {filename}")
            
            logger.info(f"Cleanup completed: {cleanup_count} files removed")
            return cleanup_count
            
        except Exception as e:
            logger.error(f"Error during cleanup: {e}")
            return 0

# Global instance for easy access
unified_loader = UnifiedDataLoader()

# Backward compatibility functions
def update_data(symbol: str, timeframe: str = None, deep_train: bool = False, training_mode: str = None) -> pd.DataFrame:
    """Backward compatibility wrapper with training mode support"""
    return unified_loader.update_data(symbol, timeframe, deep_train, training_mode)

# ========== ENHANCED DATA INTEGRATION ==========

def get_multi_timeframe_data(symbol: str, timeframes: List[str], **kwargs) -> Dict[str, pd.DataFrame]:
    """
    Thu thập dữ liệu từ nhiều timeframe
    """
    data = {}
    
    # Khởi tạo loader duy nhất
    loader = UnifiedDataLoader(training_mode=kwargs.get('training_mode', 'standard'))
    
    # Filter valid kwargs for load_and_process_data
    valid_kwargs = {k: v for k, v in kwargs.items()
                   if k in [ 'apply_labels',
                             'horizon', 'threshold', 'force_reload']}    # Keep parallel processing but with better timeout and fallback
    use_parallel = len(timeframes) > 1 and kwargs.get('use_parallel', True)
    
    if use_parallel:
        from concurrent.futures import ThreadPoolExecutor, as_completed        # Use optimized worker count
        try:
            from ai_optimizer.unified_resource_manager import get_resource_manager
            resource_manager = get_resource_manager()
            max_workers = min(len(timeframes), resource_manager.get_optimal_workers('io'))
        except:
            max_workers = min(len(timeframes), 4)  # Fallback to conservative count
        
        logger.info(f"⚡ Parallel data loading: {len(timeframes)} timeframes with {max_workers} workers")
        
        def load_single_timeframe(tf):
            try:
                df = loader.load_and_process_data(symbol, tf, **valid_kwargs)                # STEP 2: Skip heavy sentiment processing during training to avoid GPU OOM
                # Only do lightweight sentiment if needed
                df['sentiment_score'] = 0.0  # Default neutral sentiment for training
                if kwargs.get('include_sentiment', False) and kwargs.get('training_mode') != 'quick':
                    try:
                        from data_sources.news_manager import NewsManager
                        news_mgr = NewsManager()
                        sent = news_mgr.get_sentiment_analysis(days=min(7, loader.mode_config['days']))  # Limit to 7 days max
                        # Attach average sentiment score if available
                        avg_sent = 0.0
                        dist = sent.get('sentiment_distribution', {})
                        total = sent.get('total_articles', 0)
                        if total and dist:
                            avg_sent = sum(v['average_score']*v['count'] for v in dist.values())/total
                        df['sentiment_score'] = avg_sent
                        logger.info(f"📰 Added sentiment for {tf}: score={avg_sent:.3f}")
                    except Exception as e:
                        logger.warning(f"⚠️ Sentiment analysis failed for {tf}: {e}")
                        df['sentiment_score'] = 0.0
                # STEP 3: Validate data quality - RELAXED THRESHOLDS FOR TRAINING
                from data_processing.unified_data_loader import validate_data_quality
                quality = validate_data_quality(df, symbol, tf)
                logger.info(f"Validated {tf}: quality_score={quality.get('data_quality_score'):.1f}")
                # REDUCED threshold from 60 to 30 for training - allow more data through
                if quality.get('data_quality_score', 0) < 30:
                    logger.warning(f"Skipping {tf} due to very low data quality")
                    return tf, None
                if df is not None and not df.empty:
                     logger.info(f"✅ Loaded {tf}: {len(df)} rows")
                     return tf, df
                else:
                    logger.warning(f"❌ No data for {tf}")
                    return tf, None
            except Exception as e:
                logger.error(f"Lỗi loading {tf}: {e}")                
                return tf, None
                
        from ai_optimizer.unified_resource_manager import get_resource_manager

        _resource_manager = get_resource_manager()
        max_workers = _resource_manager.get_optimal_workers('processing')
        logger.info(f"🔄 DataLoader: sử dụng {max_workers} workers cho parallel loading")

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(load_single_timeframe, tf): tf for tf in timeframes}

            
            # FIXED: Add better error handling and timeout per future
            completed_count = 0
            total_timeframes = len(timeframes)
              # Add timeout exception handling to prevent hanging
            try:
                for future in as_completed(futures, timeout=1800):  # Increased to 30 minutes
                    try:
                        tf = futures[future]
                        logger.info(f"🔄 Processing result for {tf}...")
                        
                        tf_result, df = future.result(timeout=600)  # 10 min timeout per timeframe
                        completed_count += 1
                        
                        if df is not None:
                            data[tf_result] = df
                            logger.info(f"✅ Successfully loaded {tf_result}: {len(df)} rows ({completed_count}/{total_timeframes})")
                        else:
                            logger.warning(f"⚠️ No data returned for {tf_result} ({completed_count}/{total_timeframes})")
                            
                    except Exception as e:
                        tf = futures.get(future, 'unknown')
                        completed_count += 1
                        logger.error(f"❌ Future execution failed for {tf}: {e} ({completed_count}/{total_timeframes})")
                        import traceback
                        logger.error(traceback.format_exc())
                        
            except TimeoutError:
                logger.error(f"❌ Parallel loading timed out after 30 minutes. Completed: {completed_count}/{total_timeframes}")
                # Cancel remaining futures to prevent hang
                for future in futures:
                    if not future.done():
                        future.cancel()
                        
            except Exception as e:
                logger.error(f"❌ Parallel loading failed: {e}")
                # Cancel remaining futures
                for future in futures:
                    if not future.done():
                        future.cancel()
                    
            logger.info(f"📊 Parallel loading completed: {completed_count}/{len(timeframes)} timeframes processed")
    else:
        logger.info(f"📈 Sequential data loading: {len(timeframes)} timeframes")
        for tf in timeframes:
            logger.info(f"🔄 Loading timeframe {tf}...")
            try:
                df = loader.load_and_process_data(symbol, tf, **valid_kwargs)                # STEP 2: Skip heavy sentiment processing during training to avoid timeout
                df['sentiment_score'] = 0.0  # Default neutral sentiment for training
                if kwargs.get('include_sentiment', False) and kwargs.get('training_mode') != 'quick':
                    try:
                        from data_sources.news_manager import NewsManager
                        news_mgr = NewsManager()
                        sent = news_mgr.get_sentiment_analysis(days=min(7, loader.mode_config['days']))  # Limit to 7 days max
                        # Attach average sentiment score
                        avg_sent = 0.0
                        dist = sent.get('sentiment_distribution', {})
                        total = sent.get('total_articles', 0)
                        if total and dist:
                            avg_sent = sum(v['average_score']*v['count'] for v in dist.values())/total
                        df['sentiment_score'] = avg_sent
                        logger.info(f"📰 Added sentiment for {tf}: score={avg_sent:.3f}")
                    except Exception as e:
                        logger.warning(f"⚠️ Sentiment analysis failed for {tf}: {e}")
                        df['sentiment_score'] = 0.0
                # STEP 3: Validate data quality - RELAXED THRESHOLDS FOR TRAINING
                from data_processing.unified_data_loader import validate_data_quality
                quality = validate_data_quality(df, symbol, tf)
                logger.info(f"Validated {tf}: quality_score={quality.get('data_quality_score'):.1f}")
                if quality.get('data_quality_score', 0) < 30:
                    logger.warning(f"Skipping {tf} due to very low data quality")
                    continue
                if df is not None and not df.empty:
                     data[tf] = df
                     logger.info(f"✅ Loaded {tf}: {len(df)} rows")
                else:
                    logger.warning(f"❌ No data for {tf}")
            except Exception as e:
                logger.error(f"Lỗi loading {tf}: {e}")

    return data

def validate_data_quality(df: pd.DataFrame, symbol: str, timeframe: str) -> Dict[str, Any]:
    """
    Kiểm tra chất lượng dữ liệu
    """
    try:
        validation_results = {
            'symbol': symbol,
            'timeframe': timeframe,
            'total_rows': len(df),
            'total_columns': len(df.columns),
            'missing_data_pct': (df.isnull().sum().sum() / (len(df) * len(df.columns))) * 100,
            'duplicate_rows': df.duplicated().sum(),
            'data_quality_score': 0,
            'issues': [],
            'timestamp': datetime.now()
        }
        
        # Check for basic OHLCV columns
        required_cols = ['open', 'high', 'low', 'close', 'volume']
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            validation_results['issues'].append(f"Missing columns: {missing_cols}")
        
        # Check for data consistency
        if 'high' in df.columns and 'low' in df.columns:
            invalid_ranges = (df['high'] < df['low']).sum()
            if invalid_ranges > 0:
                validation_results['issues'].append(f"Invalid high/low ranges: {invalid_ranges}")
        
        # Check for extreme outliers
        if 'close' in df.columns:
            q1 = df['close'].quantile(0.25)
            q3 = df['close'].quantile(0.75)
            iqr = q3 - q1
            outliers = ((df['close'] < (q1 - 1.5 * iqr)) | (df['close'] > (q3 + 1.5 * iqr))).sum()
            validation_results['outliers'] = outliers
            
            if outliers > len(df) * 0.05:  # More than 5% outliers
                validation_results['issues'].append(f"Excessive outliers: {outliers}")
        
        # Calculate quality score
        base_score = 100
        base_score -= validation_results['missing_data_pct']
        base_score -= (validation_results['duplicate_rows'] / len(df)) * 20
        base_score -= len(validation_results['issues']) * 10
        
        validation_results['data_quality_score'] = max(0, min(100, base_score))
        
        # Log results
        if validation_results['data_quality_score'] >= 80:
            logger.info(f"✅ Data quality good: {validation_results['data_quality_score']:.1f}/100")
        elif validation_results['data_quality_score'] >= 60:
            logger.warning(f"⚠️ Data quality moderate: {validation_results['data_quality_score']:.1f}/100")
        else:
            logger.error(f"❌ Data quality poor: {validation_results['data_quality_score']:.1f}/100")
        
        return validation_results
        
    except Exception as e:
        logger.error(f"Lỗi validate_data_quality: {e}")
        return {'error': str(e), 'symbol': symbol, 'timeframe': timeframe}

def auto_data_refresh(symbols: List[str], timeframes: List[str], 
                     max_age_hours: int = 1) -> Dict[str, Any]:
    """
    Tự động refresh dữ liệu nếu cũ
    """
    refresh_results = {
        'refreshed': [],
        'skipped': [],
        'errors': [],
        'timestamp': datetime.now()
    }
    
    for symbol in symbols:
        for timeframe in timeframes:
            try:
                file_path = unified_loader._get_file_path(symbol, timeframe)
                
                # Check if refresh needed
                if os.path.exists(file_path):
                    file_age = datetime.now() - datetime.fromtimestamp(os.path.getmtime(file_path))
                    if file_age.total_seconds() / 3600 < max_age_hours:
                        refresh_results['skipped'].append(f"{symbol}@{timeframe}")
                        continue
                
                # Refresh data
                logger.info(f"🔄 Refreshing {symbol}@{timeframe}")
                df = unified_loader.update_data(symbol, timeframe)
                
                if df is not None and not df.empty:
                    refresh_results['refreshed'].append(f"{symbol}@{timeframe}")
                    logger.info(f"✅ Refreshed {symbol}@{timeframe}: {len(df)} rows")
                else:
                    refresh_results['errors'].append(f"{symbol}@{timeframe}: No data")
                    
            except Exception as e:
                error_msg = f"{symbol}@{timeframe}: {str(e)}"
                refresh_results['errors'].append(error_msg)
                logger.error(f"Lỗi refresh {symbol}@{timeframe}: {e}")
    
    logger.info(f"Data refresh completed: {len(refresh_results['refreshed'])} refreshed, "               f"{len(refresh_results['skipped'])} skipped, {len(refresh_results['errors'])} errors")
    
    return refresh_results

# Main exports
