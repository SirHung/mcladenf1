# data_processing/unified_data_validator.py
"""
Unified Data Validation Module
Consolidates the three separate validation functions into a comprehensive validation framework:
1. data_processing/data_validator.py - validate_data() [timestamp/timeframe validation]
2. ai_models/trainer_utils.py - validate_data() [ML training validation]  
3. data_processing/unified_data_loader.py - validate_data_quality() [quality assessment]

This module eliminates redundancy while maintaining backward compatibility.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from collections import Counter
from datetime import datetime, timezone, timedelta
from dataclasses import dataclass
from config.logging_config import get_logger
from data_processing.unified_timestamp_utils import timestamp_utils

logger = get_logger('unified_data_validator')

@dataclass
class ValidationConfig:
    """Configuration for data validation"""
    # Training validation settings - REDUCED for graceful degradation
    min_total_samples: int = 50     # Reduced from 20 to be more flexible
    min_samples_per_class: int = 10  # Reduced from 5 for better class balance
    min_classes: int = 2
    
    # Quality validation settings  
    max_missing_data_pct: float = 15.0   # Increased tolerance from 10%
    max_duplicate_pct: float = 8.0       # Increased tolerance from 5%
    max_outlier_pct: float = 10.0        # Increased tolerance from 5%
    min_quality_score: float = 50.0      # Reduced from 60 for graceful degradation
    
    # Timestamp validation settings
    validate_continuity: bool = True
    clean_invalid_values: bool = True
    set_timestamp_index: bool = False

@dataclass 
class ValidationResult:
    """Unified validation result structure"""
    # Core validation status
    is_valid: bool = False
    validation_type: str = ""
    
    # Processed data
    cleaned_data: Optional[pd.DataFrame] = None
    
    # Detailed results
    timestamp_validation: Dict[str, Any] = None
    training_validation: Dict[str, Any] = None  
    quality_validation: Dict[str, Any] = None
    
    # Issues and scores
    issues: List[str] = None
    quality_score: float = 0.0
    
    # Backward compatibility
    is_continuous: Optional[bool] = None  # For data_validator compatibility
    
    def __post_init__(self):
        if self.issues is None:
            self.issues = []
        if self.timestamp_validation is None:
            self.timestamp_validation = {}
        if self.training_validation is None:
            self.training_validation = {}
        if self.quality_validation is None:
            self.quality_validation = {}

class UnifiedDataValidator:
    """Unified data validator combining all validation approaches"""
    
    def __init__(self, config: Optional[ValidationConfig] = None):
        self.config = config or ValidationConfig()
        
    def validate_comprehensive(self, 
                             df: pd.DataFrame, 
                             symbol: str = None,
                             timeframe: str = None, 
                             validation_types: List[str] = None) -> ValidationResult:        
        """
        Comprehensive validation combining all approaches
        validation_types: List of ['timestamp', 'training', 'quality', 'nan_safety']
        """
        if validation_types is None:
            validation_types = ['nan_safety', 'timestamp', 'quality']  # Include nan_safety by default
            
        result = ValidationResult(
            cleaned_data=df.copy(),
            validation_type=f"comprehensive({','.join(validation_types)})"
        )
        
        all_valid = True
        
        # 0. NaN safety validation (NEW - prevents conversion errors)
        if 'nan_safety' in validation_types:
            try:
                nan_safety_result = self._validate_nan_safety(result.cleaned_data)
                result.nan_safety_validation = nan_safety_result
                result.cleaned_data = nan_safety_result.get('cleaned_data', result.cleaned_data)
                
                if not nan_safety_result.get('is_valid', False):
                    all_valid = False
                    result.issues.extend(nan_safety_result.get('issues', []))
                    
            except Exception as e:
                logger.error(f"NaN safety validation failed: {e}")
                result.issues.append(f"NaN safety validation error: {e}")
                all_valid = False
        
        # 1. Timestamp validation (from data_validator.py)
        if 'timestamp' in validation_types and timeframe:
            try:
                timestamp_result = self._validate_timestamp_structure(result.cleaned_data, timeframe)
                result.timestamp_validation = timestamp_result
                result.cleaned_data = timestamp_result.get('cleaned_data', result.cleaned_data)
                result.is_continuous = timestamp_result.get('is_continuous', None)
                
                if not timestamp_result.get('is_valid', False):
                    all_valid = False
                    result.issues.extend(timestamp_result.get('issues', []))
                    
            except Exception as e:
                logger.error(f"Timestamp validation failed: {e}")
                result.issues.append(f"Timestamp validation error: {e}")
                all_valid = False
        
        # 2. Training validation (from trainer_utils.py)  
        if 'training' in validation_types:
            try:
                training_result = self._validate_training_data(result.cleaned_data)
                result.training_validation = training_result
                
                if not training_result.get('is_valid', False):
                    all_valid = False
                    result.issues.extend(training_result.get('issues', []))
                    
            except Exception as e:
                logger.error(f"Training validation failed: {e}")
                result.issues.append(f"Training validation error: {e}")
                all_valid = False
          # 3. Quality validation (from unified_data_loader.py)
        if 'quality' in validation_types:
            try:
                quality_result = self._validate_data_quality(result.cleaned_data, symbol, timeframe)
                result.quality_validation = quality_result
                result.quality_score = quality_result.get('data_quality_score', 0.0)
                
                if result.quality_score < self.config.min_quality_score:
                    all_valid = False
                    result.issues.append(f"Quality score too low: {result.quality_score:.1f}")
                
                result.issues.extend(quality_result.get('issues', []))
                
            except Exception as e:
                logger.error(f"Quality validation failed: {e}")
                result.issues.append(f"Quality validation error: {e}")
                all_valid = False
        
        result.is_valid = all_valid 
        
        # Log summary
        if result.is_valid:
            logger.info(f"✅ Comprehensive validation passed - Score: {result.quality_score:.1f}")
        else:
            logger.warning(f"⚠️ Comprehensive validation failed - Issues: {len(result.issues)}")
            
        return result
        
    def _validate_timestamp_structure(self, df: pd.DataFrame, timeframe: str) -> Dict[str, Any]:
        """Timestamp validation logic from data_validator.py"""
        result = {
            'is_valid': False,
            'is_continuous': True,
            'missing_count': 0,
            'issues': [],
            'cleaned_data': df.copy()
        }
        
        try:
            df_work = result['cleaned_data']
            
            # Use unified timestamp utilities to ensure proper timestamp column
            df_work = timestamp_utils.ensure_timestamp_column(
                df_work, 
                preferred_column='timestamp', 
                fallback_columns=['close_time', 'time']
            )
            
            # Clean timestamp data using unified utilities
            df_work, cleaning_stats = timestamp_utils.clean_timestamp_data(
                df_work, 
                timestamp_col='timestamp',
                remove_duplicates=True,
                sort_data=True,
                drop_invalid=True
            )
            
            # Report cleaning results
            if cleaning_stats['invalid_timestamps_removed'] > 0 or cleaning_stats['duplicates_removed'] > 0:
                total_removed = cleaning_stats['invalid_timestamps_removed'] + cleaning_stats['duplicates_removed']
                result['issues'].append(f"Removed {total_removed} rows (invalid/duplicate timestamps)")
            
            if df_work.empty:
                result['issues'].append("No valid data after timestamp cleaning")
                return result
              # Clean invalid OHLCV values if requested
            if self.config.clean_invalid_values:
                for col in ('open', 'high', 'low', 'close', 'volume'):
                    if col in df_work.columns:
                        invalid_count = (df_work[col] <= 0).sum()
                        if invalid_count > 0:
                            df_work = df_work[df_work[col] > 0]
                            result['issues'].append(f"Removed {invalid_count} rows with invalid {col} values")
            
            # Check continuity based on timeframe using unified utilities
            if self.config.validate_continuity and timeframe:
                continuity_result = timestamp_utils.check_timestamp_continuity(
                    df_work, timeframe, timestamp_col='timestamp'
                )
                result['missing_count'] = continuity_result['missing_count']
                result['is_continuous'] = continuity_result['is_continuous']
                
                if continuity_result['missing_count'] > 0:
                    result['issues'].append(f"{continuity_result['missing_count']} missing intervals in '{timeframe}' timeframe")
                
                # Add any issues from continuity check
                result['issues'].extend(continuity_result.get('issues', []))
            
            # Add return calculation
            if 'close' in df_work.columns and 'return' not in df_work.columns:
                df_work['return'] = df_work['close'].pct_change().fillna(0.0)
            
            # Set timestamp as index if requested
            if self.config.set_timestamp_index and 'timestamp' in df_work.columns:
                df_work.set_index('timestamp', inplace=True)
            
            result['cleaned_data'] = df_work
            result['is_valid'] = True
            
        except Exception as e:
            result['issues'].append(f"Timestamp validation error: {e}")
            
        return result

    def _validate_training_data(self, df: pd.DataFrame) -> Dict[str, Any]:
        """Training validation logic from trainer_utils.py"""
        result = {
            'is_valid': False,
            'sample_count': len(df),
            'class_info': {},
            'issues': []
        }
        
        try:
            # Basic sample count validation
            if len(df) < self.config.min_total_samples:
                result['issues'].append(f"Insufficient samples: {len(df)} < {self.config.min_total_samples}")
                return result
            
            # Try to find target/label column for class validation
            target_col = None
            for col_name in ['target', 'label', 'y']:
                if col_name in df.columns:
                    target_col = col_name
                    break
            
            if target_col is not None:
                y = df[target_col].dropna()
                
                # Class distribution validation
                unique_labels = y.unique()
                if len(unique_labels) < self.config.min_classes:
                    result['issues'].append(f"Insufficient classes: {len(unique_labels)} < {self.config.min_classes}")
                    return result
                
                # Minimum samples per class validation
                label_counts = Counter(y)
                min_count = min(label_counts.values())
                if min_count < self.config.min_samples_per_class:
                    result['issues'].append(f"Insufficient samples per class: {min_count} < {self.config.min_samples_per_class}")
                    return result
                
                result['class_info'] = {
                    'unique_classes': len(unique_labels),
                    'class_distribution': dict(label_counts),
                    'min_samples_per_class': min_count,
                    'target_column': target_col
                }
            else:
                # No target column found - basic validation only
                result['class_info'] = {'target_column': None, 'note': 'No target column found'}
            
            result['is_valid'] = True
            
        except Exception as e:
            result['issues'].append(f"Training validation error: {e}")
            
        return result
    
    def _validate_data_quality(self, df: pd.DataFrame, symbol: str = None, timeframe: str = None) -> Dict[str, Any]:
        """Quality validation logic from unified_data_loader.py"""
        result = {
            'symbol': symbol,
            'timeframe': timeframe,
            'total_rows': len(df),
            'total_columns': len(df.columns),
            'missing_data_pct': 0.0,
            'duplicate_rows': 0,
            'data_quality_score': 0.0,
            'issues': [],
            'outliers': 0,
            'timestamp': datetime.now()
        }
        
        try:
            # Missing data percentage
            if len(df) > 0 and len(df.columns) > 0:
                total_cells = len(df) * len(df.columns)
                missing_cells = df.isnull().sum().sum()
                result['missing_data_pct'] = (missing_cells / total_cells) * 100
            
            # Duplicate rows
            result['duplicate_rows'] = df.duplicated().sum()
            
            # Required columns check
            required_cols = ['open', 'high', 'low', 'close', 'volume']
            missing_cols = [col for col in required_cols if col not in df.columns]
            if missing_cols:
                result['issues'].append(f"Missing required columns: {missing_cols}")
            
            # Data consistency checks
            if 'high' in df.columns and 'low' in df.columns:
                invalid_ranges = (df['high'] < df['low']).sum()
                if invalid_ranges > 0:
                    result['issues'].append(f"Invalid high/low ranges: {invalid_ranges}")
            
            # Outlier detection
            if 'close' in df.columns and len(df) > 10:
                try:
                    q1 = df['close'].quantile(0.25)
                    q3 = df['close'].quantile(0.75)
                    iqr = q3 - q1
                    outliers = ((df['close'] < (q1 - 1.5 * iqr)) | (df['close'] > (q3 + 1.5 * iqr))).sum()
                    result['outliers'] = outliers
                    
                    if outliers > len(df) * (self.config.max_outlier_pct / 100):
                        result['issues'].append(f"Excessive outliers: {outliers} ({outliers/len(df)*100:.1f}%)")
                except:
                    pass  # Skip outlier detection if it fails
            
            # Quality score calculation
            base_score = 100.0
            base_score -= min(result['missing_data_pct'], 50)  # Cap missing data penalty at 50
            base_score -= min((result['duplicate_rows'] / len(df)) * 20, 20)  # Cap duplicate penalty at 20
            base_score -= min(len(result['issues']) * 10, 30)  # Cap issues penalty at 30
            
            result['data_quality_score'] = max(0, min(100, base_score))
            
        except Exception as e:
            result['issues'].append(f"Quality validation error: {e}")
            
        return result

    def _validate_nan_safety(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        NaN safety validation to prevent conversion errors
        Addresses the "cannot convert the series to <class 'float'>" and "cannot convert float NaN to integer" errors
        """
        result = {
            'is_valid': False,
            'cleaned_data': df.copy(),
            'issues': [],
            'nan_stats': {},
            'conversion_tests': {}
        }
        
        try:
            df_work = result['cleaned_data']
            logger.debug("🔍 Running NaN safety validation...")
            
            # 1. Check for problematic NaN patterns in key columns
            ohlcv_cols = ['open', 'high', 'low', 'close', 'volume']
            existing_ohlcv = [col for col in ohlcv_cols if col in df_work.columns]
            
            if existing_ohlcv:
                for col in existing_ohlcv:
                    nan_count = df_work[col].isna().sum()
                    nan_pct = (nan_count / len(df_work)) * 100
                    result['nan_stats'][col] = {'count': nan_count, 'percentage': nan_pct}
                    
                    # Check for problematic NaN patterns
                    if nan_pct > 90:
                        result['issues'].append(f"Column '{col}' has {nan_pct:.1f}% NaN values")
                    
                    # Test if column can be safely converted to numeric
                    try:
                        # Sample test for conversion safety
                        sample_data = df_work[col].dropna().head(100)
                        if len(sample_data) > 0:
                            pd.to_numeric(sample_data, errors='raise')
                            result['conversion_tests'][col] = 'safe'
                        else:
                            result['conversion_tests'][col] = 'all_nan'
                            result['issues'].append(f"Column '{col}' contains only NaN values")
                    except (ValueError, TypeError) as e:
                        result['conversion_tests'][col] = f'unsafe: {str(e)[:50]}'
                        result['issues'].append(f"Column '{col}' has unsafe conversion: {str(e)[:50]}")
                        
                        # Try to clean the problematic column
                        try:
                            df_work[col] = pd.to_numeric(df_work[col], errors='coerce')
                            logger.info(f"Cleaned problematic column '{col}' using coerce conversion")
                        except Exception as clean_error:
                            logger.warning(f"Failed to clean column '{col}': {clean_error}")
            
            # 2. Check for infinite values that can cause conversion issues
            numeric_columns = df_work.select_dtypes(include=[np.number]).columns
            infinite_counts = {}
            
            for col in numeric_columns:
                inf_count = np.isinf(df_work[col]).sum()
                if inf_count > 0:
                    infinite_counts[col] = inf_count
                    # Replace infinite values with NaN for safer handling
                    df_work[col] = df_work[col].replace([np.inf, -np.inf], np.nan)
                    
            if infinite_counts:
                result['issues'].append(f"Replaced infinite values in columns: {list(infinite_counts.keys())}")
                result['infinite_replaced'] = infinite_counts
            
            # 3. Ensure OHLCV columns have consistent data types
            for col in existing_ohlcv:
                if col in df_work.columns:
                    try:
                        # Ensure the column is numeric and handle NaN appropriately
                        df_work[col] = pd.to_numeric(df_work[col], errors='coerce')
                        
                        # For volume, ensure non-negative values
                        if col == 'volume':
                            df_work[col] = df_work[col].abs()
                            
                        # Fill remaining NaN values with safe defaults
                        if df_work[col].isna().any():
                            if col == 'volume':
                                df_work[col] = df_work[col].fillna(0)
                            else:
                                # For price columns, use forward/backward fill, then mean
                                df_work[col] = df_work[col].fillna(method='ffill').fillna(method='bfill')
                                if df_work[col].isna().any():
                                    df_work[col] = df_work[col].fillna(df_work[col].mean())
                                    
                    except Exception as e:
                        result['issues'].append(f"Failed to clean column '{col}': {str(e)}")
            
            # 4. Final validation - ensure no remaining problematic NaN patterns
            final_issues = []
            for col in existing_ohlcv:
                if col in df_work.columns:
                    remaining_nan = df_work[col].isna().sum()
                    if remaining_nan > len(df_work) * 0.5:  # More than 50% NaN
                        final_issues.append(f"Column '{col}' still has {remaining_nan} NaN values after cleaning")
            
            if final_issues:
                result['issues'].extend(final_issues)
            else:
                result['is_valid'] = True
                
            result['cleaned_data'] = df_work
            
            # Log summary
            if result['is_valid']:
                logger.debug("✅ NaN safety validation passed")
            else:
                logger.warning(f"⚠️ NaN safety validation found {len(result['issues'])} issues")
                
        except Exception as e:
            result['issues'].append(f"NaN safety validation error: {e}")
            logger.error(f"NaN safety validation failed: {e}")
            
        return result

    def validate_for_stratified_split(self, y: pd.Series, min_samples_per_class: int = 2) -> Tuple[bool, str]:
        """
        FUNCTION DUY NHẤT thực sự cần thiết: Kiểm tra xem data có thể dùng stratified split không
        
        Returns:
            (can_stratify: bool, reason: str)
        """
        try:
            # Kiểm tra số lượng class
            unique_classes = y.nunique()
            if unique_classes <= 1:
                return False, f"Only {unique_classes} class found - cannot stratify"
            
            # Kiểm tra số lượng sample trong mỗi class
            class_counts = y.value_counts()
            min_class_size = class_counts.min()
            
            if min_class_size < min_samples_per_class:
                return False, f"Minimum class has only {min_class_size} samples (need >= {min_samples_per_class})"
            
            # Tất cả điều kiện OK
            return True, f"Ready for stratified split: {unique_classes} classes, min_size={min_class_size}"
            
        except Exception as e:
            return False, f"Validation error: {e}"

    def get_class_balance_info(self, y: pd.Series) -> Dict[str, Any]:
        """
        Function thứ 2 thực sự cần thiết: Lấy thông tin class balance để tính toán parameters
        
        Returns:
            Dict với thông tin class distribution và balance ratio
        """
        try:
            if hasattr(y, 'value_counts') and y.nunique() > 1:
                class_counts = y.value_counts()
                balance_info = {
                    'unique_classes': y.nunique(),
                    'class_counts': dict(class_counts),
                    'min_class_size': class_counts.min(),
                    'max_class_size': class_counts.max(),
                    'imbalance_ratio': class_counts.max() / class_counts.min(),
                    'total_samples': len(y)
                }
            else:
                balance_info = {
                    'unique_classes': y.nunique() if hasattr(y, 'nunique') else 0,
                    'class_counts': {},
                    'min_class_size': 0,
                    'max_class_size': len(y) if y is not None else 0,
                    'imbalance_ratio': 1.0,
                    'total_samples': len(y) if y is not None else 0
                }
            
            return balance_info
            
        except Exception as e:
            logger.error(f"Error getting class balance info: {e}")
            return {
                'unique_classes': 0,
                'class_counts': {},
                'min_class_size': 0,
                'max_class_size': 0,
                'imbalance_ratio': 1.0,
                'total_samples': 0,
                'error': str(e)
            }

# Global instance for easy access
unified_validator = UnifiedDataValidator()

# Export main classes and functions
__all__ = [
    'UnifiedDataValidator', 'ValidationConfig', 'ValidationResult', 'unified_validator'
]
