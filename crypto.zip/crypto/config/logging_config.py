# config/logging_config.py
"""
Cấu hình logging tập trung cho toàn bộ ứng dụng crypto trading
Loại bỏ tất cả các cấu hình logging trùng lặp
"""

import os
import sys
import logging
import warnings
from datetime import datetime
from config import settings

# Suppress all warnings before any other imports
warnings.filterwarnings("ignore")
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)

# Suppress specific framework warnings
warnings.filterwarnings("ignore", message=".*missing ScriptRunContext.*")
warnings.filterwarnings("ignore", message=".*Thread.*missing ScriptRunContext.*")
warnings.filterwarnings("ignore", message=".*MessageFactory.*")
warnings.filterwarnings("ignore", message=".*tensorboard.*")
warnings.filterwarnings("ignore", message=".*Numba needs NumPy.*")
warnings.filterwarnings("ignore", message=".*torch.*")
warnings.filterwarnings("ignore", message=".*tensorflow.*")


def setup_unified_logging(log_level=logging.INFO, enable_file_log=True):
    """
    Thiết lập cấu hình logging tập trung cho toàn bộ ứng dụng
    
    Args:
        log_level: Mức log (logging.INFO, logging.WARNING, logging.ERROR)
        enable_file_log: Có ghi log ra file hay không
        
    Returns:
        logger: Main application logger
    """
    # Tạo thư mục logs nếu chưa tồn tại
    log_dir = getattr(settings, 'LOG_DIR', 'logs')
    os.makedirs(log_dir, exist_ok=True)
    
    # Clear any existing handlers to avoid duplication
    root_logger = logging.getLogger()
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    
    # Format logging
    log_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    formatter = logging.Formatter(log_format)
    
    # Handlers list
    handlers = []
      # Console handler - Sử dụng formatter không có emoji cho Windows
    console_handler = logging.StreamHandler(sys.stdout)
    # Tạo formatter đơn giản hơn cho console trên Windows
    if sys.platform.startswith('win'):
        console_format = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        console_formatter = logging.Formatter(console_format)
    else:
        console_formatter = formatter
    console_handler.setFormatter(console_formatter)
    console_handler.setLevel(log_level)
    handlers.append(console_handler)
    
    # File handler (nếu enabled)
    if enable_file_log:
        log_filename = os.path.join(log_dir, f"crypto_app_{datetime.now().strftime('%Y%m%d')}.log")
        file_handler = logging.FileHandler(log_filename, encoding='utf-8')
        file_handler.setFormatter(formatter)
        file_handler.setLevel(log_level)
        handlers.append(file_handler)
    
    # Configure root logger
    logging.basicConfig(
        level=log_level,
        format=log_format,
        handlers=handlers,
        force=True
    )
    
    # Suppress noisy external libraries
    noisy_loggers = [
        'streamlit.runtime.scriptrunner_utils.script_run_context',
        'matplotlib', 'PIL', 'fontTools', 'numexpr', 
        'lightgbm', 'optuna', 'xgboost', 'catboost', 
        'sklearn', 'joblib', 'urllib3', 'asyncio', 
        'tensorflow', 'torch', 'GPUtil'
    ]
    
    for logger_name in noisy_loggers:
        logging.getLogger(logger_name).setLevel(logging.ERROR)
    
    # Create main app logger
    app_logger = logging.getLogger('CryptoApp')
    app_logger.setLevel(log_level)
    
    app_logger.info("=== Unified Logging System Initialized ===")
    app_logger.info(f"Log level: {logging.getLevelName(log_level)}")
    app_logger.info(f"File logging: {'Enabled' if enable_file_log else 'Disabled'}")
    
    return app_logger


def get_logger(name=None):
    """
    Lấy logger instance cho module cụ thể
    
    Args:
        name: Tên module hoặc None để lấy main app logger
        
    Returns:
        logger: Logger instance
    """
    if name is None:
        return logging.getLogger('CryptoApp')
    return logging.getLogger(f'CryptoApp.{name}')


def log_metrics(interval: str, metrics: dict, logger=None):
    """
    Log training metrics với timestamp
    
    Args:
        interval: Tên interval/timeframe
        metrics: Dictionary chứa metrics
        logger: Logger instance (optional)
    """
    if logger is None:
        logger = get_logger('metrics')
        
    timestamp = datetime.now(settings.TIMEZONE).strftime("%Y-%m-%d %H:%M:%S %Z")
    metrics_str = ", ".join([f"{k}={v:.4f}" for k, v in metrics.items()])
    logger.info(f"[{timestamp}] Interval {interval} - {metrics_str}")


# Function data logging has been permanently disabled to reduce spam


def apply_compatibility_fixes():
    """Apply framework compatibility fixes"""
    # Suppress logging from problematic modules
    for logger_name in [
        'tensorflow', 'tensorboard', 'streamlit.runtime.scriptrunner_utils.script_run_context',
        'streamlit.runtime.state.session_state_proxy', 'sklearn', 'imbalanced_learn',
        'torch', 'numba', 'matplotlib', 'lightgbm', 'lgb'
    ]:
        logging.getLogger(logger_name).setLevel(logging.ERROR)
    
    # Handle sklearn compatibility
    try:
        import sklearn.utils._tags as tags_module
        if not hasattr(tags_module, '_safe_tags'):
            def _safe_tags(estimator, key=None):
                return {'no_validation': False, 'poor_score': False, 'requires_fit': True}
            tags_module._safe_tags = _safe_tags
    except:
        pass

# Apply fixes on import
apply_compatibility_fixes()
