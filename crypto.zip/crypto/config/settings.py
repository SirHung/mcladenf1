import os
import pytz

# Comprehensive environment setup for all frameworks
os.environ.update({
    'TF_ENABLE_ONEDNN_OPTS': '0',
    'TF_CPP_MIN_LOG_LEVEL': '3',  # Suppress TensorFlow logs
    'PYTHONWARNINGS': 'ignore',
    'STREAMLIT_BROWSER_GATHER_USAGE_STATS': 'false',
    'STREAMLIT_SERVER_FILE_WATCHER_TYPE': 'none',
    'STREAMLIT_SERVER_WATCH_FILE_SYSTEM': 'false',
    'PYTORCH_DISABLE_PER_OP_PROFILING': '1',
    'OMP_NUM_THREADS': '2',  # Limit OpenMP threads
    'LIGHTGBM_VERBOSITY': '-1',  # Suppress LightGBM warnings 
    'LGB_VERBOSITY': '-1'
})

# Thư mục gốc của dự án
PROJECT_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_DIR = os.path.dirname(PROJECT_DIR)
MODEL_DIR = os.path.join(BASE_DIR, "models")
if not os.path.exists(MODEL_DIR):
    os.makedirs(MODEL_DIR)
# Thư mục chứa dữ liệu lịch sử (.pkl.gz)
DATA_DIR = os.path.join(BASE_DIR, "data")
if not os.path.exists(DATA_DIR):
    os.makedirs(DATA_DIR)

# Số ngày lịch sử tối thiểu cần tải cho từng loại khung thời gian
# FIXED: Reduced excessive data requirements that were causing training to stop at 66.7%
HISTORY_REQUIREMENTS = {
    "5m": 60,    # 60 days (was 180) - 2 months sufficient for short-term patterns
    "15m": 90,   # 90 days (was 180) - 3 months for intraday analysis  
    "30m": 120,  # 120 days (was 180) - 4 months for medium-term patterns
    "1h": 180,   # 180 days (was 180) - 6 months for hourly analysis
    "4h": 365,   # 365 days (was 180) - 1 year for 4-hour patterns
    "12h": 500,  # 500 days (was 365) - ~16 months for longer patterns
    "1d": 1000,  # 1000 days (was 1800) - ~2.7 years instead of 5 years
    "1w": 2000   # 2000 days (was 3650) - ~5.5 years instead of 10 years
}

# Cấu hình API Binance
BINANCE_BASE_URL = "https://api.binance.com"
DEFAULT_QUOTE_BINANCE = "USDT"

# symbol mặc định khi khởi động chương trình
DEFAULT_symbol = "BTC"

# Múi giờ mặc định của chương trình (Việt Nam UTC+7)
TIMEZONE = pytz.timezone("Asia/Ho_Chi_Minh")

# Danh sách khung thời gian sử dụng cho mô hình ensemble
# EXPANDED: More comprehensive timeframe coverage for deep training
TIMEFRAMES = [
    "5m", "15m", "30m", "1h", "4h", "12h", "1d", "1w"
]

# Logging – thư mục log
LOG_DIR = os.path.join(BASE_DIR, "logs")
if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)
LOG_FILE = os.path.join(LOG_DIR, "app.log")

# API key cho dịch vụ tin tức (News API) – để trống nếu không dùng
NEWS_API_KEY = os.getenv('NEWS_API_KEY', '')
# Maximum proportion of RAM được phép sử dụng cho training (0<n<1)
MAX_RAM_UTIL = 0.95
# Tỷ lệ core CPU dùng cho training (0<n<=1)
CPU_UTIL_RATIO = 0.95
# Số luồng tối đa dùng cho đào tạo (VD: số CPU nhân với tỷ lệ CPU_UTIL_RATIO)
MAX_WORKERS = int(os.cpu_count() * CPU_UTIL_RATIO)
# Mức % CPU cho phép sử dụng (trên 100% nếu có nhiều core)
MAX_CPU_PERCENT = int(CPU_UTIL_RATIO * 100)

# GPU Configuration
MAX_GPU_LOAD = 0.80
MIN_FREE_GPU_MEM = 0.15

# Model Training Configuration
OPTUNA_TRIALS = 30
CV_FOLDS = 3
MIN_SAMPLES_PER_CLASS = 5
MIN_TOTAL_SAMPLES = 20

