"""
Main App Module - Optimized Entry Point
Only contains main() function and essential imports
"""

# Import compatibility fixes FIRST
from config.logging_config import apply_compatibility_fixes
apply_compatibility_fixes()

# Import config to ensure environment variables are set
from config import settings

# CRITICAL: Set environment variables BEFORE any imports
import os
import warnings

import warnings

# Import LightGBM suppressor early
try:
    from utilities.lightgbm_suppressor import LightGBMSuppressor
    LightGBMSuppressor.suppress_all()
except Exception as e:
    print(f"Note: Could not load LightGBM suppressor: {e}")

# Suppress deprecation warnings from external libraries
warnings.filterwarnings('ignore', category=DeprecationWarning, module='feedparser')

# Comprehensive LightGBM warning suppression
warnings.filterwarnings('ignore', category=UserWarning, module='lightgbm')
warnings.filterwarnings('ignore', message='.*Stopped training because there are no more leaves.*')
warnings.filterwarnings('ignore', message='.*LightGBM.*')
warnings.filterwarnings('ignore', message='.*lgb.*')
warnings.filterwarnings('ignore', message='.*early stopping.*')
warnings.filterwarnings('ignore', message='.*no more leaves.*')

# Set LightGBM environment variables to suppress all output
os.environ['LIGHTGBM_VERBOSITY'] = '-1'
os.environ['LGB_VERBOSITY'] = '-1'

# Suppress Streamlit warnings at environment level
os.environ['STREAMLIT_BROWSER_GATHER_USAGE_STATS'] = 'false'
os.environ['STREAMLIT_SERVER_ENABLE_STATIC_SERVING'] = 'false'
os.environ['STREAMLIT_LOGGER_LEVEL'] = 'ERROR'

# FIX: Suppress PyTorch-Streamlit watcher conflicts
os.environ['STREAMLIT_SERVER_FILE_WATCHER_TYPE'] = 'none'
os.environ['STREAMLIT_SERVER_WATCH_FILE_SYSTEM'] = 'false'
os.environ['STREAMLIT_SERVER_DISABLE_WIDGET_STREAMING'] = 'true'
os.environ['STREAMLIT_SERVER_WATCH_MODULES'] = 'false'
os.environ['STREAMLIT_SERVER_RUN_ON_SAVE'] = 'false'

# Suppress PyTorch warnings that conflict with Streamlit - ENHANCED
os.environ['PYTORCH_DISABLE_PER_OP_PROFILING'] = '1'
os.environ['PYTHONWARNINGS'] = 'ignore::RuntimeWarning,ignore::UserWarning'
os.environ['TORCH_SHOW_CPP_STACKTRACES'] = '0'

# CRITICAL: Fix PyTorch-Streamlit path conflicts
import sys
try:
    import torch
    # Prevent PyTorch from interfering with Streamlit's file watching
    if hasattr(torch, '_classes'):
        # Mock the problematic __path__ attribute 
        class MockPath:
            def __getattr__(self, name):
                if name == '_path':
                    return []
                raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{name}'")
        
        torch._classes.__path__ = MockPath()
except Exception as e:
    pass  # Ignore if torch not available

# Advanced warning suppressor FIRST
import warnings
# Suppress all Streamlit warnings before any imports
warnings.filterwarnings("ignore", message=".*missing ScriptRunContext.*")
warnings.filterwarnings("ignore", message=".*Thread.*missing ScriptRunContext.*")
warnings.filterwarnings("ignore", message=".*ScriptRunContext.*")
warnings.filterwarnings("ignore", category=UserWarning, module="streamlit")

# FIX: Suppress PyTorch-Streamlit conflicts
warnings.filterwarnings("ignore", message=".*torch.classes.*")
warnings.filterwarnings("ignore", message=".*__path__._path.*")
warnings.filterwarnings("ignore", message=".*get_custom_class_python_wrapper.*")
warnings.filterwarnings("ignore", message=".*Tried to instantiate class.*")
warnings.filterwarnings("ignore", message=".*no running event loop.*")

# Create required directories if they don't exist
def ensure_directories():
    """Ensure all required directories exist"""
    directories = [
        settings.MODEL_DIR,
        settings.DATA_DIR,
        settings.LOG_DIR,
        os.path.join(settings.DATA_DIR, "unified_results"),
        os.path.join(settings.BASE_DIR, "cache"),
        os.path.join(settings.BASE_DIR, "cache", "shap"),
        os.path.join(settings.BASE_DIR, "checkpoints"),
        os.path.join(settings.BASE_DIR, "pipeline_results", "deployed_models")
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)

def main():
    """Main function - entry point of the application"""
    # Import streamlit FIRST
    import streamlit as st
    
    # CRITICAL: Set page config FIRST before any other Streamlit operations
    st.set_page_config(
        page_title="🚀 Crypto AI Trader - Enhanced",
        page_icon="🚀",
        layout="wide",  # Use full width
        initial_sidebar_state="expanded",
        menu_items={
            'About': "🚀 Crypto AI Trader - Hệ thống giao dịch crypto thông minh"
        }
    )
      # Enhanced CSS for full-width layout without any center constraints
    st.markdown("""
        <style>
        /* CRITICAL: Force full-width layout */
        .main .block-container {
            padding-top: 1rem;
            padding-bottom: 1rem;
            padding-left: 1rem;
            padding-right: 1rem;
            max-width: none !important;
            width: 100% !important;
        }
        
        /* Remove any width constraints */
        .stApp > .main {
            max-width: none !important;
            width: 100% !important;
        }
        
        /* Ensure content uses full width */
        .stApp .main > div {
            max-width: none !important;
            width: 100% !important;
        }
        
        /* Full width for all elements */
        .element-container {
            width: 100% !important;
            max-width: none !important;
        }
        
        /* Sidebar styling */
        .css-1d391kg {
            padding-top: 1rem;
        }
        
        /* Tab styling for better appearance */
        .stTabs [data-baseweb="tab-list"] {
            gap: 8px;
            width: 100%;
        }
        
        .stTabs [data-baseweb="tab"] {
            height: 50px;
            padding-left: 20px;
            padding-right: 20px;
            border-radius: 10px 10px 0px 0px;
            background-color: rgba(49, 51, 63, 0.2);
        }
        
        /* Tab content full width */
        .stTabs [data-baseweb="tab-panel"] {
            width: 100% !important;
            max-width: none !important;
        }
        
        .stTabs [aria-selected="true"] {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        /* Metrics styling */
        .metric-container {
            background-color: rgba(255, 255, 255, 0.05);
            padding: 10px;
            border-radius: 10px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        /* Button styling */
        .stButton > button {
            width: 100%;
            border-radius: 10px;
            border: none;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-weight: bold;
        }
        
        /* Progress bar styling */
        .stProgress .st-bo {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        /* Header styling */
        h1, h2, h3 {
            color: #ffffff;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        /* Data table styling */
        .dataframe {
            background-color: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
        }
        </style>
    """, unsafe_allow_html=True)
    
    # Initialize logger outside try block to ensure it's available in exception handling
    from config.logging_config import setup_unified_logging
    logger = setup_unified_logging()
    logger.info("Application starting with full-width layout...")
    
    try:
        # Ensure all required directories exist
        ensure_directories()

        # Suppress Streamlit logging
        import logging
        logging.getLogger("streamlit.runtime.scriptrunner_utils.script_run_context").setLevel(logging.ERROR)
        logging.getLogger("streamlit.runtime.state.session_state_proxy").setLevel(logging.ERROR)
        # Environment setup
        os.environ['OMP_NUM_THREADS'] = '2'
        os.environ['OPENBLAS_NUM_THREADS'] = '2'  
        os.environ['MKL_NUM_THREADS'] = '2'        
        os.environ['NUMEXPR_NUM_THREADS'] = '2'

        # Core imports        
        from ai_optimizer.unified_resource_manager import get_resource_manager
        from app_handlers import render_sidebar, show_startup_msg, initialize_session_state
        from app_handlers import (
            handle_trade_view, handle_technical_analysis, handle_news, handle_training,
             handle_training_with_mode, handle_training_results,
        )
        from utilities.zalo_sender  import ZaloSender
        # Resource manager initialization (monitoring auto-starts)
        get_resource_manager()  # Initialize singleton instance

        # CRITICAL: Initialize session state FIRST before any Streamlit operations
        initialize_session_state()
        # Setup UI components after session state is ready
        render_sidebar()  # Sidebar chỉ còn đồng hồ, giá coin, MetaAI, Fear&Greed
        show_startup_msg()

        # Import enhanced UI components
        from app_ui import render_main_tabs, render_training_tab_enhanced, render_quick_predict_tab
        from ai_models.long_term_forecast import handle_long_term_forecast
        # Create main tabs
        tabs = render_main_tabs()

        if tabs:
            # Trade View Tab
            with tabs['trade_view']:
                handle_trade_view()
            # Technical Analysis Tab  
            with tabs['technical_analysis']:
                handle_technical_analysis()
            # AI Training Tab (Enhanced)
            with tabs['ai_training']:
                # Lấy symbol/training_mode từ session_state hoặc mặc định
                symbol = getattr(st.session_state, 'sidebar_symbol', 'BTCUSDT')
                training_mode = getattr(st.session_state, 'training_mode', 'standard_7d')
                training_controls = render_training_tab_enhanced(symbol, training_mode)
                # Cập nhật lại session_state nếu user chọn mode mới
                if 'selected_training_mode' in training_controls:
                    st.session_state.training_mode = training_controls['selected_training_mode']
                if training_controls.get('start_training'):
                    st.session_state.training_in_progress = True
                    handle_training_with_mode(st.session_state.training_mode, training_controls)
                elif training_controls.get('stop_training'):
                    st.session_state.training_in_progress = False
                    st.success("🛑 Huấn luyện đã được dừng")
                elif training_controls.get('view_results'):
                    handle_training_results()            
            # News Tab
            with tabs['news']:
                handle_news()
            # Settings Tab (gom toàn bộ cài đặt hệ thống và Zalo)
            with tabs['settings']:
                col1, col2 = st.columns(2)
                with col1:
                    st.subheader("📱 Zalo")
                    ZaloSender()
                with col2:
                    st.subheader("⚙️ Cấu hình hệ thống")
                    st.write("Chức năng này hiện không khả dụng.")
                st.markdown("---")
                st.subheader("📈 Dự báo dài hạn")
                handle_long_term_forecast()
        else:
            # Fallback to old selectbox method
            choice = st.selectbox(
                "📑 Chọn chức năng",
                ["Trade View", "Phân tích kỹ thuật", "Tin tức", "Huấn luyện", "Gửi Zalo", "Cấu hình", "Dự báo dài hạn"],
                index=0
            )
            if choice == "Trade View":
                handle_trade_view()
            elif choice == "Phân tích kỹ thuật":
                handle_technical_analysis()
            elif choice == "Tin tức":
                handle_news()
            elif choice == "Huấn luyện":
                handle_training()
            elif choice == "Gửi Zalo":
                ZaloSender()
            elif choice == "Cấu hình":
                st.write("Chức năng này hiện không khả dụng.")
            elif choice == "Dự báo dài hạn":
                handle_long_term_forecast()
          # Initialize AI Parameter Calculator after all imports are loaded
        try:
            from ai_models.ai_parameters import get_parameter_calculator
            calculator = get_parameter_calculator()
            if calculator:
                os.environ['AI_PARAMETERS_ENABLED'] = 'true'
                logger.info("✅ AI Parameter Calculator initialized successfully")
            else:
                os.environ['AI_PARAMETERS_ENABLED'] = 'false'
                logger.warning("⚠️ AI Parameter Calculator not available")
        except Exception as e:
            os.environ['AI_PARAMETERS_ENABLED'] = 'false'
            logger.warning(f"⚠️ AI Parameter Calculator initialization failed: {e}")
    except Exception as e:
        import traceback
        import streamlit as st_error
        if 'st' in locals():
            st_error.error(f"Lỗi ứng dụng: {e}")
        logger.error(f"App error: {e}", exc_info=True)
        logger.error(traceback.format_exc())    
    finally:
        # Ensure cleanup happens even on error
        try:
            get_resource_manager().cleanup_resources(intensity='normal')
        except Exception as cleanup_e:
            print(f"Cleanup error: {cleanup_e}")
        
        # Force garbage collection
        import gc
        gc.collect()

if __name__ == "__main__":
    main()
