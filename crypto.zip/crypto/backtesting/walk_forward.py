# File: AI_Crypto_Project/backtesting/walk_forward.py

import pandas as pd
import numpy as np
# Use unified metrics instead of direct sklearn imports
from ai_models.unified_metrics import calculate_metrics_from_predictions

class WalkForwardBacktester:
    """
    Walk-forward backtest:
    - Train trên window_size mẫu
    - Test trên step_size mẫu kế tiếp
    - Lưu kết quả accuracy, f1 cho mỗi bước
    """

    def __init__(self, window_size: int = 500, step_size: int = 100):
        """
        :param window_size: số mẫu dùng để huấn luyện mỗi bước
        :param step_size: số mẫu dùng để kiểm thử mỗi bước
        """
        self.window_size = window_size
        self.step_size = step_size

    def run(self, model, X: pd.DataFrame, y: pd.Series) -> pd.DataFrame:
        """
        Chạy walk-forward với error handling cải thiện:
        :param model: mô hình sklearn (chưa fit)
        :param X: DataFrame feature toàn bộ chuỗi
        :param y: Series nhãn (0/1) tương ứng
        :return: DataFrame với các cột
                 ['train_start','train_end','test_end','accuracy','f1']
        """
        from config.logging_config import get_logger
        logger = get_logger('walk_forward')
        
        scores = []
        n = len(X)
        
        # Kiểm tra dữ liệu đầu vào
        if n < self.window_size + self.step_size:
            logger.warning(f"Insufficient data for backtest: {n} < {self.window_size + self.step_size}")
            return pd.DataFrame(columns=['train_start','train_end','test_end','accuracy','f1'])
        
        # Kiểm tra unique classes
        unique_classes = y.nunique()
        if unique_classes < 2:
            logger.warning(f"Insufficient classes for backtest: {unique_classes}")
            return pd.DataFrame(columns=['train_start','train_end','test_end','accuracy','f1'])
        
        # lặp qua các cửa sổ
        for start in range(0, n - self.window_size - self.step_size + 1, self.step_size):
            try:
                end_train = start + self.window_size
                end_test = end_train + self.step_size

                X_train = X.iloc[start:end_train]
                y_train = y.iloc[start:end_train]
                X_test  = X.iloc[end_train:end_test]
                y_test  = y.iloc[end_train:end_test]
                
                # Kiểm tra classes trong train set
                if y_train.nunique() < 2:
                    logger.warning(f"Skipping window {start}: insufficient classes in train set")
                    continue
                
                # Kiểm tra classes trong test set
                if y_test.nunique() < 1:
                    logger.warning(f"Skipping window {start}: no data in test set")
                    continue

                # Clone model để tránh conflict
                from sklearn.base import clone
                model_clone = clone(model)
                model_clone.fit(X_train, y_train)
                y_pred = model_clone.predict(X_test)

                # Use unified metrics instead of individual sklearn calls
                metrics = calculate_metrics_from_predictions(y_test.values, y_pred)
                acc = metrics['accuracy']
                f1 = metrics['f1']

                scores.append({
                    'train_start': start,
                    'train_end': end_train,
                    'test_end': end_test,
                    'accuracy': acc,
                    'f1': f1
                })
                
            except Exception as e:
                logger.warning(f"Backtest window {start} failed: {e}")
                continue

        if not scores:
            logger.warning("No successful backtest windows")
            return pd.DataFrame(columns=['train_start','train_end','test_end','accuracy','f1'])
            
        return pd.DataFrame(scores)
 