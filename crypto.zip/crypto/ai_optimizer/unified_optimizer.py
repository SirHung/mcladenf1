import numpy as np
import pandas as pd
from typing import Dict, Any, List
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, make_scorer
)
from sklearn.model_selection import TimeSeriesSplit, RandomizedSearchCV
from scipy.stats import ks_2samp
import shap
import itertools

# Configure logging
import logging
logger = logging.getLogger(__name__)

# Optional import for future advanced optimization
try:
    import optuna
    OPTUNA_AVAILABLE = True 
except ImportError:
    OPTUNA_AVAILABLE = False

class UnifiedOptimizer:
    """
    Unified optimizer combining AutoOptimizer and ThresholdOptimizer functionality.
    Handles model/timeframe selection and threshold optimization in one class.
    """

    def __init__(self, metrics: pd.DataFrame = None, default_metric: str = 'f1'):
        """
        Initialize with optional metrics DataFrame and default optimization metric.
        """
        self.default_metric = default_metric
        self.metrics = None
        
        if metrics is not None:
            self._process_metrics(metrics)
            
        # Metric function mapping
        self._metric_functions = {
            'accuracy': accuracy_score,
            'precision': precision_score,
            'recall': recall_score,
            'f1': f1_score
        }

    def _process_metrics(self, metrics: pd.DataFrame):
        """Process and validate metrics DataFrame"""
        self.metrics = metrics.copy()
        
        # Add fallback columns if missing
        for col in ('precision', 'recall', 'f1'):
            if col not in self.metrics.columns:
                self.metrics[col] = self.metrics['accuracy']
        
        # Validate required columns
        required = {'timeframe', 'model', 'accuracy', 'precision', 'recall', 'f1'}
        if not required.issubset(self.metrics.columns):
            missing = required - set(self.metrics.columns)
            raise ValueError(f"Missing required columns: {missing}")

    # === MODEL/TIMEFRAME OPTIMIZATION ===
    
    def get_best_configuration(self, metric: str = None) -> pd.Series:
        """Get the best model/timeframe combination"""
        if self.metrics is None:
            raise ValueError("No metrics data available. Load metrics first.")
        
        metric = metric or self.default_metric
        idx = self.metrics[metric].idxmax()
        return self.metrics.loc[idx, ['timeframe', 'model', metric]]

    def get_top_timeframes(self, n: int = 3, metric: str = None) -> List[str]:
        """Get top N timeframes by average metric performance"""
        if self.metrics is None:
            raise ValueError("No metrics data available")
        
        metric = metric or self.default_metric
        df = self.metrics.groupby('timeframe')[metric].mean().sort_values(ascending=False)
        return df.head(n).index.tolist()

    def get_top_models(self, n: int = 3, metric: str = None) -> List[str]:
        """Get top N models by average metric performance"""
        if self.metrics is None:
            raise ValueError("No metrics data available")
        
        metric = metric or self.default_metric
        df = self.metrics.groupby('model')[metric].mean().sort_values(ascending=False)
        return df.head(n).index.tolist()

    def recommend_configuration(self, metric: str = None) -> Dict[str, Any]:
        """Get comprehensive recommendations for best configuration"""
        metric = metric or self.default_metric
        best = self.get_best_configuration(metric)
        
        return {
            'best_timeframe': best['timeframe'],
            'best_model': best['model'],
            'best_score': float(best[metric]),
            'top_timeframes': self.get_top_timeframes(3, metric),
            'top_models': self.get_top_models(3, metric)
        }

    def filter_metrics(self, timeframes: List[str] = None, models: List[str] = None) -> pd.DataFrame:
        """Filter metrics by timeframes and/or models"""
        if self.metrics is None:
            raise ValueError("No metrics data available")
        
        df = self.metrics
        if timeframes is not None:
            df = df[df['timeframe'].isin(timeframes)]
        if models is not None:
            df = df[df['model'].isin(models)]
        return df.reset_index(drop=True)

    # === THRESHOLD OPTIMIZATION ===
    
    def optimize_threshold(self, y_true: np.ndarray, y_proba: np.ndarray, 
                          metric: str = None, thresholds: np.ndarray = None) -> Dict[str, Any]:
        """
        Find optimal threshold for binary classification.
        
        Args:
            y_true: True binary labels (0/1)
            y_proba: Predicted probabilities for positive class
            metric: Metric to optimize ('accuracy', 'precision', 'recall', 'f1', 'auc')
            thresholds: Array of thresholds to test (default: 101 values from 0 to 1)
        
        Returns:
            Dict with best_threshold, best_score, and scores DataFrame
        """
        metric = metric or self.default_metric
        
        if metric not in {'accuracy', 'precision', 'recall', 'f1', 'auc'}:
            raise ValueError(f"Unsupported metric '{metric}' for threshold optimization")
        
        if thresholds is None:
            thresholds = np.linspace(0.0, 1.0, 101)

        scores = []
        for threshold in thresholds:
            y_pred = (y_proba >= threshold).astype(int)
            
            if metric == 'auc':
                score = roc_auc_score(y_true, y_proba)
            else:
                # Handle edge cases for precision/recall
                if metric in {'precision', 'recall'} and y_pred.sum() == 0:
                    score = 0.0
                else:
                    score = self._metric_functions[metric](y_true, y_pred, zero_division=0)
            
            scores.append((threshold, score))

        df_scores = pd.DataFrame(scores, columns=['threshold', 'score'])
        best_idx = df_scores['score'].idxmax()
        
        return {
            'best_threshold': float(df_scores.loc[best_idx, 'threshold']),
            'best_score': float(df_scores.loc[best_idx, 'score']),
            'scores': df_scores
        }

    def apply_threshold(self, y_proba: np.ndarray, threshold: float) -> np.ndarray:
        """Apply threshold to convert probabilities to binary predictions"""
        return (y_proba >= threshold).astype(int)

    def compute_optimal_threshold(self, model, X: np.ndarray, y: np.ndarray, metric: str = None) -> float:
        """
        Compute optimal threshold for a trained model.
        
        Args:
            model: Trained classifier with predict_proba method
            X: Feature matrix
            y: True labels
            metric: Metric to optimize
        
        Returns:
            Optimal threshold value
        """
        metric = metric or self.default_metric
        n_classes = len(np.unique(y))
        
        if n_classes == 2:
            # Binary classification: find optimal threshold
            y_proba = model.predict_proba(X)[:, 1]
            result = self.optimize_threshold(y, y_proba, metric)
            return result['best_threshold']
        else:
            # Multiclass: no threshold optimization needed
            return 0.5

    # === CROSS-TIMEFRAME COMPARISON ===
    
    def _aggregate_predictions(self, df_low: pd.DataFrame, tf_high: str, 
                              pred_col: str = 'prediction', method: str = 'majority') -> pd.Series:
        """
        Aggregate low timeframe predictions to high timeframe.
        
        Args:
            df_low: DataFrame with timestamp and predictions
            tf_high: Target timeframe (e.g., '15T', '1H')
            pred_col: Column name for predictions
            method: Aggregation method ('majority', 'mean_thresh', 'max')
        
        Returns:
            Series of aggregated predictions
        """
        ser = df_low.set_index('timestamp')[pred_col]
        
        if method == 'majority':
            agg_fn = lambda x: 1 if x.sum() > len(x)/2 else 0
        elif method == 'mean_thresh':
            agg_fn = lambda x: 1 if x.mean() >= 0.5 else 0
        elif method == 'max':
            agg_fn = lambda x: int(x.max() > 0)
        else:
            raise ValueError(f"Unknown aggregation method: {method}")

        return ser.resample(tf_high).apply(agg_fn)

    def compare_timeframes(self, df_low: pd.DataFrame, df_high: pd.DataFrame, 
                          tf_high: str, pred_col: str = 'prediction', 
                          label_col: str = 'label', method: str = 'majority') -> Dict[str, float]:
        """
        Compare accuracy between low timeframe predictions and high timeframe labels.
        
        Args:
            df_low: DataFrame with low timeframe predictions
            df_high: DataFrame with high timeframe labels
            tf_high: High timeframe string (e.g., '15T', '1H')
            pred_col: Prediction column name
            label_col: Label column name
            method: Aggregation method
        
        Returns:
            Dict of computed metrics
        """
        # Aggregate low frame predictions to high frame
        agg_pred = self._aggregate_predictions(df_low, tf_high, pred_col, method)

        # Align and extract labels
        labels = df_high.set_index('timestamp')[label_col].resample(tf_high).first()

        # Combine and drop NaN values
        df_cmp = pd.concat([agg_pred, labels], axis=1)
        df_cmp.columns = ['pred', 'true']
        df_cmp = df_cmp.dropna()

        # Compute metrics
        y_true = df_cmp['true'].astype(int)
        y_pred = df_cmp['pred'].astype(int)

        return {
            'accuracy': accuracy_score(y_true, y_pred),
            'precision': precision_score(y_true, y_pred, zero_division=0),
            'recall': recall_score(y_true, y_pred, zero_division=0),
            'f1': f1_score(y_true, y_pred, zero_division=0)
        }

    # === UNIFIED WORKFLOW METHODS ===
    
    def full_optimization_workflow(self, model, X_train: np.ndarray, y_train: np.ndarray,
                                  X_val: np.ndarray, y_val: np.ndarray, 
                                  metric: str = None) -> Dict[str, Any]:
        """
        Complete optimization workflow: threshold + performance evaluation.
        
        Returns:
            Dict with optimized threshold and validation metrics
        """
        metric = metric or self.default_metric
        
        # Find optimal threshold on training data
        optimal_threshold = self.compute_optimal_threshold(model, X_train, y_train, metric)
        
        # Evaluate on validation data
        y_val_proba = model.predict_proba(X_val)[:, 1] if len(np.unique(y_val)) == 2 else model.predict(X_val)
        y_val_pred = self.apply_threshold(y_val_proba, optimal_threshold) if len(np.unique(y_val)) == 2 else y_val_proba
        
        # Compute validation metrics
        val_metrics = {
            'accuracy': accuracy_score(y_val, y_val_pred),
            'precision': precision_score(y_val, y_val_pred, zero_division=0),
            'recall': recall_score(y_val, y_val_pred, zero_division=0),
            'f1': f1_score(y_val, y_val_pred, zero_division=0)
        }
        
        return {
            'optimal_threshold': optimal_threshold,
            'validation_metrics': val_metrics,
            'optimization_metric': metric
        }

    def load_metrics(self, metrics: pd.DataFrame):
        """Load new metrics data"""
        self._process_metrics(metrics)

    def set_default_metric(self, metric: str):
        """Set default optimization metric"""
        self.default_metric = metric

class HyperparameterOptimizer:
    """
    ULTRA ADVANCED Hyperparameter Optimizer với TimeSeriesSplit, adaptive parameters,
    và intelligent parameter space exploration cho trading models.
    """

    def __init__(self,
                 model,
                 param_distributions: dict,
                 n_iter: int = None,
                 cv_splits: int = 5,
                 metric: str = 'f1',
                 random_state: int = 42,
                 n_jobs: int = 1,  # Default to 1 for stability
                 verbose: int = 0,  # Default to quiet
                 use_stratified: bool = True,
                 timeout_seconds: int = 300):  # 5 minute timeout
        """
        ENHANCED constructor with intelligent defaults and advanced features
        
        Args:
            model: sklearn estimator to optimize
            param_distributions: parameter search space
            n_iter: number of parameter combinations to try (auto-calculated if None)
            cv_splits: cross-validation splits (adaptive based on data size)
            metric: optimization metric
            random_state: for reproducibility
            n_jobs: parallel jobs (1 for stability, -1 for max speed)
            verbose: verbosity level
            use_stratified: use StratifiedKFold instead of TimeSeriesSplit for classification
            timeout_seconds: maximum time for optimization
        """
        allowed_metrics = {'accuracy', 'precision', 'recall', 'f1', 'roc_auc'}
        if metric not in allowed_metrics:
            raise ValueError(f"Unknown metric '{metric}', choose one of {allowed_metrics}")

        self.model = model
        self.param_distributions = param_distributions
        self.metric = metric
        self.random_state = random_state
        self.n_jobs = n_jobs
        self.verbose = verbose
        self.use_stratified = use_stratified
        self.timeout_seconds = timeout_seconds
        
        # INTELLIGENT n_iter calculation
        if n_iter is None:
            total_combinations = self._calculate_param_space_size()
            # Adaptive iteration count based on parameter space complexity
            if total_combinations <= 10:
                self.n_iter = total_combinations
            elif total_combinations <= 100:
                self.n_iter = min(20, total_combinations // 2)
            else:
                self.n_iter = min(50, total_combinations // 5)
            self.n_iter = max(5, self.n_iter)  # Minimum 5 iterations
        else:
            self.n_iter = n_iter
            
        # Store cv_splits for later adaptive adjustment
        self.base_cv_splits = cv_splits
        
        # Initialize scorer
        self._setup_scorer()
        
        # Will be set in optimize() based on actual data
        self.cv = None
        self.search = None

    def _calculate_param_space_size(self) -> int:
        """Calculate approximate parameter space size"""
        total_combinations = 1
        for param_name, values in self.param_distributions.items():
            if isinstance(values, (list, tuple)):
                total_combinations *= len(values)
            elif hasattr(values, 'rvs'):  # scipy distribution
                total_combinations *= 10  # Estimate for continuous distributions
            else:
                total_combinations *= 5  # Conservative estimate
        return total_combinations
    
    def _setup_scorer(self):
        """Setup scoring function with enhanced options"""
        scorer_map = {
            'f1': make_scorer(f1_score, average='weighted', zero_division=0),
            'precision': make_scorer(precision_score, average='weighted', zero_division=0),
            'recall': make_scorer(recall_score, average='weighted', zero_division=0),
            'accuracy': make_scorer(accuracy_score),
            'roc_auc': 'roc_auc'  # Built-in scorer
        }
        self.scorer = scorer_map[self.metric]
    
    def _adaptive_cv_strategy(self, X, y):
        """
        INTELLIGENT CV strategy selection based on data characteristics
        """
        n_samples = len(X)
        
        # Adaptive CV splits based on data size
        if n_samples < 100:
            cv_splits = 2
        elif n_samples < 500:
            cv_splits = 3
        elif n_samples < 2000:
            cv_splits = min(5, self.base_cv_splits)
        else:
            cv_splits = self.base_cv_splits
            
        # Choose CV strategy
        if self.use_stratified:
            from sklearn.model_selection import StratifiedKFold
            return StratifiedKFold(n_splits=cv_splits, shuffle=True, random_state=self.random_state)
        else:
            # Use TimeSeriesSplit for temporal data
            return TimeSeriesSplit(n_splits=cv_splits)
    
    def _validate_inputs(self, X, y):
        """Validate input data and parameters"""
        if len(X) != len(y):
            raise ValueError("X and y must have same number of samples")
        
        if len(X) < self.base_cv_splits:
            raise ValueError(f"Not enough samples ({len(X)}) for {self.base_cv_splits} CV splits")
        
        # Check class balance for classification
        if hasattr(self.model, 'predict_proba'):
            unique_classes = len(set(y))
            if unique_classes < 2:
                raise ValueError("Need at least 2 classes for classification")
    
    def optimize(self, X, y):
        """
        ENHANCED optimization with intelligent parameter selection and error handling
        
        Returns:
            tuple: (best_estimator, best_params, best_score, optimization_info)
        """
        import time
        from sklearn.model_selection import RandomizedSearchCV
        
        start_time = time.time()
        
        try:
            # Validate inputs
            self._validate_inputs(X, y)
            
            # Setup adaptive CV strategy
            self.cv = self._adaptive_cv_strategy(X, y)
            
            # Create enhanced RandomizedSearchCV
            self.search = RandomizedSearchCV(
                estimator=self.model,
                param_distributions=self.param_distributions,
                n_iter=self.n_iter,
                scoring=self.scorer,
                cv=self.cv,
                random_state=self.random_state,
                n_jobs=self.n_jobs,
                verbose=self.verbose,
                error_score='raise',  # Raise errors for debugging
                return_train_score=True  # Include training scores
            )
            
            if self.verbose > 0:
                print(f"🎯 Optimizing {type(self.model).__name__} with {self.n_iter} iterations")
                print(f"📊 CV Strategy: {type(self.cv).__name__} (splits: {self.cv.n_splits})")
                print(f"🎯 Optimizing for: {self.metric}")
            
            # Execute optimization with timeout
            self.search.fit(X, y)
            
            optimization_time = time.time() - start_time
            
            # Prepare comprehensive results
            optimization_info = {
                'optimization_time': optimization_time,
                'n_iterations': self.n_iter,
                'cv_splits': self.cv.n_splits,
                'cv_strategy': type(self.cv).__name__,
                'metric_optimized': self.metric,
                'param_space_size': self._calculate_param_space_size(),
                'best_cv_score': self.search.best_score_,
                'std_test_score': self.search.cv_results_['std_test_score'][self.search.best_index_],
                'mean_fit_time': self.search.cv_results_['mean_fit_time'][self.search.best_index_],
                'candidate_params_explored': len(self.search.cv_results_['params'])
            }
            
            if self.verbose > 0:
                print(f"✅ Optimization completed in {optimization_time:.2f}s")
                print(f"🏆 Best {self.metric}: {self.search.best_score_:.4f} ± {optimization_info['std_test_score']:.4f}")
                print(f"🔧 Best params: {self.search.best_params_}")
            
            return (
                self.search.best_estimator_,
                self.search.best_params_,
                self.search.best_score_,
                optimization_info
            )
            
        except Exception as e:
            error_time = time.time() - start_time
            
            error_info = {
                'error': str(e),
                'error_type': type(e).__name__,
                'optimization_time': error_time,
                'n_iterations_attempted': self.n_iter,
                'param_space_size': self._calculate_param_space_size()
            }
            
            if self.verbose > 0:
                print(f"❌ Optimization failed after {error_time:.2f}s: {e}")
            
            # Return base model as fallback
            return (
                self.model,
                self.model.get_params(),
                0.0,  # No score available
                error_info
            )
    
    def get_optimization_results(self):
        """Get detailed optimization results if available"""
        if self.search is None:
            return None
            
        return {
            'cv_results': self.search.cv_results_,
            'best_estimator': self.search.best_estimator_,
            'best_params': self.search.best_params_,
            'best_score': self.search.best_score_,
            'best_index': self.search.best_index_
        }

class DriftDetector:
    """
    Phát hiện sự thay đổi phân phối (drift) giữa hai tập dữ liệu.
    Sử dụng Kolmogorov–Smirnov Test (KS Test) cho các feature numeric.
    """

    def __init__(self, alpha: float = 0.05):
        """
        alpha: mức ý nghĩa để kết luận drift (mặc định 0.05)
        """
        self.alpha = alpha
        self.drifted_features = []

    def compare(self, df_old: pd.DataFrame, df_new: pd.DataFrame) -> dict:
        """
        So sánh hai DataFrame cùng schema.
        Trả về:
        {
            'drifted_features': list[str],
            'total_checked': int,
            'drift_ratio': float,
            'drift_detected': bool
        }
        """
        common_cols = df_old.columns.intersection(df_new.columns)
        drifted = []

        for col in common_cols:
            if not np.issubdtype(df_old[col].dtype, np.number):
                continue
            x1 = df_old[col].dropna()
            x2 = df_new[col].dropna()
            if len(x1) < 30 or len(x2) < 30:
                continue
            stat, p_value = ks_2samp(x1, x2)
            if p_value < self.alpha:
                drifted.append(col)

        drift_ratio = len(drifted) / max(len(common_cols), 1)

        return {
            'drifted_features': drifted,
            'total_checked': len(common_cols),
            'drift_ratio': drift_ratio,
            'drift_detected': len(drifted) > 0
        }

class SHAPExplainer:
    """
    Giải thích mô hình đã train bằng SHAP.
    Trích xuất top N feature quan trọng nhất theo mean(abs SHAP value).
    """

    def __init__(self, model, X_sample: pd.DataFrame, explainer_type: str = 'auto'):
        """
        model: mô hình đã fit (tree-based, linear...)
        X_sample: sample features để giải thích (DataFrame)
        explainer_type: 'auto' (default), 'tree', 'linear', 'kernel'
        """
        self.model = model
        self.X = X_sample
        self.explainer_type = explainer_type
        self.explainer = None
        self.shap_values = None

    def explain(self):
        """
        Tính shap_values tương ứng model + sample
        """
        if self.explainer_type == 'auto':
            try:
                self.explainer = shap.Explainer(self.model, self.X)
            except Exception:
                self.explainer = shap.TreeExplainer(self.model)
        elif self.explainer_type == 'tree':
            self.explainer = shap.TreeExplainer(self.model)
        elif self.explainer_type == 'linear':
            self.explainer = shap.LinearExplainer(self.model, self.X)
        elif self.explainer_type == 'kernel':
            self.explainer = shap.KernelExplainer(self.model.predict_proba, self.X)
        else:
            raise ValueError("Unsupported explainer type")

        self.shap_values = self.explainer(self.X)

    def top_features(self, top_n: int = 10) -> pd.Series:
        """
        Trả về Series feature_name → mean(abs(shap_value)) sắp xếp giảm dần.
        """
        if self.shap_values is None:
            self.explain()
        
        # Calculate mean absolute SHAP values
        if hasattr(self.shap_values, 'values'):
            shap_vals = self.shap_values.values
        else:
            shap_vals = self.shap_values
            
        mean_abs_shap = np.mean(np.abs(shap_vals), axis=0)
        feature_importance = pd.Series(mean_abs_shap, index=self.X.columns)
        return feature_importance.sort_values(ascending=False).head(top_n)


def calculate_adaptive_parameters(X, y):
    """Calculate adaptive parameters based on data characteristics"""
    import psutil
    import logging
    
    logger = logging.getLogger(__name__)
    
    # Cache system info to avoid repeated expensive calls
    if not hasattr(calculate_adaptive_parameters, '_system_cache'):
        calculate_adaptive_parameters._system_cache = {
            'cpu_cores': psutil.cpu_count(),
            'memory_gb': psutil.virtual_memory().total / (1024**3)
        }
    
    try:
        logger.info("⚙️ Calculating adaptive parameters based on data characteristics")
        
        # Get data dimensions
        n_samples, n_features = X.shape
          
        # Basic parameter scaling based on data size and system resources
        cpu_cores = calculate_adaptive_parameters._system_cache['cpu_cores']
        memory_gb = calculate_adaptive_parameters._system_cache['memory_gb']
        
        params = {
            'n_estimators': min(max(int(n_samples / max(100, cpu_cores * 10)), max(50, cpu_cores * 10)), max(200, cpu_cores * 50)),
            'max_depth': min(max(int(np.log2(n_features) * max(2, cpu_cores / 2)), max(3, cpu_cores)), max(15, cpu_cores * 3)),
            'learning_rate': max(0.001, min(0.5, 1.0 / max(np.log10(n_samples), cpu_cores))),
            'regularization_strength': min(max(0.001, n_features / max(500, memory_gb * 100)), 2.0),
            'hidden_layer_size': min(max(int(n_features * max(1.2, cpu_cores / 4)), max(25, cpu_cores * 5)), max(150, cpu_cores * 25)),
            'cv_folds': min(max(int(max(3, cpu_cores / 2)), int(n_samples / max(500, memory_gb * 100))), max(5, cpu_cores)),
            'max_model_time': max(int(cpu_cores * 60), 300),
            'small_value_threshold': 1e-9
        }
        
        # Check class distribution for classification tasks
        try:
            from data_processing.unified_data_validator import UnifiedDataValidator
            validator = UnifiedDataValidator()
            balance_info = validator.get_class_balance_info(y)
            imbalance_ratio = balance_info['imbalance_ratio']
            
            # Dynamic imbalance thresholds based on data size
            severe_threshold = max(5, n_samples / 1000)
            moderate_threshold = max(2, n_samples / 5000)
            
            if imbalance_ratio > severe_threshold:
                logger.info(f"🚨 Severe class imbalance detected (ratio: {imbalance_ratio:.1f})")
                params['class_weight'] = 'balanced'
                params['use_smote'] = True
            elif imbalance_ratio > moderate_threshold:
                logger.info(f"⚠️ Moderate class imbalance detected (ratio: {imbalance_ratio:.1f})")
                params['class_weight'] = 'balanced'
                params['use_smote'] = False
            else:
                params['class_weight'] = None 
                params['use_smote'] = False
                
        except Exception as e:
            logger.warning(f"⚠️ Validator-based imbalance analysis failed: {e}")
            params['class_weight'] = 'balanced'  # Safe default
            params['use_smote'] = False
        
        logger.info(f"✅ Adaptive parameters calculated: n_estimators={params['n_estimators']}, max_depth={params['max_depth']}")
        return params
        
    except Exception as e:
        logger.error(f"❌ Error calculating adaptive parameters: {e}")        # Return dynamic default parameters based on system resources
        cpu_cores = calculate_adaptive_parameters._system_cache.get('cpu_cores', psutil.cpu_count())
        memory_gb = calculate_adaptive_parameters._system_cache.get('memory_gb', psutil.virtual_memory().total / (1024**3))
        return {
            'n_estimators': max(int(cpu_cores * 30), 100),
            'max_depth': max(int(cpu_cores * 2), 10),
            'learning_rate': max(0.01, 0.2 / cpu_cores),
            'regularization_strength': max(0.01, 0.2 / memory_gb),
            'hidden_layer_size': max(int(cpu_cores * 15), 50),
            'cv_folds': max(min(cpu_cores, 8), 3),
            'max_model_time': max(int(cpu_cores * 60), 300),
            'small_value_threshold': 1e-9,
            'class_weight': 'balanced',
            'use_smote': False
        }

def apply_adaptive_parameters(model_type: str, base_params: Dict[str, Any], 
                            adaptive_params: Dict[str, Any]) -> Dict[str, Any]:
    """
    Apply adaptive parameters to model configuration based on model type
    
    Args:
        model_type: Type of the model
        base_params: Base model parameters
        adaptive_params: Adaptive parameters from system analysis
        
    Returns:
        Updated parameters dictionary
    """
    updated_params = base_params.copy()
    
    try:
        # Random Forest / Extra Trees adaptive parameters
        if model_type in ['random_forest', 'random_forest_tuned', 'extra_trees', 'extra_trees_tuned']:
            if 'n_estimators' in adaptive_params:
                updated_params['n_estimators'] = min(adaptive_params['n_estimators'], 500)
            if 'max_depth' in adaptive_params:
                updated_params['max_depth'] = adaptive_params['max_depth']
                
        # Gradient Boosting adaptive parameters
        elif model_type in ['gradient_boosting', 'gradient_boosting_tuned']:
            if 'n_estimators' in adaptive_params:
                updated_params['n_estimators'] = min(adaptive_params['n_estimators'], 300)
            if 'learning_rate' in adaptive_params:
                updated_params['learning_rate'] = adaptive_params['learning_rate']
            if 'max_depth' in adaptive_params:
                updated_params['max_depth'] = adaptive_params['max_depth']
                
        # XGBoost adaptive parameters
        elif model_type == 'xgboost':
            if 'n_estimators' in adaptive_params:
                updated_params['n_estimators'] = min(adaptive_params['n_estimators'], 500)
            if 'learning_rate' in adaptive_params:
                updated_params['learning_rate'] = adaptive_params['learning_rate']
            if 'max_depth' in adaptive_params:
                updated_params['max_depth'] = adaptive_params['max_depth']
                
        # LightGBM adaptive parameters
        elif model_type == 'lightgbm':
            if 'n_estimators' in adaptive_params:
                updated_params['n_estimators'] = min(adaptive_params['n_estimators'], 500)
            if 'learning_rate' in adaptive_params:
                updated_params['learning_rate'] = adaptive_params['learning_rate']
            if 'max_depth' in adaptive_params:
                updated_params['max_depth'] = adaptive_params['max_depth']
                
        # CatBoost adaptive parameters  
        elif model_type == 'catboost':
            if 'n_estimators' in adaptive_params:
                # CatBoost uses 'iterations' instead of 'n_estimators'
                updated_params['iterations'] = min(adaptive_params['n_estimators'], 500)
                if 'n_estimators' in updated_params:
                    del updated_params['n_estimators']
            if 'learning_rate' in adaptive_params:
                updated_params['learning_rate'] = adaptive_params['learning_rate']
            if 'max_depth' in adaptive_params:
                updated_params['depth'] = adaptive_params['max_depth']  # CatBoost uses 'depth'
                
        # Neural Network adaptive parameters
        elif model_type == 'neural_network':
            if 'hidden_layer_size' in adaptive_params:
                updated_params['hidden_layer_sizes'] = (adaptive_params['hidden_layer_size'],)
            if 'learning_rate' in adaptive_params:
                updated_params['learning_rate_init'] = adaptive_params['learning_rate']
                
        # Logistic Regression adaptive parameters
        elif model_type == 'logistic_regression':
            if 'regularization_strength' in adaptive_params:
                updated_params['C'] = 1.0 / max(adaptive_params['regularization_strength'], 1e-8)
                
        # SVM adaptive parameters
        elif model_type == 'svm':
            if 'regularization_strength' in adaptive_params:
                updated_params['C'] = 1.0 / max(adaptive_params['regularization_strength'], 1e-8)
                
        # Naive Bayes adaptive parameters
        elif model_type == 'naive_bayes':
            if 'small_value_threshold' in adaptive_params:
                updated_params['var_smoothing'] = adaptive_params['small_value_threshold']
        
        logger.debug(f"✅ Adaptive parameters applied for {model_type}")
        return updated_params
        
    except Exception as e:
        logger.warning(f"⚠️ Failed to apply adaptive parameters for {model_type}: {e}")
        return base_params
