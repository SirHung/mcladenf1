# ai_optimizer/unified_resource_manager.py
"""
Professional Unified Resource Management System
Enterprise-grade resource optimization, GPU management, and system monitoring
"""

import os
import gc
import sys
import time
import logging
import threading
import warnings
import psutil
import numpy as np
from threading import RLock, Event
from typing import Dict, List, Optional, Tuple, Any, Union
from dataclasses import dataclass
from datetime import datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager

# Optimize system environment BEFORE any imports
_CPU_COUNT = os.cpu_count() or 4
_RAM_GB = psutil.virtual_memory().total / (1024**3)

os.environ.update({
    'PYTORCH_CUDA_ALLOC_CONF': 'expandable_segments:True,roundup_power2_divisions:16',
    'CUDA_LAUNCH_BLOCKING': '0',
    'TORCH_CUDA_ARCH_LIST': '6.0;6.1;7.0;7.5;8.0;8.6',
    'OMP_NUM_THREADS': str(min(8, _CPU_COUNT)),
    'MKL_NUM_THREADS': str(min(8, _CPU_COUNT)),
    'NUMEXPR_NUM_THREADS': str(min(8, _CPU_COUNT)),
    'TOKENIZERS_PARALLELISM': 'false'
})

logger = logging.getLogger(__name__)

# Dynamic resource constants - Professional optimization
MAX_WORKERS = min(32, _CPU_COUNT * 3)  # Enhanced: 3x cores for optimal I/O
MAX_CPU_PERCENT = min(95.0, max(80.0, 70.0 + _CPU_COUNT * 2))  # Dynamic scaling
MAX_RAM_UTIL = min(92.0, max(85.0, 80.0 + _RAM_GB * 2))  # Smart RAM management
MAX_GPU_LOAD = 95.0
MIN_FREE_GPU_MEM = max(0.5, min(2.0, _RAM_GB / 16))  # Dynamic GPU memory

# Global training status - Enhanced tracking
training_status: Dict[str, Any] = {
    "train_progress": 0.0,
    "train_status": "",
    "train_error": None,
    "predicting": False,
    "predict_done": 0,
    "predict_total_steps": 5,
    "training": False,
    "train_results": [],
    "eta": None,
    "last_update": datetime.now(),
    "system_load": "normal",
    "resource_efficiency": 100.0,
    "train_running": False,
    "train_start_time": None,
    "current_step": "",
    "step_number": 0,
    "total_steps": 100
}

# Professional torch import with isolation
def _isolated_torch_import():
    """Professional isolated torch import to prevent conflicts"""
    try:
        import torch
        if torch.cuda.is_available():
            return torch, True
        return torch, False
    except ImportError:
        return None, False
    except Exception:
        return None, False

# Lazy loading globals
torch = None
TORCH_AVAILABLE = False

def get_torch():
    """Get torch with professional lazy loading"""
    global torch, TORCH_AVAILABLE
    if torch is None:
        torch, TORCH_AVAILABLE = _isolated_torch_import()
    return torch, TORCH_AVAILABLE

# Professional GPU monitoring
GPU_MONITORING_AVAILABLE = False
GPUTIL_AVAILABLE = False
PYNVML_AVAILABLE = False

try:
    import GPUtil
    GPUTIL_AVAILABLE = True
    GPU_MONITORING_AVAILABLE = True
except ImportError:
    GPUtil = None

try:
    import pynvml
    pynvml.nvmlInit()
    PYNVML_AVAILABLE = True
    GPU_MONITORING_AVAILABLE = True
except (ImportError, Exception):
    pynvml = None# Professional resource management globals
_resource_lock = RLock()
_monitoring_thread = None
_monitoring_interval = 10
_stop_monitoring = threading.Event()
_last_resource_check = datetime.now()
_resource_cache = {}
_resource_cache_ttl = 2  # Professional: 2-second cache for responsiveness

@dataclass
class GPUAllocation:
    """Professional GPU allocation tracking"""
    gpu_id: int
    allocated_memory: float
    allocated_tasks: List[str]
    max_memory: float
    reservation_time: float

@dataclass
class SystemResourceMetrics:
    """Professional system resource metrics"""
    timestamp: datetime
    cpu_percent: float
    memory_percent: float
    memory_available_gb: float
    gpu_metrics: List[Dict[str, Any]]
    disk_usage_percent: float
    temperature: Optional[float] = None

@dataclass
class ResourceMetrics:
    """Simplified system resource metrics for quick access"""
    cpu_percent: float
    memory_percent: float
    memory_available_gb: float
    gpu_count: int
    has_gpu: bool

@dataclass
class GPUInfo:
    """Professional GPU information container"""
    id: int
    name: str
    memory_total: float  # GB
    memory_free: float   # GB
    memory_used: float   # GB
    memory_percent: float
    temperature: Optional[float] = None
    utilization: float = 0.0
    is_available: bool = True
    compute_capability: Optional[Tuple[int, int]] = None
    power_usage: Optional[float] = None

class UnifiedResourceManager:
    """Professional unified system resource management with enterprise features"""
    _instance = None
    _initialized = False
    _monitor_thread = None
    
    def __new__(cls, *args, **kwargs):
        """Singleton pattern for resource manager"""
        if cls._instance is None:
            cls._instance = super(UnifiedResourceManager, cls).__new__(cls)
        return cls._instance
    
    def __init__(self,
                 max_workers: int = None,
                 target_cpu: int = None,
                 memory_threshold: float = None,
                 max_gpu_load: float = None,
                 min_free_gpu_mem: float = None,
                 max_gpu_memory_fraction: float = 0.90,
                 temperature_threshold: float = 85.0,
                 memory_reserve_gb: float = None):
        """Professional initialization with dynamic optimization"""
        if UnifiedResourceManager._initialized:
            return
            
        # Professional dynamic resource optimization
        self.max_workers = max_workers or min(_CPU_COUNT * 3, MAX_WORKERS)
        self.target_cpu = target_cpu or min(90.0, max(75.0, 65.0 + _CPU_COUNT * 1.5))
        self.memory_threshold = memory_threshold or min(90.0, max(80.0, 75.0 + _RAM_GB))
        self.max_gpu_load = max_gpu_load or MAX_GPU_LOAD
        self.min_free_gpu_mem = min_free_gpu_mem or max(0.5, min(2.0, _RAM_GB / 16))
        self.memory_reserve_gb = memory_reserve_gb or max(1.0, min(4.0, _RAM_GB / 16))
        
        # Professional GPU management
        self.max_memory_fraction = max_gpu_memory_fraction
        self.temperature_threshold = temperature_threshold
        
        # Professional monitoring system
        self._resource_history = []
        self._max_history_size = min(200, max(100, _CPU_COUNT * 10))
        self._monitoring_lock = threading.Lock()
        self._performance_metrics = {
            'cpu_utilization': [],
            'memory_utilization': [],
            'gpu_utilization': [],
            'efficiency_score': 100.0
        }
        
        # Professional GPU tracking
        self._allocation_lock = RLock()
        self._gpu_allocations: Dict[int, GPUAllocation] = {}
        self._gpu_info_cache: Dict[int, GPUInfo] = {}
        self._last_gpu_scan = 0.0
        self._scan_interval = max(1.0, min(5.0, _CPU_COUNT / 4))  # Professional scan interval
        
        # GPU state initialization
        self.use_gpu = False
        self.gpu_count = 0
        self.gpu_info = []
        self.selected_gpu_id = None
        self.available_gpus: List[GPUInfo] = []
        self.has_gpu = False
        self.gpu_names = []
        
        # Professional initialization sequence
        self._detect_gpu()
        self._setup_gpu_environment()
        
        # Finalize initialization
        UnifiedResourceManager._initialized = True
        
        # Professional GPU selection
        if self.has_gpu:
            best_gpu = self.select_best_gpu(
                min_free_memory_gb=self.min_free_gpu_mem,
                max_load=self.max_gpu_load
            )
            if best_gpu is not None:
                self.selected_gpu_id = best_gpu
                self.use_gpu = True
                logger.info(f"🚀 Professional GPU optimization: GPU {best_gpu} selected")
            else:
                logger.warning("⚠️ No suitable GPU found, using optimized CPU mode")
                self.use_gpu = False
        
        # Professional thread pool with optimal configuration
        optimal_workers = min(self.max_workers, _CPU_COUNT * 2)
        self.thread_pool = ThreadPoolExecutor(
            max_workers=optimal_workers,
            thread_name_prefix="ResourceManager"
        )
        logger.info(f"🎯 Professional ThreadPool initialized: {optimal_workers} workers")

    def clear_gpu_memory(self, intensity='moderate'):
        """Professional GPU memory management with multiple intensity levels"""
        try:
            torch, TORCH_AVAILABLE = get_torch()
            if not TORCH_AVAILABLE or not torch.cuda.is_available():
                return True
                
            if intensity == 'light':
                torch.cuda.empty_cache()
                gc.collect()
                
            elif intensity == 'moderate':
                torch.cuda.synchronize()
                torch.cuda.empty_cache()
                gc.collect()
                time.sleep(0.1)  # Professional: Allow system to settle
                
            elif intensity == 'aggressive':
                # Professional aggressive cleanup
                for i in range(torch.cuda.device_count()):
                    with torch.cuda.device(i):
                        torch.cuda.empty_cache()
                        torch.cuda.synchronize()
                
                # Multiple GC rounds for thorough cleanup
                for _ in range(3):
                    gc.collect()
                    time.sleep(0.05)
                
            logger.debug(f"Professional GPU memory cleanup completed (intensity: {intensity})")
            return True
            
        except Exception as e:
            logger.error(f"GPU memory cleanup failed: {e}")
            return False
    
    @contextmanager
    def managed_gpu_memory(self):
        """Professional context manager for automatic GPU memory management"""
        try:
            self.clear_gpu_memory('light')
            yield
        finally:
            self.clear_gpu_memory('moderate')
    
    @contextmanager
    def managed_execution(self, task_type='general'):
        """Unified context manager for resource-managed execution (CPU/GPU/IO)."""
        # Log entry for debugging
        logger.debug(f"[ResourceManager] Entering managed_execution for task_type: {task_type}")
        if task_type == 'gpu' and self.use_gpu:
            with self.managed_gpu_memory():
                yield
        else:
            # For IO/CPU/general, optionally could add more resource management here
            try:
                # Placeholder for future: set thread affinity, priority, etc.
                yield
            finally:
                pass  # Could add cleanup if needed
        logger.debug(f"[ResourceManager] Exiting managed_execution for task_type: {task_type}")

    def get_optimal_workers(self, task_type='general'):
        """Professional worker optimization based on system specs and task type"""
        cpu_count = _CPU_COUNT
        total_ram_gb = _RAM_GB
        
        # Professional task-specific optimization
        worker_configs = {
            'gpu': min(6, max(2, cpu_count // 3)),  # Conservative for GPU tasks
            'io': min(48, max(8, cpu_count * 6)),   # Aggressive for I/O bound
            'cpu': max(2, cpu_count - 1),           # CPU intensive
            'processing': max(4, min(cpu_count, int(total_ram_gb // 1.5))),  # Memory aware
            'training': max(4, min(cpu_count // 2, 12)),  # Balanced for ML training
            'parallel': max(2, min(cpu_count - 1, 16)),   # General parallel tasks
            'general': max(2, min(cpu_count - 1, self.max_workers))  # Default
        }
        
        return worker_configs.get(task_type, worker_configs['general'])

    def _detect_gpu(self):
        """Comprehensive GPU detection using multiple methods"""
        detected_gpus = []
        
        # Method 1: PyTorch CUDA detection
        torch, TORCH_AVAILABLE = get_torch()
        if TORCH_AVAILABLE and torch.cuda.is_available():
            for i in range(torch.cuda.device_count()):
                try:
                    props = torch.cuda.get_device_properties(i)
                    
                    # Get memory info
                    with torch.cuda.device(i):
                        memory_total = props.total_memory / (1024**3)  # Convert to GB
                        memory_reserved = torch.cuda.memory_reserved(i) / (1024**3)
                        memory_allocated = torch.cuda.memory_allocated(i) / (1024**3)
                        memory_free = memory_total - memory_allocated
                        memory_percent = (memory_allocated / memory_total) * 100
                    
                    gpu_info = GPUInfo(
                        id=i,
                        name=props.name,
                        memory_total=memory_total,
                        memory_free=memory_free,
                        memory_used=memory_allocated,
                        memory_percent=memory_percent,
                        compute_capability=(props.major, props.minor),
                        is_available=memory_free > self.memory_reserve_gb
                    )
                    detected_gpus.append(gpu_info)
                    self.gpu_names.append(props.name)
                    
                    # Legacy compatibility
                    self.gpu_info.append({
                        'id': i,
                        'name': props.name,
                        'memory_total': memory_total * 1024,  # Convert to MB for compatibility
                        'memory_free': memory_free * 1024,
                        'memory_used': memory_allocated * 1024,
                        'load': 0.0,  # Will be updated if GPUtil available
                        'temperature': None  # Will be updated if GPUtil available
                    })
                    
                    logger.info(f"PyTorch detected GPU {i}: {props.name} "
                                  f"({memory_total:.1f}GB total, {memory_free:.1f}GB free)")
                    
                except Exception as e:
                    logger.warning(f"Failed to get PyTorch GPU {i} info: {e}")
        
        # Method 2: GPUtil detection (enhance existing info or replace if PyTorch failed)
        if GPUTIL_AVAILABLE:
            try:
                gpus = GPUtil.getGPUs()
                
                if not detected_gpus:  # If PyTorch detection failed
                    self.gpu_info = []
                    
                    for gpu in gpus:
                        memory_total = gpu.memoryTotal / 1024  # MB to GB
                        memory_free = gpu.memoryFree / 1024
                        memory_used = gpu.memoryUsed / 1024
                        gpu_info = GPUInfo(
                            id=gpu.id,
                            name=gpu.name,
                            memory_total=memory_total,
                            memory_free=memory_free,
                            memory_used=memory_used,
                            memory_percent=gpu.memoryUtil * 100,
                            temperature=gpu.temperature,
                            utilization=gpu.load * 100,
                            is_available=memory_free > self.memory_reserve_gb
                        )
                        
                        detected_gpus.append(gpu_info)
                        self.gpu_names.append(gpu.name)
                        
                        self.gpu_info.append({
                            'id': gpu.id,
                            'name': gpu.name,
                            'memory_total': gpu.memoryTotal,
                            'memory_free': gpu.memoryFree,
                            'memory_used': gpu.memoryUsed,
                            'load': gpu.load,
                            'temperature': gpu.temperature
                        })
                        
                        logger.info(f"GPUtil detected GPU {gpu.id}: {gpu.name} "
                                      f"({memory_total:.1f}GB total, {memory_free:.1f}GB free)")
                
                else:  # Enhance PyTorch info with GPUtil data
                    for i, gpu_info_dict in enumerate(self.gpu_info):
                        for gpu in gpus:
                            if gpu.id == gpu_info_dict['id']:
                                gpu_info_dict['load'] = gpu.load
                                gpu_info_dict['temperature'] = gpu.temperature
                                
                                # Update detected_gpus info
                                for detected_gpu in detected_gpus:
                                    if detected_gpu.id == gpu.id:
                                        detected_gpu.temperature = gpu.temperature
                                        detected_gpu.utilization = gpu.load * 100
                
            except Exception as e:
                logger.warning(f"GPUtil detection failed: {e}")
        
        # Method 3: NVIDIA ML detection (enhanced info)
        if PYNVML_AVAILABLE:
            try:
                device_count = pynvml.nvmlDeviceGetCount()
                for i in range(device_count):
                    handle = pynvml.nvmlDeviceGetHandleByIndex(i)
                    name_raw = pynvml.nvmlDeviceGetName(handle)
                    name = name_raw.decode('utf-8') if isinstance(name_raw, bytes) else name_raw
                    
                    # Memory info
                    mem_info = pynvml.nvmlDeviceGetMemoryInfo(handle)
                    memory_total = mem_info.total / (1024**3)
                    memory_free = mem_info.free / (1024**3)
                    memory_used = mem_info.used / (1024**3)
                    
                    # Temperature
                    try:
                        temperature = pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU)
                    except:
                        temperature = None
                    
                    # Power usage
                    try:
                        power_usage = pynvml.nvmlDeviceGetPowerUsage(handle) / 1000.0  # mW to W
                    except:
                        power_usage = None
                    
                    # Utilization
                    try:
                        util_info = pynvml.nvmlDeviceGetUtilizationRates(handle)
                        utilization = util_info.gpu
                    except:
                        utilization = 0.0
                    
                    # Update existing GPU info or add new
                    existing_gpu = next((gpu for gpu in detected_gpus if gpu.name == name), None)
                    
                    if existing_gpu:
                        existing_gpu.temperature = temperature
                        existing_gpu.power_usage = power_usage
                        existing_gpu.utilization = utilization
                    else:
                        gpu_info = GPUInfo(
                            id=i,
                            name=name,
                            memory_total=memory_total,
                            memory_free=memory_free,
                            memory_used=memory_used,
                            memory_percent=(memory_used / memory_total) * 100,
                            temperature=temperature,
                            power_usage=power_usage,
                            utilization=utilization,
                            is_available=memory_free > self.memory_reserve_gb
                        )
                        detected_gpus.append(gpu_info)
                        
                        if name not in self.gpu_names:
                            self.gpu_names.append(name)
                            
                            self.gpu_info.append({
                                'id': i,
                                'name': name,
                                'memory_total': memory_total * 1024,  # Convert to MB for compatibility
                                'memory_free': memory_free * 1024,
                                'memory_used': memory_used * 1024,
                                'load': utilization / 100.0 if utilization is not None else 0.0,
                                'temperature': temperature
                            })
                    
            except Exception as e:
                logger.warning(f"NVIDIA-ML detection failed: {e}")
        
        # Finalize GPU detection
        self.available_gpus = [gpu for gpu in detected_gpus if gpu.is_available]
        self.has_gpu = len(self.available_gpus) > 0
        self.gpu_count = len(self.available_gpus)

        # Chỉ bật GPU nếu đã gọi get_optimal_device() trả về 'cuda' và thực sự có GPU
        optimal_device = self.get_optimal_device()
        if optimal_device.startswith('cuda') and self.has_gpu:
            self.use_gpu = True
            self.gpu_device = optimal_device
            logger.info(f"🔥 GPU enabled: {optimal_device}")
        else:
            self.use_gpu = False
            self.gpu_device = 'cpu'
            logger.info("💻 GPU disabled, using CPU")

        
        # Cache GPU info
        self._gpu_info_cache = {gpu.id: gpu for gpu in detected_gpus}
        self._last_gpu_scan = time.time()
          # Test GPU functionality
        if self.has_gpu:
            torch, TORCH_AVAILABLE = get_torch()
            if TORCH_AVAILABLE:
                try:
                    test_tensor = torch.tensor([1.0]).cuda()
                    del test_tensor
                    torch.cuda.empty_cache()
                except Exception as e:
                    logger.warning(f"GPU test failed: {e}, fallback to CPU")
                    self.use_gpu = False
        
        # Log results
        if self.has_gpu:
            logger.info(f"✅ GPU detection successful: {self.gpu_count} GPU(s) found")
            if self.gpu_info:
                logger.info(f"Primary GPU: {self.gpu_info[0]['name']}, VRAM={self.gpu_info[0]['memory_total']}MB")
            
            for gpu in self.available_gpus:
                logger.info(f"  GPU {gpu.id}: {gpu.name} - "
                              f"{gpu.memory_free:.1f}GB free / {gpu.memory_total:.1f}GB total")
        else:
            logger.info("❌ No suitable GPUs found, using CPU")    
    def _setup_gpu_environment(self) -> None:
        """Setup optimal GPU environment"""
        if not self.has_gpu:
            return
        
        torch, TORCH_AVAILABLE = get_torch()
        if not TORCH_AVAILABLE:
            return
        
        try:
            # Enable optimizations
            torch.backends.cudnn.benchmark = True
            torch.backends.cudnn.deterministic = False
            
            # Set memory fractions for each GPU
            for gpu in self.available_gpus:
                with torch.cuda.device(gpu.id):
                    torch.cuda.set_per_process_memory_fraction(self.max_memory_fraction)
                    torch.cuda.empty_cache()
            
            logger.info("GPU environment configured successfully")
            
        except Exception as e:
            logger.error(f"Failed to setup GPU environment: {e}")

    def get_system_stats(self) -> SystemResourceMetrics:
        """Unified system resource collection"""
        try:
            # Basic system stats
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            memory_available_gb = memory.available / (1024**3)
            
            disk = psutil.disk_usage('/')
            disk_usage_percent = disk.percent
              # GPU metrics
            gpu_metrics = self.get_gpu_metrics()
            
            # Temperature
            temperature = self._get_temperature()
            
            metrics = SystemResourceMetrics(
                timestamp=datetime.now(),
                cpu_percent=cpu_percent,
                memory_percent=memory_percent,
                memory_available_gb=memory_available_gb,
                gpu_metrics=gpu_metrics,
                disk_usage_percent=disk_usage_percent,
                temperature=temperature
            )
            
            # Store in history
            with self._monitoring_lock:
                self._resource_history.append(metrics)
                if len(self._resource_history) > self._max_history_size:
                    self._resource_history.pop(0)
            
            return metrics
        except Exception as e:
            logger.error(f"Error collecting system stats: {e}")
            return None
    
    def get_gpu_metrics(self, return_format: str = 'dict') -> Union[List[Dict[str, Any]], List[GPUInfo]]:
        """Unified GPU metrics collection with multiple return formats
        
        Args:
            return_format: 'dict' for legacy format, 'gpuinfo' for GPUInfo objects
        """
        if not self.has_gpu:
            return []
            
        gpu_metrics = []
        
        # Try GPUtil first for real-time metrics
        if GPUTIL_AVAILABLE:
            try:
                for gpu in GPUtil.getGPUs():
                    if return_format == 'gpuinfo':
                        gpu_info = GPUInfo(
                            id=gpu.id,
                            name=gpu.name,
                            memory_total=gpu.memoryTotal / 1024,  # Convert MB to GB
                            memory_free=gpu.memoryFree / 1024,
                            memory_used=gpu.memoryUsed / 1024,
                            memory_percent=gpu.memoryUtil * 100,
                            temperature=gpu.temperature,
                            utilization=gpu.load * 100,
                            is_available=gpu.memoryFree / 1024 > self.memory_reserve_gb
                        )
                        gpu_metrics.append(gpu_info)
                    else:
                        gpu_metrics.append({
                            'id': gpu.id,
                            'name': gpu.name,
                            'load': gpu.load,
                            'memory_total': gpu.memoryTotal,
                            'memory_free': gpu.memoryFree,
                            'memory_used': gpu.memoryUsed,
                            'memoryFree': gpu.memoryFree,
                            'memoryUtil': gpu.memoryUtil,
                            'utilization': gpu.load * 100,
                            'temperature': gpu.temperature
                        })
                return gpu_metrics
            except Exception as e:
                logger.warning(f"GPUtil error: {e}")
          # Fallback to PyTorch CUDA
        torch, torch_available = get_torch()
        if torch_available:
            try:
                for i in range(torch.cuda.device_count()):
                    with torch.cuda.device(i):
                        props = torch.cuda.get_device_properties(i)
                        mem_allocated = torch.cuda.memory_allocated(i)
                        total_memory = props.total_memory
                        memory_free = total_memory - mem_allocated
                    
                    if return_format == 'gpuinfo':
                        gpu_info = GPUInfo(
                            id=i,
                            name=props.name,
                            memory_total=total_memory / (1024**3),
                            memory_free=memory_free / (1024**3),
                            memory_used=mem_allocated / (1024**3),
                            memory_percent=(mem_allocated / total_memory) * 100,
                            utilization=0.0,  # PyTorch doesn't provide GPU load
                            compute_capability=(props.major, props.minor),
                            is_available=memory_free / (1024**3) > self.memory_reserve_gb
                        )
                        gpu_metrics.append(gpu_info)
                    else:
                        gpu_metrics.append({
                            'id': i,
                            'name': props.name,
                            'load': 0.0,  # PyTorch doesn't provide GPU load
                            'memory_total': total_memory / (1024**2),  # MB
                            'memory_free': memory_free / (1024**2),
                            'memory_used': mem_allocated / (1024**2),
                            'memoryFree': memory_free / (1024**2),
                            'memoryUtil': mem_allocated / total_memory,
                            'utilization': 0.0,
                            'temperature': None
                        })
            except Exception as e:
                logger.warning(f"PyTorch GPU monitoring error: {e}")
        
        return gpu_metrics

    def _get_temperature(self) -> Optional[float]:
        """Get system temperature if available"""
        try:
            temps = psutil.sensors_temperatures()
            if temps:
                for name, entries in temps.items():
                    if entries:
                        return entries[0].current
        except (AttributeError, OSError):
            pass
        return None

    def get_gpu_status(self, force_refresh: bool = False) -> List[GPUInfo]:
        """Get current GPU status with caching"""
        current_time = time.time()
        
        if not force_refresh and (current_time - self._last_gpu_scan) < self._scan_interval:
            return list(self._gpu_info_cache.values())
        
        updated_gpus = []
        
        for gpu in self.available_gpus:            
            try:
                # Update GPU info
                torch, torch_available = get_torch()
                if torch_available and torch.cuda.is_available():
                    with torch.cuda.device(gpu.id):
                        memory_total = gpu.memory_total
                        memory_allocated = torch.cuda.memory_allocated(gpu.id) / (1024**3)
                        memory_reserved = torch.cuda.memory_reserved(gpu.id) / (1024**3)
                        memory_free = memory_total - memory_allocated
                        memory_percent = (memory_allocated / memory_total) * 100
                        
                        updated_gpu = GPUInfo(
                            id=gpu.id,
                            name=gpu.name,
                            memory_total=memory_total,
                            memory_free=memory_free,
                            memory_used=memory_allocated,
                            memory_percent=memory_percent,
                            temperature=gpu.temperature,
                            power_usage=gpu.power_usage,
                            utilization=gpu.utilization,
                            compute_capability=gpu.compute_capability,
                            is_available=memory_free > self.memory_reserve_gb
                        )
                        
                        updated_gpus.append(updated_gpu)
                else:
                    updated_gpus.append(gpu)
                    
            except Exception as e:
                logger.warning(f"Failed to update GPU {gpu.id} status: {e}")
                updated_gpus.append(gpu)
        
        # Update cache
        self._gpu_info_cache = {gpu.id: gpu for gpu in updated_gpus}
        self._last_gpu_scan = current_time
        
        return updated_gpus

    def select_best_gpu(self, min_free_memory_gb: float = 1.0, max_load: float = 0.8, prefer_low_utilization: bool = True) -> Optional[int]:
        """Select optimal GPU based on memory, load and other criteria"""
        if not self.use_gpu:
            return None
            
        try:
            # Basic method using GPUtil for legacy support
            if GPUTIL_AVAILABLE:
                gpus = GPUtil.getGPUs()
                
                suitable_gpus = []
                for gpu in gpus:
                    free_memory_gb = gpu.memoryFree / 1024  # Convert MB to GB
                    if free_memory_gb >= min_free_memory_gb and gpu.load <= max_load:
                        suitable_gpus.append((gpu.id, gpu.load, free_memory_gb))
                
                if suitable_gpus:
                    # Sort by load (ascending) then by free memory (descending)
                    suitable_gpus.sort(key=lambda x: (x[1], -x[2]))
                    best_gpu_id = suitable_gpus[0][0]
                    self.selected_gpu_id = best_gpu_id
                    logger.info(f"🚀 Selected GPU {best_gpu_id} (Load: {suitable_gpus[0][1]:.2f}, Free: {suitable_gpus[0][2]:.1f}GB)")
                    return best_gpu_id
            
            # Advanced method
            current_gpus = self.get_gpu_status(force_refresh=True)
            available_gpus = [gpu for gpu in current_gpus if gpu.is_available]
            
            if not available_gpus:
                logger.warning("No GPUs available for allocation")
                return None
            
            # Filter by memory requirement
            suitable_gpus = [gpu for gpu in available_gpus 
                            if gpu.memory_free >= min_free_memory_gb]
            
            if not suitable_gpus:
                logger.warning(f"No GPUs with {min_free_memory_gb:.1f}GB free memory available")
                return None
            
            # Score GPUs based on multiple criteria
            def score_gpu(gpu: GPUInfo) -> float:
                score = 0.0
                
                # Memory availability (40% weight)
                memory_score = gpu.memory_free / gpu.memory_total
                score += memory_score * 0.4
                
                # Low utilization (30% weight)
                if prefer_low_utilization:
                    util_score = 1.0 - (gpu.utilization / 100.0)
                    score += util_score * 0.3
                
                # Temperature (20% weight)
                if gpu.temperature is not None:
                    temp_score = max(0, 1.0 - (gpu.temperature / self.temperature_threshold))
                    score += temp_score * 0.2
                else:
                    score += 0.2  # Default if no temperature data
                
                # Existing allocations (10% weight)
                with self._allocation_lock:
                    allocation = self._gpu_allocations.get(gpu.id)
                    if allocation:
                        alloc_score = 1.0 - (len(allocation.allocated_tasks) / 10.0)
                        score += max(0, alloc_score) * 0.1
                    else:
                        score += 0.1
                
                return score
            
            # Select best GPU
            best_gpu = max(suitable_gpus, key=score_gpu)
            self.selected_gpu_id = best_gpu.id
            
            logger.info(f"Selected GPU {best_gpu.id} ({best_gpu.name}) - "
                           f"{best_gpu.memory_free:.1f}GB free, "
                           f"{best_gpu.utilization:.1f}% util")
            
            return best_gpu.id
                
        except Exception as e:
            logger.error(f"GPU selection failed: {e}")
            return None

    def get_optimal_device(self) -> str:
        """
        Determine the optimal device (CPU or GPU) based on workload and available resources
        
        Returns:
            str: 'cuda' for GPU, 'cpu' for CPU
        """
        try:
            # Check if GPU is available at all
            torch, is_torch_available = get_torch()
            if not is_torch_available or not torch.cuda.is_available():
                return 'cpu'
                
            # Get current resource metrics
            metrics = self.get_resource_metrics()
            
            # Check if CPU is heavily loaded
            if metrics.cpu_percent > 85:
                # If CPU is overloaded but GPU is available, use GPU
                return 'cuda'
                
            # Check available GPU memory and utilization
            gpu_metrics = self.get_gpu_metrics()
            
            if not gpu_metrics:
                return 'cpu'
                
            # Check each GPU
            for gpu in gpu_metrics:
                # Skip if GPU is overheating
                if gpu.get('temperature', 0) > self.temperature_threshold:
                    continue
                    
                # Skip if GPU is heavily utilized
                if gpu.get('utilization', 0) > 80:
                    continue
                    
                # Check if enough free memory
                free_memory_gb = gpu.get('memory_free', 0)
                if free_memory_gb > self.min_free_gpu_mem:
                    return 'cuda'
                    
            # Default to CPU if no suitable GPU found
            return 'cpu'
            
        except Exception as e:
            logger.warning(f"Error determining optimal device: {e}")
            return 'cpu'
            
    def cleanup_resources(self, intensity: str = 'light'):
        """
        Release unused resources and optimize memory usage
        
        Args:
            intensity: Level of cleanup ('light', 'medium', 'aggressive')
        """
        try:
            # Always collect garbage
            gc.collect()
            
            # Medium or aggressive cleanup
            if intensity in ['medium', 'aggressive']:
                # Clear torch cache if available
                torch, is_torch_available = get_torch()
                if is_torch_available and hasattr(torch, 'cuda') and hasattr(torch.cuda, 'empty_cache'):
                    torch.cuda.empty_cache()
                      # Clear sklearn caches if possible
                try:
                    from sklearn.utils import _joblib
                    if hasattr(_joblib, 'Memory'):
                        _joblib.Memory.clear()
                except Exception as e:
                    logger.debug(f"Could not clear sklearn cache: {e}")
                    pass
                    
            # Aggressive cleanup
            if intensity == 'aggressive':                # Force release GPU memory by reinitializing torch
                if 'torch' in sys.modules:
                    try:
                        # Reinitialize via helper function
                        _torch_module = sys.modules.pop('torch', None)
                        new_torch, new_torch_available = _isolated_torch_import()
                        
                        # Update global variables via function to avoid global declaration issues
                        def _update_globals():
                            global torch, TORCH_AVAILABLE
                            torch = new_torch
                            TORCH_AVAILABLE = new_torch_available
                        
                        _update_globals()
                    except Exception as e:
                        logger.warning(f"Error reinitializing torch: {e}")
                        pass
                
                # Release any numpy caches
                try:
                    np.random.seed(None)  # Reset random state
                    for arr_name in list(globals()):
                        if isinstance(globals()[arr_name], np.ndarray):
                            del globals()[arr_name]
                except:
                    pass
                
                # Force multiple rounds of garbage collection
                for _ in range(3):
                    gc.collect()
                    
            # Log the cleanup
            logger.debug(f"Resource cleanup completed ({intensity})")
            
        except Exception as e:
            logger.warning(f"Error during resource cleanup: {e}")
            
    def get_prediction_eta(self, symbol: str, timeframe: str) -> Dict[str, Any]:
        """
        Calculate estimated time for prediction completion
        
        Args:
            symbol: Symbol being predicted
            timeframe: Timeframe being used
            
        Returns:
            Dict with ETA information
        """
        try:
            # Check if prediction is in progress
            if not training_status.get('predicting', False):
                return {
                    'eta_seconds': 0,
                    'progress_percent': 100,
                    'status': 'Not predicting'
                }
                
            # Get prediction status
            predict_done = training_status.get('predict_done', 0)
            predict_total = training_status.get('predict_total_steps', 5)
            start_time_str = training_status.get('predict_start_time', None)
            
            if not start_time_str:
                return {
                    'eta_seconds': 0,
                    'progress_percent': 0,
                    'status': 'Unknown start time'
                }
                
            # Calculate progress
            progress_percent = (predict_done / predict_total) * 100 if predict_total > 0 else 0
            
            # Calculate elapsed time
            start_time = datetime.fromisoformat(start_time_str)
            elapsed_seconds = (datetime.now() - start_time).total_seconds()
            
            # Calculate ETA
            if predict_done > 0:
                seconds_per_step = elapsed_seconds / predict_done
                remaining_steps = predict_total - predict_done
                eta_seconds = seconds_per_step * remaining_steps
            else:
                # Default estimate based on typical performance
                eta_seconds = 30  # Default estimate for unknown progress
                
            # Get resource utilization
            metrics = self.get_resource_metrics()
            
            # Add system performance context
            result = {
                'eta_seconds': round(eta_seconds),
                'elapsed_seconds': round(elapsed_seconds),
                'progress_percent': round(progress_percent, 1),
                'steps_done': predict_done,
                'total_steps': predict_total,
                'cpu_percent': metrics.cpu_percent,
                'memory_percent': metrics.memory_percent,
                'device': training_status.get('device_used', 'CPU'),
                'status': training_status.get('predict_status', 'In progress'),
                'symbol': symbol,
                'timeframe': timeframe
            }
            
            return result
            
        except Exception as e:
            logger.warning(f"Error calculating prediction ETA: {e}")
            return {
                'eta_seconds': 0,
                'progress_percent': 0,
                'status': f'Error: {str(e)}'
            }
    
    def get_training_eta(self, step_name: str = None, step_number: int = None, total_steps: int = None) -> Dict[str, Any]:
        """
        Calculate estimated time for training completion
        
        Args:
            step_name: Current step name (optional)
            step_number: Current step number (optional)
            total_steps: Total number of steps (optional)
            
        Returns:
            Dict with ETA information for training
        """
        try:
            # Check if training is in progress
            if not training_status.get('train_running', False):
                return {
                    'eta_seconds': 0,
                    'progress_percent': 100,
                    'status': 'Not training'
                }
                
            # Get training status
            train_progress = training_status.get('train_progress', 0)
            train_status = training_status.get('train_status', '')
            start_time_str = training_status.get('train_start_time', None)
            current_model = training_status.get('current_model', '')
            
            # Use provided values or get from training_status
            if step_name is None:
                step_name = training_status.get('current_step', '')
            
            if step_number is None:
                step_number = int(train_progress * 100) if train_progress else 0
                
            if total_steps is None:
                total_steps = training_status.get('total_steps', 100)
                
            # Handle missing start time
            if not start_time_str:
                # Try to use current timestamp as fallback
                training_status['train_start_time'] = datetime.now().isoformat()
                start_time = datetime.now()
                elapsed_seconds = 0
            else:
                # Calculate elapsed time
                try:
                    start_time = datetime.fromisoformat(start_time_str)
                    elapsed_seconds = (datetime.now() - start_time).total_seconds()
                except (ValueError, TypeError):
                    # Fallback if timestamp format is invalid
                    start_time = datetime.now()
                    elapsed_seconds = 0
                    training_status['train_start_time'] = start_time.isoformat()
            
            # Calculate progress
            progress_percent = (step_number / total_steps) * 100 if total_steps > 0 else train_progress * 100
            
            # Calculate ETA
            if step_number > 0 and total_steps > 0:
                seconds_per_step = elapsed_seconds / step_number
                remaining_steps = total_steps - step_number
                eta_seconds = seconds_per_step * remaining_steps
            else:
                # Default estimate based on typical performance
                eta_seconds = 600  # Default estimate for unknown progress
                  # Format times
            from app_ui import format_eta
            eta_str = format_eta(eta_seconds)
            elapsed_str = format_eta(elapsed_seconds)
            
            # Get resource utilization
            metrics = self.get_resource_metrics()
            
            # Add system performance context
            result = {
                'eta_seconds': round(eta_seconds),
                'eta_formatted': eta_str,
                'elapsed_seconds': round(elapsed_seconds),
                'elapsed_formatted': elapsed_str,
                'progress_percent': round(progress_percent, 1),
                'step_name': step_name,
                'step_number': step_number,
                'total_steps': total_steps,
                'current_model': current_model,
                'status': train_status,
                'cpu_percent': metrics.cpu_percent if metrics else 0,
                'memory_percent': metrics.memory_percent if metrics else 0,
                'rate': elapsed_seconds / max(step_number, 1) if step_number > 0 else 0
            }
            
            return result
            
        except Exception as e:
            logger.error(f"Error calculating training ETA: {e}")
            return {
                'eta_seconds': 0,
                'progress_percent': 0,
                'status': f'Error: {str(e)}',
                'elapsed_seconds': 0
            }

    def start_monitoring(self, interval: int = 60):
        """
        Start background system monitoring with specified interval
        
        Args:
            interval: Monitoring interval in seconds
        """
        global _monitoring_thread, _monitoring_interval, _stop_monitoring
        
        try:
            if _monitoring_thread is not None and _monitoring_thread.is_alive():
                logger.info("Monitoring thread already running")
                return
                
            _monitoring_interval = interval
            _stop_monitoring.clear()
            
            def monitoring_task():
                logger.info(f"System monitoring started (interval: {interval}s)")
                last_log = time.time() - interval
                
                while not _stop_monitoring.is_set():
                    try:
                        # Get current system stats
                        stats = self.get_system_stats()
                        
                        # Log stats periodically
                        current_time = time.time()
                        if current_time - last_log > 300:  # Log every 5 minutes
                            if stats:
                                health_score = self.get_health_score()
                                logger.info(f"System Health: {health_score:.1f}/100 | "
                                           f"CPU: {stats.cpu_percent:.1f}% | "
                                           f"RAM: {stats.memory_percent:.1f}%")
                            last_log = current_time
                            
                        # Sleep until next check
                        _stop_monitoring.wait(interval)
                        
                    except Exception as e:
                        logger.error(f"Error in monitoring thread: {e}")
                        _stop_monitoring.wait(interval)
                
                logger.info("System monitoring stopped")
            
            # Start monitoring in background thread
            _monitoring_thread = threading.Thread(
                target=monitoring_task, 
                name="SystemMonitor",
                daemon=True
            )
            _monitoring_thread.start()
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to start system monitoring: {e}")
            return False
            
    def get_health_score(self) -> float:
        """Calculate system health score (0-100)"""
        try:
            # Get latest metrics
            metrics = self.get_resource_metrics()
            if metrics is None:
                return 50.0  # Default score
                
            # Base score starts at 100
            score = 100.0
            
            # CPU penalty (0-30 points)
            if metrics.cpu_percent > 85:
                score -= 30
            elif metrics.cpu_percent > 70:
                score -= 20
            elif metrics.cpu_percent > 50:
                score -= 10
                
            # Memory penalty (0-30 points)
            if metrics.memory_percent > 90:
                score -= 30
            elif metrics.memory_percent > 80:
                score -= 20
            elif metrics.memory_percent > 70:
                score -= 10
                
            # GPU penalty (0-20 points)
            if self.has_gpu and metrics.gpu_metrics:
                try:
                    # Average GPU utilization
                    gpu_utils = [gpu.get('utilization', 0) for gpu in metrics.gpu_metrics 
                                if isinstance(gpu, dict) and 'utilization' in gpu]
                    
                    if gpu_utils:
                        avg_gpu_util = sum(gpu_utils) / len(gpu_utils)
                        if avg_gpu_util > 90:
                            score -= 20
                        elif avg_gpu_util > 80:
                            score -= 15
                        elif avg_gpu_util > 70:
                            score -= 10
                except:
                    pass
            
            # Temperature penalty (0-20 points)
            if metrics.temperature is not None:
                if metrics.temperature > 90:
                    score -= 20
                elif metrics.temperature > 80:
                    score -= 15
                elif metrics.temperature > 70:
                    score -= 10
                    
            # Ensure score is within bounds
            return max(0, min(score, 100))
            
        except Exception as e:
            logger.warning(f"Error calculating health score: {e}")
            return 50.0  # Default score
    
    def get_resource_metrics(self) -> ResourceMetrics:
        """Get current resource metrics with minimal overhead"""
        try:
            # Declare globals first
            global _last_resource_check, _resource_cache
            
            # Check if cached metrics are fresh enough
            current_time = datetime.now()
            time_diff = (current_time - _last_resource_check).total_seconds()
            
            if time_diff < _resource_cache_ttl and _resource_cache:
                return _resource_cache.get('metrics')
                
            # Get fresh metrics
            metrics = self.get_system_stats()
            
            # Update cache
            _last_resource_check = current_time
            _resource_cache = {'metrics': metrics}
            
            return metrics
            
        except Exception as e:
            logger.error(f"Error getting resource metrics: {e}")
            return None

    def suggest_workers(self, requested_workers: int = None) -> int:
        """Suggest optimal number of workers with dynamic scaling"""
        try:
            cpu_count = os.cpu_count() or 4
            total_ram_gb = psutil.virtual_memory().total / (1024**3)
            
            # Dynamic scaling based on system capabilities
            max_allowed = min(
                cpu_count * 2,  # CPU-based limit
                int(total_ram_gb * 2),  # RAM-based limit
                MAX_WORKERS  # Global limit
            )
            
            if requested_workers is not None:
                return min(requested_workers, max_allowed)
            return max_allowed
        except Exception as e:
            logger.warning(f"Error suggesting workers: {e}")
            return min(4, os.cpu_count() or 4)

    def get_optimal_parallel_config(self) -> Dict[str, int]:
        """Get optimal parallel configuration with dynamic settings"""
        cpu_count = os.cpu_count() or 4
        ram_gb = psutil.virtual_memory().total / (1024**3)
        
        workers = self.suggest_workers()
        
        return {
            "max_workers": workers,
            "cpu_count": cpu_count,
            "ram_gb": int(ram_gb),
            "recommended_batch_size": min(64, max(8, workers * 4)),
            "io_workers": min(workers * 2, 16),
            "processing_workers": max(1, workers // 2)
        }

    def check_resource_limits(self, memory_threshold: float = None, cpu_threshold: float = None) -> bool:
        """Check system resource limits with automatic optimization"""
        try:
            memory_threshold = memory_threshold or self.memory_threshold
            cpu_threshold = cpu_threshold or self.target_cpu
            
            metrics = self.get_system_stats()
            if metrics is None:
                return True  # Allow continuation if can't get metrics
            
            # Check and auto-optimize if needed
            if metrics.memory_percent > memory_threshold:
                logger.warning(f"Memory usage high ({metrics.memory_percent:.1f}%), auto-optimizing...")
                self.cleanup_resources(intensity='moderate')
                
                # Re-check after cleanup
                updated_metrics = self.get_system_stats()
                if updated_metrics and updated_metrics.memory_percent > memory_threshold:
                    return False
            
            if metrics.cpu_percent > cpu_threshold:
                logger.warning(f"CPU usage high ({metrics.cpu_percent:.1f}%), auto-optimizing...")
                self.cleanup_resources(intensity='light')
                
            return True
            
        except Exception as e:
            logger.error(f"Error checking resource limits: {e}")
            return True
    def initialize_training_progress(self, total_steps: int, progress_callback: callable = None):
            """
            Khởi tạo trạng thái tiến trình huấn luyện
            
            Args:
                total_steps: Tổng số bước huấn luyện
                progress_callback: Callback function để cập nhật tiến trình (optional)
            """
            # Cập nhật training_status
            training_status.update({
                'train_running': True,
                'train_progress': 0.0,
                'train_status': 'Khởi tạo huấn luyện',
                'train_error': None,
                'train_start_time': datetime.now().isoformat(),
                'total_steps': total_steps,
                'current_step': 'Initialization',
                'step_number': 0,
                'progress_callback': progress_callback
            })
            
            logger.info(f"Training progress initialized with {total_steps} steps")
        
    def update_training_progress(self, step_name: str, step_number: int, additional_info: dict = None):
            """
            Cập nhật tiến trình huấn luyện
            
            Args:
                step_name: Tên của bước huấn luyện hiện tại
                step_number: Số thứ tự của bước hiện tại
                additional_info: Thông tin bổ sung (optional)
            """
            # Lấy thông tin hiện tại
            total_steps = training_status.get('total_steps', 100)
            progress = step_number / total_steps if total_steps > 0 else 0
            
            # Tính toán ETA
            eta_info = self.get_training_eta(step_name, step_number, total_steps)
            
            # Cập nhật trạng thái
            update_data = {
                'train_status': f"🚀 {step_name}... {progress*100:.1f}%",
                'train_progress': progress,
                'current_step': step_name,
                'step_number': step_number,
                'eta': eta_info.get('eta_formatted', ''),
                'eta_info': eta_info
            }
            
            # Thêm thông tin bổ sung nếu có
            if additional_info and isinstance(additional_info, dict):
                update_data.update(additional_info)
            
            # Cập nhật training_status            
            training_status.update(update_data)
            
            # Gọi callback nếu có
            progress_callback = training_status.get('progress_callback')
            if progress_callback and callable(progress_callback):
                try:
                    progress_callback(progress, eta_info)
                except Exception as e:
                    logger.error(f"Error in progress callback: {e}")
            
            logger.debug(f"Training progress updated: {step_name} ({step_number}/{total_steps})")
    
    def submit_tasks(self, tasks, task_type='general'):
        """
        Submit a list of tasks to the thread pool and return a list of futures.
        Each task should be a tuple: (func, args, kwargs)
        """
        if not hasattr(self, 'thread_pool') or self.thread_pool is None:
            optimal_workers = self.get_optimal_workers(task_type=task_type)
            self.thread_pool = ThreadPoolExecutor(
                max_workers=optimal_workers,
                thread_name_prefix="ResourceManager"
            )
        futures = []
        for task in tasks:
            if len(task) == 3:
                func, args, kwargs = task
            elif len(task) == 2:
                func, args = task
                kwargs = {}
            else:
                func = task[0]
                args = ()
                kwargs = {}
            futures.append(self.thread_pool.submit(func, *args, **kwargs))
        return futures

    def safe_load_dataframe(self, filepath, filetype=None, chunk_size=100_000, max_ram_usage=0.9, wait_time=180, **kwargs):
        """
        Nạp DataFrame lớn một cách thông minh, kiểm soát RAM:
        - Chỉ nạp batch vừa đủ để tổng RAM không vượt quá max_ram_usage (mặc định 90%).
        - Nếu không đủ RAM, xếp hàng đợi wait_time (giây), sau đó kiểm tra lại.
        - Hỗ trợ CSV (chunk) và Parquet (row_group).
        """
        import pandas as pd
        import os
        import time
        filetype = filetype or os.path.splitext(filepath)[-1].lower().replace('.', '')
        stats = self.get_system_stats()
        total_mem_gb = psutil.virtual_memory().total / (1024**3)
        max_allowed_percent = int(max_ram_usage * 100)
        logger.info(f"[ResourceManager] Tổng RAM: {total_mem_gb:.2f} GB, sẽ không vượt quá {max_allowed_percent}% khi nạp {filepath}")
        df = None
        try:
            if filetype in ['csv', 'txt']:
                file_size_mb = os.path.getsize(filepath) / 1e6
                chunks = []
                reader = pd.read_csv(filepath, chunksize=chunk_size, **kwargs)
                chunk_idx = 0
                for chunk in reader:
                    chunk_idx += 1
                    # Ước lượng RAM sẽ dùng nếu nạp thêm chunk này
                    stats = self.get_system_stats()
                    used_gb = total_mem_gb * (stats.memory_percent / 100) if stats else 0
                    chunk_mem_gb = chunk.memory_usage(deep=True).sum() / 1e9
                    est_after_gb = used_gb + chunk_mem_gb
                    est_after_percent = (est_after_gb / total_mem_gb) * 100
                    if est_after_percent > max_allowed_percent:
                        logger.warning(f"⚠️ Batch {chunk_idx}: Nếu nạp sẽ vượt {max_allowed_percent}% RAM ({est_after_percent:.1f}%). Đợi giải phóng RAM {wait_time//60} phút...")
                        waited = 0
                        while est_after_percent > max_allowed_percent and waited < 3600:
                            time.sleep(wait_time)
                            waited += wait_time
                            stats = self.get_system_stats()
                            used_gb = total_mem_gb * (stats.memory_percent / 100) if stats else 0
                            est_after_gb = used_gb + chunk_mem_gb
                            est_after_percent = (est_after_gb / total_mem_gb) * 100
                            logger.info(f"⏳ Đã đợi {waited//60} phút, RAM hiện tại: {stats.memory_percent:.1f}%")
                        if est_after_percent > max_allowed_percent:
                            logger.error(f"❌ Sau khi đợi vẫn không đủ RAM, dừng nạp batch này!")
                            break
                    chunks.append(chunk)
                    logger.info(f"✅ Đã nạp batch {chunk_idx}, RAM hiện tại: {stats.memory_percent:.1f}%")
                if chunks:
                    df = pd.concat(chunks, axis=0, ignore_index=True)
            elif filetype in ['parquet']:
                import pyarrow.parquet as pq
                table = pq.read_table(filepath)
                batch_size = min(chunk_size, table.num_rows)
                batches = []
                for i in range(0, table.num_rows, batch_size):
                    batch = table.slice(i, batch_size).to_pandas()
                    stats = self.get_system_stats()
                    used_gb = total_mem_gb * (stats.memory_percent / 100) if stats else 0
                    batch_mem_gb = batch.memory_usage(deep=True).sum() / 1e9
                    est_after_gb = used_gb + batch_mem_gb
                    est_after_percent = (est_after_gb / total_mem_gb) * 100
                    if est_after_percent > max_allowed_percent:
                        logger.warning(f"⚠️ Nếu nạp batch sẽ vượt {max_allowed_percent}% RAM ({est_after_percent:.1f}%). Đợi giải phóng RAM {wait_time//60} phút...")
                        waited = 0
                        while est_after_percent > max_allowed_percent and waited < 3600:
                            time.sleep(wait_time)
                            waited += wait_time
                            stats = self.get_system_stats()
                            used_gb = total_mem_gb * (stats.memory_percent / 100) if stats else 0
                            est_after_gb = used_gb + batch_mem_gb
                            est_after_percent = (est_after_gb / total_mem_gb) * 100
                            logger.info(f"⏳ Đã đợi {waited//60} phút, RAM hiện tại: {stats.memory_percent:.1f}%")
                        if est_after_percent > max_allowed_percent:
                            logger.error(f"❌ Sau khi đợi vẫn không đủ RAM, dừng nạp batch này!")
                            break
                    batches.append(batch)
                    logger.info(f"✅ Đã nạp batch Parquet, RAM hiện tại: {stats.memory_percent:.1f}%")
                if batches:
                    df = pd.concat(batches, axis=0, ignore_index=True)
            else:
                logger.warning(f"[ResourceManager] Định dạng file {filetype} chưa hỗ trợ tối ưu, nạp trực tiếp")
                df = pd.read_csv(filepath, **kwargs)
            logger.info(f"[ResourceManager] Nạp DataFrame thành công: {df.shape if df is not None else None}")
            return df
        except Exception as e:
            logger.error(f"[ResourceManager] Lỗi khi nạp DataFrame: {e}")
            return None

    def safe_process_batches(self, df_or_path, process_func, batch_size=100_000, filetype=None, max_ram_usage=0.9, wait_time=180, **kwargs):
        """
        Xử lý DataFrame lớn theo batch một cách an toàn với RAM:
        - df_or_path: DataFrame hoặc đường dẫn file (csv/parquet)
        - process_func: hàm xử lý từng batch (nhận DataFrame, trả về kết quả hoặc None)
        - batch_size: số dòng mỗi batch
        - filetype: tự động nhận diện nếu không truyền vào
        - max_ram_usage: ngưỡng RAM tối đa (mặc định 90%)
        - wait_time: thời gian chờ khi thiếu RAM (giây)
        - kwargs: tham số cho pd.read_csv hoặc pq.read_table
        Kết quả: trả về list kết quả từng batch (nếu process_func trả về)
        """
        import pandas as pd
        import os
        import time
        results = []
        total_mem_gb = psutil.virtual_memory().total / (1024**3)
        max_allowed_percent = int(max_ram_usage * 100)
        # Nếu là file path thì nạp từng batch, nếu là DataFrame thì chia batch
        if isinstance(df_or_path, str):
            filetype = filetype or os.path.splitext(df_or_path)[-1].lower().replace('.', '')
            if filetype in ['csv', 'txt']:
                reader = pd.read_csv(df_or_path, chunksize=batch_size, **kwargs)
                for idx, batch in enumerate(reader):
                    # Kiểm soát RAM trước khi xử lý batch
                    stats = self.get_system_stats()
                    used_gb = total_mem_gb * (stats.memory_percent / 100) if stats else 0
                    batch_mem_gb = batch.memory_usage(deep=True).sum() / 1e9
                    est_after_gb = used_gb + batch_mem_gb
                    est_after_percent = (est_after_gb / total_mem_gb) * 100
                    waited = 0
                    while est_after_percent > max_allowed_percent and waited < 3600:
                        logger.warning(f"⚠️ Nếu xử lý batch {idx+1} sẽ vượt {max_allowed_percent}% RAM ({est_after_percent:.1f}%). Đợi giải phóng RAM {wait_time//60} phút...")
                        time.sleep(wait_time)
                        waited += wait_time
                        stats = self.get_system_stats()
                        used_gb = total_mem_gb * (stats.memory_percent / 100) if stats else 0
                        est_after_gb = used_gb + batch_mem_gb
                        est_after_percent = (est_after_gb / total_mem_gb) * 100
                        logger.info(f"⏳ Đã đợi {waited//60} phút, RAM hiện tại: {stats.memory_percent:.1f}%")
                    if est_after_percent > max_allowed_percent:
                        logger.error(f"❌ Sau khi đợi vẫn không đủ RAM, bỏ qua batch này!")
                        continue
                    logger.info(f"✅ Xử lý batch {idx+1}, RAM hiện tại: {stats.memory_percent:.1f}%")
                    res = process_func(batch)
                    if res is not None:
                        results.append(res)
            elif filetype in ['parquet']:
                import pyarrow.parquet as pq
                table = pq.read_table(df_or_path)
                for i in range(0, table.num_rows, batch_size):
                    batch = table.slice(i, batch_size).to_pandas()
                    stats = self.get_system_stats()
                    used_gb = total_mem_gb * (stats.memory_percent / 100) if stats else 0
                    batch_mem_gb = batch.memory_usage(deep=True).sum() / 1e9
                    est_after_gb = used_gb + batch_mem_gb
                    est_after_percent = (est_after_gb / total_mem_gb) * 100
                    waited = 0
                    while est_after_percent > max_allowed_percent and waited < 3600:
                        logger.warning(f"⚠️ Nếu xử lý batch Parquet sẽ vượt {max_allowed_percent}% RAM ({est_after_percent:.1f}%). Đợi giải phóng RAM {wait_time//60} phút...")
                        time.sleep(wait_time)
                        waited += wait_time
                        stats = self.get_system_stats()
                        used_gb = total_mem_gb * (stats.memory_percent / 100) if stats else 0
                        est_after_gb = used_gb + batch_mem_gb
                        est_after_percent = (est_after_gb / total_mem_gb) * 100
                        logger.info(f"⏳ Đã đợi {waited//60} phút, RAM hiện tại: {stats.memory_percent:.1f}%")
                    if est_after_percent > max_allowed_percent:
                        logger.error(f"❌ Sau khi đợi vẫn không đủ RAM, bỏ qua batch này!")
                        continue
                    logger.info(f"✅ Xử lý batch Parquet, RAM hiện tại: {stats.memory_percent:.1f}%")
                    res = process_func(batch)
                    if res is not None:
                        results.append(res)
            else:
                logger.warning(f"[ResourceManager] Định dạng file {filetype} chưa hỗ trợ tối ưu, xử lý toàn bộ file")
                df = pd.read_csv(df_or_path, **kwargs)
                res = process_func(df)
                if res is not None:
                    results.append(res)
        else:
            # Nếu là DataFrame, chia batch và kiểm soát RAM
            df = df_or_path
            n = len(df)
            for i in range(0, n, batch_size):
                batch = df.iloc[i:i+batch_size]
                stats = self.get_system_stats()
                used_gb = total_mem_gb * (stats.memory_percent / 100) if stats else 0
                batch_mem_gb = batch.memory_usage(deep=True).sum() / 1e9
                est_after_gb = used_gb + batch_mem_gb
                est_after_percent = (est_after_gb / total_mem_gb) * 100
                waited = 0
                while est_after_percent > max_allowed_percent and waited < 3600:
                    logger.warning(f"⚠️ Nếu xử lý batch DataFrame sẽ vượt {max_allowed_percent}% RAM ({est_after_percent:.1f}%). Đợi giải phóng RAM {wait_time//60} phút...")
                    time.sleep(wait_time)
                    waited += wait_time
                    stats = self.get_system_stats()
                    used_gb = total_mem_gb * (stats.memory_percent / 100) if stats else 0
                    est_after_gb = used_gb + batch_mem_gb
                    est_after_percent = (est_after_gb / total_mem_gb) * 100
                    logger.info(f"⏳ Đã đợi {waited//60} phút, RAM hiện tại: {stats.memory_percent:.1f}%")
                if est_after_percent > max_allowed_percent:
                    logger.error(f"❌ Sau khi đợi vẫn không đủ RAM, bỏ qua batch này!")
                    continue
                logger.info(f"✅ Xử lý batch DataFrame, RAM hiện tại: {stats.memory_percent:.1f}%")
                res = process_func(batch)
                if res is not None:
                    results.append(res)
        return results
# Professional resource manager singleton
def get_resource_manager():
    """Get the professional resource manager singleton instance"""
    return UnifiedResourceManager()

