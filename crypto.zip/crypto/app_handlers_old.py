"""
App Handlers Module - Contains all tab/function handlers
All Streamlit UI logic is contained here
"""

# Apply import fixes and warning suppression FIRST
import warnings
warnings.filterwarnings("ignore")
import os
os.environ['PYTHONWARNINGS'] = 'ignore'

try:
    from config.logging_config import apply_compatibility_fixes
    apply_compatibility_fixes()
except:
    pass

# Suppress streamlit warnings before import
import logging
logging.getLogger('streamlit.runtime.scriptrunner_utils.script_run_context').setLevel(logging.ERROR)
logging.getLogger('streamlit.runtime.state.session_state_proxy').setLevel(logging.ERROR)

import streamlit as st
import pandas as pd
import gzip
import json
import os
import pickle
import pytz
import requests
import threading
import time
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from streamlit_autorefresh import st_autorefresh
from datetime import datetime, timedelta
from typing import Dict, Any, Optional

from config.settings import MODEL_DIR, DATA_DIR, TIMEFRAMES
from config.logging_config import get_logger

logger = get_logger(__name__)

# ==================== STREAMLIT CONTEXT UTILITIES ====================

def has_streamlit_context():
    """Check if we're running in a proper Streamlit context"""
    try:
        # Try to access Streamlit's runtime context
        from streamlit.runtime.scriptrunner import get_script_run_ctx
        return get_script_run_ctx() is not None
    except:
        try:
            # Fallback method - try to access session_state
            import streamlit as st_check
            _ = st_check.session_state
            return True
        except:
            return False

def safe_session_state_get(key: str, default=None):
    """Safely get value from Streamlit session state"""
    if has_streamlit_context():
        try:
            return st.session_state.get(key, default)
        except Exception as e:
            logger.debug(f"Could not access session state key '{key}': {e}")
            return default
    return default

def safe_session_state_set(key: str, value):
    """Safely set value in Streamlit session state"""
    if has_streamlit_context():
        try:
            st.session_state[key] = value
            return True
        except Exception as e:
            logger.debug(f"Could not set session state key '{key}': {e}")
            return False
    return False

def safe_session_state_update(updates: dict):
    """Safely update multiple session state values"""
    if has_streamlit_context():
        try:
            for key, value in updates.items():
                st.session_state[key] = value
            return True
        except Exception as e:
            logger.debug(f"Could not update session state: {e}")
            return False
    return False

# Import từ các modules khác
from ai_optimizer.unified_resource_manager import (
    get_resource_manager,
    training_status
)

# Initialize DataFrame field if needed
def init_training_status():
    """Initialize training_status DataFrame field if needed"""
    if training_status.get("train_results_df") is None:
        training_status["train_results_df"] = pd.DataFrame(columns=["timeframe", "model", "accuracy", "backtest_accuracy"])

# Initialize on module load
init_training_status()

# ==================== SESSION STATE INITIALIZATION ====================

def initialize_session_state():
    """Initialize all session state variables to prevent AttributeError"""
    default_states = {        # Trading Symbol
        "symbol": "BTCUSDT",
        "timeframe": "5m",
        "selected_timeframe": "15m",
        
        # Data Loading
        "data_loaded": False,
        "last_data_load": None,
        "price_data": {},
        
        # Training States
        "training": False,
        "train_progress": 0.0,
        "train_status": "",
        "train_error": None,
        "train_results": [],
        "train_results_df": pd.DataFrame(columns=["timeframe", "model", "accuracy", "backtest_accuracy"]),
        "current_model": "",
        "eta": None,
        "train_markdown": "",
        
        # Prediction States
        "predicting": False,
        "predict_done": 0,
        "predict_total_steps": 0,
        "prediction_ready": False,
        "predictions": None,
        "predictions_df": pd.DataFrame(),
        
        # UI States
        "auto_refresh": False,
        "show_advanced": False,
        "selected_tab": "📊 Dashboard",
        
        # Model Training Settings
        "use_gpu": True,
        "use_full_data": False,
        "epochs": 20,
        "threshold": 0.01,
        "batch_size": 64,
        "horizon": 12,
        
        # Resource Management
        "parallel_training": True,
        "max_parallel_jobs": 4,
        "gpu_enabled": False,
        
        # Cache Control
        "force_refresh": False,
        "last_refresh": None,
    }
      # Initialize only missing keys to preserve existing values
    for key, default_value in default_states.items():
        if safe_session_state_get(key) is None:
            safe_session_state_set(key, default_value)
            
    logger.debug("✅ Session state initialized successfully")

# ==================== UTILITY FUNCTIONS FROM APP_UTILS ====================
# Tích hợp tất cả utility functions từ app_utils.py

def format_eta(seconds: float) -> str:
    """Format ETA seconds to HH:MM:SS"""
    if seconds <= 0:
        return "00:00:00"
    hours, remainder = divmod(int(seconds), 3600)
    minutes, secs = divmod(remainder, 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}"

def format_price(price: float) -> str:
    """Format price for display"""
    if price >= 1000:
        return f"{price:,.2f}"
    elif price >= 1:
        return f"{price:.4f}"
    else:
        return f"{price:.6f}"

def fetch_current_price(symbol: str) -> float:
    """Fetch current price from Binance"""
    url = f"https://api.binance.com/api/v3/ticker/price?symbol={symbol}"
    resp = requests.get(url, timeout=10)
    resp.raise_for_status()
    return float(resp.json()["price"])

def get_base_price(symbol: str) -> float:
    """Get base price (7AM VN time) for comparison"""
    vn_tz = pytz.timezone("Asia/Ho_Chi_Minh")
    now_vn = datetime.now(vn_tz)
    base_dt = now_vn.replace(hour=7, minute=0, second=0, microsecond=0)
    start_ms = int(base_dt.timestamp() * 1000)
    end_ms = start_ms + 60*60*1000 - 1

    resp = requests.get(
        "https://api.binance.com/api/v3/klines",
        params={
            "symbol": symbol,
            "interval": "1h",
            "startTime": start_ms,
            "endTime": end_ms,
            "limit": 1
        },
        timeout=5
    )
    resp.raise_for_status()
    klines = resp.json()
    if klines and len(klines[0]) >= 5:
        return float(klines[0][4])  # Close price
    return 0.0

def eta(start_time: float, done: int, total: int) -> str:
    """Calculate ETA"""
    if done == 0 or total == 0:
        return "--:--:--"
    elapsed = time.time() - start_time
    rate = elapsed / done
    remaining = (total - done) * rate
    return format_eta(remaining)

# Note: Removed redundant init_session_defaults() and setup_session_state() functions
# These duplicate functionality already provided by initialize_session_state()

# REMOVED: Cache functions moved to UnifiedResultsManager
# - load_cached_data() → Use UnifiedResultsManager.get_prediction_performance()
# - save_prediction_cache() → Automatic saving in EnsemblePredictor  
# - save_chart_cache() → Not needed, charts generated on-demand

def load_cached_chart(symbol: str):
    """Load cached chart data"""
    try:
        chart_path = os.path.join(MODEL_DIR, f"{symbol}_last_chart.pkl")
        if os.path.exists(chart_path):
            with open(chart_path, "rb") as f:
                chart = pickle.load(f)
            return chart, {}
        return None, {}
    except Exception as e:
        logger.error(f"Error loading cached chart: {e}")        
        return None, {}

# Note: Removed unused fmt_pred_display() and get_refresh_interval() functions
# These were not being called anywhere in the codebase

# cleanup_resources function moved to unified_resource_manager.py

# REMOVED: load_accuracy_cache() - Use UnifiedResultsManager.get_latest_accuracy() instead

def load_training_results():
    """Load training results from UnifiedResultsManager"""
    try:
        from ai_models.unified_results_manager import UnifiedResultsManager
        results_manager = UnifiedResultsManager()
        
        # Get training history
        training_history = results_manager.get_training_history(days=30)
        
        if training_history:
            # Convert to format expected by UI
            formatted_results = []
            for result in training_history:                    
                formatted_results.append({
                    'timeframe': result.get('timeframe', 'unknown'),                    'model': result.get('model_type', 'unknown'),  
                    'accuracy': result.get('accuracy', 0.0),
                    'backtest_accuracy': result.get('f1_score', 0.0),  # Use F1 as proxy
                    'training_time': result.get('training_time',  0.0)
                })
            
            if formatted_results:
                safe_session_state_set('train_results', formatted_results)
                
                # Cập nhật cả training_status để đồng bộ
                from ai_optimizer.unified_resource_manager import training_status
                training_status['train_results'] = formatted_results
                
                logger.info(f"✅ Loaded {len(formatted_results)} training results")
                return True
        
        # Fallback: Try to extract from model files if UnifiedResultsManager is empty
        return _extract_from_model_files()
            
    except Exception as e:
        logger.warning(f"Could not load from UnifiedResultsManager: {e}")
        return _extract_from_model_files()

def _extract_from_model_files():
    """Fallback: Extract results from model files directly"""
    try:
        models_dir = MODEL_DIR
        results = {}        
        if os.path.exists(models_dir):
            # FIXED: Hỗ trợ cả .pkl.gz và .pkl để đồng bộ
            model_extensions = ['.pkl.gz', '.pkl']
            
            for filename in os.listdir(models_dir):
                for ext in model_extensions:
                    if filename.endswith(ext):
                        model_path = os.path.join(models_dir, filename)
                        try:
                            # Tự động detect compression dựa trên extension
                            if ext == '.pkl.gz':
                                with gzip.open(model_path, 'rb') as f:
                                    model_data = pickle.load(f)
                            else:  # .pkl
                                with open(model_path, 'rb') as f:
                                    model_data = pickle.load(f)
                            
                            accuracy = model_data.get('accuracy')
                            if accuracy is not None:
                                base_name = filename.replace(ext, '')
                                if '_' in base_name:
                                    parts = base_name.split('_')
                                    symbol = parts[0]
                                    model_name = parts[-1]
                                    key = f"{symbol}_{model_name}"
                                    results[key] = {
                                        'accuracy': accuracy,
                                        'model_path': model_path,
                                        'last_updated': datetime.now().isoformat()
                                    }
                                    break  # Tìm thấy rồi thì dừng tìm extension khác
                        except Exception as e:
                            logger.debug(f"Could not load model {filename}: {e}")
        
        if results:
            safe_session_state_set('train_results', results)
            logger.info(f"✅ Extracted {len(results)} results from model files")
            return True
        
        return False
        
    except Exception as e:
        logger.warning(f"Could not extract from model files: {e}")
        return False

def log_function_data(function_name: str, data: Dict[str, Any]):
    """Log function data for debugging"""
    try:
        logger.debug(f"{function_name}: {data}")
    except Exception as e:
        logger.warning(f"Could not log function data: {e}")

# ==================== INTEGRATED FUNCTIONS FROM APP_CORE ====================
# Tích hợp các functions cần thiết từ app_core.py để tạo module tối ưu duy nhất

def create_chart(df: pd.DataFrame, pred: Dict[str, Any] = None, tp_sl: Dict[str, Any] = None):
    """Create optimized price chart"""
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.05,
                       row_heights=[0.7, 0.3], subplot_titles=("Price/USDT", "Indicators"))
    
    # Get time column (handle both 'time' and 'timestamp')
    time_col = 'time' if 'time' in df.columns else ('timestamp' if 'timestamp' in df.columns else df.index)
    
    # Candlestick
    fig.add_trace(go.Candlestick(x=df[time_col] if isinstance(time_col, str) else time_col, 
                                open=df['open'], high=df['high'],
                                low=df['low'], close=df['close'], name="OHLC",
                                increasing_line_color='#26a69a', decreasing_line_color='#ef5350'),
                  row=1, col=1)
      # EMAs
    for ema, color, width in [('ema9', '#f48fb1', 1), ('ema21', '#90caf9', 1.5), ('ema55', '#ffcc80', 2)]:
        if ema in df.columns:
            fig.add_trace(go.Scatter(x=df[time_col] if isinstance(time_col, str) else time_col, 
                                   y=df[ema], name=f"ema {ema[3:]}",
                                   line=dict(color=color, width=width)), row=1, col=1)
    
    # RSI
    if 'rsi' in df.columns:
        fig.add_trace(go.Scatter(x=df[time_col] if isinstance(time_col, str) else time_col, 
                               y=df['rsi'], name="rsi",
                               line=dict(color='#a5d6a7', width=1.5)), row=2, col=1)
        # RSI reference lines
        x_vals = df[time_col] if isinstance(time_col, str) else time_col
        for level, color in [(70, 'rgba(239,83,80,0.5)'), (30, 'rgba(38,166,154,0.5)')]:
            fig.add_trace(go.Scatter(x=[x_vals.iloc[0], x_vals.iloc[-1]], y=[level, level],
                                   name=f"rsi {level}", line=dict(color=color, width=1, dash='dash')), row=2, col=1)
      # Prediction line
    if pred is not None:
        label = pred.get('label', 0)
        conf = pred.get('confidence', 0.5)
        last_price = df['close'].iloc[-1]
        change = 0.02 if label == 1 else (-0.02 if label == -1 else 0.001)
        pred_price = last_price * (1 + change)
        
        if label == 1:
            color, text = 'rgba(38,166,154,0.8)', f"BUY<br>Conf: {conf:.1%}"
        elif label == -1:
            color, text = 'rgba(239,83,80,0.8)', f"SELL<br>Conf: {conf:.1%}"
        else:
            color, text = 'rgba(128,128,128,0.8)', f"NEUTRAL<br>Conf: {conf:.1%}"
        
        x_vals = df[time_col] if isinstance(time_col, str) else time_col
        last_time = x_vals.iloc[-1]
        next_time = last_time + pd.Timedelta(minutes=30)
        
        fig.add_trace(go.Scatter(x=[last_time, next_time], y=[last_price, pred_price],
                               mode='lines', line=dict(color=color, width=3, dash='dot'),
                               name=f"Prediction"), row=1, col=1)
    
    # Layout
    fig.update_layout(title_text="Price Chart with Technical Indicators", height=600,
                     template="plotly_dark", xaxis_rangeslider_visible=False,
                     legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="center", x=0.5),
                     hovermode="x unified", margin=dict(l=10, r=10, t=50, b=10))
    
    if 'rsi' in df.columns:
        fig.update_yaxes(title_text="rsi", range=[0, 100], row=2, col=1)
    
    return fig

def show_startup_msg(pred_loaded: bool = None, chart_loaded: bool = None):
    """Show startup message based on cache status"""    # Auto-detect cache status if not provided
    if pred_loaded is None or chart_loaded is None:
        # Check if we have prediction in session state instead of calling removed function
        pred_loaded = safe_session_state_get('prediction') is not None
        chart_loaded = safe_session_state_get('chart') is not None
    
    if pred_loaded or chart_loaded:
        st.success("⚡ **Khởi động nhanh hoàn tất!** App đã load kết quả dự đoán từ cache.")
    else:
        st.info("🚀 **Khởi động nhanh!** App sẵn sàng hoạt động. Click 'Dự đoán AI cho tất cả khung thời gian' để bắt đầu tính toán.")

def render_sidebar(symbol: str = None, timeframe: str = None):
    """Render sidebar with controls and price widget"""
    # Initialize session state first to prevent AttributeError
    initialize_session_state()
      # Auto-detect symbol and timeframe from session state if not provided
    if symbol is None:
        symbol = safe_session_state_get('symbol', 'BTCUSDT')
    if timeframe is None:
        timeframe = safe_session_state_get('selected_timeframe', '15m')
        
    with st.sidebar:
        st.header("⚙️ Tùy chọn")        # Symbol selection
        new_symbol = st.selectbox("Cặp giao dịch", ["BTCUSDT"], index=0)
        current_symbol = safe_session_state_get('symbol', 'BTCUSDT')
        if new_symbol != current_symbol:
            safe_session_state_update({
                'symbol': new_symbol,
                'data_loaded': False
            })

        # Auto-refresh for price
        tf = safe_session_state_get("timeframe", "5m")
        tf_min = int(tf.rstrip("m").rstrip("h")) * (60 if "h" in tf else 1)
        st_autorefresh(interval=tf_min * 60_000, key="price_refresh")

        # Price widget
        price_container = st.empty()
        time_container = st.empty()
        show_price_widget(symbol, price_container, time_container)

        # Timeframe selection
        new_timeframe = st.selectbox(
            "Khung thời gian", 
            ["5m", "15m", "1h", "4h"],
            index=1        )        
        if new_timeframe != safe_session_state_get('selected_timeframe', '15m'):
            safe_session_state_update({
                'selected_timeframe': new_timeframe,
                'data_loaded': False
            })
        
        # Data reload button
        if st.button("🔄 Tải lại dữ liệu", key="reload_data"):
            reload_data(symbol, new_timeframe)
        
        # Prediction update button - chỉ giữ lại prediction tất cả timeframes
        if st.button(
            "🚀 Dự đoán AI cho tất cả khung thời gian",
            key="update_prediction_all",
            disabled=safe_session_state_get("predicting", False),
            help="Phân tích và dự đoán cho 5m, 15m, 30m, 1h, 4h đồng thời"
        ):
            # Chạy prediction cho tất cả timeframes PARALLEL với optimal workers
            from concurrent.futures import ThreadPoolExecutor
            timeframes = ['5m', '15m', '30m', '1h', '4h']
            safe_session_state_update({
                'predicting': True,
                'predict_done': 0,
                'predict_total_steps': len(timeframes)
            })
            
            # Get optimal workers from resource manager
            resource_manager = get_resource_manager()
            max_workers = resource_manager.suggest_workers(len(timeframes))
            
            def run_all_predictions():
                """Run predictions for all timeframes in parallel with optimal workers"""
                try:
                    with ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="PredictAll") as executor:
                        futures = {executor.submit(run_enhanced_prediction_thread, symbol, tf): tf for tf in timeframes}
                        completed = 0
                        for future in futures:
                            future.result()
                            completed += 1
                            safe_session_state_update({
                                'predict_done': completed,
                                'predict_status': f'Completed {completed}/{len(timeframes)} timeframes'
                            })
                    safe_session_state_update({
                        'predicting': False,
                        'predict_done': len(timeframes),
                        'predict_status': '✅ All timeframe predictions completed!'
                    })
                except Exception as e:
                    logger.error(f"Parallel prediction error: {e}")
                    safe_session_state_update({
                        'predicting': False,
                        'predict_status': f'❌ Parallel prediction failed: {e}'
                    })
            threading.Thread(target=run_all_predictions, daemon=True).start()
            st.info(f"🚀 Started parallel predictions for {len(timeframes)} timeframes using {max_workers} workers")
        # Prediction ETA
        show_prediction_eta()
        # Real-time clock
        show_realtime_clock()

def show_price_widget(symbol: str, price_container, time_container):
    """Show price widget with comparison"""
    try:
        price = fetch_current_price(symbol)
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        if safe_session_state_get("base_price") is None:
            try:
                safe_session_state_set("base_price", get_base_price(symbol))
            except:
                safe_session_state_set("base_price", price)

        base_price = safe_session_state_get("base_price")
        change_pct = (price - base_price) / base_price * 100 if base_price > 0 else 0
        arrow = "▲" if price >= base_price else "▼"
        color = "green" if price >= base_price else "red"
        pct_str = f"{change_pct:+.2f}%"

        price_container.markdown(
            f"**Giá {symbol}:** "
            f"<span style='color:{color}; font-size:1.3em'>"
            f"{arrow} {format_price(price)} ({pct_str})"
            "</span>",
            unsafe_allow_html=True
        )
        time_container.caption(f"Cập nhật: {ts}")

    except Exception as e:
        price_container.error("Không thể lấy giá")
        time_container.caption(f"Lỗi: {e}")

def show_realtime_clock():
    """Show real-time clock widget"""
    st.markdown("---")
    st.subheader("⏰ Thời gian thực")
    
    st.components.v1.html("""
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            .realtime-clock {
                background: rgba(255,255,255,0.1);
                padding: 10px;
                border-radius: 5px;
                text-align: center;
                font-size: 24px;
                font-weight: bold;
                font-family: monospace;
            }
        </style>
    </head>
    <body>
        <div class="realtime-clock" id="clock"></div>
        <script>
            function updateClock() {
                var clock = document.getElementById('clock');
                var now = new Date();
                var options = {
                    timeZone: 'Asia/Ho_Chi_Minh',
                    year: 'numeric',
                    month: '2-digit',
                    day: '2-digit',
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                    hour12: false
                };
                clock.textContent = now.toLocaleString('vi-VN', options);
            }
            updateClock();
            setInterval(updateClock, 1000);
        </script>
    </body>
    </html>
    """, height=80)

def reload_data(symbol: str, timeframe: str):
    """Reload data for symbol and timeframe"""
    from data_processing.unified_data_loader import unified_loader
    
    df_new = unified_loader.update_data(symbol, timeframe)
    
    if df_new is None or df_new.empty:
        st.error("❌ Không thể tải dữ liệu, vui lòng thử lại.")
        safe_session_state_set('data_loaded', False)
    else:
        # Initialize price_data if needed
        price_data = safe_session_state_get('price_data', {})
        price_data[timeframe] = df_new
        safe_session_state_update({
            'price_data': price_data,
            'data_loaded': True,
            'predicting': False,
            'model_updating': False,
            'training': False
        })
        st.success("✅ Đã tải dữ liệu thành công!")




def run_enhanced_prediction_thread(symbol: str, timeframe: str):
    """Enhanced prediction thread with proper error handling and result saving"""
    try:
        from ai_optimizer.unified_resource_manager import training_status, get_resource_manager
        from ai_models.ai_logic import EnsemblePredictor, AIParameterCalculator
        
        # Lấy resource manager để kiểm soát tài nguyên
        resource_manager = get_resource_manager()
        
        # Update status
        training_status.update({
            'predicting': True,
            'predict_done': 0,
            'predict_total_steps': 6,  # Thêm bước AI parameter calculation
            'predict_symbol': symbol,
            'predict_timeframe': timeframe,
            'predict_start_time': datetime.now().isoformat()
        })
        start_time = time.time()
        
        # Step 1: Kiểm tra tính hợp lệ của dữ liệu và mô hình
        training_status.update({
            'predict_done': 1,
            'predict_status': 'Validating models and data requirements...'
        })
          # Kiểm tra mô hình và dữ liệu trước khi tiến hành - FIXED: Hỗ trợ cả .pkl.gz và .pkl
        model_extensions = ['.pkl.gz', '.pkl']
        model_path = None
        unified_model_exists = False
        
        # Tìm model file với bất kỳ extension nào
        for ext in model_extensions:
            potential_path = os.path.join(MODEL_DIR, f"{symbol}_{timeframe}{ext}")
            if os.path.exists(potential_path):
                model_path = potential_path
                break
                
        # Tìm unified model
        for ext in model_extensions:
            unified_path = os.path.join(MODEL_DIR, f"{symbol}_unified{ext}")
            if os.path.exists(unified_path):
                unified_model_exists = True
                break
        
        # Kiểm tra xem có mô hình ensemble trong unified_results hay không
        from ai_models.unified_results_manager import UnifiedResultsManager
        results_manager = UnifiedResultsManager()
        has_ensemble_model = results_manager.check_ensemble_model_exists(symbol)
        
        # Step 2: Load data with advanced caching and validation
        training_status.update({
            'predict_done': 2,
            'predict_status': 'Loading and validating market data...'
        })
        
        from data_processing.unified_data_loader import unified_loader
        df = unified_loader.update_data(symbol, timeframe, validate_data=True)
        
        if df is None or df.empty:
            raise ValueError("Failed to load market data")
            
        # Validate data quality
        required_columns = ['open', 'high', 'low', 'close', 'volume']
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            raise ValueError(f"Missing required columns: {missing_columns}")
            
        # Check for NaN values
        if df[required_columns].isna().any().any():
            # Auto-fix: forward fill NaN values
            df = df.ffill()
            logger.warning(f"Found NaN values in data, applied auto-fix with forward fill")
          # Step 3: Load market data for AI parameter calculation
        training_status.update({
            'predict_done': 3,
            'predict_status': 'Loading market data for AI analysis...'
        })
        
        # Load market data for AI-driven parameter calculation
        try:
            from data_processing.unified_data_loader import unified_loader
            market_data = unified_loader.get_latest_data(symbol, timeframe)
            if market_data is None or market_data.empty:
                market_data = df  # Fallback to current data
        except Exception as e:
            logger.warning(f"Could not load market data for AI calculations: {e}")
            market_data = df
        
        # Step 4: Run prediction analysis with AI-driven parameters
        training_status.update({
            'predict_done': 4,
            'predict_status': 'Running AI-driven prediction analysis...'
        })
        
        # Use EnsemblePredictor with AI parameter calculator
        predictor = EnsemblePredictor()
        
        # Determine optimal device based on available resources
        system_stats = resource_manager.get_resource_metrics()
        optimal_device = resource_manager.get_optimal_device()
        use_gpu = (optimal_device == 'cuda' and system_stats.gpu_memory_free > 1000)        
        try:
            # AI-driven comprehensive prediction with dynamic parameters
            prediction_result = predictor.generate_comprehensive_prediction(
                df=df,
                symbol=symbol,
                timeframe=timeframe,
                use_gpu=use_gpu,
                use_ensemble=True,
                confidence_threshold=None,  # Let AI calculate dynamic threshold
                include_explanations=True,
                use_market_context=True
            )
        except Exception as gpu_error:
            logger.warning(f"GPU prediction failed, falling back to CPU: {gpu_error}")
            # Fallback to CPU with AI-driven parameters
            prediction_result = predictor.generate_comprehensive_prediction(
                df=df,
                symbol=symbol,
                timeframe=timeframe,
                use_gpu=False,
                use_ensemble=True,
                confidence_threshold=None,  # Let AI calculate dynamic threshold
                include_explanations=True,
                use_market_context=True
            )
          # Step 5: Process and enhance results with AI validation
        training_status.update({
            'predict_done': 5,
            'predict_status': 'Processing and validating AI results...'
        })
        
        # Rename prediction_result to prediction for consistency
        prediction = prediction_result
        
        # Validate AI prediction results
        if prediction.get('error'):
            logger.error(f"AI prediction returned error: {prediction['error']}")
            raise Exception(f"AI prediction failed: {prediction['error']}")
        
        if prediction:
            # Calculate additional metrics and enhancements
            try:
                # Add volatility assessment
                if 'close' in df.columns:
                    volatility = df['close'].pct_change().std() * 100
                    prediction['Volatility'] = volatility
                
                # Add trend strength assessment
                if all(col in df.columns for col in ['open', 'close', 'high', 'low']):
                    recent_df = df.tail(20)
                    avg_body = abs(recent_df['close'] - recent_df['open']).mean()
                    avg_range = (recent_df['high'] - recent_df['low']).mean()
                    body_ratio = avg_body / avg_range if avg_range > 0 else 0
                    prediction['Trend_Strength'] = min(body_ratio * 100, 100)
                
                # Add execution risk assessment
                sl_distance = abs(prediction.get('Entry', 0) - prediction.get('SL', 0))
                price = prediction.get('Entry', 0)
                if price > 0:
                    risk_pct = sl_distance / price
                    prediction['Execution_Risk'] = 'LOW' if risk_pct < 0.01 else 'MEDIUM' if risk_pct < 0.03 else 'HIGH'
                
                # Add AI-specific metadata
                prediction['ai_driven'] = True
                prediction['confidence_threshold_used'] = prediction.get('confidence_threshold_used')
                prediction['features_count'] = prediction.get('features_count', 0)
                prediction['model_used'] = prediction.get('model_used', 'unknown')
                
            except Exception as enhance_error:
                logger.warning(f"Could not enhance prediction with additional metrics: {enhance_error}")
            
            # Step 6: Save results and update UI  
            training_status.update({
                'predict_done': 6,
                'predict_status': 'Saving AI results and updating UI...'
            })
            
            # Add execution timestamp and performance metrics
            prediction['timestamp'] = datetime.now().isoformat()
            prediction['prediction_time'] = f"{time.time() - start_time:.2f}s"
            prediction['device_used'] = 'GPU' if use_gpu else 'CPU'
            
            # Update session state
            safe_session_state_update({
                'prediction': prediction,
                'prediction_ready': True,
                'last_prediction_time': datetime.now().isoformat(),
                'prediction_perf': {
                    'time': time.time() - start_time,
                    'device': 'GPU' if use_gpu else 'CPU',
                    'symbol': symbol,
                    'timeframe': timeframe
                }
            })
            
            # Save prediction to UnifiedResultsManager with enhanced details
            try:
                from ai_models.unified_results_manager import UnifiedResultsManager, PredictionResult
                
                # Add additional fields for comprehensive tracking
                prediction_result = PredictionResult(
                    symbol=symbol,
                    timeframe=timeframe,
                    signal=prediction.get('Direction', 'UNKNOWN'),
                    entry_price=prediction.get('Entry', 0.0),
                    take_profit=prediction.get('TP', 0.0),
                    stop_loss=prediction.get('SL', 0.0),
                    confidence=prediction.get('Probability', 0.0),
                    timestamp=datetime.now().isoformat(),
                    model_used=prediction.get('model_used', 'advanced'),
                    features_used=prediction.get('features_count', 0),
                    signal_strength=prediction.get('Signal_Quality', 'BASIC'),
                    volatility=prediction.get('Volatility', 0.0),
                    trend_strength=prediction.get('Trend_Strength', 0.0),
                    execution_risk=prediction.get('Execution_Risk', 'MEDIUM'),
                    prediction_time=float(prediction.get('prediction_time', '0').replace('s', '')),
                    device_used=prediction.get('device_used', 'CPU')
                )
                
                # Lưu kết quả dự đoán với đầy đủ thông tin
                success = results_manager.save_prediction_result(prediction_result)
                logger.info(f"💾 Enhanced prediction result saved: {success} for {symbol}@{timeframe}")
                
                # Auto reload accuracy after prediction to keep UI in sync
                try:
                    # Tự động tải lại kết quả huấn luyện sau khi dự đoán
                    load_training_results()
                    logger.debug("✅ Auto-reloaded training results after prediction")
                except Exception as e:
                    logger.warning(f"Could not auto-reload training results: {e}")
                
            except Exception as save_error:
                logger.warning(f"Could not save prediction result: {save_error}")              # Step 4: Complete with enhanced status and performance metrics
        total_time = time.time() - start_time
        prediction_perf = {
            'total_time': total_time,
            'symbol': symbol,
            'timeframe': timeframe,
            'device': 'GPU' if use_gpu else 'CPU',
            'timestamp': datetime.now().isoformat(),
            'memory_usage': resource_manager.get_resource_metrics().memory_percent,
            'data_rows': len(df) if df is not None else 0
        }
        
        training_status.update({
            'predict_done': 5,
            'predict_status': f'✅ Prediction completed in {total_time:.2f}s',
            'predicting': False,
            'prediction_perf': prediction_perf,
            'last_prediction': {
                'symbol': symbol,
                'timeframe': timeframe,
                'timestamp': datetime.now().isoformat()
            }
        })
        
        # Perform light resource cleanup to prevent memory leaks
        resource_manager.cleanup_resources(intensity='light')
        logger.info(f"✅ Enhanced prediction completed in {total_time:.2f}s")
        return prediction
        
    except Exception as e:
        logger.error(f"Prediction thread error: {e}", exc_info=True)
        
        # Enhanced error diagnostics
        error_details = {
            'error_type': type(e).__name__,
            'error_message': str(e),
            'symbol': symbol,
            'timeframe': timeframe,
            'timestamp': datetime.now().isoformat()
        }
        
        # Try to collect system metrics for diagnostics
        try:
            metrics = resource_manager.get_resource_metrics()
            error_details['memory_percent'] = metrics.memory_percent
            error_details['cpu_percent'] = metrics.cpu_percent
        except:
            pass
            
        training_status.update({
            'predicting': False,
            'predict_status': f'❌ Prediction failed: {str(e)}',
            'prediction_error': str(e),
            'prediction_error_details': error_details
        })
        
        # Try to recover resources after error
        try:
            resource_manager.cleanup_resources(intensity='aggressive')
            logger.info("🧹 Performed aggressive cleanup after prediction error")
        except Exception as cleanup_error:
            logger.warning(f"Cleanup after error failed: {cleanup_error}")
            
        return None

def show_prediction_eta():
    """Show enhanced prediction ETA with detailed progress and metrics"""
    if not has_streamlit_context():
        return
        
    # Get resource manager for detailed metrics
    from ai_optimizer.unified_resource_manager import get_resource_manager, training_status
    resource_manager = get_resource_manager()
        
    if training_status.get('predicting', False):
        # Get symbol and timeframe being predicted
        symbol = training_status.get('predict_symbol', '')
        timeframe = training_status.get('predict_timeframe', '')
        
        # Get detailed ETA information from resource manager
        eta_info = resource_manager.get_prediction_eta(symbol, timeframe)
        
        # Show progress bar
        progress_percent = eta_info.get('progress_percent', 0) / 100
        st.progress(progress_percent)
        
        # Display detailed status
        status = eta_info.get('status', '🚧 Predicting...')
        elapsed = eta_info.get('elapsed_seconds', 0)
        eta = eta_info.get('eta_seconds', 0)
        
        # Format time strings
        elapsed_str = format_eta(elapsed)
        remaining_str = format_eta(eta)
        
        # Display detailed information in columns
        col1, col2, col3 = st.columns(3)
        with col1:
            st.info(f"{status}")
        with col2:
            st.info(f"⏱️ Đã chạy: {elapsed_str}")
        with col3:
            st.info(f"⏳ Còn lại: {remaining_str}")
            
        # Display additional info about the prediction
        if symbol and timeframe:
            steps_done = eta_info.get('steps_done', 0)
            total_steps = eta_info.get('total_steps', 0)
            st.caption(f"Đang dự đoán cho {symbol}@{timeframe} | Bước {steps_done}/{total_steps}")
            
            # Display comprehensive system metrics
            try:
                metrics = resource_manager.get_resource_metrics()
                gpu_metrics = resource_manager.get_gpu_metrics()
                
                cols = st.columns(4)
                with cols[0]:
                    st.metric("CPU", f"{eta_info.get('cpu_percent', metrics.cpu_percent):.1f}%")
                with cols[1]:
                    st.metric("RAM", f"{eta_info.get('memory_percent', metrics.memory_percent):.1f}%")
                with cols[2]:
                    device = eta_info.get('device', 'CPU')
                    if device == 'GPU' and gpu_metrics:
                        gpu_util = gpu_metrics[0].get('utilization', 0) if gpu_metrics else 0
                        st.metric("GPU", f"{gpu_util:.1f}%")
                    else:
                        st.metric("Mode", device)
                with cols[3]:
                    optimal_device = resource_manager.get_optimal_device().upper()
                    st.metric("Optimal", optimal_device)
                    
                # Show advanced GPU information if available
                if device == 'GPU' and gpu_metrics:
                    gpu = gpu_metrics[0]
                    st.caption(f"GPU: {gpu.get('name', 'Unknown')} | "
                               f"Mem: {gpu.get('memory_used', 0):.1f}/{gpu.get('memory_total', 0):.1f}GB | "
                               f"Temp: {gpu.get('temperature', 0)}°C")
            except Exception as e:
                logger.debug(f"Could not display resource metrics: {e}")
    else:
        # Display recent prediction history and performance
        # First check for results in UnifiedResultsManager
        try:
            from ai_models.unified_results_manager import UnifiedResultsManager
            results_manager = UnifiedResultsManager()
            
            # Get last prediction timestamp from training_status
            last_prediction = training_status.get('last_prediction', {})
            symbol = last_prediction.get('symbol', '')
            timeframe = last_prediction.get('timeframe', '')
            
            if symbol and timeframe:
                # Get detailed prediction information
                prediction_result = results_manager.get_latest_prediction(symbol, timeframe)
                
                if prediction_result:
                    # Format time ago
                    try:
                        last_time = datetime.fromisoformat(prediction_result.get('timestamp', ''))
                        time_ago = (datetime.now() - last_time).total_seconds()
                        time_ago_str = format_time_ago(time_ago)
                    except:
                        time_ago_str = "unknown time"
                    
                    # Show prediction summary
                    st.success(f"✅ Dự đoán gần nhất ({symbol}@{timeframe}) hoàn thành {time_ago_str}")
                    
                    # Display detailed performance information
                    cols = st.columns(4)
                    with cols[0]:
                        st.metric("Signal", prediction_result.get('signal', 'UNKNOWN'))
                    with cols[1]:
                        st.metric("Confidence", f"{prediction_result.get('confidence', 0)*100:.1f}%")
                    with cols[2]:
                        st.metric("Time", f"{prediction_result.get('prediction_time', 0):.2f}s")
                    with cols[3]:
                        st.metric("Device", prediction_result.get('device_used', 'CPU'))
                    
                    return
            
            # Fallback to session state if no results from manager
            last_prediction = safe_session_state_get('last_prediction', {})
            prediction_perf = safe_session_state_get('prediction_perf', {})
            
            if last_prediction and 'timestamp' in last_prediction:
                try:
                    last_time = datetime.fromisoformat(last_prediction['timestamp'])
                    time_ago = (datetime.now() - last_time).total_seconds()
                    time_ago_str = format_time_ago(time_ago)
                    
                    st.success(f"✅ Dự đoán gần nhất ({last_prediction.get('symbol', '')}@{last_prediction.get('timeframe', '')}) hoàn thành {time_ago_str}")
                    
                    if prediction_perf:
                        perf_time = prediction_perf.get('total_time', 0)
                        device = prediction_perf.get('device', 'CPU')
                        st.caption(f"⚡ Thời gian: {perf_time:.2f}s | Thiết bị: {device}")
                except:
                    pass
        except Exception as e:
            logger.debug(f"Error showing prediction history: {e}")
            # Fall back to minimal display
            st.info("⏱️ Không có dự đoán nào đang chạy. Sử dụng nút 'Predict' để tạo dự đoán mới.")

def handle_trade_view():
    """Xử lý chức năng Trade View với đầy đủ tính năng"""
    st.header("📊 Trade View")
      # Log dữ liệu Trade View
    trade_data = {
        "symbol": safe_session_state_get("symbol"),
        "timeframe": safe_session_state_get("selected_timeframe"),
        "prediction": safe_session_state_get("prediction"),
        "chart_available": safe_session_state_get("chart") is not None,
        "price_data_keys": list(safe_session_state_get("price_data", {}).keys())
    }
    log_function_data("TRADE_VIEW", trade_data)
    
    # Hiển thị biểu đồ giá
    chart = safe_session_state_get('chart')
    if chart:
        st.plotly_chart(chart, use_container_width=True)
    else:        # Thử tạo chart từ cache nếu có        
        try:
            current_symbol = safe_session_state_get('symbol', 'BTCUSDT')
            symbol_name = f"{current_symbol}USDT" if not current_symbol.endswith("USDT") else current_symbol
            selected_timeframe = safe_session_state_get('selected_timeframe', '15m')
            data_file = os.path.join(DATA_DIR, f"{symbol_name}@{selected_timeframe}.pkl.gz")
            
            if os.path.exists(data_file):
                with gzip.open(data_file, 'rb') as f:
                    df_temp = pickle.load(f)
                
                if df_temp is not None and not df_temp.empty:
                    prediction = safe_session_state_get("prediction")
                    temp_chart = create_chart(df_temp, prediction)
                    st.plotly_chart(temp_chart, use_container_width=True)
                    st.info("📊 Biểu đồ từ cache")
                else:
                    st.info("⏳ Chưa có biểu đồ, vui lòng cập nhật dự đoán")
            else:
                st.info("⏳ Chưa có dữ liệu cache")
        except Exception as e:
            logger.warning(f"Could not create chart from cache: {e}")
            st.info("⏳ Chưa có biểu đồ, vui lòng cập nhật dự đoán")
      # Hiển thị thông tin dự báo
    prediction = safe_session_state_get("prediction")
    if prediction:
        col1, col2 = st.columns(2)
        with col1:
            st.subheader("Dự báo")
            # Updated keys to match new prediction format
            direction = prediction.get("signal", prediction.get("Direction", "NEUTRAL"))
            probability = prediction.get("probability", prediction.get("Probability", 0.5)) * 100  # Convert to percentage
            signal_quality = prediction.get("signal_quality", "UNKNOWN")
            
            st.markdown(f"**Hướng:** {direction}")
            st.markdown(f"**Xác suất:** {probability:.1f}%")
            st.markdown(f"**Chất lượng:** {signal_quality}")
              # Show additional info if available
            if prediction.get("trend_direction"):
                st.markdown(f"**Xu hướng:** {prediction.get('trend_direction')}")
        
        with col2:
            st.subheader("Mức giá")
            # Updated keys to match new prediction format
            entry = prediction.get("entry_price", prediction.get("Entry", 0))
            tp = prediction.get("take_profit", prediction.get("TP", 0))
            sl = prediction.get("stop_loss", prediction.get("SL", 0))
            
            st.markdown(f"**Entry:** {entry:.2f}")
            st.markdown(f"**TP:** {tp:.2f}" if tp else "**TP:** N/A")
            st.markdown(f"**SL:** {sl:.2f}" if sl else "**SL:** N/A")
            
            # Show risk/reward if available
            if prediction.get("risk_reward_ratio"):
                st.markdown(f"**R:R:** {prediction.get('risk_reward_ratio'):.2f}")
        
        # Show performance metrics if available        if prediction.get("performance_metrics"):
            perf = prediction["performance_metrics"]
            st.info(f"⚡ Tính toán: {perf.get('prediction_time', 'N/A')} | Đa luồng: {'✅' if perf.get('multi_threading_used') else '❌'}")
    else:
        st.info("⏳ Chưa có dự đoán, vui lòng nhấn 'Cập nhật dự đoán'")
    
    # Hiển thị giải thích
    explanation = safe_session_state_get("explanation")
    if explanation:
        st.subheader("Giải thích")
        for feature, impact in explanation.items():
            st.markdown(f"- {feature}: {impact}")

def handle_technical_analysis():
    """Xử lý chức năng phân tích kỹ thuật đầy đủ"""
    st.header("📈 Phân tích kỹ thuật")
    
    tf = safe_session_state_get('selected_timeframe', '15m')
      # Log dữ liệu
    tech_data = {
        "timeframe": tf,
        "symbol": safe_session_state_get("symbol"),
        "price_data_available": tf in safe_session_state_get("price_data", {}),
    }
    log_function_data("TECHNICAL_ANALYSIS", tech_data)
    
    # Lấy dữ liệu
    price_dict = safe_session_state_get("price_data", {})
    
    # Load từ cache nếu chưa có
    if tf not in price_dict:
        symbol = safe_session_state_get('symbol', 'BTCUSDT')
        cache_file = os.path.join(DATA_DIR, f"{symbol}@{tf}.pkl.gz")
        if os.path.exists(cache_file):
            try:
                with gzip.open(cache_file, "rb") as f:
                    df_cached = pickle.load(f)
                if df_cached is not None and not df_cached.empty:
                    # Update price_data safely
                    current_price_data = safe_session_state_get('price_data', {})
                    current_price_data[tf] = df_cached
                    safe_session_state_set('price_data', current_price_data)
                    price_dict[tf] = df_cached
            except Exception as e:
                st.warning(f"⚠️ Không load được cache {tf}: {e}")
    
    df = price_dict.get(tf)
    
    if df is None or df.empty:
        st.warning("⏳ Chưa có dữ liệu kỹ thuật. Vui lòng cập nhật dự đoán trước.")
    else:
        # Danh sách indicators để hiển thị
        indicators = [
            ("RSI", "rsi"), ("MACD", "macd"), ("ATR", "atr"), ("Volume", "volume"),
            ("BB Upper", "bb_upper"), ("BB Mid", "bb_middle"), ("BB Lower", "bb_lower"),
            ("CCI", "cci"), ("ADX", "adx"), ("Stoch %K", "stochk"), ("Stoch %D", "stochd"),
            ("Williams %R", "willr"), ("OBV", "obv"), ("MFI", "mfi"), ("PSAR", "psar")
        ]

        # Hiển thị metrics 5 cột
        cols = st.columns(5)
        for i, (label, col_name) in enumerate(indicators):
            if col_name in df.columns:
                val = df[col_name].iloc[-1]
                disp = f"{val:.2f}"
            else:
                disp = "N/A"
            cols[i % 5].metric(label, disp)

        # Vẽ biểu đồ kỹ thuật
        try:
            if "timestamp" in df.columns:
                x = pd.to_datetime(df["timestamp"])
            elif "time" in df.columns:
                x = pd.to_datetime(df["time"])
            else:
                x = pd.to_datetime(df.index)
            
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=x, y=df["close"], name="Close", line=dict(width=1.5)))

            # Bollinger Bands
            if {"bb_upper", "bb_middle", "bb_lower"}.issubset(df.columns):
                fig.add_trace(go.Scatter(x=x, y=df["bb_upper"], name="BB Up", line=dict(dash="dash")))
                fig.add_trace(go.Scatter(x=x, y=df["bb_middle"], name="BB Mid", line=dict(dash="dot")))
                fig.add_trace(go.Scatter(x=x, y=df["bb_lower"], name="BB Low", line=dict(dash="dash")))

            fig.update_xaxes(type="date", tickformat="%d/%m %H:%M", nticks=8)
            fig.update_layout(margin=dict(l=0, r=0, t=30, b=0))
            st.plotly_chart(fig, use_container_width=True)
        except Exception as e:
            st.error(f"❌ Lỗi vẽ biểu đồ: {e}")

def handle_news():
    """Xử lý chức năng tin tức đầy đủ"""
    st.header("📰 Tin tức")
      # Log dữ liệu
    news_data = {
        "symbol": safe_session_state_get("symbol"),
        "max_news": safe_session_state_get("max_news"),
        "show_news": safe_session_state_get("show_news"),
        "good_news_count": len(safe_session_state_get("good_news", [])),
        "bad_news_count": len(safe_session_state_get("bad_news", [])),
        "market_score": safe_session_state_get("market_score"),
    }
    log_function_data("NEWS", news_data)
    
    # Load cache nếu có
    cache_path = os.path.join(DATA_DIR, "news_cache.csv")
    if os.path.exists(cache_path) and not safe_session_state_get("show_news", False):
        try:
            df_cache = pd.read_csv(cache_path, parse_dates=["publishedAt"])
            
            safe_session_state_update({
                'news_table': df_cache,
                'good_news': df_cache[df_cache["sentiment"] > 0].to_dict("records"),
                'bad_news': df_cache[df_cache["sentiment"] < 0].to_dict("records"),
                'market_score': df_cache["sentiment"].mean(),
                'show_news': True
            })
        except Exception as e:
            logger.warning(f"Could not load news cache: {e}")
    
    # Nút cập nhật tin tức
    max_news = safe_session_state_get("max_news", 50)
    if st.button("🔄 Cập nhật tin tức", key="refresh_news"):
        symbol = safe_session_state_get('symbol', 'BTCUSDT')
        with st.spinner(f"Đang lấy {max_news} tin cho {symbol}..."):
            try:
                from data_sources.news_manager import NewsManager
                good, bad, score = NewsManager(symbol, max_items=max_news)
                all_news = good + bad
                
                safe_session_state_update({
                    'good_news': good,
                    'bad_news': bad,
                    'market_score': score,
                    'news_table': pd.DataFrame(all_news),
                    'show_news': True
                })
                
                st.success(f"✅ Đã tải {len(all_news)} tin tức")
            except Exception as e:
                st.error(f"❌ Lỗi tải tin tức: {e}")    # Hiển thị bảng tổng hợp
    st.subheader("📋 Bảng tổng hợp tin tức")
    news_table = safe_session_state_get("news_table")
    if news_table is not None and not news_table.empty:
        df_news = news_table.copy()
        if not df_news.empty:
            cols_to_show = ["publishedAt", "title", "sentiment", "summary"]
            available_cols = [col for col in cols_to_show if col in df_news.columns]
            
            if available_cols:
                df_display = df_news[available_cols].sort_values(
                    available_cols[0] if available_cols[0] in df_news.columns else df_news.columns[0], 
                    ascending=False
                )
                st.dataframe(df_display, use_container_width=True)    # Hiển thị sentiment và phân loại tin
    if safe_session_state_get("show_news", False):
        score = safe_session_state_get("market_score", 0)
        st.metric("🔍 Sentiment thị trường", f"{score:.2f}")

        col1, col2 = st.columns(2)
        with col1:
            good_news = safe_session_state_get('good_news', [])
            st.subheader(f"🟢 Tin tích cực ({len(good_news)})")
            for n in good_news[:5]:
                st.markdown(f"**{n.get('title', 'N/A')}** *(+{n.get('sentiment', 0):.2f})*")
                st.markdown(f"> {n.get('summary', 'N/A')}")
                st.write("---")
        
        with col2:
            bad_news = safe_session_state_get('bad_news', [])
            st.subheader(f"🔴 Tin tiêu cực ({len(bad_news)})")
            for n in bad_news[:5]:
                st.markdown(f"**{n.get('title', 'N/A')}** *({n.get('sentiment', 0):.2f})*")
                st.markdown(f"> {n.get('summary', 'N/A')}")
                st.write("---")
    else:
        st.info("Chưa có dữ liệu tin tức, nhấn nút Cập nhật.")

def handle_training():
    """Xử lý chức năng huấn luyện đầy đủ"""
    st.header("🧠 Huấn luyện mô hình")
    # FIXED: Sync global training status to session state at start
    sync_training_status_enhanced()
      # Log dữ liệu
    train_data = {
        "model_updating": safe_session_state_get("model_updating"),
        "training": safe_session_state_get("training"),
        "train_progress": safe_session_state_get("train_progress"),
        "train_results_count": len(safe_session_state_get("train_results", [])),
        "symbol": safe_session_state_get("symbol"),
        "selected_timeframe": safe_session_state_get("selected_timeframe")
    }
    log_function_data("TRAINING", train_data)
    
    # Hiển thị trạng thái hệ thống    try:    
    try:
        resource_manager = get_resource_manager()       
        col1, col2, col3 = st.columns(3)
        with col1:
            health_score = resource_manager.get_health_score()
            st.metric("🏥 System Health", f"{health_score:.0f}/100")        
        with col2:
            optimal_device = resource_manager.get_optimal_device()
            st.metric("🖥️ Device", optimal_device.upper())
        with col3:
            stats = resource_manager.get_system_stats()
            ram_usage = stats.memory_percent if stats else 0
            st.metric("💾 RAM", f"{ram_usage:.1f}%")
    except Exception as e:
        logger.warning(f"Could not get system stats: {e}")
      # Load accuracy cache from various sources - Use UnifiedResultsManager
    load_training_results()    # Hiển thị kết quả huấn luyện
    st.subheader("🔍 Kết quả huấn luyện")
    
    train_results = safe_session_state_get("train_results")
    if train_results:
        # Display results in matrix format: Models (rows) x Timeframes (columns)
        if isinstance(train_results, dict):
            # New format from enhanced cache loading - convert to legacy format for matrix display
            legacy_results = []
            for key, data in train_results.items():
                parts = key.split('_')
                if len(parts) >= 2:
                    symbol = parts[0]
                    timeframe = '_'.join(parts[1:]).replace('_pipeline', '')
                    
                    legacy_results.append({
                        'timeframe': timeframe,
                        'model': data.get('model', 'unknown'),
                        'accuracy': data.get('accuracy', 0),
                        'backtest_accuracy': data.get('backtest_accuracy', 0)
                    })
            if legacy_results:
                df_results = pd.DataFrame(legacy_results)
            else:
                st.info("Chưa có kết quả huấn luyện.")
                return
        
        else:
            # Legacy format - use directly
            df_results = pd.DataFrame(train_results)
        
        if not df_results.empty and 'model' in df_results.columns and 'timeframe' in df_results.columns:
            # Get latest result for each model-timeframe combination
            df_latest = df_results.groupby(['model', 'timeframe']).last().reset_index()
            
            # Create matrix format: Models as rows, Timeframes as columns (đã chuyển)
            timeframes = sorted(df_latest['timeframe'].unique())
            models = sorted(df_latest['model'].unique())
            
            # Create accuracy matrix
            st.write("**📊 Ma trận độ chính xác (Timeframe x Model):**")
            
            # Tạo DataFrame với các mô hình làm cột và timeframe làm chỉ mục
            matrix_data = {}
            
            # Khởi tạo cột cho mỗi mô hình
            for model in models:
                matrix_data[model] = []
            
            # Điền dữ liệu cho từng timeframe
            for tf in timeframes:
                row_data = {}
                for model in models:
                    model_tf_data = df_latest[(df_latest['model'] == model) & (df_latest['timeframe'] == tf)]
                    if not model_tf_data.empty:
                        accuracy = model_tf_data['accuracy'].iloc[0]
                        backtest = model_tf_data.get('backtest_accuracy', [0]).iloc[0] if 'backtest_accuracy' in model_tf_data.columns else 0
                        
                        # Format: accuracy / backtest
                        if pd.notna(accuracy) and pd.notna(backtest):
                            row_data[model] = f"{accuracy*100:.1f}% / {backtest*100:.1f}%"
                        elif pd.notna(accuracy):
                            row_data[model] = f"{accuracy*100:.1f}% / –"
                        else:
                            row_data[model] = "– / –"
                    else:
                        row_data[model] = "– / –"
                
                # Thêm dữ liệu vào matrix_data
                for model in models:
                    matrix_data[model].append(row_data.get(model, "– / –"))
            
            # Tạo DataFrame cuối cùng
            df_matrix = pd.DataFrame(matrix_data, index=timeframes)
            df_matrix.index.name = "Timeframe"
            
            if not df_matrix.empty:
                st.dataframe(df_matrix, use_container_width=True)
                
                # Add legend
                st.caption("📝 **Chú thích:** Định dạng hiển thị: `Accuracy% / Backtest%`")
            else:
                st.info("Chưa có kết quả huấn luyện.")
        else:
            st.info("Dữ liệu kết quả không đầy đủ.")
    else:
        st.info("Chưa có kết quả huấn luyện.")
      # Refresh accuracy cache button - Commented out because we now auto-reload
    # col1, col2 = st.columns([1, 4])
    # with col1:
    #    if st.button("🔄 Cập nhật độ chính xác", help="Tải lại dữ liệu độ chính xác từ các mô hình đã huấn luyện"):
    #        # Clear current results and reload
    #        if "train_results" in st.session_state:
    #            del st.session_state.train_results
    #        load_training_results()  # Use new UnifiedResultsManager integration
    #        st.rerun()

    # Tùy chọn huấn luyện
    st.subheader("Tùy chọn huấn luyện")
    col1, col2 = st.columns(2)
    with col1:
        horizon = st.slider("Horizon (số nến)", 1, 24, 12)
        threshold = st.slider("Ngưỡng biến động (%)", 0.1, 5.0, 1.0)
        epochs = st.slider("Số epochs", 5, 100, 20)
    with col2:
        batch_size = st.slider("Batch size", 16, 256, 64, step=16)
        use_gpu = st.checkbox("Sử dụng GPU", value=True)        
        use_enhanced = st.checkbox("🚀 Huấn luyện nâng cao", value=True)
        
        # Training modes với 4 lựa chọn tối ưu
        training_mode = st.selectbox(
            "🎯 Chế độ huấn luyện",
            options=['quick', 'standard', 'deep'],
            index=2,  # Default to standard
            format_func=lambda x: {
                'quick': '⚡ QUICK (7 ngày) - Cập nhật nhanh', 
                'standard': '📊 STANDARD (30 ngày) - Chuẩn',
                'deep': '🧠 DEEP (365 ngày) - Chuyên sâu'
            }[x]
        )
        
        # Hiển thị thông tin mode
        from data_processing.unified_data_loader import TRAINING_MODES
        mode_info = TRAINING_MODES[training_mode]
        st.info(f"📅 **{mode_info['description']}** - Sử dụng dữ liệu {mode_info['days']} ngày gần nhất")        
        use_full_data = (training_mode == 'deep')
        
        # Nếu chọn deep mode, hiển thị nút download
        if training_mode == 'deep':
            try:
                from data_processing.unified_data_loader import unified_loader                # Lấy toàn bộ dữ liệu với deep mode
                symbol = safe_session_state_get('symbol', 'BTCUSDT')
                timeframe = safe_session_state_get('selected_timeframe', '15m')
                df_all = unified_loader.update_data(symbol, timeframe, training_mode='deep')
                if df_all is not None and not df_all.empty:
                    # Chuyển thành CSV bytes để dùng cho download_button
                    csv_bytes = df_all.to_csv(index=False).encode('utf-8')
                    st.download_button(
                        label="⤓ Tải xuống toàn bộ dữ liệu (CSV)",
                        data=csv_bytes,
                        file_name=f"{symbol}@{timeframe}_deep.csv",
                        mime="text/csv"
                    )
                else:
                    st.warning("Không có dữ liệu để tải xuống.")
            except Exception as e:                
                st.error(f"Lỗi khi tải dữ liệu: {e}")
      # Nút bắt đầu huấn luyện
    if st.button("🚀 Bắt đầu huấn luyện", key="train_button", 
                 disabled=safe_session_state_get("model_updating", False)):
        
        safe_session_state_update({
            "model_updating": True,
            "training": True
        })
          # FIXED: Also update global training_status for consistency
        training_status.update({
            "model_updating": True,
            "training": True
        })
        
        # Khởi chạy thread huấn luyện
        try:
            symbol = safe_session_state_get('symbol', 'BTCUSDT')
            timeframe = safe_session_state_get('selected_timeframe', '15m')
            
            t = threading.Thread(
                target=train_thread,
                args=(symbol, timeframe, epochs, threshold/100, batch_size, horizon, use_gpu, training_mode, use_enhanced),
                daemon=True
            )
            safe_session_state_set("train_thread", t)
            t.start()
            st.info(f"🚀 Đã bắt đầu huấn luyện {symbol}@{timeframe}")
        
        except Exception as e:
            st.error(f"❌ Lỗi khởi động huấn luyện: {e}")
            safe_session_state_update({
                "model_updating": False,
                "training": False
            })
            # FIXED: Also update global training_status
            training_status.update({
                "model_updating": False,
                "training": False
            })
      # Hiển thị tiến trình với enhanced error handling
    if safe_session_state_get("training", False):
        # ENHANCED: Sync global training status to session state
        sync_training_status_enhanced()
        
        # Use enhanced training status display
        show_train_status()
        
        # Display ETA information if available
        eta_info = safe_session_state_get("eta_info", {})
        if eta_info:
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("⏱️ Elapsed", eta_info.get("elapsed", "--:--:--"))
            with col2:
                st.metric("🕐 Remaining", eta_info.get("remaining", "--:--:--"))
            with col3:
                current_model = safe_session_state_get("current_model", "")
                if current_model:
                    st.metric("🤖 Current Model", current_model)

        # Auto-refresh every 600 seconds during training
        time.sleep(600)
        st.rerun()
      # Display final results or error state when training is done
    elif safe_session_state_get("train_error") or safe_session_state_get("training_failed"):
        st.subheader("❌ Training Failed")
        show_train_status()  # This will show detailed error information
    elif safe_session_state_get("prediction_ready"):
        st.success("✅ Training completed successfully!")
        show_train_status()

def handle_zalo():
    """Xử lý chức năng gửi Zalo đầy đủ"""
    st.header("📱 Gửi thông báo Zalo - Enhanced Version")
    
    try:
        from utilities.zalo_sender import ZaloSender
        zalo = ZaloSender()

        # Log dữ liệu Zalo
        zalo_data = {
            "has_access_token": bool(zalo.access_token),
            "contacts_count": len(zalo.contacts),
            "symbol": safe_session_state_get("symbol"),
            "prediction": safe_session_state_get("prediction"),
        }
        log_function_data("ZALO_SENDER", zalo_data)

        # Kiểm tra kết nối
        if zalo.access_token:
            is_valid, validation_msg = zalo.validate_access_token()
            if is_valid:
                st.success(f"✅ Kết nối Zalo thành công: {validation_msg}")
                
                # Hiển thị profile info
                profile = zalo.get_oa_profile()
                if "error" not in profile:
                    st.info(f"📱 OA: {profile.get('name', 'Unknown')} | Followers: {profile.get('followers_count', 'N/A')}")
            else:
                st.error(f"❌ Token không hợp lệ: {validation_msg}")
                zalo.access_token = None

        # Xác thực nếu chưa có token
        if not zalo.access_token:
            st.subheader("🔐 Xác thực Zalo OA")
            
            if safe_session_state_get("zalo_pkce") is None:
                cv, cc, stt = zalo.generate_pkce()
                safe_session_state_set("zalo_pkce", {"verifier": cv, "challenge": cc, "state": stt})
            
            zalo_pkce = safe_session_state_get("zalo_pkce", {})
            cv = zalo_pkce.get("verifier")
            cc = zalo_pkce.get("challenge") 
            stt = zalo_pkce.get("state")

            auth_url = zalo.build_auth_url(cc, stt)
            qr_png = zalo.get_qr_code_bytes(auth_url)
            st.image(qr_png, caption="Scan QR để xác thực", use_container_width=True)
            st.markdown(f"[Mở link xác thực]({auth_url})")

            code = st.text_input("Nhập code từ callback URL", key="zalo_auth_code")
            if st.button("🔄 Xác thực", key="zalo_auth_button"):
                ok, msg = zalo.exchange_code_for_token(code, cv)
                if ok:
                    st.success(msg)
                    st.rerun()
                else:
                    st.error(msg)
            st.stop()

        # Quản lý danh bạ
        st.subheader("Danh sách liên hệ")
        contacts = zalo.contacts
        if contacts:
            for c in contacts:
                col1, col2, col3 = st.columns([3, 2, 1])
                with col1:
                    st.markdown(f"**{c.get('name', 'Không tên')}** – {c['phone']}")
                with col2:
                    if c.get("last_sent"):
                        st.markdown(f"Lần cuối: {c['last_sent']}")
                with col3:
                    if st.button("Xóa", key=f"zalo_del_{c['phone']}"):
                        zalo.remove_contact(c["phone"])
                        st.success("Đã xóa liên hệ")
                        st.rerun()
        else:
            st.info("Chưa có liên hệ nào")

        # Thêm liên hệ mới
        st.subheader("Thêm liên hệ mới")
        col1, col2 = st.columns(2)
        with col1:
            ph = st.text_input("Số điện thoại", key="zalo_new_phone")
        with col2:
            nm = st.text_input("Tên (tùy chọn)", key="zalo_new_name")
        
        if st.button("Thêm", key="zalo_add_contact"):
            if ph:
                if ph.isdigit() and len(ph) >= 10:
                    ok, msg = zalo.add_contact(ph, nm or f"Contact_{ph[-4:]}")
                    if ok:
                        st.success(msg)
                        st.rerun()
                    else:
                        st.error(msg)
                else:
                    st.error("❌ Số điện thoại không hợp lệ")
            else:
                st.warning("Vui lòng nhập số điện thoại")

        # Gửi tin nhắn
        st.subheader("📤 Gửi tin nhắn")
        
        # Loại tin nhắn
        message_type = st.selectbox(
            "Loại tin nhắn",
            ["Dự đoán AI", "Tin nhắn tùy chỉnh", "Broadcast"]        )
        
        if message_type == "Dự đoán AI":
            pred = safe_session_state_get("prediction")
            if pred and isinstance(pred, dict) and "Entry" in pred:
                if contacts:
                    selected = st.multiselect("Chọn người nhận", [c["phone"] for c in contacts])
                    msg_text = zalo.compose_pred_msg([pred])
                    st.text_area("Nội dung", value=msg_text, height=200)

                    if st.button("🚀 Gửi dự đoán AI"):
                        success_count = 0
                        for phone in selected:
                            ok, _ = zalo.send_text_message(phone, msg_text)
                            if ok:
                                success_count += 1
                        st.success(f"✅ Đã gửi đến {success_count}/{len(selected)} liên hệ")
                else:
                    st.warning("⚠️ Chưa có liên hệ nào")
            else:
                st.info("⏳ Chưa có dự đoán AI")

        elif message_type == "Tin nhắn tùy chỉnh":
            if contacts:
                selected = st.multiselect("Chọn người nhận", [c["phone"] for c in contacts])
                custom_msg = st.text_area("Nội dung tin nhắn", height=150)
                
                if st.button("📤 Gửi tin nhắn") and custom_msg and selected:
                    success_count = 0
                    for phone in selected:
                        ok, _ = zalo.send_text_message(phone, custom_msg)
                        if ok:
                            success_count += 1
                    st.success(f"✅ Đã gửi đến {success_count}/{len(selected)} liên hệ")
            else:
                st.warning("⚠️ Chưa có liên hệ nào")

        elif message_type == "Broadcast":
            broadcast_msg = st.text_area("Nội dung broadcast", height=150)
            if st.button("📢 Gửi Broadcast") and broadcast_msg:
                results = zalo.broadcast_message(broadcast_msg, "all")
                st.success(f"✅ Thành công: {results['success']}, Thất bại: {results['failed']}")
                
    except Exception as e:
        st.error(f"❌ Lỗi Zalo: {e}")

def handle_configuration():
    """Xử lý chức năng cấu hình"""
    st.subheader("⚙️ Cấu hình hệ thống")
    
    # Cấu hình chung
    st.write("### 🔧 Cấu hình AI")
    
    col1, col2 = st.columns(2)
    with col1:
        gpu_enabled = st.checkbox("Sử dụng GPU", value=True)
        auto_update = st.checkbox("Tự động cập nhật dự đoán", value=False)
        cache_enabled = st.checkbox("Sử dụng cache", value=True)
    
    with col2:
        log_level = st.selectbox("Log level", ["INFO", "DEBUG", "WARNING", "ERROR"])
        refresh_interval = st.number_input("Refresh interval (giây)", 
                                         min_value=5, max_value=300, value=30)
    
    # Cấu hình tin tức
    st.write("### 📰 Cấu hình tin tức")
    max_news = st.number_input("Số lượng tin tức tối đa", 
                              min_value=10, max_value=500, value=100)
    
    # Lưu cấu hình
    if st.button("💾 Lưu cấu hình"):
        config = {
            'gpu_enabled': gpu_enabled,
            'auto_update': auto_update,
            'cache_enabled': cache_enabled,
            'log_level': log_level,
            'refresh_interval': refresh_interval,
            'max_news': max_news
        }
        
        config_path = os.path.join(DATA_DIR, "config.json")
        with open(config_path, "w") as f:
            json.dump(config, f, indent=2)
        
        st.success("✅ Đã lưu cấu hình thành công!")

def handle_long_term_forecast():
    """Xử lý chức năng dự báo dài hạn"""
    st.subheader("🔮 Dự báo dài hạn")
    try:
        # Tham số dự báo
        col1, col2 = st.columns(2)
        with col1:
            forecast_days = st.number_input("Số ngày dự báo", 
                                          min_value=1, max_value=365, value=30)
            confidence_level = st.slider("Độ tin cậy", 
                                        min_value=0.5, max_value=0.99, value=0.95)
        
        with col2:
            include_events = st.checkbox("Bao gồm sự kiện lịch sử", value=True)
            include_sentiment = st.checkbox("Bao gồm phân tích sentiment", value=True)
        
        if st.button("🔮 Tạo dự báo dài hạn"):
            with st.spinner("Đang tạo dự báo..."):
                try:
                    # Simple forecasting using current prediction logic
                    from ai_models.ai_logic import EnsemblePredictor
                    from data_processing.unified_data_loader import unified_loader
                      # Load data for prediction
                    symbol = safe_session_state_get('symbol', 'BTCUSDT')
                    timeframe = safe_session_state_get('selected_timeframe')
                    df = unified_loader.update_data(symbol, timeframe)
                    
                    if df is None or df.empty:
                        raise ValueError("Cannot load market data for forecasting")
                    
                    # Generate prediction using EnsemblePredictor directly
                    predictor = EnsemblePredictor()
                   
                    prediction = predictor.generate_comprehensive_prediction(
                        df, 
                        symbol,
                        timeframe
                    )
                    
                    if prediction:
                        # Create simple forecast result
                        current_price = prediction.get('Entry', 0)
                        direction = prediction.get('Direction', 'SIDEWAYS')
                        
                        # Simple price projection based on direction
                        if direction == 'LONG':
                            forecast_price = current_price * (1 + 0.05 * (forecast_days / 30))
                            trend = 'UP'
                        elif direction == 'SHORT':
                            forecast_price = current_price * (1 - 0.05 * (forecast_days / 30))
                            trend = 'DOWN'
                        else:
                            forecast_price = current_price
                            trend = 'SIDEWAYS'
                            
                        forecast_result = {
                            'forecast_price': forecast_price,
                            'trend': trend,
                            'confidence': prediction.get('Probability', 0.5)
                        }
                    
                    if forecast_result:
                        st.success("✅ Dự báo dài hạn hoàn tất!")
                        
                        # Hiển thị kết quả
                        col1, col2, col3 = st.columns(3)
                        with col1:
                            st.metric("Giá dự báo (30 ngày)", 
                                    f"{forecast_result.get('forecast_price', 0):.2f}")
                        with col2:
                            trend = forecast_result.get('trend', 'SIDEWAYS')
                            trend_emoji = {"UP": "📈", "DOWN": "📉", "SIDEWAYS": "➡️"}.get(trend, "➡️")
                            st.metric("Xu hướng", f"{trend_emoji} {trend}")
                        with col3:
                            confidence = forecast_result.get('confidence', 0) * 100
                            st.metric("Độ tin cậy", f"{confidence:.1f}%")
                          # Biểu đồ dự báo
                        if 'forecast_chart' in forecast_result and forecast_result['forecast_chart'] is not None:
                            try:
                                import plotly.graph_objects as go
                                chart = forecast_result['forecast_chart']
                                # Verify it's a valid plotly figure
                                if isinstance(chart, (go.Figure, dict)) or hasattr(chart, 'to_dict'):
                                    st.plotly_chart(chart, use_container_width=True)
                                else:
                                    st.info("📊 Biểu đồ dự báo không khả dụng")
                            except Exception as chart_error:
                                logger.warning(f"Chart display error: {chart_error}")
                                st.info("📊 Không thể hiển thị biểu đồ dự báo")
                        
                        # Hiển thị chi tiết dự báo
                        if 'forecast_data' in forecast_result:
                            st.subheader("📊 Chi tiết dự báo theo khung thời gian")
                            
                            forecast_data = forecast_result['forecast_data']
                            if isinstance(forecast_data, dict):
                                for timeframe, data in forecast_data.items():
                                    if isinstance(data, dict) and 'xu hướng' in data:
                                        with st.expander(f"📈 Khung {timeframe}"):
                                            col1, col2 = st.columns(2)
                                            with col1:
                                                st.write(f"**Xu hướng:** {data.get('xu hướng', 'N/A')}")
                                                st.write(f"**Độ tin cậy:** {data.get('độ tin cậy', 'N/A')}")
                                                st.write(f"**Giá dự báo:** {data.get('giá dự báo', 'N/A')}")
                                            with col2:
                                                st.write(f"**Chốt lời:** {data.get('giá chốt lời', 'N/A')}")
                                                st.write(f"**Cắt lỗ:** {data.get('giá cắt lỗ', 'N/A')}")
                                                st.write(f"**Giá hiện tại:** {data.get('giá hiện tại', 'N/A')}")
                    else:
                        st.error("❌ Không thể tạo dự báo dài hạn")
                        
                except Exception as forecast_error:
                    st.error(f"❌ Lỗi trong quá trình dự báo: {str(forecast_error)}")
                    logger.error(f"Forecast error: {forecast_error}")
                    
    except Exception as e:
        st.error(f"❌ Lỗi dự báo dài hạn: {str(e)}")
        logger.error(f"Handle long term forecast error: {e}")

def format_time_ago(seconds: float) -> str:
    """Format a time difference in seconds into a human-readable 'time ago' string"""
    if seconds < 60:
        return f"{int(seconds)} giây trước"
    elif seconds < 3600:
        minutes = int(seconds / 60)
        return f"{minutes} phút trước"
    elif seconds < 86400:
        hours = int(seconds / 3600)
        return f"{hours} giờ trước"
    else:
        days = int(seconds / 86400)
        return f"{days} ngày trước"

# ==================== TRAINING THREAD ====================
# Note: Removed unused run_pred_thread function (120+ lines of unused code)
# Using run_prediction_thread function instead

def train_thread(symbol, timeframe, epochs, threshold, batch_size, horizon, use_gpu=True, training_mode='standard', use_enhanced=True):
    """Simplified training thread - delegates to unified_trainer"""
    start_time = time.time()
    
    # CRITICAL: Add comprehensive error logging to catch ALL crashes
    logger.info(f"🔄 TRAIN_THREAD STARTED: {symbol}@{timeframe}, mode={training_mode}, gpu={use_gpu}")
    
    try:
        from ai_optimizer.unified_resource_manager import training_status
        logger.info("✅ Imported training_status successfully")
        
        # FIXED: Use global training_status for thread-safe updates
        training_status.update({
            "training": True, 
            "train_progress": 0.05, 
            "train_status": "📡 Đang tải dữ liệu từ Binance... (có thể mất 5-30 giây)",
            "train_error": None, 
            "current_model": "", 
            "eta": None, 
            "train_results": []
        })
        logger.info("✅ Updated training_status successfully")        
        # Enhanced progress callback - Now accepts 2 parameters like UnifiedTrainer expects
        def progress_cb(progress, info=None):
            """Progress callback that matches unified trainer signature"""
            elapsed = time.time() - start_time
            elapsed_str = format_eta(elapsed)
            
            # Calculate ETA based on progress
            if progress > 0:
                estimated_total = elapsed / progress
                remaining_secs = estimated_total - elapsed
            else:
                remaining_secs = 0
            
            eta_str = format_eta(remaining_secs)
            rate = elapsed / max(progress * 100, 1) if progress > 0 else 0
            
            # Use info from UnifiedTrainer if available
            if info and isinstance(info, dict):
                current_model = info.get('current_model', '')
                status = f"🚀 Training {current_model}... {progress*100:.1f}%"
            else:
                current_model = ""
                status = f"🚀 Training... {progress*100:.1f}%"
            
            # Create proper eta_info structure
            eta_info = {
                "remaining": eta_str,
                "elapsed": elapsed_str,
                "rate": rate,
                "status": status,
                "current_model": current_model
            }            # FIXED: Use thread-safe training_status updates
            training_status.update({
                "train_progress": progress,
                "train_status": status,
                "current_model": current_model,
                "eta": eta_str,
                "eta_info": eta_info
            })
          # Delegate to unified trainer with training mode - FULL ENSEMBLE TRAINING
        logger.info("🔄 Attempting to import UnifiedTrainer...")
        from ai_models.unified_trainer import UnifiedTrainer
        logger.info("✅ Imported UnifiedTrainer successfully")
          # Map training_mode to UnifiedTrainer duration format - FIXED mapping
        mode_mapping = {
            'quick': 'quick',      # Map to TRAINING_MODES keys
            'standard': 'standard', # Map to TRAINING_MODES keys  
            'deep': 'deep'         # Map to TRAINING_MODES keys
        }
        training_duration = mode_mapping.get(training_mode, 'standard')
        logger.info(f"📊 Training duration mapped: {training_mode} -> {training_duration}")
        
        # CHỈNH SỬA: Khởi tạo trainer instance với tham số đầy đủ
        logger.info(f"🚀 Starting UnifiedTrainer with params: symbol={symbol}, timeframe={timeframe}, duration={training_duration}, gpu={use_gpu}")
          # Khởi tạo trainer instance với config dict đúng format
        config = {
            'symbol': symbol,
            'timeframe': timeframe,
            'epochs': epochs,
            'threshold': threshold,
            'batch_size': batch_size,
            'horizon': horizon,
            'training_mode': training_duration,
            'use_gpu': use_gpu,
            'gpu_available': use_gpu
        }
        
        trainer = UnifiedTrainer(config)
        
        # Cấu hình GPU
        if use_gpu: 
            trainer.use_gpu = True
            logger.info("🔥 GPU training enabled")
        
        # Cấu hình threshold cho classification
        if hasattr(trainer, 'classification_threshold'):
            trainer.classification_threshold = threshold
            logger.info(f"🎯 Classification threshold set to: {threshold}")        # Cấu hình horizon cho prediction 
        if hasattr(trainer, 'prediction_horizon'):
            trainer.prediction_horizon = horizon
            logger.info(f"🔮 Prediction horizon set to: {horizon}")        # Gọi phương thức train với progress callback
        logger.info("🏃‍♂️ Starting training process with full parameters...")
        final_result = trainer.train(progress_callback=progress_cb)
        logger.info(f"✅ UnifiedTrainer training completed")
          # Xử lý kết quả huấn luyện
        results = []
        if final_result and isinstance(final_result, dict):
            # Extract model info từ final_result
            model_info = {
                "timeframe": "unified",  # Multi-timeframe model
                "model": final_result.get('type', 'ensemble'),
                "accuracy": final_result.get('accuracy', 0.0),
                "f1_score": final_result.get('f1_score', 0.0),
                "threshold": threshold,
                "backtest_accuracy": final_result.get('backtest_accuracy', 0.0),
                "model_object": final_result.get('model'),
                "training_time": final_result.get('training_time', 0.0),
                "ensemble_weights": final_result.get('ensemble_weights', {}),
                "feature_count": final_result.get('feature_count', 0)
            }
            results.append(model_info)
            
            # Thêm individual model results nếu có
            individual_results = final_result.get('individual_results', {})
            for model_name, model_result in individual_results.items():
                if hasattr(model_result, 'accuracy'):
                    individual_info = {
                        "timeframe": getattr(model_result, 'timeframe', 'unified'),
                        "model": model_name,
                        "accuracy": model_result.accuracy,
                        "f1_score": model_result.f1_score,
                        "threshold": threshold,
                        "backtest_accuracy": getattr(model_result, 'backtest_accuracy', 0.0),
                        "model_object": getattr(model_result, 'model', None),
                        "training_time": getattr(model_result, 'training_time', 0.0)
                    }
                    results.append(individual_info)
          # Save results using UnifiedResultsManager
        try:
            from ai_models.unified_results_manager import UnifiedResultsManager, TrainingResult
            results_manager = UnifiedResultsManager()
              # Save final model result
            if final_result and isinstance(final_result, dict):
                training_result_obj = TrainingResult(
                    symbol=symbol,
                    timeframe="unified",
                    model_type=final_result.get('type', 'ensemble'),
                    accuracy=final_result.get('accuracy', 0.0),
                    precision=final_result.get('precision', 0.0),
                    recall=final_result.get('recall', 0.0),
                    f1_score=final_result.get('f1_score', 0.0),
                    auc_score=final_result.get('auc_score', 0.0),
                    training_time=final_result.get('training_time', 0.0),
                    timestamp=datetime.now().isoformat(),
                    model_path=final_result.get('model_path', ''),
                    feature_count=final_result.get('feature_count', 0),
                    data_points=final_result.get('data_points', 0),
                    cv_scores=final_result.get('cv_scores', []),
                    hyperparameters=final_result.get('hyperparameters', {})
                )
                
                success = results_manager.save_training_result(training_result_obj)
                logger.info(f"💾 Final model result saved: {success} for {symbol}@unified")
                
        except Exception as e:
            logger.warning(f"Could not save training results: {e}")
            
        # Final update
        best_result = max(results, key=lambda x: x['accuracy']) if results else None
        if best_result:
            training_status.update({
                "train_progress": 1.0,
                "train_status": f"✅ Training completed! Best: {best_result['model']} (Acc: {best_result['accuracy']:.2%})",                
                "train_results": results,
                "prediction_ready": True,
                "current_model": best_result['model'],
                "eta": "00:00:00"
            })
        else:
            raise ValueError("No successful training results")
            
        logger.info(f"✅ Training completed in {time.time() - start_time:.1f}s")
        
    except Exception as e:
        error_msg = f"❌ Training failed: {str(e)}"
        logger.error(f"Training error: {e}", exc_info=True)
        
        # Enhanced error diagnostics
        error_type = "unknown"
        detailed_error = str(e)
        
        if "NaN" in str(e) or "float" in str(e):
            error_type = "data_conversion"
            detailed_error = "Data conversion error - likely NaN values in dataset"
        elif "memory" in str(e).lower() or "allocation" in str(e).lower():
            error_type = "memory"
            detailed_error = "Memory allocation error - try reducing data size"
        elif "import" in str(e).lower() or "module" in str(e).lower():
            error_type = "dependency"
            detailed_error = "Missing dependency error - check package installation"
        elif "timeout" in str(e).lower():
            error_type = "timeout"
            detailed_error = "Training timeout - try reducing data size or epochs"
        else:
            error_type = "training"
            detailed_error = f"Training process error: {str(e)}"
        
        # Enhanced error status update
        error_status = {
            "train_status": f"❌ {error_type.title()} Error: {detailed_error}",
            "train_error": detailed_error,
            "error_type": error_type,
            "error_timestamp": datetime.now().isoformat(),
            "train_progress": 0.0,
            "training": False,
            "model_updating": False,
            "training_failed": True,
            "last_error_details": {
                "error": str(e),
                "type": error_type,
                "symbol": symbol,
                "timeframe": timeframe,
                "training_mode": training_mode,
                "timestamp": datetime.now().isoformat()
            }
        }
        
        training_status.update(error_status)
        
    finally:
        # Enhanced resource cleanup and status finalization
        final_status = {
            "training": False,
            "model_updating": False,
        }
        
        # Set progress based on whether there was an error
        if training_status.get("train_error"):
            final_status["train_progress"] = 0.0
            final_status["training_completed"] = False
        else:            
            final_status["train_progress"] = 1.0
            final_status["training_completed"] = True
            
        final_status["training_failed"] = training_status.get("training_failed", False)
        training_status.update({
            "train_progress": 1.0,
            "train_status": "✅ Training completed!",
            "training": False,            # Đánh dấu đã kết thúc huấn luyện
            "prediction_ready": True,
            })  

        # Update final status
        training_status.update(final_status)
        
        # Auto reload accuracy after training if successful
        if not training_status.get("train_error") and not training_status.get("training_failed"):
            try:
                # Tự động tải lại kết quả huấn luyện
                load_training_results()
                logger.info("✅ Auto-reloaded training results after successful training")
            except Exception as e:
                training_status.update({
                "train_status": f"❌ Training failed: {e}",
                "training": False,
                "train_error": str(e),
                })
                logger.warning(f"Could not auto-reload training results: {e}")        
        # Enhanced resource cleanup
        resource_manager = get_resource_manager()
        if training_status.get("train_error"):
            resource_manager.cleanup_resources(intensity='aggressive')
            logger.info("🧹 Aggressive cleanup performed due to training error")
        else:
            resource_manager.cleanup_resources(intensity='normal')
            logger.info("🧹 Normal cleanup performed after successful training")
        
        # Log final training status
        elapsed_total = time.time() - start_time
        if training_status.get("train_error"):
            logger.error(f"❌ Training session failed after {elapsed_total:.1f}s")
        else:
            logger.info(f"✅ Training session completed successfully in {elapsed_total:.1f}s")
        



def show_accuracy(acc_data: Dict) -> None:
    """Display accuracy table"""
    if not acc_data or "accuracy_results" not in acc_data:
        st.info("ℹ️ No accuracy data. Please train models first.")
        return
    
    df_acc = pd.DataFrame(acc_data["accuracy_results"])
    df_acc["acc_display"] = df_acc["accuracy"].apply(lambda x: f"{x*100:.2f}%" if pd.notna(x) else "–")
    df_acc["bt_display"] = df_acc["backtest_accuracy"].apply(lambda x: f"{x*100:.2f}%" if pd.notna(x) else "–")
    
    display_df = df_acc[["timeframe", "model", "acc_display", "bt_display"]].copy()
    display_df.columns = ["Timeframe", "Model", "Accuracy", "Backtest"]
    st.dataframe(display_df, use_container_width=True)

def show_train_status():
    """Display enhanced training status with detailed error information"""
    # Display main status
    train_status = safe_session_state_get("train_status")
    if train_status:
        # Check if this is an error status
        if safe_session_state_get("train_error") or safe_session_state_get("training_failed"):
            st.error(train_status)
        else:
            st.info(train_status)
    
    # Display progress bar
    train_progress = safe_session_state_get("train_progress", 0.0)
    st.progress(train_progress)
    
    # Display enhanced error information if available
    if safe_session_state_get("train_error"):
        with st.expander("🔍 Chi tiết lỗi", expanded=True):
            error_details = safe_session_state_get("last_error_details", {})
            
            if error_details:
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write("**Loại lỗi:**", error_details.get("type", "unknown").title())
                    st.write("**Symbol:**", error_details.get("symbol", "N/A"))
                    st.write("**Timeframe:**", error_details.get("timeframe", "N/A"))
                    
                with col2:
                    st.write("**Training Mode:**", error_details.get("training_mode", "N/A"))
                    st.write("**Thời gian:**", error_details.get("timestamp", "N/A"))
                
                st.write("**Chi tiết lỗi:**")
                st.code(error_details.get("error", "No details available"), language="text")
                  # Display troubleshooting suggestions based on error type
                error_type = error_details.get("type", "unknown")
                
                if error_type == "data_conversion":
                    st.info("💡 **Gợi ý khắc phục:** Dữ liệu có giá trị NaN hoặc không hợp lệ. Thử tải lại dữ liệu hoặc sử dụng chế độ 'test' với ít dữ liệu hơn.")
                elif error_type == "memory":
                    st.info("💡 **Gợi ý khắc phục:** Hệ thống hết bộ nhớ. Thử giảm 'batch size', chọn chế độ 'quick' hoặc khởi động lại ứng dụng.")
                elif error_type == "dependency":
                    st.info("💡 **Gợi ý khắc phục:** Thiếu thư viện. Kiểm tra cài đặt các package cần thiết như scikit-learn, pandas, numpy.")
                elif error_type == "timeout":
                    st.info("💡 **Gợi ý khắc phục:** Quá thời gian huấn luyện. Thử giảm số epochs hoặc chọn chế độ training nhẹ hơn.")
                else:
                    st.info("💡 **Gợi ý khắc phục:** Kiểm tra log files trong thư mục logs/ để biết thêm chi tiết.")
            else:
                train_error = safe_session_state_get("train_error", "")
                st.write("**Lỗi:**", train_error)
        
        # Add retry button for failed training
        if st.button("🔄 Thử lại với cài đặt an toàn", key="retry_safe_training"):
            # Reset error states
            safe_session_state_update({
                "train_error": None,
                "training_failed": False,
                "last_error_details": {},
                "model_updating": False,
                "training": False
            })
            st.rerun()
      # Display markdown if available
    train_markdown = safe_session_state_get("train_markdown")
    if train_markdown:
        st.markdown(train_markdown, unsafe_allow_html=True)
    
    # Display training results
    train_results = safe_session_state_get("train_results")
    if train_results:
        df_metrics = pd.DataFrame(train_results)
        st.table(df_metrics)
    
    # Display success message
    if safe_session_state_get("prediction_ready") and not safe_session_state_get("train_error"):
        st.success("✅ Hoàn tất huấn luyện và đã cập nhật dự đoán!")

def show_progress_details():
    """Show detailed progress information"""
    try:
        resource_manager = get_resource_manager()
        pct = safe_session_state_get("train_progress", 0.0)
        eta_info = safe_session_state_get("eta_info", {})
        current = safe_session_state_get("current_model", "")
        
        # System health metrics
        health_score = resource_manager.get_health_score()
        resource_manager = get_resource_manager()
        health_score = resource_manager.get_health_score()
        optimal_device = resource_manager.get_optimal_device()
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("🏥 System Health", f"{health_score:.0f}/100")
        with col2:
            st.metric("🖥️ Device", optimal_device.upper())
        with col3:
            if eta_info:
                st.metric("⏱️ ETA", eta_info.get("remaining", "--:--:--"))
        
        # Progress details
        progress_text = f"**{current}**" if current else "Processing"
        status = eta_info.get("status", "⏳ Đang xử lý...")
        
        if eta_info:
            st.info(f"{status} — {progress_text} — {pct*100:.1f}%")
            remaining = eta_info.get("remaining", "--:--:--")
            elapsed = eta_info.get("elapsed", "--:--:--")
            rate = eta_info.get("rate", 0)
            
            st.progress(pct, text=f"⏱️ ETA: {remaining} | Elapsed: {elapsed} | Rate: {rate:.2f}s/step")
    except Exception as e:
        logger.warning(f"Could not show progress details: {e}")

def sync_training_status_enhanced():
    """Enhanced sync between global training_status and session_state"""
    try:
        from ai_optimizer.unified_resource_manager import training_status
          # Sync from global to session state
        for key, value in training_status.items():
            safe_session_state_set(key, value)
        
        # Tự động tải lại kết quả training nếu cần
        if training_status.get('training_completed', False) and not training_status.get('train_error'):
            # Tải lại kết quả training từ hàm load_training_results
            try:
                load_training_results()
                logger.debug("✅ Auto-synced training results after successful training")
            except Exception as e:
                logger.debug(f"Could not sync training results: {e}")
    except Exception as e:
        logger.warning(f"Enhanced status sync failed: {e}")

def handle_meta_ai():
    """Handle Meta-AI recommendations with updated AI logic"""
    train_results = safe_session_state_get('train_results')
    if train_results:
        try:
            from ai_models.ai_logic import MetaAI
            
            # Create metrics dataframe from training results
            if isinstance(train_results, list):
                metrics_df = pd.DataFrame(train_results)
            elif isinstance(train_results, dict):
                # Convert dict format to list format
                metrics_list = []
                for key, value in train_results.items():
                    if isinstance(value, dict):
                        entry = value.copy()
                        entry['model_key'] = key
                        metrics_list.append(entry)
                metrics_df = pd.DataFrame(metrics_list)
            else:
                metrics_df = pd.DataFrame()
            
            if not metrics_df.empty:
                symbol = safe_session_state_get('symbol', 'BTCUSDT')
                
                # Initialize MetaAI with enhanced AI logic
                meta = MetaAI()
                
                # Get AI-driven recommendations
                recommendations = {
                    'sentiment': meta.analyze_sentiment(symbol=symbol),
                    'trends': meta.detect_trends(metrics_df, symbol=symbol) if 'close' in metrics_df.columns else None,
                    'model_performance': metrics_df.to_dict('records') if not metrics_df.empty else []
                }
                
                safe_session_state_set('meta_recommendation', recommendations)
                logger.info("✅ Meta-AI recommendations updated with enhanced AI logic")
            else:
                logger.warning("No training results available for Meta-AI analysis")
                
        except Exception as e:
            logger.warning(f"Meta-AI recommendation failed: {e}")
            st.warning(f"⚠️ Meta-AI recommendation skipped: {e}")

def show_prediction_results():
    """Show enhanced prediction results for all timeframes"""
    # Hiển thị kết quả dự đoán tất cả khung thời gian
    show_multi_timeframe_predictions()
      # Legacy single prediction display (for backward compatibility)
    pred = safe_session_state_get("prediction")
    if isinstance(pred, dict) and ('Entry' in pred or 'entry_price' in pred):
        st.markdown("---")
        st.subheader("📌 Chi tiết dự đoán khung thời gian chính")
        
        # Basic prediction info
        col1, col2, col3 = st.columns(3)
        with col1:
            entry = pred.get('entry_price', pred.get('Entry', 0))
            tp = pred.get('take_profit', pred.get('TP', 0))
            sl = pred.get('stop_loss', pred.get('SL', 0))
            st.metric("Entry Price", f"{entry:.4f}")
            st.metric("Take Profit", f"{tp:.4f}")
            st.metric("Stop Loss", f"{sl:.4f}")
            
        with col2:
            direction = pred.get('signal', pred.get('Direction', 'NEUTRAL'))
            direction_color = "🟢" if direction == 'LONG' else "🔴" if direction == 'SHORT' else "⚫"
            st.metric("Direction", f"{direction_color} {direction}")
            probability = pred.get('probability', pred.get('Probability', 0.5))
            st.metric("Probability", f"{probability:.2%}")
            signal_quality = pred.get('signal_quality', pred.get('Signal_Quality', 'BASIC'))
            q_color = {"HIGH": "🟢", "MEDIUM": "🟡", "LOW": "🔴", "BASIC": "⚫"}.get(signal_quality, "⚫")
            st.metric("Signal Quality", f"{q_color} {signal_quality}")
    
        with col3:
            if pred.get('Advanced_Features', False) or pred.get('confidence'):
                confidence = pred.get('confidence', pred.get('Model_Confidence', 0))
                st.metric("Model Confidence", f"{confidence:.1%}")
                rr_ratio = pred.get('risk_reward_ratio', pred.get('Risk_Reward_Ratio', 1))
                st.metric("Risk:Reward", f"1:{rr_ratio:.2f}")
                sentiment = pred.get('sentiment', pred.get('Sentiment_Classification', 'Neutral'))
                st.metric("Sentiment", sentiment)
        
        timestamp = pred.get('timestamp', pred.get('Timestamp', 'Unknown'))
        st.caption(f"Last updated: {timestamp}")
    else:
        st.info("⏳ Chưa có dự đoán, vui lòng nhấn 'Dự đoán AI cho tất cả khung thời gian'")

def show_meta_ai_section(symbol: str):
    """Show Meta-AI recommendation section"""
    try:
        meta_path = os.path.join(MODEL_DIR, f"{symbol}_meta.json")
        if os.path.exists(meta_path):
            with open(meta_path, "r") as f:
                meta_data = json.load(f)
        
            st.markdown("---")
            st.subheader("🔮 Meta-AI Gợi ý")
    
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Khung thời gian tốt nhất", meta_data["best_timeframe"])
               
                st.metric("Độ chính xác", f"{meta_data['accuracy']*100:.1f}%")
            with col2:
                st.metric("Loại model", meta_data["best_model"])
                st.metric("Backtest accuracy", f"{meta_data['backtest_accuracy']*100:.1f}%")
        
            st.info(f"""
            👉 Gợi ý giao dịch:
            - Hướng: **{meta_data['direction']}**
            - Entry: **{meta_data['entry']:.2f}**
            - TP: **{meta_data['tp']:.2f}**
            - SL: **{meta_data['sl']:.2f}**
            """)
    except Exception as e:
        st.warning("⚠️ Chưa có gợi ý từ Meta-AI")


    
def get_timeframe_explanation(timeframe: str, prediction_data: dict) -> str:
    """Trả về giải thích lý do chọn khung thời gian cụ thể"""
    explanations = {
        '5m': {
            'purpose': 'Giao dịch scalping và entry/exit chính xác',
            'advantages': ['Phát hiện điểm vào/ra tức thì', 'Phù hợp day trading', 'Tín hiệu nhanh'],
            'risks': ['Nhiều noise', 'Cần theo dõi liên tục', 'Spread cost cao'],
            'ideal_for': 'Trader kinh nghiệm, vốn nhỏ, thời gian theo dõi nhiều'
        },
        '15m': {
            'purpose': 'Cân bằng giữa tốc độ và độ tin cậy',
            'advantages': ['Ít noise hơn 5m', 'Tín hiệu khá nhanh', 'Phù hợp intraday'],
            'risks': ['Vẫn cần theo dõi thường xuyên', 'Có thể bị fake signal'],
            'ideal_for': 'Trader trung bình, giao dịch trong ngày'
        },
        '30m': {
            'purpose': 'Xu hướng ngắn hạn với độ tin cậy cao hơn',
            'advantages': ['Tín hiệu ổn định hơn', 'Ít false signal', 'Phù hợp swing trade ngắn'],
            'risks': ['Chậm hơn trong entry', 'Miss một số cơ hội nhanh'],
            'ideal_for': 'Trader bận rộn, ưa thích ổn định'
        },
        '1h': {
            'purpose': 'Phân tích xu hướng trung hạn',
            'advantages': ['Tín hiệu đáng tin cậy', 'Ít stress', 'Phù hợp swing trading'],
            'risks': ['Entry không tối ưu', 'Chậm phản ứng với tin tức'],
            'ideal_for': 'Trader part-time, đầu tư trung hạn'
        },
        '4h': {
            'purpose': 'Xu hướng dài hạn và position trading',
            'advantages': ['Tín hiệu rất tin cậy', 'Ít theo dõi', 'Phù hợp hold dài'],
            'risks': ['Entry timing kém', 'Miss short-term opportunities'],
            'ideal_for': 'Investor dài hạn, ít thời gian theo dõi'
        }
    }
    
    explanation = explanations.get(timeframe, {})
    if not explanation:
        return f"Khung thời gian {timeframe} - Thông tin chưa có sẵn"
    
    # Phân tích dự đoán cụ thể
    signal = prediction_data.get('signal', 'NEUTRAL')
    probability = prediction_data.get('probability', 0.5) * 100
    confidence = prediction_data.get('confidence', 0.5) * 100
    
    reason_text = f"""
## 📊 Phân tích khung thời gian {timeframe}

### 🎯 Mục đích chính:
{explanation['purpose']}

### ✅ Ưu điểm:
{chr(10).join([f"• {adv}" for adv in explanation['advantages']])}

### ⚠️ Rủi ro:
{chr(10).join([f"• {risk}" for risk in explanation['risks']])}

### 👥 Phù hợp với:
{explanation['ideal_for']}

### 🔮 Dự đoán hiện tại:
- **Tín hiệu:** {signal}
- **Xác suất:** {probability:.1f}%
- **Độ tin cậy:** {confidence:.1f}%

### 💡 Lý do chọn khung này:
"""
    
    # Logic chọn khung thời gian dựa trên điều kiện
    if probability > 80:
        reason_text += f"• Tín hiệu rất mạnh ({probability:.1f}%) phù hợp với độ tin cậy của {timeframe}"
    elif probability > 65:
        reason_text += f"• Tín hiệu khá tốt ({probability:.1f}%) trên khung {timeframe}"
    else:
        reason_text += f"• Tín hiệu yếu ({probability:.1f}%) cần thận trọng với {timeframe}"
    
    if timeframe in ['5m', '15m'] and signal != 'NEUTRAL':
        reason_text += f"\n• Khung ngắn hạn phù hợp cho entry/exit nhanh"
    elif timeframe in ['1h', '4h'] and signal != 'NEUTRAL':
        reason_text += f"\n• Khung dài hạn cho xu hướng bền vững"
    
    return reason_text

def show_multi_timeframe_predictions():
    """Hiển thị kết quả dự đoán tất cả khung thời gian với khả năng click để xem giải thích"""
      # Lấy predictions từ unified results file
    all_predictions = {}
    timeframes = ['5m', '15m', '30m', '1h', '4h']
    symbol = safe_session_state_get('symbol', 'BTCUSDT')
    
    # Load từ prediction_results.json
    unified_results_path = os.path.join(DATA_DIR, "unified_results", "prediction_results.json")
    try:
        if os.path.exists(unified_results_path):
            with open(unified_results_path, 'r') as f:
                all_predictions_data = json.load(f)
            
            # Lọc và lấy dự đoán mới nhất cho từng timeframe
            for tf in timeframes:
                # Lọc theo symbol và timeframe
                tf_predictions = [p for p in all_predictions_data 
                                if p.get('symbol') == symbol and p.get('timeframe') == tf]
                
                # Lấy bản ghi mới nhất (theo timestamp)
                if tf_predictions:
                    latest_pred = max(tf_predictions, key=lambda x: x.get('timestamp', ''))
                    all_predictions[tf] = latest_pred
                    
        # Fallback: nếu không có dữ liệu từ unified results, thử cache cũ
        if not all_predictions:
            for tf in timeframes:
                cache_path = os.path.join(MODEL_DIR, f"{symbol}_{tf}_last_prediction.json")
                try:
                    if os.path.exists(cache_path):
                        with open(cache_path, 'r') as f:
                            pred_data = json.load(f)
                            all_predictions[tf] = pred_data
                except Exception as e:
                    logger.warning(f"Could not load prediction for {tf}: {e}")
                    
    except Exception as e:
        logger.error(f"Error loading unified predictions: {e}")
    
    if not all_predictions:
        st.info("⏳ Chưa có dự đoán nào. Vui lòng nhấn 'Dự đoán AI cho tất cả khung thời gian'")
        return
    
    st.subheader("🎯 Kết quả dự đoán tất cả khung thời gian")
    
    # Tạo columns cho từng timeframe
    cols = st.columns(len(timeframes))
    
    for i, tf in enumerate(timeframes):
        with cols[i]:
            pred = all_predictions.get(tf)
            if pred:
                signal = pred.get('signal', 'NEUTRAL')
                probability = pred.get('probability', 0.5) * 100
                
                # Color coding
                if signal == 'LONG':
                    color = '🟢'
                    bg_color = '#d4edda'
                elif signal == 'SHORT':
                    color = '🔴'
                    bg_color = '#f8d7da'
                else:
                    color = '⚫'
                    bg_color = '#e2e3e5'
                
                # Create clickable card
                card_html = f"""
                <div style="
                    background-color: {bg_color};
                    padding: 15px;
                    border-radius: 10px;
                    border: 2px solid #dee2e6;
                    text-align: center;
                    cursor: pointer;
                    margin: 5px 0;
                ">
                    <h4>{tf}</h4>
                    <p style="font-size: 1.2em; margin: 5px 0;">{color} {signal}</p>
                    <p style="margin: 5px 0;"><strong>{probability:.1f}%</strong></p>
                    <p style="font-size: 0.9em; color: #6c757d;">Click để xem giải thích</p>
                </div>
                """
                
                st.markdown(card_html, unsafe_allow_html=True)
                  # Button để hiển thị giải thích
                if st.button(f"📋 Giải thích {tf}", key=f"explain_{tf}"):
                    explanation = get_timeframe_explanation(tf, pred)
                    safe_session_state_update({
                        f'show_explanation_{tf}': True,
                        f'explanation_text_{tf}': explanation
                    })
                
                # Hiển thị giải thích nếu được chọn
                if safe_session_state_get(f'show_explanation_{tf}', False):
                    with st.expander(f"💡 Phân tích chi tiết {tf}", expanded=True):
                        explanation_text = safe_session_state_get(f'explanation_text_{tf}', '')
                        st.markdown(explanation_text)
                        if st.button(f"❌ Đóng", key=f"close_{tf}"):
                            safe_session_state_set(f'show_explanation_{tf}', False)
                            st.rerun()
            else:
                st.markdown(f"""
                <div style="
                    background-color: #f8f9fa;
                    padding: 15px;
                    border-radius: 10px;
                    border: 2px dashed #dee2e6;
                    text-align: center;
                ">
                    <h4>{tf}</h4>
                    <p>⏳ Chưa có dự đoán</p>
                </div>
                """, unsafe_allow_html=True)
    
    # Summary section
    st.markdown("---")
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📊 Tổng quan tín hiệu")
        signals = [pred.get('signal', 'NEUTRAL') for pred in all_predictions.values()]
        long_count = signals.count('LONG')
        short_count = signals.count('SHORT')
        neutral_count = signals.count('NEUTRAL')
        
        st.metric("🟢 LONG signals", long_count)
        st.metric("🔴 SHORT signals", short_count)
        st.metric("⚫ NEUTRAL signals", neutral_count)
    
    with col2:
        st.subheader("🎯 Khuyến nghị tổng hợp")
        if long_count > short_count:
            st.success(f"📈 Xu hướng TĂNG chiếm ưu thế ({long_count}/{len(all_predictions)} khung)")
            st.info("💡 Cân nhắc các vị thế LONG, đặc biệt chú ý khung thời gian có xác suất cao")
        elif short_count > long_count:
            st.error(f"📉 Xu hướng GIẢM chiếm ưu thế ({short_count}/{len(all_predictions)} khung)")
            st.info("💡 Cân nhắc các vị thế SHORT, đặc biệt chú ý khung thời gian có xác suất cao")
        else:
            st.warning("⚖️ Tín hiệu trái chiều hoặc trung tính")
            st.info("💡 Nên đợi tín hiệu rõ ràng hơn hoặc sử dụng chiến lược trung tính")
