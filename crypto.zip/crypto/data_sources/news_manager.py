"""
Unified News Manager System
Optimized version with no redundant code, Vietnamese Times New Roman support,
and full backward compatibility.
Multi-threaded and GPU optimized using unified resource manager.
"""

import sqlite3
import requests
import feedparser
import re
import json
import os
import logging
import hashlib
import time
import unicodedata
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any, Union, Set
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import RLock
import threading

# Import resource manager for optimal performance
try:
    from ai_optimizer.unified_resource_manager import UnifiedResourceManager
    RESOURCE_MANAGER_AVAILABLE = True
except ImportError:
    print("Resource manager not available")
    RESOURCE_MANAGER_AVAILABLE = False

# Import required libraries with error handling
import os

# Setup TensorFlow environment before any TensorFlow-related imports
def setup_tensorflow_environment():
    """Setup TensorFlow environment variables to avoid compatibility issues"""
    os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'  # Suppress TensorFlow warnings
    os.environ['TOKENIZERS_PARALLELISM'] = 'false'  # Avoid tokenizer warnings
    os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'  # Disable oneDNN optimizations
    # Suppress the specific register_load_context_function error
    os.environ['TF_FORCE_GPU_ALLOW_GROWTH'] = 'false'

# Setup environment before imports
setup_tensorflow_environment()

try:
    from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
    VADER_AVAILABLE = True
except ImportError:
    print("VADER Sentiment not available. Install with: pip install vaderSentiment")
    VADER_AVAILABLE = False

try:
    from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    print("Transformers not available. Install with: pip install transformers torch")
    TRANSFORMERS_AVAILABLE = False

try:
    from deep_translator import GoogleTranslator
    TRANSLATOR_AVAILABLE = True
except ImportError:
    print("Deep Translator not available. Install with: pip install deep-translator")
    TRANSLATOR_AVAILABLE = False

try:
    from summarizer import Summarizer
    BERT_SUMMARIZER_AVAILABLE = True
except ImportError:
    print("BERT Summarizer not available. Install with: pip install bert-extractive-summarizer")
    BERT_SUMMARIZER_AVAILABLE = False

# Setup logging
try:
    from config.logging_config import get_logger
    logger = get_logger(__name__)
except ImportError:
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)


class NewsManager:
    """Unified News Manager - Single class handling all news operations with maximum parallelization"""
    
    def __init__(self, db_path: str = "data/news.db", cache_dir: str = "data"):
        """Initialize the unified news manager with resource optimization"""
        self.db_path = db_path
        self.cache_dir = cache_dir
        self.lock = RLock()
        self._stats = defaultdict(int) 
          # Initialize resource manager for optimal performance
        if RESOURCE_MANAGER_AVAILABLE:
            from ai_optimizer.unified_resource_manager import get_resource_manager
            self.resource_manager = get_resource_manager()
            self.max_workers = self.resource_manager.suggest_workers()
            logger.info(f"NewsManager using {self.max_workers} workers for parallel processing")
        else:
            self.max_workers = 8  # Fallback value
            self.resource_manager = None
            logger.warning("Resource manager not available, using fallback configuration")
        
        # Ensure directories exist
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        os.makedirs(self.cache_dir, exist_ok=True)
        
        # Initialize components
        self._init_database()
        self._init_sentiment_analyzer()
        self._init_translator()
        self._init_summarizer()
        self._init_news_sources()
        
        # Cache for translations and summaries
        self.translation_cache = {}
        self.summary_cache = {}
        self.sentiment_cache = {}
        
        logger.info("NewsManager initialized successfully with parallel processing")
    
    def _init_database(self):
        """Initialize SQLite database with Vietnamese-optimized schema"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("PRAGMA foreign_keys = ON")
                conn.execute("PRAGMA journal_mode = WAL")
                conn.execute("PRAGMA synchronous = NORMAL")
                conn.execute("PRAGMA cache_size = 10000")
                
                # Create news table with Vietnamese-specific fields
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS news (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        title TEXT NOT NULL,
                        title_vi TEXT,
                        content TEXT,
                        content_vi TEXT,
                        summary TEXT,
                        summary_vi TEXT,
                        url TEXT UNIQUE,
                        source TEXT,
                        published_date TEXT,
                        sentiment_score REAL,
                        sentiment_label TEXT,
                        tags TEXT,
                        language TEXT DEFAULT 'en',
                        processed_date TEXT DEFAULT CURRENT_TIMESTAMP,
                        view_count INTEGER DEFAULT 0,
                        font_optimized INTEGER DEFAULT 0
                    )
                """)
                
                # Create indexes for performance
                conn.execute("CREATE INDEX IF NOT EXISTS idx_news_url ON news(url)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_news_source ON news(source)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_news_published ON news(published_date)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_news_sentiment ON news(sentiment_score)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_news_language ON news(language)")
                
                # Create source health monitoring table
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS source_health (
                        source TEXT PRIMARY KEY,
                        last_check TEXT,
                        status TEXT,
                        success_rate REAL,
                        avg_response_time REAL,
                        error_count INTEGER DEFAULT 0
                    )
                """)
                
                conn.commit()
                logger.info("Database initialized with Vietnamese optimization")
        except Exception as e:
            logger.error(f"Database initialization error: {e}")
            raise
    def _init_sentiment_analyzer(self):
        """Initialize sentiment analysis components with TensorFlow compatibility fix"""
        self.sentiment_analyzers = {}
        
        # Initialize VADER (most reliable)
        if VADER_AVAILABLE:
            try:
                self.sentiment_analyzers['vader'] = SentimentIntensityAnalyzer()
                logger.info("VADER sentiment analyzer initialized")
            except Exception as e:
                logger.warning(f"VADER initialization failed: {e}")
        
        # Initialize FinBERT with TensorFlow compatibility handling
        if TRANSFORMERS_AVAILABLE:
            try:
                # Set TensorFlow environment to avoid compatibility issues
                import os
                os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
                os.environ['TOKENIZERS_PARALLELISM'] = 'false'
                
                # Try to initialize with error handling for TensorFlow issues
                self.sentiment_analyzers['finbert'] = pipeline(
                    "sentiment-analysis",
                    model="ProsusAI/finbert",
                    tokenizer="ProsusAI/finbert",
                    device=-1,  # Use CPU
                    framework="pt"  # Force PyTorch backend
                )
                logger.info("FinBERT sentiment analyzer initialized")
            except Exception as e:
                logger.warning(f"FinBERT initialization failed (TensorFlow compatibility issue): {e}")
                # Try alternative model
                try:
                    self.sentiment_analyzers['cardiffnlp'] = pipeline(
                        "sentiment-analysis",
                        model="cardiffnlp/twitter-roberta-base-sentiment-latest",
                        device=-1,
                        framework="pt"
                    )
                    logger.info("Alternative sentiment analyzer (CardiffNLP) initialized")
                except Exception as e2:
                    logger.warning(f"Alternative sentiment analyzer also failed: {e2}")
        
        # Simple fallback sentiment analyzer
        if not self.sentiment_analyzers:
            logger.warning("No advanced sentiment analyzers available, using simple keyword-based analysis")
    
    def _init_translator(self):
        """Initialize translation system with Vietnamese optimization"""
        self.translator = None
        if TRANSLATOR_AVAILABLE:
            try:
                self.translator = GoogleTranslator(source='en', target='vi')
                logger.info("Google Translator initialized for Vietnamese")
            except Exception as e:
                logger.warning(f"Translator initialization failed: {e}")
      
    def _init_summarizer(self):
        """Initialize text summarization with TensorFlow compatibility fix"""
        self.summarizers = {}
        
        # Initialize BERT Summarizer
        if BERT_SUMMARIZER_AVAILABLE:
            try:
                self.summarizers['bert'] = Summarizer()
                logger.info("BERT Summarizer initialized")
            except Exception as e:
                logger.warning(f"BERT Summarizer initialization failed: {e}")
        
        # Initialize BART with TensorFlow compatibility handling
        if TRANSFORMERS_AVAILABLE:
            try:
                import os
                os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
                os.environ['TOKENIZERS_PARALLELISM'] = 'false'
                
                self.summarizers['bart'] = pipeline(
                    "summarization",
                    model="facebook/bart-large-cnn",
                    device=-1,
                    framework="pt"  # Force PyTorch backend
                )
                logger.info("BART Summarizer initialized")
            except Exception as e:
                logger.warning(f"BART Summarizer initialization failed (TensorFlow compatibility): {e}")
                # Try smaller, more compatible model
                try:
                    self.summarizers['distilbart'] = pipeline(
                        "summarization",
                        model="sshleifer/distilbart-cnn-12-6",
                        device=-1,
                        framework="pt"
                    )
                    logger.info("DistilBART Summarizer initialized as fallback")
                except Exception as e2:
                    logger.warning(f"Fallback summarizer also failed: {e2}")
    def _init_news_sources(self):
        """Initialize RSS news sources with improved error handling"""
        self.rss_sources = {
            'coindesk': {
                'url': 'https://www.coindesk.com/arc/outboundfeeds/rss/',
                'name': 'CoinDesk',
                'active': True,
                'priority': 1,
                'headers': {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            },
            'cointelegraph': {
                'url': 'https://cointelegraph.com/rss',
                'name': 'Cointelegraph',
                'active': True,
                'priority': 2,
                'headers': {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            },
            'decrypt': {
                'url': 'https://decrypt.co/feed',
                'name': 'Decrypt',
                'active': True,
                'priority': 2,
                'headers': {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            },            'bitcoinmagazine': {
                'url': 'https://bitcoinmagazine.com/feed',  # Alternative RSS feed URL
                'name': 'Bitcoin Magazine',
                'active': True,
                'priority': 3,
                'headers': {
                    'User-Agent': 'Mozilla/5.0 (compatible; NewsBot/1.0; +https://newsbot.com)',
                    'Accept': 'application/rss+xml, application/xml, text/xml, */*',
                    'Accept-Language': 'en-US,en;q=0.9',
                    'Accept-Encoding': 'gzip, deflate, br',
                    'Cache-Control': 'no-cache',
                    'Connection': 'keep-alive'
                }
            },
            'newsbtc': {
                'url': 'https://www.newsbtc.com/feed/',
                'name': 'NewsBTC',
                'active': True,
                'priority': 3,
                'headers': {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            }
        }
        logger.info(f"Initialized {len(self.rss_sources)} news sources with enhanced headers")
    
    def normalize_vietnamese_text(self, text: str) -> str:
        """Normalize Vietnamese text for Times New Roman font compatibility"""
        if not text:
            return text
        
        # Normalize Unicode to ensure proper rendering
        text = unicodedata.normalize('NFC', text)
        
        # Fix common Vietnamese punctuation issues
        text = re.sub(r'["""]', '"', text)
        text = re.sub(r"[‘’]", "'", text)       
        text = re.sub(r'…', '...', text)
        
        # Ensure proper spacing around punctuation
        text = re.sub(r'\s+([,.!?;:])', r'\1', text)
        text = re.sub(r'([,.!?;:])\s*', r'\1 ', text)
        
        # Clean up multiple spaces
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    def generate_vietnamese_css(self) -> str:
        """Generate CSS for optimal Vietnamese text display"""
        return """
        .vietnamese-text {
            font-family: "Times New Roman", "Liberation Serif", "Nimbus Roman", serif;
            font-feature-settings: "liga" 1, "kern" 1;
            text-rendering: optimizeLegibility;
            line-height: 1.6;
            letter-spacing: 0.02em;
        }
        
        .vietnamese-title {
            font-family: "Times New Roman", serif;
            font-weight: bold;
            font-size: 1.2em;
            line-height: 1.4;
        }
        
        .vietnamese-content {
            font-family: "Times New Roman", serif;
            font-size: 1em;
            line-height: 1.6;
            text-align: justify;
            hyphens: auto;
        }
        """
    
    def get_sentiment_score(self, text: str) -> Tuple[float, str]:
        """Get sentiment score using multiple analyzers"""
        if not text:
            return 0.0, 'neutral'
        
        # Check cache first
        text_hash = hashlib.md5(text.encode()).hexdigest()
        if text_hash in self.sentiment_cache:
            return self.sentiment_cache[text_hash]
        
        sentiment_scores = []
        
        # VADER sentiment
        if 'vader' in self.sentiment_analyzers:
            try:
                vader_scores = self.sentiment_analyzers['vader'].polarity_scores(text)
                compound_score = vader_scores['compound']
                sentiment_scores.append(('vader', compound_score, 0.4))  # 40% weight
            except Exception as e:
                logger.warning(f"VADER sentiment analysis failed: {e}")
        
        # FinBERT sentiment
        if 'finbert' in self.sentiment_analyzers:
            try:
                # Truncate text for FinBERT (max 512 tokens)
                truncated_text = text[:2000]
                finbert_result = self.sentiment_analyzers['finbert'](truncated_text)
                
                label = finbert_result[0]['label'].lower()
                confidence = finbert_result[0]['score']
                
                # Convert to numeric score
                if label == 'positive':
                    finbert_score = confidence
                elif label == 'negative':
                    finbert_score = -confidence
                else:
                    finbert_score = 0.0
                
                sentiment_scores.append(('finbert', finbert_score, 0.6))  # 60% weight
            except Exception as e:
                logger.warning(f"FinBERT sentiment analysis failed: {e}")
        
        # Fallback keyword-based sentiment
        if not sentiment_scores:
            try:
                positive_words = ['good', 'great', 'excellent', 'positive', 'up', 'rise', 'gain', 'profit', 'bull', 'surge', 'rally']
                negative_words = ['bad', 'terrible', 'negative', 'down', 'fall', 'loss', 'bear', 'crash', 'dump', 'decline']
                
                text_lower = text.lower()
                positive_count = sum(1 for word in positive_words if word in text_lower)
                negative_count = sum(1 for word in negative_words if word in text_lower)
                
                total_words = len(text_lower.split())
                if total_words > 0:
                    fallback_score = (positive_count - negative_count) / total_words * 10
                    fallback_score = max(-1, min(1, fallback_score))
                else:
                    fallback_score = 0.0
                
                sentiment_scores.append(('keyword', fallback_score, 1.0))
            except Exception as e:
                logger.warning(f"Fallback sentiment analysis failed: {e}")
                sentiment_scores.append(('default', 0.0, 1.0))
        
        # Calculate weighted average
        if sentiment_scores:
            total_weighted_score = sum(score * weight for _, score, weight in sentiment_scores)
            total_weight = sum(weight for _, _, weight in sentiment_scores)
            final_score = total_weighted_score / total_weight if total_weight > 0 else 0.0
        else:
            final_score = 0.0
        
        # Determine label
        if final_score > 0.1:
            label = 'positive'
        elif final_score < -0.1:
            label = 'negative'
        else:
            label = 'neutral'
        
        # Cache the result
        result = (final_score, label)
        self.sentiment_cache[text_hash] = result
        self._stats['sentiment_analyzed'] += 1
        
        return result
    
    def translate_text(self, text: str, target_lang: str = 'vi') -> str:
        """Translate text with Vietnamese font optimization"""
        if not text or not self.translator:
            return text
        
        # Check cache first
        cache_key = f"{text[:100]}_{target_lang}"
        if cache_key in self.translation_cache:
            return self.translation_cache[cache_key]
        
        try:
            # Split long text into chunks
            max_chunk_size = 4500  # Google Translate limit
            if len(text) <= max_chunk_size:
                translated = self.translator.translate(text)
            else:
                # Split by sentences for better translation
                sentences = re.split(r'[.!?]+', text)
                translated_sentences = []
                current_chunk = ""
                
                for sentence in sentences:
                    if len(current_chunk + sentence) <= max_chunk_size:
                        current_chunk += sentence + ". "
                    else:
                        if current_chunk:
                            chunk_translation = self.translator.translate(current_chunk.strip())
                            translated_sentences.append(chunk_translation)
                        current_chunk = sentence + ". "
                
                # Translate remaining chunk
                if current_chunk:
                    chunk_translation = self.translator.translate(current_chunk.strip())
                    translated_sentences.append(chunk_translation)
                
                translated = " ".join(translated_sentences)
            
            # Optimize for Vietnamese Times New Roman
            if target_lang == 'vi':
                translated = self.normalize_vietnamese_text(translated)
            
            # Cache the result
            self.translation_cache[cache_key] = translated
            self._stats['texts_translated'] += 1
            
            return translated
            
        except Exception as e:
            logger.error(f"Translation failed: {e}")
            return text
    
    def summarize_text(self, text: str, max_length: int = 150) -> str:
        """Summarize text using available summarizers"""
        if not text or len(text) < 100:
            return text
        
        # Check cache first
        cache_key = hashlib.md5(f"{text[:500]}_{max_length}".encode()).hexdigest()
        if cache_key in self.summary_cache:
            return self.summary_cache[cache_key]
        
        summary = text
        
        # Try BART summarizer first
        if 'bart' in self.summarizers:
            try:
                # BART works best with text between 100-1000 words
                word_count = len(text.split())
                if word_count > 50:
                    min_length = min(30, max_length // 3)
                    max_len = min(max_length, word_count // 3)
                    
                    result = self.summarizers['bart'](
                        text[:4000],  # Limit input length
                        max_length=max_len,
                        min_length=min_length,
                        do_sample=False
                    )
                    summary = result[0]['summary_text']
                    logger.debug("BART summarization successful")
            except Exception as e:
                logger.warning(f"BART summarization failed: {e}")
        
        # Try BERT summarizer as fallback
        if summary == text and 'bert' in self.summarizers:
            try:
                summary = self.summarizers['bert'](text, ratio=0.3)
                logger.debug("BERT summarization successful")
            except Exception as e:
                logger.warning(f"BERT summarization failed: {e}")
        
        # Extractive fallback - take first few sentences
        if summary == text:
            try:
                sentences = re.split(r'[.!?]+', text)
                summary = ". ".join(sentences[:3]) + "."
                logger.debug("Extractive summarization used")
            except Exception as e:
                logger.warning(f"Extractive summarization failed: {e}")
        
        # Cache the result
        self.summary_cache[cache_key] = summary
        self._stats['texts_summarized'] += 1
        
        return summary
    
    def fetch_rss_news(self, source_key: str = None, max_articles: int = 50) -> List[Dict]:
        """Fetch news from RSS sources"""
        articles = []
        sources_to_fetch = [source_key] if source_key else list(self.rss_sources.keys())
        
        # Filter active sources
        active_sources = [key for key in sources_to_fetch if self.rss_sources[key]['active']]
        def fetch_single_source(source_key: str) -> List[Dict]:
            source = self.rss_sources[source_key]
            source_articles = []
            start_time = time.time()
            
            try:
                # Use enhanced headers to avoid 403 errors
                headers = source.get('headers', {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                })
                
                response = requests.get(source['url'], headers=headers, timeout=30)
                response.raise_for_status()
                
                feed = feedparser.parse(response.content)
                
                for entry in feed.entries[:max_articles]:
                    try:
                        # Parse published date
                        published_date = None
                        if hasattr(entry, 'published_parsed') and entry.published_parsed:
                            published_date = datetime(*entry.published_parsed[:6]).isoformat()
                        elif hasattr(entry, 'published'):
                            published_date = entry.published
                        
                        article = {
                            'title': entry.title if hasattr(entry, 'title') else 'No Title',
                            'url': entry.link if hasattr(entry, 'link') else '',
                            'content': entry.summary if hasattr(entry, 'summary') else '',
                            'source': source['name'],
                            'published_date': published_date,
                            'tags': [tag.term for tag in entry.tags] if hasattr(entry, 'tags') else []
                        }
                        
                        source_articles.append(article)
                        
                    except Exception as e:
                        logger.warning(f"Error parsing article from {source_key}: {e}")
                
                # Update source health
                response_time = time.time() - start_time
                self._update_source_health(source_key, 'success', response_time)
                
                logger.info(f"Fetched {len(source_articles)} articles from {source['name']}")
                
            except Exception as e:
                logger.error(f"Error fetching from {source_key}: {e}")
                self._update_source_health(source_key, 'error', time.time() - start_time)
            
            return source_articles
          # Fetch from multiple sources concurrently with optimal worker count
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_source = {
                executor.submit(fetch_single_source, source_key): source_key 
                for source_key in active_sources
            }
            
            for future in as_completed(future_to_source):
                source_key = future_to_source[future]
                try:
                    source_articles = future.result()
                    articles.extend(source_articles)
                except Exception as e:
                    logger.error(f"Error processing {source_key}: {e}")
        
        # Remove duplicates
        articles = self._remove_duplicate_articles(articles)
        
        # Sort by priority and date
        articles.sort(key=lambda x: (
            self.rss_sources.get(x.get('source_key', ''), {}).get('priority', 999),
            x.get('published_date', '')
        ), reverse=True)
        
        self._stats['articles_fetched'] += len(articles)
        return articles
    
    def _remove_duplicate_articles(self, articles: List[Dict]) -> List[Dict]:
        """Remove duplicate articles based on URL and title similarity"""
        seen_urls = set()
        seen_titles = set()
        unique_articles = []
        
        for article in articles:
            url = article.get('url', '')
            title = article.get('title', '').lower().strip()
            
            # Skip if URL already seen
            if url and url in seen_urls:
                continue
            
            # Skip if very similar title already seen
            title_words = set(title.split())
            is_duplicate = False
            
            for seen_title in seen_titles:
                seen_words = set(seen_title.split())
                # Check if titles have high similarity (>70% common words)
                if len(title_words) > 0 and len(seen_words) > 0:
                    common_words = title_words.intersection(seen_words)
                    similarity = len(common_words) / max(len(title_words), len(seen_words))
                    if similarity > 0.7:
                        is_duplicate = True
                        break
            
            if not is_duplicate:
                unique_articles.append(article)
                if url:
                    seen_urls.add(url)
                if title:
                    seen_titles.add(title)
        
        logger.info(f"Removed {len(articles) - len(unique_articles)} duplicate articles")
        return unique_articles
    
    def _update_source_health(self, source_key: str, status: str, response_time: float):
        """Update source health monitoring"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                # Get current stats
                cursor = conn.execute(
                    "SELECT success_rate, avg_response_time, error_count FROM source_health WHERE source = ?",
                    (source_key,)
                )
                row = cursor.fetchone()
                
                if row:
                    success_rate, avg_response_time, error_count = row
                    # Update existing record
                    if status == 'success':
                        new_success_rate = min(1.0, success_rate * 0.9 + 0.1)
                        new_avg_time = avg_response_time * 0.8 + response_time * 0.2
                        new_error_count = max(0, error_count - 1)
                    else:
                        new_success_rate = success_rate * 0.9
                        new_avg_time = avg_response_time * 0.8 + response_time * 0.2
                        new_error_count = error_count + 1
                    
                    conn.execute("""
                        UPDATE source_health 
                        SET last_check = ?, status = ?, success_rate = ?, 
                            avg_response_time = ?, error_count = ?
                        WHERE source = ?
                    """, (datetime.now().isoformat(), status, new_success_rate, 
                          new_avg_time, new_error_count, source_key))
                else:
                    # Insert new record
                    initial_success_rate = 1.0 if status == 'success' else 0.0
                    initial_error_count = 0 if status == 'success' else 1
                    
                    conn.execute("""
                        INSERT INTO source_health 
                        (source, last_check, status, success_rate, avg_response_time, error_count)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, (source_key, datetime.now().isoformat(), status, 
                          initial_success_rate, response_time, initial_error_count))
                
                conn.commit()
        except Exception as e:
            logger.error(f"Error updating source health: {e}")
    
    def save_news_articles(self, articles: List[Dict]) -> int:
        """Save news articles to database with Vietnamese optimization"""
        saved_count = 0
        
        try:
            with sqlite3.connect(self.db_path) as conn:
                for article in articles:
                    try:
                        # Check if article already exists
                        cursor = conn.execute("SELECT id FROM news WHERE url = ?", (article.get('url', ''),))
                        if cursor.fetchone():
                            continue
                        
                        # Process article content
                        title = article.get('title', '')
                        content = article.get('content', '')
                        
                        # Generate Vietnamese translations
                        title_vi = self.translate_text(title, 'vi') if title else ''
                        content_vi = self.translate_text(content, 'vi') if content else ''
                        
                        # Generate summary
                        summary = self.summarize_text(content) if content else ''
                        summary_vi = self.translate_text(summary, 'vi') if summary else ''
                        
                        # Analyze sentiment
                        sentiment_text = f"{title} {content}"
                        sentiment_score, sentiment_label = self.get_sentiment_score(sentiment_text)
                        
                        # Prepare tags
                        tags = json.dumps(article.get('tags', []))
                        
                        # Insert article
                        conn.execute("""
                            INSERT INTO news (
                                title, title_vi, content, content_vi, summary, summary_vi,
                                url, source, published_date, sentiment_score, sentiment_label,
                                tags, language, font_optimized
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """, (
                            title, title_vi, content, content_vi, summary, summary_vi,
                            article.get('url', ''), article.get('source', ''),
                            article.get('published_date', ''), sentiment_score, sentiment_label,
                            tags, 'en', 1  # font_optimized = 1 for Vietnamese
                        ))
                        
                        saved_count += 1
                        
                    except Exception as e:
                        logger.error(f"Error saving article: {e}")
                        continue
                
                conn.commit()
                
        except Exception as e:
            logger.error(f"Database error: {e}")
        
        self._stats['articles_saved'] += saved_count
        logger.info(f"Saved {saved_count} new articles to database")
        return saved_count
    
    def get_latest_news(self, limit: int = 20, sentiment_filter: str = None, 
                       source_filter: str = None, language: str = 'vi') -> List[Dict]:
        """Get latest news with filters"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                query = """
                    SELECT id, title, title_vi, content, content_vi, summary, summary_vi,
                           url, source, published_date, sentiment_score, sentiment_label,
                           tags, view_count, processed_date
                    FROM news
                    WHERE 1=1
                """
                params = []
                
                # Apply filters
                if sentiment_filter:
                    query += " AND sentiment_label = ?"
                    params.append(sentiment_filter)
                
                if source_filter:
                    query += " AND source = ?"
                    params.append(source_filter)
                
                query += " ORDER BY published_date DESC, processed_date DESC LIMIT ?"
                params.append(limit)
                
                cursor = conn.execute(query, params)
                rows = cursor.fetchall()
                
                articles = []
                for row in rows:
                    article = {
                        'id': row[0],
                        'title': row[2] if language == 'vi' and row[2] else row[1],  # Use Vietnamese if available
                        'title_en': row[1],
                        'title_vi': row[2],
                        'content': row[4] if language == 'vi' and row[4] else row[3],
                        'content_en': row[3],
                        'content_vi': row[4],
                        'summary': row[6] if language == 'vi' and row[6] else row[5],
                        'summary_en': row[5],
                        'summary_vi': row[6],
                        'url': row[7],
                        'source': row[8],
                        'published_date': row[9],
                        'sentiment_score': row[10],
                        'sentiment_label': row[11],
                        'tags': json.loads(row[12]) if row[12] else [],
                        'view_count': row[13],
                        'processed_date': row[14],
                        'css_class': 'vietnamese-text' if language == 'vi' else ''
                    }
                    articles.append(article)
                
                # Update view counts
                if articles:
                    article_ids = [str(article['id']) for article in articles]
                    conn.execute(f"""
                        UPDATE news SET view_count = view_count + 1 
                        WHERE id IN ({','.join(['?'] * len(article_ids))})
                    """, article_ids)
                    conn.commit()
                
                self._stats['news_retrieved'] += len(articles)
                return articles
                
        except Exception as e:
            logger.error(f"Error retrieving news: {e}")
            return []
    
    def get_sentiment_analysis(self, days: int = 7) -> Dict[str, Any]:
        """Get sentiment analysis for recent news"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                since_date = (datetime.now() - timedelta(days=days)).isoformat()
                
                cursor = conn.execute("""
                    SELECT sentiment_label, COUNT(*) as count, AVG(sentiment_score) as avg_score
                    FROM news 
                    WHERE processed_date >= ?
                    GROUP BY sentiment_label
                """, (since_date,))
                
                sentiment_data = {}
                total_articles = 0
                
                for row in cursor.fetchall():
                    label, count, avg_score = row
                    sentiment_data[label] = {
                        'count': count,
                        'average_score': round(avg_score, 3),
                        'percentage': 0  # Will calculate after getting total
                    }
                    total_articles += count
                
                # Calculate percentages
                for label in sentiment_data:
                    sentiment_data[label]['percentage'] = round(
                        (sentiment_data[label]['count'] / total_articles) * 100, 1
                    ) if total_articles > 0 else 0
                
                # Get trend data
                cursor = conn.execute("""
                    SELECT DATE(processed_date) as date, AVG(sentiment_score) as avg_sentiment
                    FROM news 
                    WHERE processed_date >= ?
                    GROUP BY DATE(processed_date)
                    ORDER BY date
                """, (since_date,))
                
                trend_data = [{'date': row[0], 'sentiment': round(row[1], 3)} for row in cursor.fetchall()]
                
                return {
                    'period_days': days,
                    'total_articles': total_articles,
                    'sentiment_distribution': sentiment_data,
                    'trend': trend_data,
                    'generated_at': datetime.now().isoformat()
                }
                
        except Exception as e:
            logger.error(f"Error getting sentiment analysis: {e}")
            return {}
    
    def update_all_news(self, max_articles_per_source: int = 20) -> Dict[str, int]:
        """Update news from all sources"""
        logger.info("Starting news update from all sources")
        
        # Fetch new articles
        articles = self.fetch_rss_news(max_articles=max_articles_per_source)
        
        # Save to database
        saved_count = self.save_news_articles(articles)
        
        # Cache current data
        self._cache_data()
        
        result = {
            'fetched': len(articles),
            'saved': saved_count,
            'sources': len([s for s in self.rss_sources.values() if s['active']]),
            'timestamp': datetime.now().isoformat()
        }
        
        logger.info(f"News update completed: {result}")
        return result
    
    def _cache_data(self):
        """Cache current data to JSON files"""
        try:
            # Cache latest news
            latest_news = self.get_latest_news(limit=100, language='vi')
            cache_file = os.path.join(self.cache_dir, 'latest_news_vi.json')
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(latest_news, f, ensure_ascii=False, indent=2)
            
            # Cache sentiment analysis
            sentiment_data = self.get_sentiment_analysis(days=7)
            cache_file = os.path.join(self.cache_dir, 'sentiment_analysis.json')
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(sentiment_data, f, ensure_ascii=False, indent=2)
            
            # Cache statistics
            stats = dict(self._stats)
            stats['last_updated'] = datetime.now().isoformat()
            cache_file = os.path.join(self.cache_dir, 'news_stats.json')
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(stats, f, ensure_ascii=False, indent=2)
            
            logger.info("Data cached successfully")
            
        except Exception as e:
            logger.error(f"Error caching data: {e}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get comprehensive statistics"""
        stats = dict(self._stats)
        
        try:
            with sqlite3.connect(self.db_path) as conn:
                # Total articles
                cursor = conn.execute("SELECT COUNT(*) FROM news")
                stats['total_articles'] = cursor.fetchone()[0]
                
                # Articles by source
                cursor = conn.execute("SELECT source, COUNT(*) FROM news GROUP BY source")
                stats['articles_by_source'] = dict(cursor.fetchall())
                
                # Recent activity (last 24 hours)
                since_yesterday = (datetime.now() - timedelta(hours=24)).isoformat()
                cursor = conn.execute("SELECT COUNT(*) FROM news WHERE processed_date >= ?", (since_yesterday,))
                stats['articles_last_24h'] = cursor.fetchone()[0]
                
                # Source health
                cursor = conn.execute("SELECT source, status, success_rate FROM source_health")
                stats['source_health'] = {row[0]: {'status': row[1], 'success_rate': row[2]} for row in cursor.fetchall()}
        
        except Exception as e:
            logger.error(f"Error getting statistics: {e}")
        
        stats['cache_sizes'] = {
            'translation_cache': len(self.translation_cache),
            'summary_cache': len(self.summary_cache),
            'sentiment_cache': len(self.sentiment_cache)
        }
        
        stats['last_updated'] = datetime.now().isoformat()
        return stats
    
    def search_news(self, query: str, limit: int = 20, language: str = 'vi') -> List[Dict]:
        """Search news articles"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                search_query = f"%{query}%"
                
                # Search in both English and Vietnamese content
                cursor = conn.execute("""
                    SELECT id, title, title_vi, content, content_vi, summary, summary_vi,
                           url, source, published_date, sentiment_score, sentiment_label,
                           tags, view_count
                    FROM news
                    WHERE title LIKE ? OR title_vi LIKE ? 
                       OR content LIKE ? OR content_vi LIKE ?
                       OR summary LIKE ? OR summary_vi LIKE ?
                    ORDER BY published_date DESC
                    LIMIT ?
                """, (search_query, search_query, search_query, search_query, 
                      search_query, search_query, limit))
                
                articles = []
                for row in cursor.fetchall():
                    article = {
                        'id': row[0],
                        'title': row[2] if language == 'vi' and row[2] else row[1],
                        'title_en': row[1],
                        'title_vi': row[2],
                        'content': row[4] if language == 'vi' and row[4] else row[3],
                        'summary': row[6] if language == 'vi' and row[6] else row[5],
                        'url': row[7],
                        'source': row[8],
                        'published_date': row[9],
                        'sentiment_score': row[10],
                        'sentiment_label': row[11],
                        'tags': json.loads(row[12]) if row[12] else [],
                        'view_count': row[13]
                    }
                    articles.append(article)
                
                self._stats['searches_performed'] += 1
                return articles
                
        except Exception as e:
            logger.error(f"Error searching news: {e}")
            return []

    def batch_sentiment_analysis(self, texts: List[str]) -> List[Tuple[float, str]]:
        """Analyze sentiment for multiple texts in parallel"""
        if not texts:
            return []
        
        def analyze_single_text(text):
            return self.get_sentiment_score(text)
        from ai_optimizer.unified_resource_manager import get_resource_manager

        resource_manager = get_resource_manager()
        max_workers = resource_manager.get_optimal_workers('io')  # hoặc 'processing' tuỳ yêu cầu
        logger.info(f"NewsManager: sử dụng {max_workers} workers cho batch tasks")

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            results = list(executor.map(analyze_single_text, texts))

        
        self._stats['batch_sentiment_analyzed'] += len(texts)
        return results
    
    def batch_translation(self, texts: List[str], target_lang: str = 'vi') -> List[str]:
        """Translate multiple texts in parallel"""
        if not texts:
            return []
        
        def translate_single_text(text):
            return self.translate_text(text, target_lang)
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            results = list(executor.map(translate_single_text, texts))
        
        self._stats['batch_translations'] += len(texts)
        return results
    
    def batch_summarization(self, texts: List[str], max_length: int = 150) -> List[str]:
        """Summarize multiple texts in parallel"""
        if not texts:
            return []
        
        def summarize_single_text(text):
            return self.summarize_text(text, max_length)
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            results = list(executor.map(summarize_single_text, texts))
        
        self._stats['batch_summarizations'] += len(texts)
        return results
    
    def process_articles_parallel(self, articles: List[Dict]) -> int:
        """Process and save multiple articles with parallel sentiment/translation/summarization"""
        if not articles:
            return 0
        
        saved_count = 0
        
        try:
            with sqlite3.connect(self.db_path) as conn:                # Check for existing articles first
                existing_urls = set()
                urls = [article.get('url', '') for article in articles if article.get('url')]
                if urls:
                    placeholders = ','.join(['?' for _ in urls])
                    cursor = conn.execute(f"SELECT url FROM news WHERE url IN ({placeholders})", urls)
                    existing_urls = {row[0] for row in cursor.fetchall()}
                
                # Filter out existing articles
                new_articles = [article for article in articles if article.get('url', '') not in existing_urls]
                
                if not new_articles:
                    logger.info("No new articles to process")
                    return 0
                
                logger.info(f"Processing {len(new_articles)} new articles in parallel")
                
                # Extract texts for batch processing
                titles = [article.get('title', '') for article in new_articles]
                contents = [article.get('content', '') for article in new_articles]
                
                # Parallel translation
                logger.info("Starting parallel translation...")
                titles_vi = self.batch_translation(titles, 'vi')
                contents_vi = self.batch_translation(contents, 'vi')
                
                # Parallel summarization
                logger.info("Starting parallel summarization...")
                summaries = self.batch_summarization(contents, 150)
                summaries_vi = self.batch_translation(summaries, 'vi')
                
                # Parallel sentiment analysis
                logger.info("Starting parallel sentiment analysis...")
                sentiment_texts = [f"{title} {content}" for title, content in zip(titles, contents)]
                sentiment_results = self.batch_sentiment_analysis(sentiment_texts)
                
                # Save all processed articles
                logger.info("Saving processed articles to database...")
                for i, article in enumerate(new_articles):
                    try:
                        # Get processed data
                        title = titles[i]
                        title_vi = titles_vi[i] if i < len(titles_vi) else title
                        content = contents[i]
                        content_vi = contents_vi[i] if i < len(contents_vi) else content
                        summary = summaries[i] if i < len(summaries) else content[:200]
                        summary_vi = summaries_vi[i] if i < len(summaries_vi) else summary
                        sentiment_score, sentiment_label = sentiment_results[i] if i < len(sentiment_results) else (0.0, 'neutral')
                        
                        # Prepare tags
                        tags = json.dumps(article.get('tags', []))
                        
                        # Insert article
                        conn.execute("""
                            INSERT INTO news (
                                title, title_vi, content, content_vi, summary, summary_vi,
                                url, source, published_date, sentiment_score, sentiment_label,
                                tags, language, font_optimized
                            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """, (
                            title, title_vi, content, content_vi, summary, summary_vi,
                            article.get('url', ''), article.get('source', ''),
                            article.get('published_date', ''), sentiment_score, sentiment_label,
                            tags, 'en', 1  # font_optimized = 1 for Vietnamese
                        ))
                        
                        saved_count += 1
                        
                    except Exception as e:
                        logger.error(f"Error saving article {i}: {e}")
                        continue
                
                conn.commit()
                
        except Exception as e:
            logger.error(f"Database error in parallel processing: {e}")
        
        self._stats['articles_saved'] += saved_count
        logger.info(f"Saved {saved_count} new articles to database using parallel processing")
        return saved_count

# Backward Compatibility Layer
class OptimizedNewsManager(NewsManager):
    """Backward compatible alias for NewsManager"""
    pass


class BackwardCompatibleNewsManager(NewsManager):
    """Ensures backward compatibility with existing code"""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
    # Add any legacy method aliases here if needed


# Global instances for backward compatibility
news_manager = NewsManager()
newsManager = news_manager  # Alternative naming
optimized_news_manager = OptimizedNewsManager()

# Utility functions for backward compatibility
# Auto-initialize if running directly
if __name__ == "__main__":
    logger.info("NewsManager module loaded successfully")
    logger.info(f"Available features: Sentiment={bool(news_manager.sentiment_analyzers)}, "
                f"Translation={news_manager.translator is not None}, "
                f"Summarization={bool(news_manager.summarizers)}")
