"""
App Data Module
Chứa tất cả các hàm data loading, caching và API calls.

Module này được tách từ app_handlers.py để tối ưu hóa và dễ bảo trì.
"""

import pandas as pd
import gzip
import json
import os
import pickle
import requests
import time
from typing import Dict, Any, Optional
from datetime import datetime
from config.logging_config import get_logger
from config.settings import MODEL_DIR, DATA_DIR

logger = get_logger('app_data')

def fetch_current_price(symbol: str) -> float:
    """Fetch current price from Binance API with caching"""
    try:
        cache_key = f"price_{symbol}"
        cache_timeout = 10  # 10 seconds cache
        
        # Check cache first
        if hasattr(fetch_current_price, 'cache'):
            cached_data = fetch_current_price.cache.get(cache_key)
            if cached_data and time.time() - cached_data['timestamp'] < cache_timeout:
                return cached_data['price']
        else:
            fetch_current_price.cache = {}
        
        # Fetch from API
        url = f"https://api.binance.com/api/v3/ticker/price?symbol={symbol}"
        response = requests.get(url, timeout=5)
        
        if response.status_code == 200:
            data = response.json()
            price = float(data['price'])
            
            # Cache result
            fetch_current_price.cache[cache_key] = {
                'price': price,
                'timestamp': time.time()
            }
            
            return price
        else:
            logger.warning(f"Failed to fetch price for {symbol}: HTTP {response.status_code}")
            return 0.0
            
    except Exception as e:
        logger.error(f"Price fetch error for {symbol}: {e}")
        return 0.0

def get_base_price(symbol: str) -> float:
    """Get base price for percentage calculations"""
    try:
        # Try to get from recent data first
        recent_data = load_cached_chart(symbol)
        if recent_data is not None and not recent_data.empty:
            return recent_data['close'].iloc[-1]
        
        # Fallback to API
        return fetch_current_price(symbol)
        
    except Exception as e:
        logger.error(f"Base price fetch error: {e}")
        return 1.0  # Fallback

def load_cached_chart(symbol: str) -> Optional[pd.DataFrame]:
    """Load cached chart data for a symbol"""
    try:
        # Try multiple data sources
        data_files = [
            f"{DATA_DIR}/{symbol}_combined.csv",
            f"{DATA_DIR}/{symbol}_test_pipeline.csv",
            f"{DATA_DIR}/{symbol}_test_simple.csv"
        ]
        
        for file_path in data_files:
            if os.path.exists(file_path):
                try:
                    df = pd.read_csv(file_path)
                    
                    # Ensure required columns exist
                    required_cols = ['open', 'high', 'low', 'close', 'volume']
                    if all(col in df.columns for col in required_cols):
                        # Convert timestamp column if exists
                        if 'timestamp' in df.columns:
                            df['timestamp'] = pd.to_datetime(df['timestamp'])
                            df.set_index('timestamp', inplace=True)
                        elif 'open_time' in df.columns:
                            df['open_time'] = pd.to_datetime(df['open_time'])
                            df.set_index('open_time', inplace=True)
                        
                        # Get recent data (last 500 candles)
                        if len(df) > 500:
                            df = df.tail(500)
                            
                        logger.info(f"✅ Loaded cached chart data for {symbol}: {len(df)} rows from {file_path}")
                        return df
                        
                except Exception as e:
                    logger.warning(f"Failed to load {file_path}: {e}")
                    continue
        
        logger.warning(f"No cached chart data found for {symbol}")
        return None
        
    except Exception as e:
        logger.error(f"Chart loading error: {e}")
        return None

def load_training_results() -> Dict[str, Any]:
    """Load latest training results from files"""
    try:
        results = {
            'models_found': 0,
            'best_accuracy': 0.0,
            'latest_training': None,
            'models': {},
            'performance_summary': {}
        }
        
        if not os.path.exists(MODEL_DIR):
            logger.warning(f"Model directory not found: {MODEL_DIR}")
            return results
        
        # Find latest model files
        model_files = []
        for filename in os.listdir(MODEL_DIR):
            if filename.endswith('.pkl.gz') or filename.endswith('.pkl'):
                file_path = os.path.join(MODEL_DIR, filename)
                stat = os.stat(file_path)
                model_files.append({
                    'filename': filename,
                    'path': file_path,
                    'modified': stat.st_mtime,
                    'size': stat.st_size
                })
        
        # Sort by modification time (newest first)
        model_files.sort(key=lambda x: x['modified'], reverse=True)
        
        results['models_found'] = len(model_files)
        
        if model_files:
            results['latest_training'] = datetime.fromtimestamp(model_files[0]['modified'])
        
        # Extract model information
        models_info = _extract_from_model_files(model_files[:10])  # Process top 10 newest
        results.update(models_info)
        
        logger.info(f"✅ Training results loaded: {len(model_files)} models found")
        return results
        
    except Exception as e:
        logger.error(f"Training results loading error: {e}")
        return {
            'models_found': 0,
            'error': str(e)
        }

def _extract_from_model_files(model_files: list) -> Dict[str, Any]:
    """Extract information from model files"""
    try:
        models = {}
        accuracies = []
        
        for model_file in model_files:
            try:
                if model_file['filename'].endswith('.pkl.gz'):
                    with gzip.open(model_file['path'], 'rb') as f:
                        model_data = pickle.load(f)
                else:
                    with open(model_file['path'], 'rb') as f:
                        model_data = pickle.load(f)
                
                # Extract model info
                model_name = model_file['filename'].replace('.pkl.gz', '').replace('.pkl', '')
                
                if isinstance(model_data, dict):
                    accuracy = model_data.get('accuracy', 0.0)
                    if accuracy == 0.0:
                        # Try nested performance data
                        performance = model_data.get('performance', {})
                        if isinstance(performance, dict):
                            accuracy = performance.get('accuracy', performance.get('best_accuracy', 0.0))
                    
                    models[model_name] = {
                        'accuracy': accuracy,
                        'file_size': model_file['size'],
                        'modified': datetime.fromtimestamp(model_file['modified']),
                        'type': 'ensemble' if 'ensemble' in model_name.lower() else 'single',
                        'has_scaler': 'scaler' in model_data,
                        'has_features': 'features' in model_data or 'feature_columns' in model_data
                    }
                    
                    if accuracy > 0:
                        accuracies.append(accuracy)
                        
                else:
                    # Handle non-dict model data
                    models[model_name] = {
                        'accuracy': 0.0,
                        'file_size': model_file['size'],
                        'modified': datetime.fromtimestamp(model_file['modified']),
                        'type': 'unknown',
                        'has_scaler': False,
                        'has_features': False
                    }
                    
            except Exception as e:
                logger.warning(f"Failed to extract info from {model_file['filename']}: {e}")
                continue
        
        return {
            'models': models,
            'best_accuracy': max(accuracies) if accuracies else 0.0,
            'avg_accuracy': sum(accuracies) / len(accuracies) if accuracies else 0.0,
            'performance_summary': {
                'total_models': len(models),
                'models_with_accuracy': len(accuracies),
                'ensemble_models': len([m for m in models.values() if m['type'] == 'ensemble']),
                'single_models': len([m for m in models.values() if m['type'] == 'single'])
            }
        }
        
    except Exception as e:
        logger.error(f"Model file extraction error: {e}")
        return {'models': {}, 'best_accuracy': 0.0}

def log_function_data(function_name: str, data: Dict[str, Any]):
    """Log function call data for debugging"""
    try:
        log_dir = "logs"
        os.makedirs(log_dir, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = os.path.join(log_dir, f"function_calls_{timestamp}.json")
        
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'function': function_name,
            'data': data
        }
        
        # Append to log file
        if os.path.exists(log_file):
            with open(log_file, 'r') as f:
                logs = json.load(f)
        else:
            logs = []
            
        logs.append(log_entry)
        
        # Keep only last 100 entries
        if len(logs) > 100:
            logs = logs[-100:]
            
        with open(log_file, 'w') as f:
            json.dump(logs, f, indent=2, default=str)
            
    except Exception as e:
        logger.warning(f"Function logging error: {e}")

def reload_data(symbol: str, timeframe: str) -> Dict[str, Any]:
    """Reload data for symbol and timeframe"""
    try:
        logger.info(f"🔄 Reloading data for {symbol}@{timeframe}")
        
        # Clear caches
        if hasattr(fetch_current_price, 'cache'):
            fetch_current_price.cache.clear()
            
        # Try to load fresh data from unified data loader
        try:
            from data_processing.unified_data_loader import unified_loader
            fresh_data = unified_loader.load_and_process_data(
                symbol=symbol,
                timeframe=timeframe,
                apply_labels=False,
                force_reload=True
            )
            
            if fresh_data is not None and not fresh_data.empty:
                logger.info(f"✅ Fresh data loaded: {len(fresh_data)} rows")
                return {
                    'success': True,
                    'data': fresh_data,
                    'rows': len(fresh_data),
                    'source': 'unified_loader'
                }
                
        except Exception as e:
            logger.warning(f"Unified loader failed: {e}")
        
        # Fallback to cached data
        cached_data = load_cached_chart(symbol)
        if cached_data is not None:
            return {
                'success': True,
                'data': cached_data,
                'rows': len(cached_data),
                'source': 'cached'
            }
        
        # Ultimate fallback - generate sample data
        logger.warning(f"No data sources available for {symbol}, generating sample data")
        sample_data = _generate_sample_data(symbol)
        
        return {
            'success': False,
            'data': sample_data,
            'rows': len(sample_data),
            'source': 'sample',
            'warning': 'Using sample data - no real data available'
        }
        
    except Exception as e:
        logger.error(f"Data reload error: {e}")
        return {
            'success': False,
            'error': str(e),
            'data': None
        }

def _generate_sample_data(symbol: str, periods: int = 100) -> pd.DataFrame:
    """Generate sample OHLCV data for testing"""
    try:
        import numpy as np
        
        # Base price based on symbol
        base_prices = {
            'BTCUSDT': 45000,
            'ETHUSDT': 3000,
            'ADAUSDT': 0.5,
            'DOTUSDT': 25,
            'LINKUSDT': 15,
            'BNBUSDT': 400
        }
        
        base_price = base_prices.get(symbol, 100)
        
        # Generate random walk
        np.random.seed(42)  # For reproducible sample data
        
        # Price changes (smaller volatility for more realistic data)
        returns = np.random.normal(0, 0.02, periods)
        prices = [base_price]
        
        for i in range(periods - 1):
            new_price = prices[-1] * (1 + returns[i])
            prices.append(max(new_price, base_price * 0.5))  # Prevent too low prices
        
        # Generate OHLCV
        data = []
        for i, close in enumerate(prices):
            # Realistic OHLC relationships
            open_price = prices[i-1] if i > 0 else close
            high = max(open_price, close) * (1 + abs(np.random.normal(0, 0.01)))
            low = min(open_price, close) * (1 - abs(np.random.normal(0, 0.01)))
            volume = abs(np.random.normal(1000000, 200000))
            
            data.append({
                'open': open_price,
                'high': high,
                'low': low,
                'close': close,
                'volume': volume
            })
        
        # Create DataFrame with timestamp index
        df = pd.DataFrame(data)
        timestamps = pd.date_range(
            start=datetime.now() - pd.Timedelta(hours=periods),
            periods=periods,
            freq='H'
        )
        df.index = timestamps
        
        logger.info(f"Generated {len(df)} rows of sample data for {symbol}")
        return df
        
    except Exception as e:
        logger.error(f"Sample data generation error: {e}")
        # Return minimal fallback data
        return pd.DataFrame({
            'open': [100],
            'high': [105],
            'low': [95],
            'close': [102],
            'volume': [1000000]
        }, index=[datetime.now()])

def get_market_data_summary(df: pd.DataFrame) -> Dict[str, Any]:
    """Get summary statistics for market data"""
    try:
        if df is None or df.empty:
            return {}
        
        summary = {
            'total_rows': len(df),
            'date_range': {
                'start': df.index[0].isoformat() if hasattr(df.index[0], 'isoformat') else str(df.index[0]),
                'end': df.index[-1].isoformat() if hasattr(df.index[-1], 'isoformat') else str(df.index[-1])
            },
            'price_stats': {
                'current': df['close'].iloc[-1],
                'high_24h': df['high'].tail(24).max() if len(df) >= 24 else df['high'].max(),
                'low_24h': df['low'].tail(24).min() if len(df) >= 24 else df['low'].min(),
                'change_24h': 0.0
            },
            'volume_stats': {
                'current': df['volume'].iloc[-1],
                'avg_24h': df['volume'].tail(24).mean() if len(df) >= 24 else df['volume'].mean(),
                'total_24h': df['volume'].tail(24).sum() if len(df) >= 24 else df['volume'].sum()
            }
        }
        
        # Calculate 24h change
        if len(df) >= 24:
            price_24h_ago = df['close'].iloc[-24]
            current_price = df['close'].iloc[-1]
            summary['price_stats']['change_24h'] = ((current_price - price_24h_ago) / price_24h_ago) * 100
        
        return summary
        
    except Exception as e:
        logger.error(f"Market data summary error: {e}")
        return {}

def cache_prediction_result(symbol: str, timeframe: str, result: Dict[str, Any]):
    """Cache prediction result for quick access"""
    try:
        cache_dir = "cache"
        os.makedirs(cache_dir, exist_ok=True)
        
        cache_file = os.path.join(cache_dir, f"prediction_{symbol}_{timeframe}.json")
        
        cache_data = {
            'timestamp': time.time(),
            'symbol': symbol,
            'timeframe': timeframe,
            'result': result
        }
        
        with open(cache_file, 'w') as f:
            json.dump(cache_data, f, indent=2, default=str)
            
        logger.debug(f"Cached prediction result for {symbol}@{timeframe}")
        
    except Exception as e:
        logger.warning(f"Prediction cache error: {e}")

def load_cached_prediction(symbol: str, timeframe: str, max_age: int = 300) -> Optional[Dict[str, Any]]:
    """Load cached prediction result if not too old"""
    try:
        cache_file = os.path.join("cache", f"prediction_{symbol}_{timeframe}.json")
        
        if not os.path.exists(cache_file):
            return None
            
        with open(cache_file, 'r') as f:
            cache_data = json.load(f)
            
        # Check age
        cache_age = time.time() - cache_data['timestamp']
        if cache_age > max_age:
            return None
            
        logger.debug(f"Loaded cached prediction for {symbol}@{timeframe} (age: {cache_age:.1f}s)")
        return cache_data['result']
        
    except Exception as e:
        logger.warning(f"Prediction cache load error: {e}")
        return None

def get_data_freshness_info(symbol: str) -> Dict[str, Any]:
    """Get information about data freshness"""
    try:
        info = {
            'cached_files': [],
            'api_available': False,
            'recommendation': 'unknown'
        }
        
        # Check cached files
        data_files = [
            f"{DATA_DIR}/{symbol}_combined.csv",
            f"{DATA_DIR}/{symbol}_test_pipeline.csv", 
            f"{DATA_DIR}/{symbol}_test_simple.csv"
        ]
        
        for file_path in data_files:
            if os.path.exists(file_path):
                stat = os.stat(file_path)
                age_hours = (time.time() - stat.st_mtime) / 3600
                
                info['cached_files'].append({
                    'file': os.path.basename(file_path),
                    'age_hours': age_hours,
                    'size_mb': stat.st_size / (1024*1024),
                    'fresh': age_hours < 24
                })
        
        # Test API availability
        try:
            test_price = fetch_current_price(symbol)
            info['api_available'] = test_price > 0
        except:
            info['api_available'] = False
        
        # Generate recommendation
        if info['api_available']:
            info['recommendation'] = 'api_preferred'
        elif any(f['fresh'] for f in info['cached_files']):
            info['recommendation'] = 'cache_ok'
        else:
            info['recommendation'] = 'data_stale'
            
        return info
        
    except Exception as e:
        logger.error(f"Data freshness check error: {e}")
        return {'error': str(e)}

# Global data cache
_data_cache = {}
_cache_timeout = 300  # 5 minutes

def get_cached_or_fetch(key: str, fetch_func, *args, **kwargs):
    """Generic cache wrapper for data fetching functions"""
    try:
        global _data_cache
        
        # Check cache
        if key in _data_cache:
            cached_item = _data_cache[key]
            if time.time() - cached_item['timestamp'] < _cache_timeout:
                return cached_item['data']
        
        # Fetch fresh data
        data = fetch_func(*args, **kwargs)
        
        # Cache result
        _data_cache[key] = {
            'data': data,
            'timestamp': time.time()
        }
        
        # Clean old cache entries
        if len(_data_cache) > 100:
            # Remove oldest entries
            sorted_items = sorted(_data_cache.items(), key=lambda x: x[1]['timestamp'])
            for old_key, _ in sorted_items[:20]:
                del _data_cache[old_key]
        
        return data
        
    except Exception as e:
        logger.error(f"Cache wrapper error: {e}")
        # Try to call function directly if cache fails
        return fetch_func(*args, **kwargs)
