"""
App UI Module
Chứa tất cả các hàm UI rendering cho Streamlit app.

Module này được tách từ app_handlers.py để tối ưu hóa và dễ bảo trì.
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import time
from datetime import datetime, timedelta
import pytz
from typing import Dict, Any, Optional
from config.logging_config import get_logger

logger = get_logger('app_ui')

def format_eta(seconds: float) -> str:
    """Format ETA seconds to human readable string"""
    if seconds <= 0:
        return "N/A"
    
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    seconds = int(seconds % 60)
    
    if hours > 0:
        return f"{hours}h {minutes}m {seconds}s"
    elif minutes > 0:
        return f"{minutes}m {seconds}s"
    else:
        return f"{seconds}s"

def format_price(price: float) -> str:
    """Format price with appropriate decimal places"""
    if price >= 1000:
        return f"${price:,.2f}"
    elif price >= 1:
        return f"${price:.4f}"
    else:
        return f"${price:.8f}"

def create_chart(df: pd.DataFrame, pred: Dict[str, Any] = None, tp_sl: Dict[str, Any] = None):
    """Create interactive candlestick chart with predictions"""
    try:
        if df is None or df.empty:
            st.warning("No data available for chart")
            return None
            
        # Prepare data
        df_chart = df.copy()
        
        # Create subplots
        fig = make_subplots(
            rows=2, cols=1,
            shared_xaxes=True,
            vertical_spacing=0.1,
            subplot_titles=('Price Chart', 'Volume'),
            row_heights=[0.7, 0.3]
        )
        
        # Add candlestick chart
        fig.add_trace(
            go.Candlestick(
                x=df_chart.index,
                open=df_chart['open'],
                high=df_chart['high'],
                low=df_chart['low'],
                close=df_chart['close'],
                name="Price",
                increasing_line_color='#00ff88',
                decreasing_line_color='#ff4444'
            ),
            row=1, col=1
        )
        
        # Add volume
        colors = ['#00ff88' if close >= open else '#ff4444' 
                 for close, open in zip(df_chart['close'], df_chart['open'])]
        
        fig.add_trace(
            go.Bar(
                x=df_chart.index,
                y=df_chart['volume'],
                name="Volume",
                marker_color=colors,
                opacity=0.7
            ),
            row=2, col=1
        )
        
        # Add prediction markers
        if pred and isinstance(pred, dict):
            current_price = df_chart['close'].iloc[-1]
            current_time = df_chart.index[-1]
            
            # Prediction arrow
            direction = pred.get('direction', 'HOLD')
            if direction in ['LONG', 'BUY']:
                arrow_color = '#00ff88'
                arrow_symbol = 'triangle-up'
            elif direction in ['SHORT', 'SELL']:
                arrow_color = '#ff4444'
                arrow_symbol = 'triangle-down'
            else:
                arrow_color = '#ffaa00'
                arrow_symbol = 'circle'
            
            fig.add_trace(
                go.Scatter(
                    x=[current_time],
                    y=[current_price],
                    mode='markers',
                    marker=dict(
                        symbol=arrow_symbol,
                        size=15,
                        color=arrow_color,
                        line=dict(width=2, color='white')
                    ),
                    name=f"Signal: {direction}",
                    showlegend=True
                ),
                row=1, col=1
            )
            
            # Add TP/SL lines if available
            if tp_sl:
                tp_price = tp_sl.get('TP')
                sl_price = tp_sl.get('SL')
                
                if tp_price:
                    fig.add_hline(
                        y=tp_price,
                        line_dash="dash",
                        line_color="#00ff88",
                        annotation_text=f"TP: {format_price(tp_price)}",
                        annotation_position="bottom right",
                        row=1, col=1
                    )
                
                if sl_price:
                    fig.add_hline(
                        y=sl_price,
                        line_dash="dash", 
                        line_color="#ff4444",
                        annotation_text=f"SL: {format_price(sl_price)}",
                        annotation_position="top right",
                        row=1, col=1
                    )
          # Update layout for full-width display
        fig.update_layout(
            title={
                'text': "Crypto Price Analysis",
                'x': 0.5,
                'xanchor': 'center',
                'font': {'size': 20, 'color': 'white'}
            },
            xaxis_title="Time",
            yaxis_title="Price (USDT)",
            template="plotly_dark",
            showlegend=True,
            height=700,  # Increased height for better visibility
            width=None,  # Let it use full width
            margin=dict(l=50, r=50, t=80, b=50),
            plot_bgcolor='rgba(0,0,0,0.8)',
            paper_bgcolor='rgba(0,0,0,0.9)',
            font=dict(color='white', size=12),
            legend=dict(
                orientation="h",
                yanchor="bottom",
                y=1.02,
                xanchor="right",
                x=1
            )
        )
        
        # Remove range slider
        fig.update_layout(xaxis_rangeslider_visible=False)
        
        return fig
        
    except Exception as e:
        logger.error(f"❌ Chart creation failed: {e}")
        st.error(f"Chart creation failed: {e}")
        return None

def show_startup_msg(pred_loaded: bool = None, chart_loaded: bool = None):
    """Show startup status message"""
    try:
        status_msgs = []
        
        if pred_loaded is True:
            status_msgs.append("✅ AI Prediction Engine")
        elif pred_loaded is False:
            status_msgs.append("❌ AI Prediction Engine")
        
        if chart_loaded is True:
            status_msgs.append("✅ Chart Data")
        elif chart_loaded is False:
            status_msgs.append("❌ Chart Data")
            
        if status_msgs:
            st.info(" | ".join(status_msgs))
            
    except Exception as e:
        logger.error(f"Startup message error: {e}")

def render_realtime_clock():
    """Render realtime clock in sidebar for Vietnam timezone (non-blocking, always updates)"""
    import streamlit as st
    from datetime import datetime
    import pytz
    try:
        vietnam_tz = pytz.timezone('Asia/Ho_Chi_Minh')
        current_time = datetime.now(vietnam_tz)
        time_str = current_time.strftime("%H:%M:%S")
        date_str = current_time.strftime("%d-%m-%Y")
        st.sidebar.markdown(f"""
        <div style='text-align: center; padding: 15px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 15px; margin-bottom: 20px; color: white; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);'>
            <div style='font-size: 14px; margin-bottom: 5px; opacity: 0.9;'>🕒 Giờ Việt Nam</div>
            <div style='font-size: 24px; font-weight: bold; font-family: monospace; margin: 8px 0;'>{time_str}</div>
            <div style='font-size: 12px; opacity: 0.8;'>📅 Ngày: {date_str}</div>
        </div>
        """, unsafe_allow_html=True)
        # Use query param to force rerun every second (Streamlit best practice)
        st.experimental_set_query_params(_clock=str(current_time.second))
    except Exception as e:
        logger.error(f"Clock rendering error: {e}")
        st.sidebar.error("⏰ Clock error")

def render_sidebar(symbol: str = None):
    """Render streamlined sidebar: realtime clock, price, MetaAI, Fear & Greed Index only, with real-time clock update"""
    import streamlit as st
    st.sidebar.title("🚀 Crypto AI Trader")
    render_realtime_clock()
    st.sidebar.markdown("---")
    # Real-time price
    from app_data import fetch_current_price
    selected_symbol = symbol if symbol else "BTCUSDT"
    try:
        current_price = fetch_current_price(selected_symbol)
        if current_price:
            st.sidebar.success(f"💹 Giá hiện tại: {format_price(current_price)}")
    except:
        st.sidebar.info("Không lấy được giá coin")
    st.sidebar.markdown("---")
    # MetaAI suggestion placeholder (to be implemented)
    st.sidebar.markdown("**🤖 Gợi ý MetaAI:**")
    st.sidebar.info("(Đang cập nhật...)")
    st.sidebar.markdown("---")
    render_fear_greed_index()

def show_price_widget(symbol: str, price_container, time_container):
    """Show real-time price widget"""
    try:
        from app_data import fetch_current_price
        
        # Get current price
        current_price = fetch_current_price(symbol)
        
        if current_price > 0:
            # Format price
            formatted_price = format_price(current_price)
            
            # Show price with animation
            price_container.metric(
                label=f"{symbol} Price",
                value=formatted_price,
                delta=None,  # Could add delta calculation here
                help="Real-time price from exchange"
            )
        else:
            price_container.error("❌ Price fetch failed")
            
        # Show current time
        current_time = datetime.now().strftime("%H:%M:%S")
        time_container.text(f"Last Update: {current_time}")
        
    except Exception as e:
        logger.error(f"Price widget error: {e}")
        price_container.error(f"Price error: {e}")

def show_realtime_clock():
    """Show real-time clock"""
    try:
        current_time = datetime.now()
        
        # Time in different formats
        local_time = current_time.strftime("%Y-%m-%d %H:%M:%S")
        utc_time = datetime.utcnow().strftime("%H:%M:%S UTC")
        
        col1, col2 = st.columns(2)
        with col1:
            st.text(f"🕒 Local: {local_time}")
        with col2:
            st.text(f"🌍 UTC: {utc_time}")
            
        # Market status
        hour = current_time.hour
        if 0 <= hour < 6:
            market_status = "🌙 Low Activity"
        elif 6 <= hour < 12:
            market_status = "🌅 Asian Session"
        elif 12 <= hour < 18:
            market_status = "☀️ European Session"
        else:
            market_status = "🌆 US Session"
            
        st.text(f"📊 {market_status}")
        
    except Exception as e:
        logger.error(f"Clock error: {e}")

def show_prediction_eta():
    """Show prediction ETA and progress"""
    try:
        # Get training status
        from ai_optimizer.unified_resource_manager import training_status
        
        if training_status.get('training', False):
            progress = training_status.get('train_progress', 0.0)
            current_step = training_status.get('current_step', 'Processing...')
            eta_seconds = training_status.get('eta_seconds', 0)
            
            # Progress bar
            st.progress(progress)
            
            # Status info
            col1, col2 = st.columns(2)
            with col1:
                st.text(f"⚡ {current_step}")
            with col2:
                if eta_seconds > 0:
                    eta_formatted = format_eta(eta_seconds)
                    st.text(f"⏱️ ETA: {eta_formatted}")
                else:
                    st.text("⏱️ ETA: Calculating...")
                    
        elif training_status.get('predicting', False):
            st.info("🔮 AI Prediction in progress...")
            
            # Show spinning indicator
            with st.spinner("Analyzing market data..."):
                time.sleep(0.1)  # Small delay for visual effect
                
        else:
            st.success("✅ AI Ready")
            
    except Exception as e:
        logger.error(f"ETA display error: {e}")

def format_time_ago(seconds: float) -> str:
    """Format time ago in human readable format"""
    if seconds < 60:
        return f"{int(seconds)} seconds ago"
    elif seconds < 3600:
        minutes = int(seconds / 60)
        return f"{minutes} minute{'s' if minutes != 1 else ''} ago"
    elif seconds < 86400:
        hours = int(seconds / 3600)
        return f"{hours} hour{'s' if hours != 1 else ''} ago"
    else:
        days = int(seconds / 86400)
        return f"{days} day{'s' if days != 1 else ''} ago"

def show_model_performance_table(models_info: Dict[str, Any]):
    """Show model performance in a table"""
    try:
        if not models_info or not models_info.get('models'):
            st.warning("No model performance data available")
            return
            
        # Prepare data for table
        table_data = []
        for model_name, model_data in models_info['models'].items():
            table_data.append({
                'Model': model_name,
                'Accuracy': f"{model_data.get('accuracy', 0):.3f}",
                'Weight': f"{model_data.get('weight', 0):.3f}",
                'Threshold': f"{model_data.get('threshold', 0.5):.2f}",
                'Type': 'Ensemble' if model_data.get('is_ensemble') else 'Single',
                'Status': '✅ Loaded' if model_data.get('loaded') else '❌ Error'
            })
            
        if table_data:
            df_table = pd.DataFrame(table_data)
            st.dataframe(df_table, use_container_width=True)
            
            # Summary stats
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Total Models", models_info.get('total_models', 0))
            with col2:
                st.metric("Active Models", models_info.get('weighted_models', 0))
            with col3:
                best_acc = models_info.get('best_accuracy', 0)
                st.metric("Best Accuracy", f"{best_acc:.3f}")
                
    except Exception as e:
        logger.error(f"Model performance table error: {e}")
        st.error(f"Failed to show model performance: {e}")

def show_training_progress_card(training_info: Dict[str, Any]):
    """Show training progress in a card format"""
    try:
        with st.container():
            st.markdown("### 🎯 Training Progress")
            
            if training_info.get('training', False):
                progress = training_info.get('train_progress', 0.0)
                step_num = training_info.get('step_number', 0)
                total_steps = training_info.get('total_steps', 30)
                current_step = training_info.get('current_step', 'Processing...')
                
                # Progress bar
                st.progress(progress)
                
                # Step info
                col1, col2 = st.columns(2)
                with col1:
                    st.text(f"Step {step_num}/{total_steps}")
                with col2:
                    progress_percent = progress * 100
                    st.text(f"{progress_percent:.1f}% Complete")
                
                # Current step
                st.text(f"🔄 {current_step}")
                
                # ETA
                eta_seconds = training_info.get('eta_seconds', 0)
                if eta_seconds > 0:
                    eta_formatted = format_eta(eta_seconds)
                    st.text(f"⏱️ ETA: {eta_formatted}")
                    
            else:
                st.success("✅ Training Complete")
                
                # Show last training info if available
                last_training = training_info.get('last_training_time')
                if last_training:
                    time_ago = time.time() - last_training
                    st.text(f"Last training: {format_time_ago(time_ago)}")
                    
    except Exception as e:
        logger.error(f"Training progress card error: {e}")

def show_market_analysis_card(market_data: Dict[str, Any]):
    """Show market analysis in a card format"""
    try:
        with st.container():
            st.markdown("### 📊 Market Analysis")
            
            if not market_data:
                st.info("No market analysis data available")
                return
                
            # Market regime
            regime = market_data.get('regime', {})
            volatility = regime.get('volatility', 'UNKNOWN')
            trend_strength = regime.get('trend_strength', 0)
            volume_trend = regime.get('volume_trend', 1.0)
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                # Volatility indicator
                vol_color = {
                    'HIGH': '🔴',
                    'NORMAL': '🟡', 
                    'LOW': '🟢'
                }.get(volatility, '⚪')
                st.metric("Volatility", f"{vol_color} {volatility}")
                
            with col2:
                # Trend strength
                trend_color = '🔴' if trend_strength > 0.7 else '🟡' if trend_strength > 0.3 else '🟢'
                st.metric("Trend Strength", f"{trend_color} {trend_strength:.2f}")
                
            with col3:
                # Volume trend
                vol_indicator = '📈' if volume_trend > 1.2 else '📉' if volume_trend < 0.8 else '➡️'
                st.metric("Volume Trend", f"{vol_indicator} {volume_trend:.2f}")
                
            # Market state
            market_state = regime.get('market_state', 'UNKNOWN')
            if market_state != 'UNKNOWN':
                state_colors = {
                    'TRENDING_VOLATILE': '🔴',
                    'STRONG_TREND': '🟢',
                    'SIDEWAYS_CALM': '🔵',
                    'CHOPPY_VOLATILE': '🟠',
                    'NORMAL_MARKET': '⚪'
                }
                state_icon = state_colors.get(market_state, '⚪')
                st.info(f"{state_icon} Market State: {market_state.replace('_', ' ').title()}")
                
    except Exception as e:
        logger.error(f"Market analysis card error: {e}")

def show_prediction_confidence_gauge(confidence: float, threshold: float = 0.6):
    """Show prediction confidence as a gauge"""
    try:
        # Create gauge chart
        fig = go.Figure(go.Indicator(
            mode = "gauge+number+delta",
            value = confidence,
            domain = {'x': [0, 1], 'y': [0, 1]},
            title = {'text': "Prediction Confidence"},
            delta = {'reference': threshold},
            gauge = {
                'axis': {'range': [None, 1]},
                'bar': {'color': "darkblue"},
                'steps': [
                    {'range': [0, 0.4], 'color': "lightgray"},
                    {'range': [0.4, 0.6], 'color': "yellow"},
                    {'range': [0.6, 1], 'color': "green"}
                ],
                'threshold': {
                    'line': {'color': "red", 'width': 4},
                    'thickness': 0.75,
                    'value': threshold
                }
            }
        ))
        
        fig.update_layout(
            height=300,
            margin=dict(l=20, r=20, t=40, b=20),
            template="plotly_dark"
        )
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Confidence interpretation
        if confidence >= 0.8:
            st.success("🎯 Very High Confidence")
        elif confidence >= 0.6:
            st.info("📊 High Confidence") 
        elif confidence >= 0.4:
            st.warning("⚠️ Medium Confidence")
        else:
            st.error("❌ Low Confidence")
            
    except Exception as e:
        logger.error(f"Confidence gauge error: {e}")
        st.error("Failed to display confidence gauge")

def create_mini_chart(df: pd.DataFrame, height: int = 200) -> go.Figure:
    """Create a mini chart for quick view"""
    try:
        if df is None or df.empty:
            return None
            
        fig = go.Figure()
        
        # Add line chart
        fig.add_trace(go.Scatter(
            x=df.index,
            y=df['close'],
            mode='lines',
            name='Price',
            line=dict(color='#00ff88', width=2)
        ))
        
        fig.update_layout(
            height=height,
            margin=dict(l=0, r=0, t=0, b=0),
            template="plotly_dark",
            showlegend=False,
            xaxis=dict(showgrid=False, showticklabels=False),
            yaxis=dict(showgrid=True, gridcolor='rgba(128, 128, 128, 0.2)')
        )
        
        return fig
        
    except Exception as e:
        logger.error(f"Mini chart creation failed: {e}")
        return None

def render_training_tab_enhanced(symbol: str, training_mode: str):
    """Render enhanced training tab with training timeframe selection and controls"""
    try:
        # --- Symbol selection for training ---
        coin_list = [
            "BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "ADAUSDT", "XRPUSDT", "DOGEUSDT", "DOTUSDT", "LINKUSDT", "MATICUSDT"
        ]
        if 'sidebar_symbol' not in st.session_state:
            st.session_state['sidebar_symbol'] = 'BTCUSDT'
        selected_symbol = st.selectbox(
            "Chọn coin để huấn luyện:",
            coin_list,
            index=coin_list.index(st.session_state['sidebar_symbol']) if st.session_state['sidebar_symbol'] in coin_list else 0,
            key="training_symbol_select",
            help="Chọn coin để huấn luyện AI"
        )
        st.session_state['sidebar_symbol'] = selected_symbol
        symbol = selected_symbol
        
        # Full-width header
        st.markdown("""
        <div style="text-align: center; padding: 20px; margin-bottom: 30px; 
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    border-radius: 15px; color: white;">
            <h1 style="margin: 0; font-size: 2.5em;">🎯 Huấn luyện AI nâng cao</h1>
            <p style="margin: 10px 0 0 0; font-size: 1.2em; opacity: 0.9;">
                Hệ thống huấn luyện AI thông minh với tối ưu hóa toàn diện
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        # Training mode information with full-width cards
        mode_info = {
            "quick_24h": {
                "title": "🚀 Huấn luyện nhanh (24 giờ)",
                "description": "Sử dụng dữ liệu 24 giờ gần nhất để huấn luyện nhanh",
                "color": "#3498db",
                "icon": "⚡",
                "time": "5-10 phút"
            },
            "standard_7d": {
                "title": "🎯 Huấn luyện tiêu chuẩn (7 ngày)",
                "description": "Sử dụng dữ liệu 7 ngày để cân bằng độ chính xác và tốc độ",
                "color": "#2ecc71",
                "icon": "🎯",
                "time": "15-30 phút"
            },
            "full_data": {
                "title": "🔬 Huấn luyện toàn bộ dữ liệu",
                "description": "Sử dụng toàn bộ dữ liệu lịch sử để đạt độ chính xác cao nhất",
                "color": "#e74c3c",
                "icon": "🔬",
                "time": "1-3 giờ"
            }
        }
        current_mode = mode_info.get(training_mode, mode_info["standard_7d"])

        # --- Update history_data to reflect current training mode and symbol ---
        # This is a mockup; in real use, replace with actual training history filtered by symbol and mode
        history_data = [
            {"Thời gian": datetime.now().strftime("%Y-%m-%d %H:%M"), "Coin": symbol, "Mode": current_mode['title'], "Chi tiết": current_mode['description'], "Thời gian dự kiến": current_mode['time'], "Trạng thái": "✅ Hoàn thành"}
        ]

        # Display current training mode with enhanced styling
        st.markdown(f"""
        <div style="padding: 20px; margin: 20px 0; 
                    background: linear-gradient(135deg, {current_mode['color']}22 0%, {current_mode['color']}11 100%);
                    border: 2px solid {current_mode['color']}44;
                    border-radius: 15px;">
            <h2 style="margin: 0 0 10px 0; color: {current_mode['color']};">
                {current_mode['icon']} {current_mode['title']}
            </h2>
            <p style="margin: 0 0 10px 0; font-size: 1.1em; opacity: 0.9;">
                {current_mode['description']}
            </p>
            <p style="margin: 0; font-weight: bold; color: {current_mode['color']};">
                ⏱️ Thời gian dự kiến: {current_mode['time']}
            </p>
        </div>
        """, unsafe_allow_html=True)
        
        # Training timeframe selection (moved from sidebar)
        st.markdown("### 🎯 Chọn khung thời gian huấn luyện")
        training_modes = {
            "Nhanh (24 giờ)": "quick_24h",
            "Tiêu chuẩn (7 ngày)": "standard_7d",
            "Toàn bộ dữ liệu": "full_data"
        }
        selected_training_mode = st.selectbox(
            "Chọn dữ liệu huấn luyện:",
            list(training_modes.keys()),
            index=list(training_modes.values()).index(training_mode) if training_mode in training_modes.values() else 1,
            key="training_mode_tab",
            help="Chọn khoảng thời gian dữ liệu để huấn luyện AI"
        )
        training_mode_value = training_modes[selected_training_mode]
        
        # Training controls with full-width layout
        st.markdown("### 🎮 Điều khiển huấn luyện")
        col1, col2, col3, col4 = st.columns([3, 2, 2, 2])
        
        with col1:
            start_training = st.button(
                f"🚀 Bắt đầu huấn luyện cho {symbol}",
                type="primary",
                use_container_width=True,
                help=f"Khởi động huấn luyện {current_mode['title']}"
            )
        
        with col2:
            stop_training = st.button(
                "🛑 Dừng",
                use_container_width=True,
                help="Dừng quá trình huấn luyện hiện tại"
            )
            
        with col3:
            view_results = st.button(
                "📊 Kết quả",
                use_container_width=True,
                help="Xem kết quả huấn luyện và hiệu suất model"
            )
            
        with col4:
            export_model = st.button(
                "💾 Xuất model",
                use_container_width=True,
                help="Xuất model đã huấn luyện"
            )
        
        # Advanced training options
        with st.expander("⚙️ Tùy chọn nâng cao", expanded=False):
            col1, col2 = st.columns(2)
            
            with col1:
                use_ensemble = st.checkbox(
                    "🔗 Sử dụng Ensemble",
                    value=True,
                    help="Kết hợp nhiều model để tăng độ chính xác"
                )
                
                optimize_hyperparams = st.checkbox(
                    "🎛️ Tối ưu siêu tham số",
                    value=False,
                    help="Tự động tìm siêu tham số tối ưu (tốn thời gian hơn)"
                )
                
            with col2:
                cross_validation = st.checkbox(
                    "✅ Cross Validation",
                    value=True,
                    help="Sử dụng cross validation để đánh giá model"
                )
                
                save_checkpoint = st.checkbox(
                    "💾 Lưu checkpoint",
                    value=True,
                    help="Lưu tiến trình để có thể tiếp tục sau"
                )
        
        # Training progress (if training is in progress)
        if st.session_state.get('training_in_progress', False):
            st.markdown("---")
            st.subheader("📈 Tiến trình huấn luyện")
            
            # Progress bars
            overall_progress = st.progress(0)
            step_progress = st.progress(0)
            
            # Status updates
            status_container = st.empty()
            metrics_container = st.empty()
            
            # ETA and current step
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Bước hiện tại", "0/100")
            with col2:
                st.metric("Thời gian còn lại", "Calculating...")
            with col3:
                st.metric("Accuracy hiện tại", "0.0%")
        
        # Training history
        st.markdown("---")
        st.subheader("📜 Lịch sử huấn luyện")
        # Update history_data to always reflect current selection
        history_data = [
            {"Thời gian": datetime.now().strftime("%Y-%m-%d %H:%M"), "Coin": symbol, "Mode": current_mode['title'], "Chi tiết": current_mode['description'], "Thời gian dự kiến": current_mode['time'], "Trạng thái": "✅ Hoàn thành"}
        ]
        if history_data:
            import pandas as pd
            df_history = pd.DataFrame(history_data)
            st.dataframe(df_history, use_container_width=True)
        else:
            st.info("Chưa có lịch sử huấn luyện")

        # --- ETA countdown and progress bar when training ---
        if st.session_state.get('training_in_progress', False):
            st.markdown("---")
            st.subheader("⏳ Đang huấn luyện...")
            # Lấy trạng thái lỗi nếu có
            training_failed = st.session_state.get('training_failed', False)
            training_error = st.session_state.get('training_error', None)
            eta_seconds = st.session_state.get('training_eta', 1200)  # 20 phút mặc định
            progress = st.session_state.get('training_progress', 0.0)
            eta_container = st.empty()
            progress_bar = st.progress(progress)
            import time as _time
            import math
            start_time = st.session_state.get('training_start_time', _time.time())
            st.session_state['training_start_time'] = start_time
            if training_failed:
                eta_container.markdown(f"**❌ Huấn luyện thất bại!**\n{training_error if training_error else ''}")
                progress_bar.progress(progress)
            else:
                while progress < 1.0:
                    elapsed = _time.time() - start_time
                    remaining = max(0, eta_seconds - elapsed)
                    percent = min(1.0, elapsed / eta_seconds) if eta_seconds > 0 else 0
                    eta_container.markdown(f"**⏱️ Thời gian còn lại:** {format_eta(remaining)}")
                    progress_bar.progress(percent)
                    st.session_state['training_progress'] = percent
                    if percent >= 1.0:
                        break
                    _time.sleep(1)
                eta_container.markdown("**✅ Huấn luyện hoàn thành!**")
                progress_bar.progress(1.0)
        
        return {
            'selected_training_mode': training_mode_value,
            'start_training': start_training,
            'stop_training': stop_training,
            'view_results': view_results,
            'use_ensemble': locals().get('use_ensemble', True),
            'optimize_hyperparams': locals().get('optimize_hyperparams', False),
            'cross_validation': locals().get('cross_validation', True),
            'save_checkpoint': locals().get('save_checkpoint', True)
        }
    except Exception as e:
        logger.error(f"Training tab render error: {e}")
        st.error(f"Lỗi hiển thị tab huấn luyện: {e}")
        return {}

def render_quick_predict_tab(prediction_timeframe: str = "15m"):
    """Render Quick Predict tab with prediction timeframe selection"""
    try:
        st.markdown("### ⚡ Dự đoán nhanh")
        timeframes = ["5m", "15m", "30m", "1h", "4h", "1d"]
        selected_timeframe = st.selectbox(
            "Chọn khung thời gian dự đoán:",
            timeframes,
            index=timeframes.index(prediction_timeframe) if prediction_timeframe in timeframes else 1,
            key="quick_predict_timeframe"
        )
        # ...rest of quick predict UI...
        return {'prediction_timeframe': selected_timeframe}
    except Exception as e:
        logger.error(f"Quick predict tab error: {e}")
        st.error("Lỗi tab dự đoán nhanh")
        return {}

def render_settings_tab(settings: dict = None):
    """Render all system settings in a dedicated tab"""
    try:
        st.markdown("### ⚙️ Cài đặt hệ thống")
        if settings is None:
            settings = {}
        learning_rate = st.number_input(
            "Learning Rate",
            min_value=0.00001, max_value=1.0, value=float(settings.get('learning_rate', 0.001)), step=0.0001, format="%f"
        )
        batch_size = st.number_input(
            "Batch Size",
            min_value=8, max_value=4096, value=int(settings.get('batch_size', 64)), step=8
        )
        parallel_models = st.slider(
            "Số mô hình song song",
            min_value=1, max_value=16, value=int(settings.get('parallel_models', 4)), step=1
        )
        use_gpu = st.checkbox(
            "Sử dụng GPU (nếu có)",
            value=bool(settings.get('use_gpu', True))
        )
        ram_limit = st.slider(
            "Giới hạn RAM (GB)",
            min_value=1, max_value=64, value=int(settings.get('ram_limit', 8)), step=1
        )
        st.success("Cài đặt sẽ được áp dụng cho các phiên huấn luyện và dự đoán mới.")
        return {
            'learning_rate': learning_rate,
            'batch_size': batch_size,
            'parallel_models': parallel_models,
            'use_gpu': use_gpu,
            'ram_limit': ram_limit
        }
    except Exception as e:
        logger.error(f"Settings tab error: {e}")
        st.error("Lỗi tab cài đặt")
        return {}

def render_main_tabs():
    """Render main application tabs with enhanced UI and full-width layout"""
    try:
        # Enhanced custom styling for absolute full-width tabs
        st.markdown("""
        <style>
        /* CRITICAL: Force absolute full-width for all tab content */
        .stTabs [data-baseweb="tab-list"] {
            gap: 2px;
            background-color: rgba(255, 255, 255, 0.05);
            border-radius: 10px;
            padding: 5px;
            margin-bottom: 20px;
            width: 100% !important;
            max-width: none !important;
        }
        
        .stTabs [data-baseweb="tab"] {
            height: 50px;
            padding: 0 24px;
            border-radius: 8px;
            background-color: transparent;
            color: rgba(255, 255, 255, 0.7);
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .stTabs [aria-selected="true"] {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-weight: 600;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }
        
        /* Tab content styling - FORCE FULL WIDTH */
        .stTabs [data-baseweb="tab-panel"] {
            padding: 0 !important;
            width: 100% !important;
            max-width: none !important;
        }
        
        /* Force all elements inside tabs to use full width */
        .stTabs [data-baseweb="tab-panel"] > div {
            width: 100% !important;
            max-width: none !important;
        }
        
        /* Columns should also use full width */
        .stTabs .element-container {
            width: 100% !important;
            max-width: none !important;
        }
        
        /* Data tables and charts full width */
        .stTabs .stDataFrame,
        .stTabs .js-plotly-plot {
            width: 100% !important;
            max-width: none !important;
        }
        
        /* Metrics containers full width */
        .stTabs .metric-container {
            width: 100% !important;
            max-width: none !important;
        }
        </style>
        """, unsafe_allow_html=True)
          # Main tabs with emojis and Vietnamese labels - UPDATED WITH NEW TABS
        tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs([
            "📈 Giao dịch", 
            "📊 Phân tích", 
            "🎯 Huấn luyện AI",
            "🔍 Tìm kiếm coin",
            "🤖 Giao dịch tự động", 
            "📰 Tin tức", 
            "⚙️ Cài đặt"
        ])
        
        return {
            'trade_view': tab1,
            'technical_analysis': tab2,
            'ai_training': tab3,
            'coin_screening': tab4,
            'auto_trading': tab5,
            'news': tab6,
            'settings': tab7
        }
        
    except Exception as e:
        logger.error(f"Main tabs render error: {e}")
        return None

def render_fear_greed_index():
    """Render Fear & Greed Index in sidebar"""
    try:
        from utilities.coin_screener import get_coin_screener
        
        screener = get_coin_screener()
        fng_data = screener.get_fear_greed_index()
        
        if fng_data['success']:
            value = fng_data['value']
            classification = fng_data['classification']
            emoji = fng_data['emoji']
            
            # Color based on value
            if value <= 25:
                color = "#ff4444"  # Red
            elif value <= 45:
                color = "#ffaa00"  # Orange
            elif value <= 55:
                color = "#ffff00"  # Yellow
            elif value <= 75:
                color = "#88ff00"  # Light Green
            else:
                color = "#00ff88"  # Green
            
            st.sidebar.markdown(f"""
            <div style="text-align: center; padding: 15px; 
                        background: linear-gradient(135deg, {color}20, {color}40); 
                        border: 2px solid {color}; border-radius: 15px; 
                        margin-bottom: 20px; color: white;">
                <div style="font-size: 14px; margin-bottom: 5px; opacity: 0.9;">😱📊 Chỉ số Sợ hãi & Tham lam</div>
                <div style="font-size: 32px; margin: 8px 0;">{emoji}</div>
                <div style="font-size: 28px; font-weight: bold; color: {color}; margin: 8px 0;">{value}</div>
                <div style="font-size: 14px; font-weight: bold; margin-bottom: 5px;">{classification}</div>
                <div style="font-size: 10px; opacity: 0.7;">alternative.me</div>
            </div>
            """, unsafe_allow_html=True)
        else:
            st.sidebar.error("❌ Không thể tải chỉ số F&G")
            
    except Exception as e:
        logger.error(f"Fear & Greed Index error: {e}")
        st.sidebar.error("❌ F&G Index error")

# Export main components
__all__ = [
    # Time and formatting functions
    'format_eta', 'format_price', 'format_time_ago',
    
    # Chart and UI rendering
    'create_chart', 'render_sidebar', 'render_realtime_clock',
    
    # Message and display functions
    'show_startup_msg', 'show_price_widget', 'show_realtime_clock',
    'show_prediction_eta', 'show_model_performance_table', 
    'show_training_progress_card', 'show_market_analysis_card',
    'show_prediction_confidence_gauge',
      # Enhanced UI components
    'render_training_tab_enhanced', 'render_main_tabs', 'render_fear_greed_index',
]
