import requests
import qrcode
import io
import os
import json
import time
from datetime import datetime, timezone, timedelta
from dotenv import load_dotenv, set_key
from cryptography.fernet import Fernet
import secrets
import hashlib
import base64
from typing import Tuple
load_dotenv()

class ZaloSender:
    """
    Module thuần logic để:
      - Tạo PKCE codes
      - Sinh QR code / URL để user scan
      - Hoán đổi code → access_token
      - Quản lý contact (load, save, add, remove)
      - Gửi tin nhắn text
    Hoàn toàn không phụ thuộc Streamlit.
    """

    def __init__(self):
        self.app_id       = os.getenv("ZALO_APP_ID")
        self.secret_key   = os.getenv("ZALO_SECRET_KEY")
        self.redirect_uri = os.getenv("ZALO_REDIRECT_URI")
        self.access_token = os.getenv("ZALO_ACCESS_TOKEN")  # có thể None

        # Khóa mã hóa dữ liệu contacts
        self.enc_key  = self._get_encryption_key()
        self.contacts = self.load_contacts()

    # — PKCE helpers — 
    def generate_pkce(self):
        """
        Trả về tuple (code_verifier, code_challenge, state)
        để build URL OAuth PKCE.
        """
        code_verifier = secrets.token_urlsafe(64)
        code_challenge = base64.urlsafe_b64encode(
            hashlib.sha256(code_verifier.encode()).digest()
        ).decode().rstrip("=")
        state = secrets.token_urlsafe(16)
        return code_verifier, code_challenge, state

    def build_auth_url(self, code_challenge: str, state: str) -> str:
        """
        Trả về URL để user scan QR hoặc click.
        """
        return (
            f"https://oauth.zaloapp.com/v4/oa/permission"
            f"?app_id={self.app_id}"
            f"&redirect_uri={self.redirect_uri}"
            f"&code_challenge={code_challenge}"
            f"&code_challenge_method=S256"
            f"&state={state}"
        )

    def get_qr_code_bytes(self, auth_url: str) -> bytes:
        """
        Sinh QR code PNG bytes từ auth_url.
        """
        img = qrcode.make(auth_url)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        buf.seek(0)
        return buf.getvalue()

    def exchange_code_for_token(self, auth_code: str, code_verifier: str) -> Tuple[bool, str]:
        """
        Gửi request lấy access_token.
        Trả về (success, message). Nếu success=True thì
        self.access_token được cập nhật.
        """
        token_url = "https://oauth.zaloapp.com/v4/oa/access_token"
        data = {
            "app_id":        self.app_id,
            "grant_type":    "authorization_code",
            "code":          auth_code,
            "redirect_uri":  self.redirect_uri,
            "code_verifier": code_verifier,
            "app_secret":    self.secret_key
        }
        resp = requests.post(token_url, data=data).json()
        if "access_token" in resp:
            self.access_token = resp["access_token"]
            # Ghi vào .env để reuse
            set_key(".env", "ZALO_ACCESS_TOKEN", self.access_token)
            return True, "Authenticated successfully"
        else:
            return False, resp.get("error_description", "Unknown error")

    # — Encryption & contacts persistence —
    def _get_encryption_key(self) -> bytes:
        key_path = "data/key.enc"
        os.makedirs("data", exist_ok=True)
        if os.path.exists(key_path):
            return open(key_path, "rb").read()
        key = Fernet.generate_key()
        open(key_path, "wb").write(key)
        return key

    def load_contacts(self) -> list:
        """
        Đọc file data/contacts.enc (nếu có),
        giải mã và trả về list of dict.
        """
        path = "data/contacts.enc"
        if not os.path.exists(path):
            return []
        encrypted = open(path, "rb").read()
        fernet = Fernet(self.enc_key)
        data    = fernet.decrypt(encrypted)
        contacts = json.loads(data.decode("utf-8"))
        # đảm bảo có key last_sent
        for c in contacts:
            c.setdefault("last_sent", None)
        return contacts

    def save_contacts(self):
        """
        Mã hóa và ghi lại toàn bộ self.contacts vào file.
        """
        fernet   = Fernet(self.enc_key)
        data     = json.dumps(self.contacts).encode("utf-8")
        encrypted = fernet.encrypt(data)
        open("data/contacts.enc", "wb").write(encrypted)

    def add_contact(self, phone: str, name: str = None) -> Tuple[bool, str]:
        """
        Thêm 1 contact mới rồi save.
        """
        self.contacts.append({"phone": phone, "name": name, "last_sent": None})
        self.save_contacts()
        return True, "Contact added successfully"

    def remove_contact(self, phone: str) -> Tuple[bool, str]:
        """
        Xóa contact theo phone rồi save.
        """
        before = len(self.contacts)
        self.contacts = [c for c in self.contacts if c["phone"] != phone]
        if len(self.contacts) == before:
            return False, "Contact not found"
        self.save_contacts()
        return True, "Contact removed successfully"

    # — Enhanced Messaging Functions —
    def send_text_message(self, user_id: str, message: str) -> Tuple[bool, str]:
        """
        Gửi tin nhắn text qua Zalo OA API với retry logic và better error handling.
        """
        if not self.access_token:
            return False, "No access token. Please authenticate first."
        
        url = "https://openapi.zalo.me/v2.0/oa/message"
        headers = {
            "access_token": self.access_token,
            "Content-Type": "application/json"
        }
        payload = {
            "recipient": {"user_id": user_id},
            "message": {"text": message}
        }
        
        # Retry logic
        max_retries = 3
        for attempt in range(max_retries):
            try:
                r = requests.post(url, headers=headers, json=payload, timeout=10)
                r.raise_for_status()
                response = r.json()
                
                if response.get("error") == 0:
                    # Update last_sent for this contact
                    self._update_contact_last_sent(user_id)
                    return True, "Message sent successfully"
                else:
                    error_msg = response.get("message", "Unknown error")
                    if attempt == max_retries - 1:
                        return False, f"Zalo API error: {error_msg}"
                    # Wait before retry
                    time.sleep(2 ** attempt)
                    
            except requests.exceptions.RequestException as e:
                if attempt == max_retries - 1:
                    return False, f"Network error: {str(e)}"
                time.sleep(2 ** attempt)
                
        return False, "Failed after all retry attempts"

    def send_rich_message(self, user_id: str, title: str, subtitle: str, 
                         elements: list = None, buttons: list = None) -> Tuple[bool, str]:
        """
        Gửi tin nhắn phong phú với template.
        """
        if not self.access_token:
            return False, "No access token. Please authenticate first."
            
        url = "https://openapi.zalo.me/v2.0/oa/message"
        headers = {
            "access_token": self.access_token,
            "Content-Type": "application/json"
        }
        
        # Build rich message payload
        attachment = {
            "type": "template",
            "payload": {
                "template_type": "list",
                "elements": elements or [
                    {
                        "title": title,
                        "subtitle": subtitle,
                        "image_url": "https://via.placeholder.com/150x150.png"
                    }
                ]
            }
        }
        
        if buttons:
            attachment["payload"]["buttons"] = buttons
            
        payload = {
            "recipient": {"user_id": user_id},
            "message": {"attachment": attachment}
        }
        
        try:
            r = requests.post(url, headers=headers, json=payload, timeout=10)
            r.raise_for_status()
            response = r.json()
            
            if response.get("error") == 0:
                self._update_contact_last_sent(user_id)
                return True, "Rich message sent successfully"
            else:
                return False, f"Zalo API error: {response.get('message', 'Unknown error')}"
                
        except Exception as e:
            return False, f"Error sending rich message: {str(e)}"

    def broadcast_message(self, message: str, target_group: str = "all") -> dict:
        """
        Gửi tin nhắn broadcast đến nhiều contacts.
        target_group: "all", "recent" (sent in last 7 days), "frequent" (sent >5 times)
        """
        results = {
            "success": 0,
            "failed": 0,
            "errors": [],
            "recipients": []
        }
        
        # Filter contacts based on target group
        target_contacts = self._filter_contacts_by_group(target_group)
        
        for contact in target_contacts:
            user_id = contact.get("phone") or contact.get("user_id")
            if not user_id:
                continue
                
            success, msg = self.send_text_message(user_id, message)
            if success:
                results["success"] += 1
                results["recipients"].append(contact.get("name", user_id))
            else:
                results["failed"] += 1
                results["errors"].append(f"{contact.get('name', user_id)}: {msg}")
                
            # Rate limiting - avoid spam
            time.sleep(1)
            
        return results

    def _filter_contacts_by_group(self, target_group: str) -> list:
        """
        Lọc contacts theo nhóm target.
        """
        if target_group == "all":
            return self.contacts
        elif target_group == "recent":
            # Contacts sent to in last 7 days
            cutoff = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()
            return [c for c in self.contacts 
                   if c.get("last_sent") and c["last_sent"] > cutoff]
        elif target_group == "frequent":
            # Contacts with send_count > 5
            return [c for c in self.contacts 
                   if c.get("send_count", 0) > 5]
        else:
            return self.contacts

    def _update_contact_last_sent(self, user_id: str):
        """
        Cập nhật timestamp và count cho contact vừa gửi tin nhắn.
        """
        for contact in self.contacts:
            if contact.get("phone") == user_id or contact.get("user_id") == user_id:
                contact["last_sent"] = datetime.now(timezone.utc).isoformat()
                contact["send_count"] = contact.get("send_count", 0) + 1
                break
        self.save_contacts()

    def get_contact_stats(self) -> dict:
        """
        Thống kê về contacts và hoạt động gửi tin nhắn.
        """
        total = len(self.contacts)
        active_7d = len([c for c in self.contacts 
                        if c.get("last_sent") and 
                        c["last_sent"] > (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()])
        
        frequent = len([c for c in self.contacts if c.get("send_count", 0) > 5])
        
        return {
            "total_contacts": total,
            "active_last_7_days": active_7d,
            "frequent_contacts": frequent,
            "last_broadcast": self._get_last_broadcast_time()
        }

    def _get_last_broadcast_time(self) -> str:
        """
        Lấy thời gian broadcast gần nhất.
        """
        if not self.contacts:
            return "Never"
        
        last_times = [c.get("last_sent") for c in self.contacts if c.get("last_sent")]
        if not last_times:
            return "Never"
            
        latest = max(last_times)
        dt = datetime.fromisoformat(latest.replace('Z', '+00:00'))
        return dt.strftime("%Y-%m-%d %H:%M:%S")

    def compose_message_from_predictions(self, predictions: list, include_chart_link: bool = True) -> str:
        """
        Tạo nội dung tin nhắn tự động từ kết quả dự đoán với enhanced formatting.
        - predictions: list of dict, mỗi dict có các key:
            'symbol'      (str)   – mã coin
            'action'      (str)   – BUY/SELL hoặc tương tự
            'entry_price' (float) – giá vào lệnh
            'take_profit' (float) – giá chốt lời
            'stop_loss'   (float) – giá cắt lỗ
            'confidence'  (float) – hệ số tin cậy (0–1)
            'timestamp'   (float) – UNIX timestamp (giây)
            'timeframe'   (str)   – khung thời gian
        """
        if not predictions:
            return "🤖 Không có tín hiệu mới hiện tại."
            
        # Header
        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        lines = [
            "🚀 CRYPTO AI SIGNALS 🚀",
            f"⏰ {timestamp}",
            "─" * 30
        ]
        
        # Group predictions by action
        buy_signals = [p for p in predictions if p.get('action', '').upper() in ['BUY', 'LONG']]
        sell_signals = [p for p in predictions if p.get('action', '').upper() in ['SELL', 'SHORT']]
        
        # Process buy signals
        if buy_signals:
            lines.append("📈 BUY SIGNALS:")
            for pr in buy_signals:
                signal_text = self._format_single_prediction(pr, include_chart_link)
                lines.append(signal_text)
            lines.append("")
            
        # Process sell signals  
        if sell_signals:
            lines.append("📉 SELL SIGNALS:")
            for pr in sell_signals:
                signal_text = self._format_single_prediction(pr, include_chart_link)
                lines.append(signal_text)
            lines.append("")
            
        # Footer
        lines.extend([
            "─" * 30,
            "⚠️ Đây chỉ là dự đoán AI, không phải lời khuyên tài chính.",
            "📊 DYOR - Tự nghiên cứu trước khi đầu tư!"
        ])
        
        return "\n".join(lines)

    def _format_single_prediction(self, pr: dict, include_chart_link: bool = True) -> str:
        """
        Format một prediction thành text đẹp.
        """
        symbol = pr.get('symbol', 'N/A')
        action = pr.get('action', '').upper()
        entry = pr.get('entry_price')
        tp = pr.get('take_profit')
        sl = pr.get('stop_loss')
        conf = pr.get('confidence')
        tf = pr.get('timeframe', '1h')
        
        # Action emoji
        emoji = "🟢" if action in ['BUY', 'LONG'] else "🔴"
        
        # Build signal text
        parts = [f"{emoji} {symbol} ({tf})"]
        
        if entry is not None:
            parts.append(f"Entry: ${entry:.4f}")
        if tp is not None:
            parts.append(f"TP: ${tp:.4f}")
        if sl is not None:
            parts.append(f"SL: ${sl:.4f}")
        if conf is not None:
            conf_emoji = "🔥" if conf > 0.8 else "⚡" if conf > 0.6 else "💡"
            parts.append(f"{conf_emoji} {conf:.1%}")
            
        signal_text = " | ".join(parts)
        
        # Add chart link if requested
        if include_chart_link:
            chart_url = f"https://www.tradingview.com/chart/?symbol=BINANCE:{symbol}"
            signal_text += f"\n📊 Chart: {chart_url}"
            
        return signal_text

    def create_alert_from_price_change(self, symbol: str, current_price: float, 
                                     previous_price: float, timeframe: str = "1h") -> str:
        """
        Tạo alert khi giá thay đổi đáng kể.
        """
        change_pct = ((current_price - previous_price) / previous_price) * 100
        
        if abs(change_pct) < 2:  # Chỉ alert khi thay đổi > 2%
            return ""
            
        emoji = "🚀" if change_pct > 0 else "💥"
        direction = "tăng" if change_pct > 0 else "giảm"
        
        alert = [
            f"{emoji} PRICE ALERT {emoji}",
            f"📊 {symbol}: {direction} {abs(change_pct):.2f}%",
            f"💰 Giá hiện tại: ${current_price:.4f}",
            f"⏰ Khung thời gian: {timeframe}",
            f"🕐 {datetime.now(timezone.utc).strftime('%H:%M UTC')}"
        ]
        
        return "\n".join(alert)

    def validate_access_token(self) -> Tuple[bool, str]:
        """
        Kiểm tra tính hợp lệ của access token hiện tại.
        """
        if not self.access_token:
            return False, "No access token available"
            
        url = "https://openapi.zalo.me/v2.0/oa/getoa"
        headers = {"access_token": self.access_token}
        
        try:
            r = requests.get(url, headers=headers, timeout=10)
            r.raise_for_status()
            response = r.json()
            
            if response.get("error") == 0:
                oa_info = response.get("data", {})
                return True, f"Token valid for OA: {oa_info.get('name', 'Unknown')}"
            else:
                return False, f"Invalid token: {response.get('message', 'Unknown error')}"
                
        except Exception as e:
            return False, f"Validation error: {str(e)}"

    def get_oa_profile(self) -> dict:
        """
        Lấy thông tin profile của Official Account.
        """
        if not self.access_token:
            return {"error": "No access token"}
            
        url = "https://openapi.zalo.me/v2.0/oa/getoa"
        headers = {"access_token": self.access_token}
        
        try:
            r = requests.get(url, headers=headers, timeout=10)
            response = r.json()
            return response.get("data", {}) if response.get("error") == 0 else {"error": response.get("message")}
        except Exception as e:
            return {"error": str(e)}
