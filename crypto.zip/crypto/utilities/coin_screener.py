"""
Coin Screener Module
Quét thị trường coin và dự đoán AI xu hướng tiếp theo
"""

import pandas as pd
import numpy as np
import requests
import asyncio
import aiohttp
import time
import threading
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
import logging
from concurrent.futures import ThreadPoolExecutor, as_completed
import psutil
import os

from config.logging_config import get_logger

logger = get_logger('coin_screener')

class CoinScreener:
    """Quét thị trường và phân tích coin tiềm năng"""
    
    def __init__(self):
        self.binance_api_url = "https://api.binance.com/api/v3"
        self.last_update = None
        self.cache_duration = 300  # 5 phút cache
        self.cached_data = None
        self.ai_predictor = None
        self.max_workers = min(4, os.cpu_count())
        
        # Khởi tạo AI predictor
        self._initialize_ai_predictor()
    
    def _initialize_ai_predictor(self):
        """Khởi tạo AI predictor cho dự đoán xu hướng"""
        try:
            from ai_models.ai_logic import get_ensemble_predictor
            self.ai_predictor = get_ensemble_predictor()
            logger.info("✅ AI Predictor khởi tạo thành công")
        except Exception as e:
            logger.warning(f"⚠️ Không thể khởi tạo AI predictor: {e}")
            self.ai_predictor = None
    
    def check_resource_usage(self) -> bool:
        """Kiểm tra tài nguyên hệ thống"""
        try:
            cpu_usage = psutil.cpu_percent(interval=1)
            memory_usage = psutil.virtual_memory().percent
            
            if memory_usage > 90:
                logger.warning(f"⚠️ RAM usage cao: {memory_usage}%")
                return False
            
            if cpu_usage > 95:
                logger.warning(f"⚠️ CPU usage cao: {cpu_usage}%")
                return False
                
            return True
        except Exception as e:
            logger.error(f"❌ Lỗi kiểm tra tài nguyên: {e}")
            return True  # Tiếp tục nếu không kiểm tra được
    
    async def fetch_market_data(self, session: aiohttp.ClientSession) -> Optional[List[Dict]]:
        """Lấy dữ liệu thị trường từ Binance API"""
        try:
            url = f"{self.binance_api_url}/ticker/24hr"
            async with session.get(url, timeout=10) as response:
                if response.status == 200:
                    data = await response.json()
                    # Lọc chỉ các cặp USDT
                    usdt_pairs = [item for item in data if item['symbol'].endswith('USDT')]
                    logger.info(f"✅ Lấy được {len(usdt_pairs)} cặp USDT")
                    return usdt_pairs
                else:
                    logger.error(f"❌ API error: {response.status}")
                    return None
        except Exception as e:
            logger.error(f"❌ Lỗi fetch market data: {e}")
            return None
    
    async def fetch_coin_klines(self, session: aiohttp.ClientSession, symbol: str, limit: int = 100) -> Optional[List]:
        """Lấy dữ liệu nến cho AI prediction"""
        try:
            url = f"{self.binance_api_url}/klines"
            params = {
                'symbol': symbol,
                'interval': '15m',
                'limit': limit
            }
            
            async with session.get(url, params=params, timeout=10) as response:
                if response.status == 200:
                    return await response.json()
                else:
                    return None
        except Exception as e:
            logger.error(f"❌ Lỗi fetch klines {symbol}: {e}")
            return None
    
    def process_market_data(self, market_data: List[Dict]) -> pd.DataFrame:
        """Xử lý và phân tích dữ liệu thị trường"""
        try:
            df = pd.DataFrame(market_data)
            
            # Chuyển đổi kiểu dữ liệu
            numeric_cols = ['lastPrice', 'priceChangePercent', 'volume', 'quoteVolume', 'count']
            for col in numeric_cols:
                df[col] = pd.to_numeric(df[col], errors='coerce')
            
            # Tính toán các chỉ số
            df['price'] = df['lastPrice']
            df['change_24h'] = df['priceChangePercent']
            df['volume_usdt'] = df['quoteVolume']
            df['trades_count'] = df['count']
            
            # Lọc coin có khối lượng đủ lớn (> 1M USDT)
            df = df[df['volume_usdt'] > 1000000]
            
            # Loại bỏ stablecoin và fiat pairs
            exclude_symbols = ['USDT', 'BUSD', 'USDC', 'TUSD', 'FDUSD', 'EUR', 'GBP', 'AUD']
            df = df[~df['symbol'].str.replace('USDT', '').isin(exclude_symbols)]
            
            # Tính điểm quan trọng (importance score)
            df['importance_score'] = (
                np.log(df['volume_usdt']) * 0.4 +
                np.abs(df['change_24h']) * 0.3 +
                np.log(df['trades_count'] + 1) * 0.3
            )
            
            logger.info(f"✅ Xử lý {len(df)} coin hợp lệ")
            return df.sort_values('importance_score', ascending=False)
            
        except Exception as e:
            logger.error(f"❌ Lỗi xử lý market data: {e}")
            return pd.DataFrame()
    
    def predict_coin_trend(self, symbol: str, klines_data: List) -> str:
        """Dự đoán xu hướng coin bằng AI"""
        try:
            if not self.ai_predictor or not klines_data:
                return "Không rõ"
            
            # Chuyển đổi klines thành DataFrame
            df = pd.DataFrame(klines_data, columns=[
                'timestamp', 'open', 'high', 'low', 'close', 'volume',
                'close_time', 'quote_volume', 'trades', 'taker_buy_base',
                'taker_buy_quote', 'ignore'
            ])
            
            # Chuyển đổi kiểu dữ liệu
            price_cols = ['open', 'high', 'low', 'close', 'volume']
            for col in price_cols:
                df[col] = pd.to_numeric(df[col], errors='coerce')
            
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df.set_index('timestamp', inplace=True)
            
            if len(df) < 50:  # Cần đủ dữ liệu để dự đoán
                return "Không rõ"
            
            # Sử dụng AI predictor
            prediction = self.ai_predictor.predict_single(df, symbol)
            
            if prediction and 'direction' in prediction:
                direction = prediction['direction']
                confidence = prediction.get('confidence', 0)
                
                if confidence < 0.6:
                    return "Không rõ"
                elif direction in ['LONG', 'BUY']:
                    return "Tăng tiếp"
                elif direction in ['SHORT', 'SELL']:
                    return "Giảm tiếp"
                else:
                    return "Không rõ"
            
            return "Không rõ"
            
        except Exception as e:
            logger.error(f"❌ Lỗi dự đoán {symbol}: {e}")
            return "Không rõ"
    
    async def analyze_top_coins(self, df: pd.DataFrame, top_n: int = 5) -> Tuple[List[Dict], List[Dict]]:
        """Phân tích top coins tăng/giảm mạnh với AI prediction"""
        try:
            if df.empty:
                return [], []
            
            # Top gainers và losers
            top_gainers = df.nlargest(top_n, 'change_24h')
            top_losers = df.nsmallest(top_n, 'change_24h')
            
            gainers_result = []
            losers_result = []
            
            # Async fetch klines và predict
            async with aiohttp.ClientSession() as session:
                # Process gainers
                gainer_tasks = []
                for _, coin in top_gainers.iterrows():
                    task = self.fetch_coin_klines(session, coin['symbol'])
                    gainer_tasks.append((coin, task))
                
                # Process losers  
                loser_tasks = []
                for _, coin in top_losers.iterrows():
                    task = self.fetch_coin_klines(session, coin['symbol'])
                    loser_tasks.append((coin, task))
                
                # Gather gainer results
                for coin, task in gainer_tasks:
                    try:
                        klines = await task
                        ai_prediction = self.predict_coin_trend(coin['symbol'], klines)
                        
                        gainers_result.append({
                            'symbol': coin['symbol'],
                            'price': f"${coin['price']:.6f}",
                            'change_24h': f"{coin['change_24h']:.2f}%",
                            'volume_usdt': f"${coin['volume_usdt']:,.0f}",
                            'ai_prediction': ai_prediction,
                            'importance_score': f"{coin['importance_score']:.2f}"
                        })
                    except Exception as e:
                        logger.error(f"❌ Lỗi xử lý gainer {coin['symbol']}: {e}")
                
                # Gather loser results
                for coin, task in loser_tasks:
                    try:
                        klines = await task
                        ai_prediction = self.predict_coin_trend(coin['symbol'], klines)
                        
                        losers_result.append({
                            'symbol': coin['symbol'],
                            'price': f"${coin['price']:.6f}",
                            'change_24h': f"{coin['change_24h']:.2f}%",
                            'volume_usdt': f"${coin['volume_usdt']:,.0f}",
                            'ai_prediction': ai_prediction,
                            'importance_score': f"{coin['importance_score']:.2f}"
                        })
                    except Exception as e:
                        logger.error(f"❌ Lỗi xử lý loser {coin['symbol']}: {e}")
            
            logger.info(f"✅ Phân tích {len(gainers_result)} gainers, {len(losers_result)} losers")
            return gainers_result, losers_result
            
        except Exception as e:
            logger.error(f"❌ Lỗi analyze top coins: {e}")
            return [], []
    
    async def scan_market(self, criteria: Dict = None) -> Dict:
        """Quét thị trường theo tiêu chí"""
        try:
            # Kiểm tra tài nguyên
            if not self.check_resource_usage():
                logger.warning("⚠️ Tài nguyên hệ thống cao, tạm dừng scan")
                await asyncio.sleep(30)  # Nghỉ 30 giây
                return {'error': 'Tài nguyên hệ thống cao, vui lòng thử lại sau'}
            
            # Kiểm tra cache
            now = time.time()
            if (self.cached_data and self.last_update and 
                (now - self.last_update) < self.cache_duration):
                logger.info("📦 Sử dụng dữ liệu cache")
                return self.cached_data
            
            logger.info("🔄 Bắt đầu quét thị trường...")
            
            async with aiohttp.ClientSession() as session:
                # Lấy dữ liệu thị trường
                market_data = await self.fetch_market_data(session)
                
                if not market_data:
                    return {'error': 'Không thể lấy dữ liệu thị trường'}
                
                # Xử lý dữ liệu
                df = self.process_market_data(market_data)
                
                if df.empty:
                    return {'error': 'Không có dữ liệu hợp lệ'}
                
                # Áp dụng criteria nếu có
                if criteria:
                    df = self.apply_criteria(df, criteria)
                
                # Phân tích top coins
                top_gainers, top_losers = await self.analyze_top_coins(df)
                
                result = {
                    'success': True,
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'total_coins': len(df),
                    'top_gainers': top_gainers,
                    'top_losers': top_losers,
                    'market_summary': {
                        'avg_change': df['change_24h'].mean(),
                        'total_volume': df['volume_usdt'].sum(),
                        'positive_coins': len(df[df['change_24h'] > 0]),
                        'negative_coins': len(df[df['change_24h'] < 0])
                    }
                }
                
                # Cache kết quả
                self.cached_data = result
                self.last_update = now
                
                logger.info("✅ Quét thị trường hoàn thành")
                return result
                
        except Exception as e:
            logger.error(f"❌ Lỗi scan market: {e}")
            return {'error': f'Lỗi quét thị trường: {str(e)}'}
    
    def apply_criteria(self, df: pd.DataFrame, criteria: Dict) -> pd.DataFrame:
        """Áp dụng tiêu chí lọc coin"""
        try:
            filtered_df = df.copy()
            
            # Lọc theo khối lượng tối thiểu
            if criteria.get('min_volume'):
                min_vol = criteria['min_volume'] * 1000000  # Convert to actual value
                filtered_df = filtered_df[filtered_df['volume_usdt'] >= min_vol]
            
            # Lọc theo mức độ thay đổi
            if criteria.get('min_change'):
                filtered_df = filtered_df[np.abs(filtered_df['change_24h']) >= criteria['min_change']]
            
            # Lọc theo giá
            if criteria.get('min_price'):
                filtered_df = filtered_df[filtered_df['price'] >= criteria['min_price']]
            
            if criteria.get('max_price'):
                filtered_df = filtered_df[filtered_df['price'] <= criteria['max_price']]
            
            # Lọc theo danh sách coin cụ thể
            if criteria.get('watch_list'):
                watch_symbols = [s.upper() + 'USDT' for s in criteria['watch_list']]
                filtered_df = filtered_df[filtered_df['symbol'].isin(watch_symbols)]
            
            logger.info(f"✅ Lọc từ {len(df)} xuống {len(filtered_df)} coins")
            return filtered_df
            
        except Exception as e:
            logger.error(f"❌ Lỗi apply criteria: {e}")
            return df
    
    def get_fear_greed_index(self) -> Dict:
        """Lấy chỉ số Fear & Greed"""
        try:
            url = "https://api.alternative.me/fng/"
            response = requests.get(url, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                if data.get('data'):
                    fng_data = data['data'][0]
                    value = int(fng_data['value'])
                    classification = fng_data['value_classification']
                    
                    # Emoji theo mức độ
                    if value <= 25:
                        emoji = "😱"
                    elif value <= 45:
                        emoji = "😰"
                    elif value <= 55:
                        emoji = "😐"
                    elif value <= 75:
                        emoji = "😊"
                    else:
                        emoji = "🤑"
                    
                    return {
                        'value': value,
                        'classification': classification,
                        'emoji': emoji,
                        'timestamp': fng_data['timestamp'],
                        'success': True
                    }
            
            return {'success': False, 'error': 'Không thể lấy chỉ số Fear & Greed'}
            
        except Exception as e:
            logger.error(f"❌ Lỗi lấy Fear & Greed index: {e}")
            return {'success': False, 'error': str(e)}

# Singleton instance
_screener_instance = None

def get_coin_screener() -> CoinScreener:
    """Lấy singleton instance của CoinScreener"""
    global _screener_instance
    if _screener_instance is None:
        _screener_instance = CoinScreener()
    return _screener_instance

# Async wrapper functions for Streamlit
def scan_market_sync(criteria: Dict = None) -> Dict:
    """Wrapper sync cho scan_market"""
    try:
        screener = get_coin_screener()
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(screener.scan_market(criteria))
            return result
        finally:
            loop.close()
    except Exception as e:
        logger.error(f"❌ Lỗi scan_market_sync: {e}")
        return {'error': f'Lỗi hệ thống: {str(e)}'}

def get_market_overview() -> Dict:
    """Lấy tổng quan thị trường"""
    try:
        screener = get_coin_screener()
        
        # Simple market overview
        url = f"{screener.binance_api_url}/ticker/24hr"
        response = requests.get(url, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            usdt_pairs = [item for item in data if item['symbol'].endswith('USDT')]
            
            changes = [float(item['priceChangePercent']) for item in usdt_pairs]
            volumes = [float(item['quoteVolume']) for item in usdt_pairs]
            
            positive_count = len([c for c in changes if c > 0])
            negative_count = len([c for c in changes if c < 0])
            
            return {
                'total_coins': len(usdt_pairs),
                'positive_coins': positive_count,
                'negative_coins': negative_count,
                'avg_change': np.mean(changes),
                'total_volume': sum(volumes),
                'success': True
            }
        
        return {'success': False, 'error': 'Không thể lấy dữ liệu'}
        
    except Exception as e:
        logger.error(f"❌ Lỗi get market overview: {e}")
        return {'success': False, 'error': str(e)}
