# utilities/lightgbm_suppressor.py
"""
Comprehensive LightGBM Warning Suppression Utility
Prevents all LightGBM warnings including "no more leaves" warnings
"""

import os
import sys
import warnings
import logging
from contextlib import contextmanager

class LightGBMSuppressor:
    """Comprehensive LightGBM warning and output suppression"""
    
    @staticmethod
    def suppress_all():
        """Apply all available LightGBM suppression methods"""
        
        # 1. Environment variables
        os.environ['LIGHTGBM_VERBOSITY'] = '-1'
        os.environ['LGB_VERBOSITY'] = '-1'
        
        # 2. Warning filters
        warnings.filterwarnings('ignore', category=UserWarning, module='lightgbm')
        warnings.filterwarnings('ignore', message='.*LightGBM.*')
        warnings.filterwarnings('ignore', message='.*lgb.*')
        warnings.filterwarnings('ignore', message='.*Stopped training because there are no more leaves.*')
        warnings.filterwarnings('ignore', message='.*early stopping.*')
        warnings.filterwarnings('ignore', message='.*no more leaves.*')
        warnings.filterwarnings('ignore', message='.*split.*')
        
        # 3. Logging suppression
        try:
            lgb_logger = logging.getLogger('lightgbm')
            lgb_logger.setLevel(logging.CRITICAL)
            lgb_logger.disabled = True
        except:
            pass        # 4. Try to import and configure LightGBM
        try:
            import lightgbm as lgb
            # LightGBM 4.x+ removed set_verbosity, use environment variables only
            # Environment variables already set above
            
            # Additional internal logger suppression
            for logger_name in ['lightgbm', 'lgb', 'LightGBM']:
                logger = logging.getLogger(logger_name)
                logger.setLevel(logging.CRITICAL)
                logger.disabled = True
                
        except ImportError:
            pass
    
    @staticmethod
    @contextmanager
    def suppress_warnings():
        """Context manager for temporary warning suppression"""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            # Capture and redirect stderr temporarily
            original_stderr = sys.stderr
            try:
                import io
                sys.stderr = io.StringIO()
                yield
            finally:
                sys.stderr = original_stderr
    
    @staticmethod
    def get_optimal_params(n_samples, n_features=None):
        """Get optimal LightGBM parameters to prevent warnings"""
        
        # Base parameters that prevent most warnings
        params = {
            'verbosity': -1,
            'force_col_wise': True,
            'early_stopping_rounds': None,
            'min_child_samples': 1,
            'min_split_gain': 0.0,
            'min_child_weight': 0.0,
            'bagging_freq': 0,
            'feature_fraction': 1.0,
            'bagging_fraction': 1.0,
            'lambda_l1': 0.0,
            'lambda_l2': 0.0
        }
        
        # Adjust parameters based on data size
        if n_samples < 20:
            params.update({
                'n_estimators': max(5, n_samples // 3),
                'max_depth': 2,
                'learning_rate': 0.3,
                'num_leaves': max(2, n_samples // 5)
            })
        elif n_samples < 100:
            params.update({
                'n_estimators': max(10, n_samples // 2),
                'max_depth': 3,
                'learning_rate': 0.2,
                'num_leaves': max(5, n_samples // 3)
            })
        else:
            params.update({
                'n_estimators': 50,
                'max_depth': 4,
                'learning_rate': 0.1,
                'num_leaves': 31 
            })
        
        return params

# Initialize suppression when module is imported
LightGBMSuppressor.suppress_all()
