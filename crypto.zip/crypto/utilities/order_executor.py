"""
Order Executor Module
Thực hiện giao dịch tự động với API Binance
"""

import hashlib
import hmac
import time
import requests
import pandas as pd
from datetime import datetime
from typing import Dict, List, Optional, Tuple
import threading
import queue
import json
import os
from decimal import Decimal, ROUND_DOWN
import psutil

from config.logging_config import get_logger

logger = get_logger('order_executor')

class OrderExecutor:
    """Thực hiện giao dịch tự động với Binance API"""
    
    def __init__(self):
        self.api_key = None
        self.api_secret = None
        self.base_url = "https://api.binance.com"
        self.testnet_url = "https://testnet.binance.vision"
        self.use_testnet = True  # Mặc định dùng testnet để an toàn
        
        self.order_history = []
        self.account_info = None
        self.last_balance_update = None
        self.balance_cache_duration = 30  # 30 giây cache balance
        
        # Thread-safe queue cho orders
        self.order_queue = queue.Queue()
        self.is_processing = False
        self.processing_thread = None
        
        # AI predictor
        self.ai_predictor = None
        self._initialize_ai_predictor()
    
    def _initialize_ai_predictor(self):
        """Khởi tạo AI predictor"""
        try:
            from ai_models.ai_logic import get_ensemble_predictor
            self.ai_predictor = get_ensemble_predictor()
            logger.info("✅ AI Predictor khởi tạo thành công cho OrderExecutor")
        except Exception as e:
            logger.warning(f"⚠️ Không thể khởi tạo AI predictor: {e}")
            self.ai_predictor = None
    
    def set_api_credentials(self, api_key: str, api_secret: str, use_testnet: bool = True):
        """Thiết lập API credentials"""
        try:
            self.api_key = api_key.strip()
            self.api_secret = api_secret.strip()
            self.use_testnet = use_testnet
            
            # Kiểm tra credentials
            if self.validate_credentials():
                logger.info("✅ API credentials hợp lệ")
                return {'success': True, 'message': 'API credentials đã được thiết lập'}
            else:
                logger.error("❌ API credentials không hợp lệ")
                return {'success': False, 'error': 'API credentials không hợp lệ'}
                
        except Exception as e:
            logger.error(f"❌ Lỗi thiết lập API: {e}")
            return {'success': False, 'error': f'Lỗi thiết lập API: {str(e)}'}
    
    def validate_credentials(self) -> bool:
        """Kiểm tra tính hợp lệ của API credentials"""
        try:
            if not self.api_key or not self.api_secret:
                return False
            
            # Test với endpoint account
            account_info = self.get_account_info()
            return account_info.get('success', False)
            
        except Exception as e:
            logger.error(f"❌ Lỗi validate credentials: {e}")
            return False
    
    def _generate_signature(self, query_string: str) -> str:
        """Tạo chữ ký cho API request"""
        return hmac.new(
            self.api_secret.encode('utf-8'),
            query_string.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
    
    def _make_request(self, method: str, endpoint: str, params: Dict = None, signed: bool = False) -> Dict:
        """Thực hiện API request"""
        try:
            if not self.api_key or not self.api_secret:
                return {'success': False, 'error': 'Chưa thiết lập API credentials'}
            
            base_url = self.testnet_url if self.use_testnet else self.base_url
            url = f"{base_url}{endpoint}"
            
            headers = {
                'X-MBX-APIKEY': self.api_key,
                'Content-Type': 'application/json'
            }
            
            if params is None:
                params = {}
            
            if signed:
                params['timestamp'] = int(time.time() * 1000)
                query_string = '&'.join([f"{k}={v}" for k, v in params.items()])
                params['signature'] = self._generate_signature(query_string)
            
            if method.upper() == 'GET':
                response = requests.get(url, headers=headers, params=params, timeout=30)
            elif method.upper() == 'POST':
                response = requests.post(url, headers=headers, params=params, timeout=30)
            else:
                return {'success': False, 'error': f'Unsupported method: {method}'}
            
            if response.status_code == 200:
                return {'success': True, 'data': response.json()}
            else:
                error_msg = f"API Error {response.status_code}"
                try:
                    error_data = response.json()
                    error_msg = error_data.get('msg', error_msg)
                except:
                    pass
                
                logger.error(f"❌ API Error: {error_msg}")
                return {'success': False, 'error': error_msg}
                
        except Exception as e:
            logger.error(f"❌ Lỗi API request: {e}")
            return {'success': False, 'error': f'Lỗi kết nối API: {str(e)}'}
    
    def get_account_info(self) -> Dict:
        """Lấy thông tin tài khoản và số dư"""
        try:
            # Kiểm tra cache
            now = time.time()
            if (self.account_info and self.last_balance_update and 
                (now - self.last_balance_update) < self.balance_cache_duration):
                return {'success': True, 'data': self.account_info}
            
            result = self._make_request('GET', '/api/v3/account', signed=True)
            
            if result['success']:
                account_data = result['data']
                
                # Xử lý balances
                balances = []
                for balance in account_data.get('balances', []):
                    free = float(balance['free'])
                    locked = float(balance['locked'])
                    total = free + locked
                    
                    if total > 0:  # Chỉ hiển thị coin có số dư
                        balances.append({
                            'asset': balance['asset'],
                            'free': free,
                            'locked': locked,
                            'total': total
                        })
                
                # Sắp xếp theo total giảm dần
                balances.sort(key=lambda x: x['total'], reverse=True)
                
                self.account_info = {
                    'balances': balances,
                    'canTrade': account_data.get('canTrade', False),
                    'canWithdraw': account_data.get('canWithdraw', False),
                    'canDeposit': account_data.get('canDeposit', False),
                    'accountType': account_data.get('accountType', 'SPOT'),
                    'updateTime': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
                
                self.last_balance_update = now
                logger.info("✅ Cập nhật thông tin tài khoản thành công")
                
                return {'success': True, 'data': self.account_info}
            else:
                return result
                
        except Exception as e:
            logger.error(f"❌ Lỗi lấy account info: {e}")
            return {'success': False, 'error': f'Lỗi lấy thông tin tài khoản: {str(e)}'}
    
    def get_symbol_info(self, symbol: str) -> Optional[Dict]:
        """Lấy thông tin symbol (filters, precision, etc.)"""
        try:
            result = self._make_request('GET', '/api/v3/exchangeInfo')
            
            if result['success']:
                symbols = result['data'].get('symbols', [])
                for sym_info in symbols:
                    if sym_info['symbol'] == symbol.upper():
                        return sym_info
            
            return None
            
        except Exception as e:
            logger.error(f"❌ Lỗi lấy symbol info {symbol}: {e}")
            return None
    
    def get_current_price(self, symbol: str) -> Optional[float]:
        """Lấy giá hiện tại của symbol"""
        try:
            result = self._make_request('GET', '/api/v3/ticker/price', 
                                      params={'symbol': symbol.upper()})
            
            if result['success']:
                return float(result['data']['price'])
            
            return None
            
        except Exception as e:
            logger.error(f"❌ Lỗi lấy giá {symbol}: {e}")
            return None
    
    def calculate_quantity_precision(self, symbol: str, quantity: float) -> float:
        """Tính toán quantity với precision đúng"""
        try:
            symbol_info = self.get_symbol_info(symbol)
            if not symbol_info:
                return quantity
            
            # Tìm LOT_SIZE filter
            for filter_info in symbol_info.get('filters', []):
                if filter_info['filterType'] == 'LOT_SIZE':
                    step_size = float(filter_info['stepSize'])
                    
                    # Tính precision từ stepSize
                    precision = len(str(step_size).rstrip('0').split('.')[-1])
                    if '.' not in str(step_size).rstrip('0'):
                        precision = 0
                    
                    # Round down với precision
                    multiplier = 10 ** precision
                    return float(int(quantity * multiplier) / multiplier)
            
            return quantity
            
        except Exception as e:
            logger.error(f"❌ Lỗi tính precision {symbol}: {e}")
            return quantity
    
    def validate_order_params(self, symbol: str, side: str, quantity: float, order_type: str = 'MARKET', price: float = None) -> Dict:
        """Kiểm tra tham số order"""
        try:
            # Lấy symbol info
            symbol_info = self.get_symbol_info(symbol)
            if not symbol_info:
                return {'valid': False, 'error': f'Không tìm thấy thông tin symbol {symbol}'}
            
            # Kiểm tra symbol có được trade không
            if symbol_info['status'] != 'TRADING':
                return {'valid': False, 'error': f'Symbol {symbol} hiện không thể giao dịch'}
            
            # Kiểm tra order types
            if order_type not in symbol_info.get('orderTypes', []):
                return {'valid': False, 'error': f'Order type {order_type} không được hỗ trợ'}
            
            # Validate filters
            for filter_info in symbol_info.get('filters', []):
                filter_type = filter_info['filterType']
                
                # LOT_SIZE - quantity constraints
                if filter_type == 'LOT_SIZE':
                    min_qty = float(filter_info['minQty'])
                    max_qty = float(filter_info['maxQty'])
                    
                    if quantity < min_qty:
                        return {'valid': False, 'error': f'Quantity quá nhỏ (min: {min_qty})'}
                    if quantity > max_qty:
                        return {'valid': False, 'error': f'Quantity quá lớn (max: {max_qty})'}
                
                # MIN_NOTIONAL - minimum order value
                elif filter_type == 'MIN_NOTIONAL':
                    min_notional = float(filter_info['minNotional'])
                    current_price = self.get_current_price(symbol)
                    
                    if current_price:
                        order_value = quantity * current_price
                        if order_value < min_notional:
                            return {'valid': False, 'error': f'Giá trị order quá nhỏ (min: ${min_notional})'}
                
                # PRICE_FILTER - price constraints for limit orders
                elif filter_type == 'PRICE_FILTER' and order_type == 'LIMIT' and price:
                    min_price = float(filter_info['minPrice'])
                    max_price = float(filter_info['maxPrice'])
                    
                    if price < min_price:
                        return {'valid': False, 'error': f'Giá quá thấp (min: {min_price})'}
                    if price > max_price:
                        return {'valid': False, 'error': f'Giá quá cao (max: {max_price})'}
            
            return {'valid': True, 'message': 'Tham số order hợp lệ'}
            
        except Exception as e:
            logger.error(f"❌ Lỗi validate order: {e}")
            return {'valid': False, 'error': f'Lỗi validate: {str(e)}'}
    
    def get_ai_prediction_for_order(self, symbol: str) -> Dict:
        """Lấy dự đoán AI cho symbol trước khi đặt order"""
        try:
            if not self.ai_predictor:
                return {
                    'prediction': 'Không có AI',
                    'confidence': 0,
                    'signal_explanation': 'AI predictor chưa được khởi tạo'
                }
            
            # Lấy dữ liệu recent cho prediction
            from app_data import load_cached_chart
            chart_data = load_cached_chart(symbol.replace('USDT', ''))
            
            if chart_data is None or chart_data.empty:
                return {
                    'prediction': 'Không có dữ liệu',
                    'confidence': 0,
                    'signal_explanation': 'Không có dữ liệu chart để phân tích'
                }
            
            # Thực hiện prediction
            prediction = self.ai_predictor.predict_single(chart_data, symbol)
            
            if prediction:
                return {
                    'prediction': prediction.get('direction', 'HOLD'),
                    'confidence': prediction.get('confidence', 0),
                    'signal_explanation': prediction.get('signal_explanation', ''),
                    'tp_sl': prediction.get('tp_sl', {}),
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                }
            
            return {
                'prediction': 'Không rõ',
                'confidence': 0,
                'signal_explanation': 'AI không thể phân tích'
            }
            
        except Exception as e:
            logger.error(f"❌ Lỗi AI prediction {symbol}: {e}")
            return {
                'prediction': 'Lỗi',
                'confidence': 0,
                'signal_explanation': f'Lỗi AI: {str(e)}'
            }
    
    def place_order(self, symbol: str, side: str, quantity: float, 
                   order_type: str = 'MARKET', price: float = None, 
                   get_ai_prediction: bool = True) -> Dict:
        """Đặt lệnh giao dịch"""
        try:
            # Kiểm tra tài nguyên hệ thống
            memory_usage = psutil.virtual_memory().percent
            if memory_usage > 90:
                return {'success': False, 'error': 'Tài nguyên hệ thống cao, không thể đặt lệnh'}
            
            symbol = symbol.upper()
            side = side.upper()
            order_type = order_type.upper()
            
            # Validate parameters
            validation = self.validate_order_params(symbol, side, quantity, order_type, price)
            if not validation['valid']:
                return {'success': False, 'error': validation['error']}
            
            # Tính precision cho quantity
            adjusted_quantity = self.calculate_quantity_precision(symbol, quantity)
            
            # Kiểm tra số dư
            account_info = self.get_account_info()
            if not account_info['success']:
                return {'success': False, 'error': 'Không thể lấy thông tin tài khoản'}
            
            # Lấy AI prediction trước khi đặt lệnh
            ai_prediction = None
            if get_ai_prediction:
                ai_prediction = self.get_ai_prediction_for_order(symbol)
            
            # Chuẩn bị order parameters
            order_params = {
                'symbol': symbol,
                'side': side,
                'type': order_type,
                'quantity': adjusted_quantity
            }
            
            if order_type == 'LIMIT':
                if price is None:
                    return {'success': False, 'error': 'Cần chỉ định giá cho LIMIT order'}
                order_params['price'] = price
                order_params['timeInForce'] = 'GTC'  # Good Till Canceled
            
            # Thực hiện đặt lệnh
            logger.info(f"🚀 Đặt lệnh {side} {adjusted_quantity} {symbol} ({order_type})")
            
            result = self._make_request('POST', '/api/v3/order', params=order_params, signed=True)
            
            if result['success']:
                order_data = result['data']
                
                # Lưu vào lịch sử
                order_record = {
                    'orderId': order_data.get('orderId'),
                    'symbol': symbol,
                    'side': side,
                    'type': order_type,
                    'quantity': adjusted_quantity,
                    'price': price,
                    'status': order_data.get('status'),
                    'executedQty': float(order_data.get('executedQty', 0)),
                    'cummulativeQuoteQty': float(order_data.get('cummulativeQuoteQty', 0)),
                    'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'ai_prediction': ai_prediction
                }
                
                self.order_history.append(order_record)
                
                # Clear balance cache để update mới
                self.last_balance_update = None
                
                logger.info(f"✅ Đặt lệnh thành công: {order_data.get('orderId')}")
                
                return {
                    'success': True,
                    'order': order_record,
                    'ai_prediction': ai_prediction,
                    'message': f'Đặt lệnh {side} {adjusted_quantity} {symbol} thành công'
                }
            else:
                return result
                
        except Exception as e:
            logger.error(f"❌ Lỗi đặt lệnh: {e}")
            return {'success': False, 'error': f'Lỗi đặt lệnh: {str(e)}'}
    
    def get_order_history(self, limit: int = 10) -> List[Dict]:
        """Lấy lịch sử orders"""
        try:
            # Trả về orders từ memory (local history)
            return self.order_history[-limit:] if self.order_history else []
            
        except Exception as e:
            logger.error(f"❌ Lỗi lấy order history: {e}")
            return []
    
    def get_open_orders(self, symbol: str = None) -> List[Dict]:
        """Lấy danh sách orders đang mở"""
        try:
            params = {}
            if symbol:
                params['symbol'] = symbol.upper()
            
            result = self._make_request('GET', '/api/v3/openOrders', params=params, signed=True)
            
            if result['success']:
                return result['data']
            else:
                logger.error(f"❌ Lỗi lấy open orders: {result.get('error', 'Unknown')}")
                return []
                
        except Exception as e:
            logger.error(f"❌ Lỗi lấy open orders: {e}")
            return []
    
    def cancel_order(self, symbol: str, order_id: int) -> Dict:
        """Hủy order"""
        try:
            params = {
                'symbol': symbol.upper(),
                'orderId': order_id
            }
            
            result = self._make_request('DELETE', '/api/v3/order', params=params, signed=True)
            
            if result['success']:
                logger.info(f"✅ Hủy order {order_id} thành công")
                return {'success': True, 'message': f'Hủy order {order_id} thành công'}
            else:
                return result
                
        except Exception as e:
            logger.error(f"❌ Lỗi hủy order: {e}")
            return {'success': False, 'error': f'Lỗi hủy order: {str(e)}'}
    
    def get_24hr_stats(self, symbol: str = None) -> Dict:
        """Lấy thống kê 24h"""
        try:
            params = {}
            if symbol:
                params['symbol'] = symbol.upper()
            
            endpoint = '/api/v3/ticker/24hr'
            result = self._make_request('GET', endpoint, params=params)
            
            if result['success']:
                return {'success': True, 'data': result['data']}
            else:
                return result
                
        except Exception as e:
            logger.error(f"❌ Lỗi lấy 24hr stats: {e}")
            return {'success': False, 'error': str(e)}

# Singleton instance
_executor_instance = None

def get_order_executor() -> OrderExecutor:
    """Lấy singleton instance của OrderExecutor"""
    global _executor_instance
    if _executor_instance is None:
        _executor_instance = OrderExecutor()
    return _executor_instance

# Helper functions
def format_balance_display(balances: List[Dict]) -> pd.DataFrame:
    """Format balances cho hiển thị"""
    try:
        if not balances:
            return pd.DataFrame()
        
        df = pd.DataFrame(balances)
        
        # Format numbers
        df['free'] = df['free'].apply(lambda x: f"{x:.8f}".rstrip('0').rstrip('.'))
        df['locked'] = df['locked'].apply(lambda x: f"{x:.8f}".rstrip('0').rstrip('.'))
        df['total'] = df['total'].apply(lambda x: f"{x:.8f}".rstrip('0').rstrip('.'))
        
        # Rename columns to Vietnamese
        df.columns = ['Asset', 'Khả dụng', 'Đang khóa', 'Tổng cộng']
        
        return df
        
    except Exception as e:
        logger.error(f"❌ Lỗi format balance: {e}")
        return pd.DataFrame()

def format_order_history_display(orders: List[Dict]) -> pd.DataFrame:
    """Format order history cho hiển thị"""
    try:
        if not orders:
            return pd.DataFrame()
        
        df = pd.DataFrame(orders)
        
        # Select và rename columns
        display_cols = {
            'timestamp': 'Thời gian',
            'symbol': 'Coin',
            'side': 'Loại',
            'quantity': 'Số lượng',
            'status': 'Trạng thái',
            'executedQty': 'Đã thực hiện'
        }
        
        df_display = df[list(display_cols.keys())].copy()
        df_display.columns = list(display_cols.values())
        
        return df_display
        
    except Exception as e:
        logger.error(f"❌ Lỗi format order history: {e}")
        return pd.DataFrame()
