"""
Trainer Core Module - REFACTORED
Contains core training logic and model management for the unified trainer.

Module này chứa:
- Model configuration and initialization
- Core training algorithms
- Data preparation and feature engineering
- Model saving and loading
- Resource management
"""

import os
import logging
import numpy as np
import pandas as pd
from typing import Dict, Tuple, Optional
from datetime import datetime
import pickle
import gzip
from pathlib import Path
import threading
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed

logger = logging.getLogger(__name__)

# GPU support
try:
    import torch
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    torch = None

def prepare_training_data(raw_data: Dict, clean_data: Dict, config: Dict) -> Dict:
    """Prepare data for training across multiple timeframes (multi-threaded)"""
    try:
        logger.info("🔧 Preparing training data for all timeframes (multi-threaded)...")
        from ai_models.feature_engineering import UnifiedFeatureEngineer
        feature_engineer = UnifiedFeatureEngineer(config.get('feature_config', {}))
        features = {}

        from concurrent.futures import ThreadPoolExecutor, as_completed
        def engineer(tf, df):
            if df is None or df.empty:
                logger.warning(f"⚠️ No data for timeframe {tf}")
                return tf, None
            logger.info(f"🎯 Engineering features for {tf}...")
            features_df = feature_engineer.engineer_features(
                df,
                include_technical=True,
                include_statistical=True,
                include_advanced=True
            )
            return tf, features_df

        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = [executor.submit(engineer, tf, df) for tf, df in clean_data.items()]
            for future in as_completed(futures):
                tf, features_df = future.result()
                if features_df is not None and not features_df.empty:
                    features[tf] = features_df
                    logger.info(f"✅ {tf}: {features_df.shape[1]} features engineered")
                else:
                    logger.warning(f"⚠️ Feature engineering failed for {tf}")

        return features
    except Exception as e:
        logger.error(f"❌ Data preparation failed: {e}")
        return {}

def train_timeframe_models(timeframe: str, features_df: pd.DataFrame, config: Dict, device: str = 'cpu') -> Dict:
    """Train models for a specific timeframe"""
    try:
        logger.info(f"🚀 Training models for {timeframe}...")
        
        from ai_models.unified_ensemble import create_individual_model
        from ai_optimizer.unified_resource_manager import get_resource_manager
        
        resource_mgr = get_resource_manager()
        
        # Get training data split
        train_data, val_data = get_train_val_split(features_df)
        
        if train_data is None or val_data is None:
            logger.error(f"❌ Invalid data split for {timeframe}")
            return {}
        
        # Separate features and target
        feature_cols = [col for col in train_data.columns if col not in ['target', 'label']]
        X_train = train_data[feature_cols].values
        y_train = train_data['target'].values if 'target' in train_data.columns else train_data['label'].values
        X_val = val_data[feature_cols].values
        y_val = val_data['target'].values if 'target' in val_data.columns else val_data['label'].values
        
        # Get model configuration
        if device != 'cpu' and TORCH_AVAILABLE:
            models_config = get_ai_models_config_gpu()
        else:
            models_config = get_ai_models_config()
        
        trained_models = {}
        
        # Train each model type
        for model_name, model_config in models_config.items():
            try:
                logger.debug(f"Training {model_name} for {timeframe}...")
                
                # Create and train model
                model = create_individual_model(
                    model_type=model_name,
                    config=model_config,
                    device=device
                )
                
                if model is not None:
                    # Train the model
                    model.fit(X_train, y_train)
                    
                    # Validate
                    val_predictions = model.predict(X_val)
                    
                    # Calculate metrics
                    from ai_models.unified_metrics import calculate_metrics_from_predictions
                    metrics = calculate_metrics_from_predictions(y_val, val_predictions)
                    
                    trained_models[model_name] = {
                        'model': model,
                        'metrics': metrics,
                        'timeframe': timeframe
                    }
                    
                    logger.debug(f"✅ {model_name} trained - Accuracy: {metrics.get('accuracy', 0):.3f}")
                
            except Exception as e:
                logger.warning(f"⚠️ Failed to train {model_name} for {timeframe}: {e}")
                continue
        
        logger.info(f"✅ Completed training for {timeframe}: {len(trained_models)} models")
        return trained_models
        
    except Exception as e:
        logger.error(f"❌ Training failed for {timeframe}: {e}")
        return {}

def get_train_val_split(features_df: pd.DataFrame, val_ratio: float = 0.2) -> Tuple[Optional[pd.DataFrame], Optional[pd.DataFrame]]:
    """Split data into training and validation sets"""
    try:
        if features_df is None or features_df.empty:
            return None, None
        
        # Time-based split for time series data
        split_idx = int(len(features_df) * (1 - val_ratio))
        
        train_data = features_df.iloc[:split_idx].copy()
        val_data = features_df.iloc[split_idx:].copy()
        
        # Validate that both sets have target column
        target_col = 'target' if 'target' in features_df.columns else 'label'
        if target_col not in features_df.columns:
            logger.error("❌ No target column found in features")
            return None, None
        
        logger.debug(f"📊 Train: {len(train_data)} rows, Val: {len(val_data)} rows")
        return train_data, val_data
        
    except Exception as e:
        logger.error(f"❌ Data split failed: {e}")
        return None, None

def get_ai_models_config() -> Dict:
    """Get AI models configuration for CPU training"""
    try:
        from ai_optimizer.unified_resource_manager import get_resource_manager
        resource_mgr = get_resource_manager()
        
        # Get adaptive configuration based on system resources
        optimal_workers = resource_mgr.get_optimal_workers()
        memory_gb = resource_mgr.get_memory_status()['available_gb']
        
        # Scale model complexity based on available resources
        if memory_gb > 8:
            max_features = 'sqrt'
            n_estimators_rf = 200
            n_estimators_et = 150
        elif memory_gb > 4:
            max_features = 'sqrt'
            n_estimators_rf = 100
            n_estimators_et = 100
        else:
            max_features = 'log2'
            n_estimators_rf = 50
            n_estimators_et = 50
        
        models_config = {
            'random_forest': {
                'n_estimators': n_estimators_rf,
                'max_depth': 15,
                'min_samples_split': 5,
                'min_samples_leaf': 2,
                'max_features': max_features,
                'n_jobs': optimal_workers,
                'random_state': 42
            },
            'extra_trees': {
                'n_estimators': n_estimators_et,
                'max_depth': 12,
                'min_samples_split': 3,
                'min_samples_leaf': 1,
                'max_features': max_features,
                'n_jobs': optimal_workers,
                'random_state': 42
            },
            'logistic_regression': {
                'C': 1.0,
                'penalty': 'l2',
                'solver': 'liblinear',
                'max_iter': 1000,
                'random_state': 42,
                'n_jobs': optimal_workers
            }
        }
        
        # Add gradient boosting models if available
        try:
            import xgboost
            models_config['xgboost'] = {
                'n_estimators': 100,
                'max_depth': 6,
                'learning_rate': 0.1,
                'subsample': 0.8,
                'colsample_bytree': 0.8,
                'random_state': 42,
                'n_jobs': optimal_workers
            }
        except ImportError:
            pass
        
        try:
            import lightgbm
            models_config['lightgbm'] = {
                'n_estimators': 100,
                'max_depth': 6,
                'learning_rate': 0.1,
                'subsample': 0.8,
                'colsample_bytree': 0.8,
                'random_state': 42,
                'n_jobs': optimal_workers,
                'verbose': -1
            }
        except ImportError:
            pass
        
        try:
            import catboost
            models_config['catboost'] = {
                'iterations': 100,
                'depth': 6,
                'learning_rate': 0.1,
                'random_seed': 42,
                'verbose': False,
                'thread_count': optimal_workers
            }
        except ImportError:
            pass
        
        logger.info(f"🎯 CPU models config: {list(models_config.keys())}")
        return models_config
        
    except Exception as e:
        logger.error(f"❌ Failed to get models config: {e}")
        return {
            'random_forest': {
                'n_estimators': 50,
                'max_depth': 10,
                'random_state': 42
            }
        }

def get_ai_models_config_gpu() -> Dict:
    """Get AI models configuration for GPU training"""
    try:
        if not TORCH_AVAILABLE:
            logger.warning("⚠️ PyTorch not available, falling back to CPU config")
            return get_ai_models_config()
        
        from ai_optimizer.unified_resource_manager import get_resource_manager
        resource_mgr = get_resource_manager()
        
        gpu_info = resource_mgr.get_gpu_metrics()
        optimal_workers = resource_mgr.get_optimal_workers()
        
        # Scale model complexity based on GPU memory
        gpu_memory_gb = gpu_info.get('memory_total', 0) / 1024**3
        
        if gpu_memory_gb > 8:
            # High-end GPU
            max_epochs = 200
            batch_size = 512
            hidden_sizes = [256, 128, 64]
        elif gpu_memory_gb > 4:
            # Mid-range GPU
            max_epochs = 150
            batch_size = 256
            hidden_sizes = [128, 64, 32]
        else:
            # Low-end GPU or integrated
            max_epochs = 100
            batch_size = 128
            hidden_sizes = [64, 32]
        
        models_config = {
            'neural_network': {
                'hidden_layer_sizes': hidden_sizes,
                'activation': 'relu',
                'solver': 'adam',
                'learning_rate': 'adaptive',
                'max_iter': max_epochs,
                'random_state': 42,
                'early_stopping': True,
                'validation_fraction': 0.1
            },
            'gradient_boosting': {
                'n_estimators': 150,
                'max_depth': 8,
                'learning_rate': 0.1,
                'subsample': 0.8,
                'random_state': 42
            }
        }
        
        # Add CPU models as well
        cpu_config = get_ai_models_config()
        models_config.update(cpu_config)
        
        logger.info(f"🚀 GPU-enabled models config: {list(models_config.keys())}")
        return models_config
        
    except Exception as e:
        logger.error(f"❌ Failed to get GPU models config: {e}")
        return get_ai_models_config()

def select_optimal_models(all_models: Dict, max_models: int = 5) -> Dict:
    """Select the best performing models from all trained models"""
    try:
        logger.info("🎯 Selecting optimal models based on performance...")
        
        model_scores = []
        
        # Collect all models with their scores
        for timeframe, timeframe_models in all_models.items():
            for model_name, model_data in timeframe_models.items():
                metrics = model_data.get('metrics', {})
                
                # Calculate composite score
                accuracy = metrics.get('accuracy', 0)
                precision = metrics.get('precision', 0)
                recall = metrics.get('recall', 0)
                f1 = metrics.get('f1_score', 0)
                
                # Weighted composite score
                composite_score = (accuracy * 0.3 + precision * 0.25 + recall * 0.25 + f1 * 0.2)
                
                model_scores.append({
                    'timeframe': timeframe,
                    'model_name': model_name,
                    'score': composite_score,
                    'model_data': model_data
                })
        
        # Sort by score (descending)
        model_scores.sort(key=lambda x: x['score'], reverse=True)
        
        # Select top models
        optimal_models = {}
        selected_count = 0
        
        for model_info in model_scores[:max_models]:
            timeframe = model_info['timeframe']
            model_name = model_info['model_name']
            
            if timeframe not in optimal_models:
                optimal_models[timeframe] = {}
            
            optimal_models[timeframe][model_name] = model_info['model_data']
            selected_count += 1
            
            logger.info(f"✅ Selected {model_name} ({timeframe}) - Score: {model_info['score']:.3f}")
        
        logger.info(f"🎯 Selected {selected_count} optimal models from {len(model_scores)} candidates")
        return optimal_models
        
    except Exception as e:
        logger.error(f"❌ Model selection failed: {e}")
        return all_models

def save_multi_timeframe_model(models: Dict, config: Dict, symbol: str) -> bool:
    """Save multi-timeframe model to disk"""
    try:
        from config.settings import MODEL_DIR
        
        # Create model directory if it doesn't exist
        model_dir = Path(MODEL_DIR)
        model_dir.mkdir(parents=True, exist_ok=True)
        
        # Prepare model data
        model_data = {
            'models': models,
            'config': config,
            'symbol': symbol,
            'created_at': datetime.now().isoformat(),
            'version': '2.0'
        }
        
        # Save with compression
        model_path = model_dir / f"{symbol}_multi_timeframe_model.pkl.gz"
        
        with gzip.open(model_path, 'wb') as f:
            pickle.dump(model_data, f, protocol=pickle.HIGHEST_PROTOCOL)
        
        logger.info(f"✅ Multi-timeframe model saved: {model_path}")
        return True
        
    except Exception as e:
        logger.error(f"❌ Failed to save model: {e}")
        return False

def load_multi_timeframe_model(symbol: str) -> Optional[Dict]:
    """Load multi-timeframe model from disk"""
    try:
        from config.settings import MODEL_DIR
        
        model_path = Path(MODEL_DIR) / f"{symbol}_multi_timeframe_model.pkl.gz"
        
        if not model_path.exists():
            logger.warning(f"⚠️ Model file not found: {model_path}")
            return None
        
        with gzip.open(model_path, 'rb') as f:
            model_data = pickle.load(f)
        
        logger.info(f"✅ Multi-timeframe model loaded: {model_path}")
        return model_data
        
    except Exception as e:
        logger.error(f"❌ Failed to load model: {e}")
        return None

def cleanup_gpu_memory():
    """Clean up GPU memory if available"""
    try:
        if TORCH_AVAILABLE and torch.cuda.is_available():
            torch.cuda.empty_cache()
            torch.cuda.synchronize()
            logger.debug("🧹 GPU memory cleaned")
    except Exception as e:
        logger.warning(f"⚠️ GPU cleanup failed: {e}")

def optimize_dataframe_memory(df: pd.DataFrame) -> pd.DataFrame:
    """Optimize DataFrame memory usage"""
    try:
        start_memory = df.memory_usage(deep=True).sum() / 1024**2
        
        for col in df.columns:
            if df[col].dtype == 'object':
                continue
            
            col_type = df[col].dtype
            
            if col_type != object:
                c_min = df[col].min()
                c_max = df[col].max()
                
                if str(col_type)[:3] == 'int':
                    if c_min > np.iinfo(np.int8).min and c_max < np.iinfo(np.int8).max:
                        df[col] = df[col].astype(np.int8)
                    elif c_min > np.iinfo(np.int16).min and c_max < np.iinfo(np.int16).max:
                        df[col] = df[col].astype(np.int16)
                    elif c_min > np.iinfo(np.int32).min and c_max < np.iinfo(np.int32).max:
                        df[col] = df[col].astype(np.int32)
                else:
                    if c_min > np.finfo(np.float32).min and c_max < np.finfo(np.float32).max:
                        df[col] = df[col].astype(np.float32)
        
        end_memory = df.memory_usage(deep=True).sum() / 1024**2
        reduction = (start_memory - end_memory) / start_memory * 100
        
        if reduction > 1:
            logger.debug(f"🔧 Memory usage reduced by {reduction:.1f}%")
        
        return df
        
    except Exception as e:
        logger.warning(f"⚠️ Memory optimization failed: {e}")
        return df

def clean_training_data(raw_data: pd.DataFrame) -> pd.DataFrame:
    """Clean raw trading data for training"""
    try:
        if raw_data is None or raw_data.empty:
            return pd.DataFrame()
        
        df = raw_data.copy()
        
        # Convert to numeric
        numeric_cols = ['open', 'high', 'low', 'close', 'volume']
        for col in numeric_cols:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        
        # Remove rows with NaN in critical columns
        df = df.dropna(subset=numeric_cols)
        
        # Remove invalid OHLC data
        if all(col in df.columns for col in ['open', 'high', 'low', 'close']):
            # High should be >= max(open, close) and <= high
            # Low should be <= min(open, close) and >= low
            valid_mask = (
                (df['high'] >= df[['open', 'close']].max(axis=1)) &
                (df['low'] <= df[['open', 'close']].min(axis=1)) &
                (df['high'] >= df['low']) &
                (df['volume'] >= 0)
            )
            df = df[valid_mask]
        
        # Remove extreme outliers (more than 50% price change in one period)
        if 'close' in df.columns:
            price_change = df['close'].pct_change().abs()
            df = df[price_change <= 0.5]
        
        # Ensure minimum data size
        if len(df) < 100:
            logger.warning(f"⚠️ Insufficient clean data: {len(df)} rows")
            return pd.DataFrame()
        
        logger.info(f"✅ Data cleaned: {len(df)} rows remaining")
        return df
        
    except Exception as e:
        logger.error(f"❌ Data cleaning failed: {e}")
        return pd.DataFrame()

def train_all_timeframes(features: Dict, config: Dict, device: str = 'cpu') -> Dict:
    """Train models for all timeframes in parallel"""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    all_models = {}
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = {executor.submit(train_timeframe_models, tf, features_df, config, device): tf for tf, features_df in features.items()}
        for future in as_completed(futures):
            tf = futures[future]
            try:
                models = future.result()
                all_models[tf] = models
            except Exception as e:
                logger.error(f"❌ Training failed for {tf}: {e}")
    return all_models
