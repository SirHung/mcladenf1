# ai_models/trainer_utils.py
"""
Trainer Utility Functions
Split from unified_trainer.py for optimization
"""

import gc
import os
import time
import pickle
import gzip
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple, Union
from collections import Counter
from datetime import datetime

from sklearn.model_selection import StratifiedKFold
# Use unified metrics instead of direct sklearn imports
from ai_models.unified_metrics import optimize_simple_threshold
# Metrics now handled by unified_metrics module to eliminate duplication
# Validation now handled by unified_data_validator module to eliminate duplication

from config.logging_config import get_logger
logger = get_logger('trainer_utils')

# Import unified validation for backward compatibility
from data_processing.unified_data_validator import validate_training_data as validate_data

# Imbalanced learning
try:
    from imblearn.over_sampling import SMOTE
    from imblearn.under_sampling import RandomUnderSampler
    IMBALANCED_AVAILABLE = True
except ImportError:
    IMBALANCED_AVAILABLE = False

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False


def apply_class_balancing(X: pd.DataFrame, y: pd.Series) -> Tuple[pd.DataFrame, pd.Series]:
    """Apply SMOTE or undersampling for class balancing"""
    if not IMBALANCED_AVAILABLE:
        logger.info("⚠️ Imbalanced-learn not available, skipping class balancing")
        return X, y
        
    try:
        counts = Counter(y)
        majority_count = max(counts.values())
        minority_count = min(counts.values())
        
        # Only balance if significantly imbalanced
        if minority_count / majority_count < 0.8 and minority_count >= 2:
            
            # Check available memory if psutil available
            if PSUTIL_AVAILABLE:
                mem = psutil.virtual_memory()
                use_undersampling = mem.available / mem.total < 0.3
            else:
                use_undersampling = len(X) > 10000  # Use undersampling for large datasets
            
            if use_undersampling:
                # Use undersampling
                rus = RandomUnderSampler(random_state=42)
                X_balanced, y_balanced = rus.fit_resample(X, y)
                logger.info(f"📊 Applied undersampling: {Counter(y_balanced)}")
            else:
                # Use SMOTE
                k_neighbors = min(3, minority_count - 1)
                if k_neighbors > 0:
                    smote = SMOTE(k_neighbors=k_neighbors, random_state=42)
                    X_balanced, y_balanced = smote.fit_resample(X, y)
                    logger.info(f"📊 Applied SMOTE: {Counter(y_balanced)}")
                else:
                    logger.warning("Not enough minority samples for SMOTE")
                    return X, y
            
            return X_balanced, y_balanced
        else:
            logger.info("📊 Classes already balanced, skipping resampling")
            return X, y
            
    except Exception as e:
        logger.error(f"Class balancing failed: {e}")
        return X, y

def get_cv_strategy(y: Union[pd.Series, np.ndarray], cv_folds: int = 3) -> StratifiedKFold:
    """Get appropriate cross-validation strategy"""
    counts = Counter(y)
    min_count = min(counts.values())
    n_splits = min(cv_folds, min_count, len(y) // 10)
    n_splits = max(2, n_splits)  # Minimum 2 splits
    
    return StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)

def compute_metrics(model, X: pd.DataFrame, y: pd.Series) -> dict:
    """Compute comprehensive metrics using unified metrics module"""
    try:
        # Delegate to unified metrics module to eliminate duplication
        from ai_models.unified_metrics import compute_comprehensive_metrics
        return compute_comprehensive_metrics(model, X, y)
        
    except Exception as e:
        logger.error(f"Metrics computation failed: {e}")
        return {"error": str(e)}

def optimize_threshold(model, X: pd.DataFrame, y: pd.Series) -> float:
    """Simple threshold optimization - use unified_metrics for advanced optimization"""
    if hasattr(model, 'predict_proba'):
        try:
            y_proba = model.predict_proba(X)
            # Check if binary classification
            if y_proba.shape[1] == 2:
                y_proba_pos = y_proba[:, 1]
                # Use unified_metrics threshold optimization
                return optimize_simple_threshold(y, y_proba_pos)
            else:
                # Multiclass classification - return default threshold
                logger.info("Multiclass classification detected, using default threshold 0.5")
                return 0.5
        except Exception as e:
            logger.warning(f"Threshold optimization failed: {e}")
    return 0.5

def save_model(model, filepath: str, metrics: dict = None, compress: bool = True) -> bool:
    """Save model to file with optional compression"""
    try:
        model_data = {
            'model': model,
            'metrics': metrics or {},
            'timestamp': datetime.now().isoformat(),
            'scaler': getattr(model, 'scaler', None)
        }
        
        if compress:
            with gzip.open(filepath, 'wb') as f:
                pickle.dump(model_data, f)
            logger.info(f"💾 Model saved (compressed) to {filepath}")
        else:
            with open(filepath, 'wb') as f:
                pickle.dump(model_data, f)
            logger.info(f"💾 Model saved to {filepath}")
        
        return True
        
    except Exception as e:
        logger.error(f"Failed to save model: {e}")
        return False

def load_model(filepath: str) -> Tuple[Any, dict]:
    """Load model from file"""
    try:
        if filepath.endswith('.gz'):
            with gzip.open(filepath, 'rb') as f:
                model_data = pickle.load(f)
        else:
            with open(filepath, 'rb') as f:
                model_data = pickle.load(f)
        
        if isinstance(model_data, dict):
            model = model_data.get('model')
            metrics = model_data.get('metrics', {})
        else:
            model = model_data
            metrics = {}
        
        return model, metrics
        
    except Exception as e:
        logger.error(f"Failed to load model from {filepath}: {e}")
        return None, {}

def cleanup_memory():
    """Cleanup memory and garbage collection"""
    gc.collect()
    if PSUTIL_AVAILABLE:
        try:
            process = psutil.Process()
            memory_info = process.memory_info()
            logger.debug(f"Memory usage: {memory_info.rss / 1024 / 1024:.1f} MB")
        except:
            pass

# NOTE: Model configuration moved to ai_models.ai_logic for AI-driven optimization
# Use get_adaptive_model_config() from ai_logic module instead

# NOTE: GPU model configuration moved to ai_models.ai_logic for AI-driven optimization
# Use get_adaptive_model_config() from ai_logic module instead

# NOTE: Model selection moved to ai_models.ai_logic for AI-driven optimization
# Use get_adaptive_model_selection() from ai_logic module instead

def get_memory_usage(use_gpu=False) -> Dict[str, float]:
    """Get current memory usage information"""
    if not PSUTIL_AVAILABLE:
        return {'rss_mb': 0, 'vms_mb': 0, 'percent': 0}
        
    try: 
        process = psutil.Process()
        memory_info = process.memory_info()
        
        result = {
            'rss_mb': memory_info.rss / 1024 / 1024,  # Resident Set Size
            'vms_mb': memory_info.vms / 1024 / 1024,  # Virtual Memory Size
            'percent': process.memory_percent()
        }
        
        # GPU memory if available
        if use_gpu:
            try:
                import torch
                if torch.cuda.is_available():
                    gpu_memory = torch.cuda.memory_allocated() / 1024 / 1024
                    gpu_reserved = torch.cuda.memory_reserved() / 1024 / 1024
                    result.update({
                        'gpu_allocated_mb': gpu_memory,
                        'gpu_reserved_mb': gpu_reserved
                    })
            except ImportError:
                pass
        
        return result
        
    except Exception as e:
        logger.error(f"Memory usage check failed: {e}")
        return {'rss_mb': 0, 'vms_mb': 0, 'percent': 0}

# NOTE: Memory optimization moved to utilities module for centralized access
# Use optimize_dataframe_memory() from utilities module instead
