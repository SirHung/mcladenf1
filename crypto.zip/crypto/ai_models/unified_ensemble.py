# ai_models/unified_ensemble.py
"""
Advanced Unified Ensemble System - Modularized Ensemble Creation and Management
Ultra-optimized ensemble methods with timeout protection, diversity analysis, and advanced meta-learning
"""

import gc, os, time, threading
import numpy as np
import pandas as pd
from typing import Dict, Any, Optional, Tuple, List, Callable, Union
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# Configure logging
import logging
logger = logging.getLogger(__name__)

# Core ML imports with error handling
try:
    from sklearn.ensemble import StackingClassifier, VotingClassifier
    from sklearn.linear_model import LogisticRegression, Ridge, ElasticNet
    from sklearn.model_selection import StratifiedKFold
    from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, precision_score, recall_score
    from sklearn.base import clone
    from sklearn.calibration import CalibratedClassifierCV
    SKLEARN_AVAILABLE = True
except ImportError as e:
    logger.warning(f"Sklearn imports limited: {e}")
    SKLEARN_AVAILABLE = False

# Import resource manager
try:
    from ai_optimizer.unified_resource_manager import get_resource_manager
    RESOURCE_MANAGER_AVAILABLE = True
except ImportError:
    logger.warning("Resource manager not available")
    RESOURCE_MANAGER_AVAILABLE = False

# Import metrics
try:
    from ai_models.unified_results_manager import TrainingResult
    TRAINER_UTILS_AVAILABLE = True
except ImportError:
    logger.warning("TrainingResult not available")
    TRAINER_UTILS_AVAILABLE = False

# Additional imports for individual model training
try:
    from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier, GradientBoostingClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.svm import SVC
    from sklearn.neural_network import MLPClassifier
    from sklearn.naive_bayes import GaussianNB
    from sklearn.model_selection import cross_val_score
    from sklearn.metrics import accuracy_score
    ML_MODELS_AVAILABLE = True
except ImportError as e:
    logger.warning(f"ML models import failed: {e}")
    ML_MODELS_AVAILABLE = False

try:
    import xgboost as xgb
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False

try:
    import lightgbm as lgb
    LIGHTGBM_AVAILABLE = True
except ImportError:
    LIGHTGBM_AVAILABLE = False

try:
    import catboost as cb
    CATBOOST_AVAILABLE = True
except ImportError:
    CATBOOST_AVAILABLE = False

# Global ensemble manager instance
_ensemble_manager = None

@dataclass
class EnsembleConfig:
    """Configuration for ensemble creation"""
    use_stacking: bool = True
    use_voting: bool = True
    use_calibration: bool = True
    use_diversity_analysis: bool = True
    use_meta_learning: bool = True
    max_ensemble_time: int = 300  # 5 minutes max
    stacking_timeout: int = 60    # 1 minute for stacking
    diversity_timeout: int = 30   # 30 seconds for diversity
    min_models_for_stacking: int = 2
    max_models_for_stacking: int = 5
    ensemble_strategies: List[str] = field(default_factory=lambda: ['performance', 'diversity', 'softmax', 'rank'])
    meta_learners: List[str] = field(default_factory=lambda: ['logistic', 'ridge', 'elastic'])

@dataclass  
class EnsembleResult:
    """Result from ensemble creation"""
    ensemble_predict: Callable
    model_weights: Dict[str, float]
    best_model_name: str
    stacking_model: Optional[Any]
    voting_model: Optional[Any]
    diversity_scores: Dict[str, float]
    ensemble_score: float
    performance_metrics: Dict[str, float]
    creation_time: float
    strategies_used: List[str]
    meta_learner_used: Optional[str]
    timeout_occurred: bool = False
    fallback_used: bool = False

class UnifiedEnsembleManager:
    """Ultra-advanced ensemble creation and management system"""
    
    def __init__(self, config: Optional[EnsembleConfig] = None):
        self.config = config or EnsembleConfig()
        self.resource_manager = get_resource_manager() if RESOURCE_MANAGER_AVAILABLE else None
        self.cpu_cores = os.cpu_count() or 4
        self.memory_gb = self._get_memory_gb()
        self.feature_scaler = None
        
        # Dynamic thresholds based on system resources
        self.diversity_threshold = max(0.1, min(0.5, self.cpu_cores / 20))
        self.performance_threshold = max(0.6, min(0.9, (self.cpu_cores + self.memory_gb) / 20))
        
        logger.info(f"🎭 UnifiedEnsembleManager initialized with {self.cpu_cores} cores, {self.memory_gb}GB RAM")
    
    def _get_memory_gb(self) -> float:
        """Get available memory in GB"""
        try:
            import psutil
            return psutil.virtual_memory().total / (1024**3)
        except:
            return 8.0  # Default fallback
    
    def create_advanced_ensemble(self, 
                                all_results: Dict[str, Any], 
                                symbol: str,
                                feature_scaler: Optional[Any] = None,
                                unified_features: Optional[Dict[str, Any]] = None) -> EnsembleResult:
        """
        Create ultra-advanced ensemble with timeout protection and fallback mechanisms
        
        Args:
            all_results: Dictionary of trained model results
            symbol: Trading symbol
            feature_scaler: Optional feature scaler
            unified_features: Optional unified features for advanced techniques
            
        Returns:
            EnsembleResult: Complete ensemble result with all components
        """
        start_time = time.time()
        self.feature_scaler = feature_scaler
        
        logger.info(f"🎭 Creating ultra-advanced ensemble from {len(all_results)} models")
        
        try:
            # Step 1: Validate inputs
            if not all_results:
                raise ValueError("No training results provided for ensemble creation")
            
            # Step 2: Calculate diversity metrics with timeout
            diversity_scores = self._calculate_diversity_safe(all_results)
            
            # Step 3: Calculate model weights using multiple strategies
            model_weights, best_strategy = self._calculate_ensemble_weights(all_results, diversity_scores)
            
            # Step 4: Select best performing model
            best_model_name = self._select_best_model(all_results, model_weights)
            
            # Step 5: Create stacking ensemble if applicable
            stacking_model = self._create_stacking_ensemble(all_results, unified_features)
            
            # Step 6: Create voting ensemble if applicable
            voting_model = self._create_voting_ensemble(all_results)
            
            # Step 7: Create final ensemble prediction function
            ensemble_predict = self._create_ensemble_predictor(
                all_results, model_weights, stacking_model, voting_model
            )
            
            # Step 8: Calculate ensemble performance
            ensemble_score = self._evaluate_ensemble_performance(
                ensemble_predict, unified_features, all_results
            )
            
            creation_time = time.time() - start_time
            
            result = EnsembleResult(
                ensemble_predict=ensemble_predict,
                model_weights=model_weights,
                best_model_name=best_model_name,
                stacking_model=stacking_model,
                voting_model=voting_model,
                diversity_scores=diversity_scores,
                ensemble_score=ensemble_score,
                performance_metrics=self._get_performance_summary(all_results),
                creation_time=creation_time,
                strategies_used=[best_strategy],
                meta_learner_used=getattr(stacking_model, '_final_estimator_name', None) if stacking_model else None,
                timeout_occurred=creation_time > self.config.max_ensemble_time,
                fallback_used=False
            )
            
            logger.info(f"🏆 Advanced ensemble created successfully in {creation_time:.2f}s")
            logger.info(f"   🎯 Best model: {best_model_name}")
            logger.info(f"   📊 Ensemble score: {ensemble_score:.3f}")
            logger.info(f"   🏗️ Stacking: {'✅' if stacking_model else '❌'}")
            logger.info(f"   🗳️ Voting: {'✅' if voting_model else '❌'}")
            
            return result
            
        except Exception as e:
            logger.error(f"❌ Advanced ensemble creation failed: {e}")
            # Create fallback ensemble
            return self._create_fallback_ensemble(all_results, symbol, start_time)
    
    def _calculate_diversity_safe(self, all_results: Dict[str, Any]) -> Dict[str, float]:
        """Calculate diversity metrics with timeout protection"""
        if not self.config.use_diversity_analysis or len(all_results) < 2:
            return {name: 0.5 for name in all_results.keys()}
        
        diversity_start = time.time()
        diversity_scores = {}
        
        try:
            logger.info("📊 Calculating ensemble diversity metrics...")
            
            # Extract predictions for diversity calculation
            model_predictions = {}
            for name, result in all_results.items():
                if hasattr(result, 'model') and result.model is not None:
                    # Use a small sample for diversity calculation to speed up
                    model_predictions[name] = result.model
            
            if len(model_predictions) < 2:
                return {name: 0.5 for name in all_results.keys()}
            
            # Calculate pairwise diversity using correlation
            model_names = list(model_predictions.keys())
            n_models = len(model_names)
            
            for i, name in enumerate(model_names):
                if time.time() - diversity_start > self.config.diversity_timeout:
                    logger.warning("⚠️ Diversity calculation timeout, using defaults")
                    break
                
                # Calculate diversity as 1 - average correlation with other models
                correlations = []
                for j, other_name in enumerate(model_names):
                    if i != j:
                        # Simplified diversity: use model performance difference
                        perf_diff = abs(all_results[name].accuracy - all_results[other_name].accuracy)
                        correlations.append(1.0 - perf_diff)  # Higher diff = more diverse
                
                avg_correlation = np.mean(correlations) if correlations else 0.5
                diversity_scores[name] = 1.0 - avg_correlation  # Higher = more diverse
            
            # Fill missing scores
            for name in all_results.keys():
                if name not in diversity_scores:
                    diversity_scores[name] = 0.5  # Default diversity
            
            logger.info(f"✅ Diversity calculation completed: {len(diversity_scores)} scores")
            return diversity_scores
            
        except Exception as e:
            logger.warning(f"⚠️ Diversity calculation failed: {e}, using equal weights")
            return {name: 0.5 for name in all_results.keys()}
    
    def _calculate_ensemble_weights(self, 
                                  all_results: Dict[str, Any], 
                                  diversity_scores: Dict[str, float]) -> Tuple[Dict[str, float], str]:
        """Calculate ensemble weights using multiple strategies"""
        
        logger.info("⚖️ Calculating ensemble weights using multiple strategies...")
        
        num_models = len(all_results)
        base_weight = 1.0 / max(num_models, 6)
        
        # Dynamic weight calculation based on model count and system resources
        weights_config = {
            'accuracy': base_weight * max(1.5, num_models / 4),
            'f1_score': base_weight * max(1.5, num_models / 4), 
            'auc_score': base_weight * max(1.5, num_models / 4),
            'precision': base_weight * max(0.5, num_models / 12),
            'recall': base_weight * max(0.5, num_models / 12),
            'diversity': base_weight * max(0.8, num_models / 8),
            'efficiency': base_weight * max(0.3, num_models / 15)
        }
        
        # Normalize weights
        total_weight = sum(weights_config.values())
        weights_config = {k: v / total_weight for k, v in weights_config.items()}
        
        # Calculate composite scores
        model_scores = {}
        for model_name, result in all_results.items():
            score = (
                result.accuracy * weights_config['accuracy'] +
                result.f1_score * weights_config['f1_score'] +
                result.auc_score * weights_config['auc_score'] +
                result.precision * weights_config['precision'] +
                result.recall * weights_config['recall'] +
                diversity_scores.get(model_name, 0.5) * weights_config['diversity']
            )
            
            # Efficiency bonus
            if result.training_time > 0:
                typical_time = max(self.cpu_cores * 10, 30)
                efficiency_bonus = min(0.1, typical_time / result.training_time * weights_config['efficiency'])
                score += efficiency_bonus
            
            model_scores[model_name] = score
        
        # Strategy 1: Performance-weighted
        total_score = sum(model_scores.values())
        perf_weights = {name: score / total_score for name, score in model_scores.items()}
        
        # Strategy 2: Softmax with temperature
        temperature = 3.0
        exp_scores = {name: np.exp(score * temperature) for name, score in model_scores.items()}
        exp_total = sum(exp_scores.values())
        softmax_weights = {name: exp_score / exp_total for name, exp_score in exp_scores.items()}
        
        # Strategy 3: Rank-based
        sorted_models = sorted(model_scores.items(), key=lambda x: x[1], reverse=True)
        rank_weights = {}
        for i, (name, score) in enumerate(sorted_models):
            rank_weights[name] = (len(sorted_models) - i) / sum(range(1, len(sorted_models) + 1))
        
        # Select best strategy (simplified: use performance for reliability)
        best_strategy = 'performance'
        best_weights = perf_weights
        
        logger.info(f"📊 Selected strategy: {best_strategy}")
        logger.info(f"📊 Top weighted models: {[(k, f'{v:.3f}') for k, v in sorted(best_weights.items(), key=lambda x: x[1], reverse=True)[:3]]}")
        
        return best_weights, best_strategy
    
    def _select_best_model(self, all_results: Dict[str, Any], model_weights: Dict[str, float]) -> str:
        """Select the best performing single model"""
        # Primary: highest composite score (accuracy + f1 + auc)
        best_score = 0
        best_model = list(all_results.keys())[0]  # Fallback
        
        for name, result in all_results.items():
            composite_score = (result.accuracy + result.f1_score + result.auc_score) / 3
            if composite_score > best_score:
                best_score = composite_score
                best_model = name
        
        logger.info(f"🎯 Best single model: {best_model} (score: {best_score:.3f})")
        return best_model
    
    def _create_stacking_ensemble(self, 
                                all_results: Dict[str, Any], 
                                unified_features: Optional[Dict[str, Any]] = None) -> Optional[Any]:
        """Create stacking ensemble with timeout protection"""
        
        if not self.config.use_stacking or len(all_results) < self.config.min_models_for_stacking:
            logger.info("🔧 Skipping stacking: insufficient models or disabled")
            return None
        
        try:
            logger.info("🏗️ Creating advanced stacking ensemble...")
            stacking_start = time.time()
            
            # Select models for stacking (top performers)
            sorted_models = sorted(all_results.items(), 
                                 key=lambda x: x[1].accuracy, reverse=True)
            
            selected_models = []
            for name, result in sorted_models[:self.config.max_models_for_stacking]:
                if hasattr(result, 'model') and result.model is not None:
                    selected_models.append((name, clone(result.model)))
                
                if time.time() - stacking_start > self.config.stacking_timeout:
                    logger.warning("⚠️ Stacking timeout during model selection")
                    break
            
            if len(selected_models) < 2:
                logger.warning("⚠️ Not enough valid models for stacking")
                return None
            
            # Select meta-learner
            meta_learner = self._select_meta_learner()
            
            # Create stacking classifier
            stacking_model = StackingClassifier(
                estimators=selected_models,
                final_estimator=meta_learner,
                cv=min(3, max(2, self.cpu_cores // 4)),  # Dynamic CV folds
                stack_method='predict_proba',
                n_jobs=1,  # Single job to prevent deadlocks
                passthrough=False  # Don't pass original features
            )
            
            logger.info(f"✅ Stacking ensemble created with {len(selected_models)} models")
            return stacking_model
            
        except Exception as e:
            logger.warning(f"⚠️ Stacking ensemble creation failed: {e}")
            return None
    
    def _create_voting_ensemble(self, all_results: Dict[str, Any]) -> Optional[Any]:
        """Create voting ensemble for additional diversity"""
        
        if not self.config.use_voting or len(all_results) < 3:
            return None
        
        try:
            logger.info("🗳️ Creating voting ensemble...")
            
            # Select top 3-5 models for voting
            sorted_models = sorted(all_results.items(), 
                                 key=lambda x: x[1].accuracy, reverse=True)
            
            voting_models = []
            for name, result in sorted_models[:5]:
                if hasattr(result, 'model') and result.model is not None:
                    voting_models.append((name, clone(result.model)))
            
            if len(voting_models) < 3:
                return None
            
            # Create soft voting classifier
            voting_model = VotingClassifier(
                estimators=voting_models,
                voting='soft',  # Use probabilities
                n_jobs=1
            )
            
            logger.info(f"✅ Voting ensemble created with {len(voting_models)} models")
            return voting_model
            
        except Exception as e:
            logger.warning(f"⚠️ Voting ensemble creation failed: {e}")
            return None
    
    def _select_meta_learner(self) -> Any:
        """Select optimal meta-learner based on system resources and configuration"""
        
        if not self.config.use_meta_learning:
            return LogisticRegression(C=1.0, random_state=42, max_iter=100, solver='liblinear')
        
        # System-based meta-learner selection
        if self.memory_gb >= 16 and self.cpu_cores >= 8:
            # High-resource system: use ElasticNet
            return ElasticNet(alpha=0.1, l1_ratio=0.5, random_state=42, max_iter=200)
        elif self.memory_gb >= 8 and self.cpu_cores >= 4:
            # Medium-resource system: use Ridge
            return Ridge(alpha=1.0, random_state=42, max_iter=200)
        else:
            # Low-resource system: use simple LogisticRegression
            return LogisticRegression(C=1.0, random_state=42, max_iter=100, solver='liblinear')
    
    def _create_ensemble_predictor(self, 
                                 all_results: Dict[str, Any],
                                 model_weights: Dict[str, float],
                                 stacking_model: Optional[Any],
                                 voting_model: Optional[Any]) -> Callable:
        """Create the final ensemble prediction function"""
        
        def ensemble_predict(X):
            """Ultra-advanced ensemble prediction with multiple strategies"""
            if len(X.shape) == 1:
                X = X.reshape(1, -1)
            
            predictions = []
            weights = []
            
            # Strategy 1: Weighted ensemble of individual models
            for model_name, result in all_results.items():
                try:
                    model = result.model
                    if hasattr(model, 'predict_proba'):
                        pred_proba = model.predict_proba(X)
                        pred = pred_proba[:, 1] if pred_proba.shape[1] > 1 else pred_proba
                    else:
                        pred = model.predict(X)
                    
                    predictions.append(pred)
                    weights.append(model_weights[model_name])
                    
                except Exception as e:
                    logger.debug(f"Model {model_name} prediction failed: {e}")
                    continue
            
            if not predictions:
                return np.array([0.5])  # Neutral fallback
            
            # Weighted average
            predictions_array = np.array(predictions)
            weights_array = np.array(weights)
            weighted_pred = np.average(predictions_array, axis=0, weights=weights_array)
            
            # Strategy 2: Stacking prediction
            stacking_pred = None
            if stacking_model is not None:
                try:
                    X_scaled = X
                    if self.feature_scaler is not None:
                        X_scaled = self.feature_scaler.transform(X)
                    
                    stacking_proba = stacking_model.predict_proba(X_scaled)
                    stacking_pred = stacking_proba[:, 1] if stacking_proba.shape[1] > 1 else stacking_proba
                except Exception as e:
                    logger.debug(f"Stacking prediction failed: {e}")
            
            # Strategy 3: Voting prediction
            voting_pred = None
            if voting_model is not None:
                try:
                    X_scaled = X
                    if self.feature_scaler is not None:
                        X_scaled = self.feature_scaler.transform(X)
                    
                    voting_proba = voting_model.predict_proba(X_scaled)
                    voting_pred = voting_proba[:, 1] if voting_proba.shape[1] > 1 else voting_proba
                except Exception as e:
                    logger.debug(f"Voting prediction failed: {e}")
            
            # Combine all strategies with intelligent weighting
            final_pred = weighted_pred  # Base prediction
            strategy_count = 1
            
            if stacking_pred is not None:
                final_pred = (final_pred * strategy_count + stacking_pred * 1.2) / (strategy_count + 1.2)
                strategy_count += 1.2
            
            if voting_pred is not None:
                final_pred = (final_pred * strategy_count + voting_pred * 0.8) / (strategy_count + 0.8)
                strategy_count += 0.8
            
            # Apply confidence-based adjustment
            if len(predictions) > 1:
                confidence = 1.0 - np.std(predictions_array.flatten())
                if confidence < 0.5:
                    # Low confidence: move toward neutral
                    final_pred = 0.5 + (final_pred - 0.5) * confidence
            
            return final_pred
        
        return ensemble_predict
    
    def _evaluate_ensemble_performance(self, 
                                     ensemble_predict: Callable,
                                     unified_features: Optional[Dict[str, Any]],
                                     all_results: Dict[str, Any]) -> float:
        """Evaluate ensemble performance if test data is available"""
        
        if unified_features is None or 'X_test' not in unified_features:
            # Fallback: use best individual model performance
            best_accuracy = max(result.accuracy for result in all_results.values())
            return min(best_accuracy * 1.05, 1.0)  # Slight boost for ensemble
        
        try:
            X_test = unified_features['X_test']
            y_test = unified_features['y_test']
            
            # Get ensemble predictions
            ensemble_preds = ensemble_predict(X_test)
            ensemble_class_preds = (ensemble_preds > 0.5).astype(int)
            
            # Calculate ensemble accuracy
            ensemble_accuracy = accuracy_score(y_test, ensemble_class_preds)
            
            logger.info(f"📊 Ensemble test accuracy: {ensemble_accuracy:.3f}")
            return ensemble_accuracy
            
        except Exception as e:
            logger.warning(f"⚠️ Ensemble evaluation failed: {e}")
            # Fallback to best individual model performance
            best_accuracy = max(result.accuracy for result in all_results.values())
            return min(best_accuracy * 1.02, 1.0)
    
    def _get_performance_summary(self, all_results: Dict[str, Any]) -> Dict[str, float]:
        """Get performance summary of all models"""
        if not all_results:
            return {}
        
        accuracies = [result.accuracy for result in all_results.values()]
        f1_scores = [result.f1_score for result in all_results.values()]
        auc_scores = [result.auc_score for result in all_results.values()]
        
        return {
            'mean_accuracy': np.mean(accuracies),
            'max_accuracy': np.max(accuracies),
            'min_accuracy': np.min(accuracies),
            'mean_f1': np.mean(f1_scores),
            'max_f1': np.max(f1_scores),
            'mean_auc': np.mean(auc_scores),
            'max_auc': np.max(auc_scores),
            'model_count': len(all_results)
        }
    
    def _create_fallback_ensemble(self, 
                                all_results: Dict[str, Any], 
                                symbol: str, 
                                start_time: float) -> EnsembleResult:
        """Create simple fallback ensemble when advanced methods fail"""
        
        logger.warning("⚠️ Creating fallback ensemble due to errors")
        
        # Simple weighted average based on accuracy
        total_accuracy = sum(result.accuracy for result in all_results.values())
        simple_weights = {name: result.accuracy / total_accuracy 
                         for name, result in all_results.items()}
        
        best_model = max(all_results.items(), key=lambda x: x[1].accuracy)[0]
        
        def simple_ensemble_predict(X):
            """Simple weighted ensemble prediction"""
            if len(X.shape) == 1:
                X = X.reshape(1, -1)
            
            predictions = []
            weights = []
            
            for model_name, result in all_results.items():
                try:
                    model = result.model
                    pred = model.predict_proba(X) if hasattr(model, 'predict_proba') else model.predict(X)
                    if hasattr(pred, 'shape') and len(pred.shape) > 1 and pred.shape[1] > 1:
                        pred = pred[:, 1]
                    
                    predictions.append(pred)
                    weights.append(simple_weights[model_name])
                except:
                    continue
            
            if not predictions:
                return np.array([0.5])
            
            return np.average(predictions, axis=0, weights=weights)
        
        creation_time = time.time() - start_time
        
        return EnsembleResult(
            ensemble_predict=simple_ensemble_predict,
            model_weights=simple_weights,
            best_model_name=best_model,
            stacking_model=None,
            voting_model=None,
            diversity_scores={name: 0.5 for name in all_results.keys()},
            ensemble_score=max(result.accuracy for result in all_results.values()),
            performance_metrics=self._get_performance_summary(all_results),
            creation_time=creation_time,
            strategies_used=['simple_weighted'],
            meta_learner_used=None,
            timeout_occurred=True,
            fallback_used=True
        )

@dataclass
class IndividualModelResult:
    """Result container for individual model training"""
    model: Any
    model_name: str = ""
    cv_score: float = 0.0
    test_score: float = 0.0
    training_time: float = 0.0
    hyperparameters: Dict[str, Any] = field(default_factory=dict)

def create_individual_model(model_name: str, model_type: str, params: Dict[str, Any],
                          X_train: pd.DataFrame, y_train: pd.Series,
                          X_test: pd.DataFrame, y_test: pd.Series,
                          cv_strategy: Any = None, use_hyperparameter_tuning: bool = False,
                          use_calibration: bool = False, timeout: float = 300,
                          gpu_available: bool = False) -> Optional[IndividualModelResult]:
    """
    Create and train an individual model with comprehensive error handling
    
    Args:
        model_name: Name of the model
        model_type: Type/category of the model  
        params: Model parameters
        X_train, y_train: Training data
        X_test, y_test: Test data
        cv_strategy: Cross-validation strategy
        use_hyperparameter_tuning: Whether to use hyperparameter tuning
        use_calibration: Whether to apply model calibration
        timeout: Training timeout
        gpu_available: Whether GPU is available
        
    Returns:
        IndividualModelResult or None if training failed
    """
    start_time = time.time()
    
    try:
        logger.debug(f"🔧 Creating {model_name} model...")
          # Create model based on type
        model = None
        
        if model_type in ['random_forest', 'random_forest_tuned', 'rf']:
            if ML_MODELS_AVAILABLE:
                model = RandomForestClassifier(**params)
            
        elif model_type in ['extra_trees', 'extra_trees_tuned']:
            if ML_MODELS_AVAILABLE:
                model = ExtraTreesClassifier(**params)
                
        elif model_type in ['gradient_boosting', 'gradient_boosting_tuned']:
            if ML_MODELS_AVAILABLE:
                model = GradientBoostingClassifier(**params)
                
        elif model_type == 'logistic_regression':
            if ML_MODELS_AVAILABLE:
                model = LogisticRegression(**params)
                
        elif model_type == 'svm':
            if ML_MODELS_AVAILABLE:
                model = SVC(**params)
                
        elif model_type == 'neural_network':
            if ML_MODELS_AVAILABLE:
                model = MLPClassifier(**params)
                
        elif model_type == 'naive_bayes':
            if ML_MODELS_AVAILABLE:
                model = GaussianNB(**params)
                
        elif model_type == 'xgboost' and XGBOOST_AVAILABLE:
            # Configure XGBoost for GPU if available
            if gpu_available:
                params = params.copy()
                params.update({'tree_method': 'hist', 'device': 'cuda'})
            model = xgb.XGBClassifier(**params)
            
        elif model_type == 'lightgbm' and LIGHTGBM_AVAILABLE:
            # Configure LightGBM for GPU if available
            if gpu_available:
                params = params.copy()
                params.update({'device': 'gpu', 'gpu_platform_id': 0})
            model = lgb.LGBMClassifier(**params)
            
        elif model_type == 'catboost' and CATBOOST_AVAILABLE:
            # Configure CatBoost for GPU if available
            if gpu_available:
                params = params.copy()
                params.update({'task_type': 'GPU', 'devices': '0'})
            model = cb.CatBoostClassifier(**params)
            
        else:
            logger.error(f"❌ {model_name}: Unknown or unavailable model type: {model_type}")
            return None
            
        if model is None:
            logger.error(f"❌ {model_name}: Model creation failed")
            return None
            
        # Train the model
        logger.debug(f"🎯 Training {model_name}...")
        model.fit(X_train, y_train)
        
        # Calculate CV score if strategy provided
        cv_score = 0.0
        if cv_strategy is not None and ML_MODELS_AVAILABLE:
            try:
                cv_scores = cross_val_score(model, X_train, y_train, cv=cv_strategy, scoring='f1_weighted', n_jobs=1)
                cv_score = cv_scores.mean()
                logger.debug(f"📊 {model_name}: CV score: {cv_score:.3f}")
            except Exception as e:
                logger.debug(f"⚠️ {model_name}: CV calculation failed: {e}")
                cv_score = 0.0
          # Apply calibration if requested
        if use_calibration and hasattr(model, 'predict_proba'):
            try:
                logger.debug(f"📐 Calibrating {model_name}...")
                model = CalibratedClassifierCV(model, cv=3)
                model.fit(X_train, y_train)
                logger.debug(f"✅ {model_name}: Calibration completed")
            except Exception as e:
                logger.warning(f"⚠️ {model_name}: Calibration failed: {e}") 
        
        # Calculate test score
        test_score = 0.0
        try:
            y_pred = model.predict(X_test)
            test_score = accuracy_score(y_test, y_pred)
            logger.debug(f"🎯 {model_name}: Test score: {test_score:.3f}")
        except Exception as e:
            logger.warning(f"⚠️ {model_name}: Test score calculation failed: {e}")
            test_score = 0.0
        
        training_time = time.time() - start_time
        result = IndividualModelResult(
            model=model,
            model_name=model_name,
            cv_score=cv_score,
            test_score=test_score,
            training_time=training_time,
            hyperparameters=params
        )
        
        logger.debug(f"✅ {model_name}: Individual model training completed in {training_time:.2f}s")
        return result
        
    except Exception as e:
        logger.error(f"❌ {model_name}: Individual model training failed: {e}")
        return None

# Global ensemble manager instance
_ensemble_manager = None

def get_ensemble_manager(config: Optional[EnsembleConfig] = None) -> UnifiedEnsembleManager:
    """Get singleton ensemble manager instance"""
    global _ensemble_manager
    if _ensemble_manager is None or config is not None:
        _ensemble_manager = UnifiedEnsembleManager(config)
    return _ensemble_manager

def create_optimized_ensemble(all_results: Dict[str, Any], 
                            symbol: str,
                            feature_scaler: Optional[Any] = None,
                            unified_features: Optional[Dict[str, Any]] = None,
                            config: Optional[EnsembleConfig] = None) -> EnsembleResult:
    """
    Create optimized ensemble using the unified ensemble manager
    
    This is the main entry point for ensemble creation from other modules
    """
    ensemble_manager = get_ensemble_manager(config)
    return ensemble_manager.create_advanced_ensemble(
        all_results=all_results,
        symbol=symbol, 
        feature_scaler=feature_scaler,
        unified_features=unified_features
    )
