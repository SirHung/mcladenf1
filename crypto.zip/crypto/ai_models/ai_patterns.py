"""
AI Pattern Recognition Module
Chứa tất cả các hàm nhận diện pattern cho crypto trading.

Module này được tách từ ai_logic.py để tối ưu hóa và dễ bảo trì.
"""

import numpy as np
import pandas as pd
from typing import Dict, Any
from config.logging_config import get_logger
from ai_optimizer.unified_resource_manager import get_resource_manager

logger = get_logger('ai_patterns')

# Import AI parameter calculator để tính toán thresholds thông minh
ai_parameter_calculator = None

def set_parameter_calculator(calculator):
    """Set AI parameter calculator cho pattern recognition"""
    global ai_parameter_calculator
    ai_parameter_calculator = calculator
    logger.info("✅ AI Parameter Calculator set for pattern recognition")

def add_triangle(df: pd.DataFrame, symbol: str = "BTCUSDT") -> pd.DataFrame:
    """
    Detect Triangle patterns using AI-driven thresholds
    Returns DataFrame with additional triangle columns
    """
    try:
        df = df.copy()
        df['ascending_triangle'] = 0
        df['descending_triangle'] = 0
        df['symmetrical_triangle'] = 0
        
        if len(df) < 20:
            return df
            
        # Get AI-driven thresholds
        if ai_parameter_calculator:
            thresholds = ai_parameter_calculator.calculate_pattern_thresholds(df, 'triangle')
            trend_threshold = thresholds['trend_threshold']
        else:
            trend_threshold = 0.001  # Fallback static value
            
        window = 20
        for i in range(window, len(df)):
            subset = df.iloc[i-window:i]
            
            highs = subset['high'].values
            lows = subset['low'].values
            
            # Calculate trend lines
            high_trend = np.polyfit(range(len(highs)), highs, 1)[0]
            low_trend = np.polyfit(range(len(lows)), lows, 1)[0]
            
            # AI-driven pattern detection
            if abs(high_trend) < trend_threshold and low_trend > trend_threshold:
                df.iloc[i, df.columns.get_loc('ascending_triangle')] = 1
            elif high_trend < -trend_threshold and abs(low_trend) < trend_threshold:
                df.iloc[i, df.columns.get_loc('descending_triangle')] = 1
            elif abs(high_trend - (-low_trend)) < trend_threshold:
                df.iloc[i, df.columns.get_loc('symmetrical_triangle')] = 1
                
        return df
        
    except Exception as e:
        logger.error(f"Triangle pattern detection failed: {e}")
        return df

def add_flag(df: pd.DataFrame, symbol: str = "BTCUSDT") -> pd.DataFrame:
    """
    Detect Flag patterns using AI-driven thresholds
    """
    try:
        df = df.copy()
        df['bullish_flag'] = 0
        df['bearish_flag'] = 0
        
        if len(df) < 25:
            return df
            
        # Get AI-driven thresholds
        if ai_parameter_calculator:
            thresholds = ai_parameter_calculator.calculate_pattern_thresholds(df, 'flag')
            volume_threshold = thresholds.get('volume_threshold', 1.5)
            trend_strength = thresholds.get('trend_strength', 0.02)
        else:
            volume_threshold = 1.5
            trend_strength = 0.02
            
        window = 20
        flag_window = 10
        
        for i in range(window + flag_window, len(df)):
            # Check for strong prior trend
            prior_trend = df.iloc[i-window-flag_window:i-flag_window]
            flag_period = df.iloc[i-flag_window:i]
            
            if len(prior_trend) < 5 or len(flag_period) < 5:
                continue
                
            # Calculate trend strength
            prior_trend_slope = np.polyfit(range(len(prior_trend)), prior_trend['close'], 1)[0]
            flag_trend_slope = np.polyfit(range(len(flag_period)), flag_period['close'], 1)[0]
            
            # Volume analysis
            avg_volume = df['volume'].rolling(window=20).mean().iloc[i]
            flag_volume = flag_period['volume'].mean()
            
            # AI-driven flag detection
            if (prior_trend_slope > trend_strength and 
                abs(flag_trend_slope) < trend_strength/2 and
                flag_volume < avg_volume * volume_threshold):
                df.iloc[i, df.columns.get_loc('bullish_flag')] = 1
                
            elif (prior_trend_slope < -trend_strength and 
                  abs(flag_trend_slope) < trend_strength/2 and
                  flag_volume < avg_volume * volume_threshold):
                df.iloc[i, df.columns.get_loc('bearish_flag')] = 1
                
        return df
        
    except Exception as e:
        logger.error(f"Flag pattern detection failed: {e}")
        return df

def add_pennant(df: pd.DataFrame) -> pd.DataFrame:
    """
    Detect Pennant patterns with AI-driven parameters
    """
    try:
        df = df.copy()
        df['pennant'] = 0
        
        if len(df) < 30:
            return df
            
        # Get AI-driven thresholds
        if ai_parameter_calculator:
            thresholds = ai_parameter_calculator.calculate_pattern_thresholds(df, 'pennant')
            convergence_rate = thresholds.get('convergence_rate', 0.001)
        else:
            convergence_rate = 0.001
            
        window = 20
        
        for i in range(window, len(df)):
            subset = df.iloc[i-window:i]
            
            if len(subset) < 10:
                continue
                
            # Calculate convergence
            high_trend = np.polyfit(range(len(subset)), subset['high'], 1)[0]
            low_trend = np.polyfit(range(len(subset)), subset['low'], 1)[0]
            
            # Check for convergence (pennant characteristic)
            if (high_trend < -convergence_rate and 
                low_trend > convergence_rate and
                abs(high_trend + low_trend) < convergence_rate):
                df.iloc[i, df.columns.get_loc('pennant')] = 1
                
        return df
        
    except Exception as e:
        logger.error(f"Pennant pattern detection failed: {e}")
        return df

def add_rising_wedge(df: pd.DataFrame) -> pd.DataFrame:
    """
    Detect Rising Wedge patterns with AI-driven parameters
    """
    try:
        df = df.copy()
        df['rising_wedge'] = 0
        
        if len(df) < 25:
            return df
            
        # Get AI-driven thresholds
        if ai_parameter_calculator:
            thresholds = ai_parameter_calculator.calculate_pattern_thresholds(df, 'wedge')
            wedge_threshold = thresholds.get('wedge_threshold', 0.001)
        else:
            wedge_threshold = 0.001
            
        window = 20
        
        for i in range(window, len(df)):
            subset = df.iloc[i-window:i]
            
            high_trend = np.polyfit(range(len(subset)), subset['high'], 1)[0]
            low_trend = np.polyfit(range(len(subset)), subset['low'], 1)[0]
            
            # Rising wedge: both trends rising, but highs rising slower
            if (high_trend > wedge_threshold and 
                low_trend > wedge_threshold and
                low_trend > high_trend * 1.2):
                df.iloc[i, df.columns.get_loc('rising_wedge')] = 1
                
        return df
        
    except Exception as e:
        logger.error(f"Rising wedge pattern detection failed: {e}")
        return df

def add_falling_wedge(df: pd.DataFrame) -> pd.DataFrame:
    """
    Detect Falling Wedge patterns with AI-driven parameters
    """
    try:
        df = df.copy()
        df['falling_wedge'] = 0
        
        if len(df) < 25:
            return df
            
        # Get AI-driven thresholds
        if ai_parameter_calculator:
            thresholds = ai_parameter_calculator.calculate_pattern_thresholds(df, 'wedge')
            wedge_threshold = thresholds.get('wedge_threshold', 0.001)
        else:
            wedge_threshold = 0.001
            
        window = 20
        
        for i in range(window, len(df)):
            subset = df.iloc[i-window:i]
            
            high_trend = np.polyfit(range(len(subset)), subset['high'], 1)[0]
            low_trend = np.polyfit(range(len(subset)), subset['low'], 1)[0]
            
            # Falling wedge: both trends falling, but lows falling slower
            if (high_trend < -wedge_threshold and 
                low_trend < -wedge_threshold and
                abs(low_trend) < abs(high_trend) * 0.8):
                df.iloc[i, df.columns.get_loc('falling_wedge')] = 1
                
        return df
        
    except Exception as e:
        logger.error(f"Falling wedge pattern detection failed: {e}")
        return df

def add_double_top(df: pd.DataFrame, symbol: str = "BTCUSDT") -> pd.DataFrame:
    """
    Detect Double Top patterns with AI-driven parameters
    """
    try:
        df = df.copy()
        df['double_top'] = 0
        
        if len(df) < 40:
            return df
            
        # Get AI-driven thresholds
        if ai_parameter_calculator:
            thresholds = ai_parameter_calculator.calculate_pattern_thresholds(df, 'double_top')
            similarity_threshold = thresholds.get('similarity_threshold', 0.02)
            min_distance = thresholds.get('min_distance', 10)
        else:
            similarity_threshold = 0.02
            min_distance = 10
            
        # Find local maxima
        window = 5
        local_maxima = []
        
        for i in range(window, len(df) - window):
            if (df['high'].iloc[i] == df['high'].iloc[i-window:i+window+1].max()):
                local_maxima.append((i, df['high'].iloc[i]))
        
        # Check for double tops
        for i in range(len(local_maxima) - 1):
            for j in range(i + 1, len(local_maxima)):
                idx1, peak1 = local_maxima[i]
                idx2, peak2 = local_maxima[j]
                
                if idx2 - idx1 < min_distance:
                    continue
                    
                # Check similarity of peaks
                if abs(peak1 - peak2) / peak1 < similarity_threshold:
                    # Found double top
                    df.iloc[idx2, df.columns.get_loc('double_top')] = 1
                    
        return df
        
    except Exception as e:
        logger.error(f"Double top pattern detection failed: {e}")
        return df

def add_double_bottom(df: pd.DataFrame) -> pd.DataFrame:
    """
    Detect Double Bottom patterns with AI-driven parameters
    """
    try:
        df = df.copy()
        df['double_bottom'] = 0
        
        if len(df) < 40:
            return df
            
        # Get AI-driven thresholds
        if ai_parameter_calculator:
            thresholds = ai_parameter_calculator.calculate_pattern_thresholds(df, 'double_bottom')
            similarity_threshold = thresholds.get('similarity_threshold', 0.02)
            min_distance = thresholds.get('min_distance', 10)
        else:
            similarity_threshold = 0.02
            min_distance = 10
            
        # Find local minima
        window = 5
        local_minima = []
        
        for i in range(window, len(df) - window):
            if (df['low'].iloc[i] == df['low'].iloc[i-window:i+window+1].min()):
                local_minima.append((i, df['low'].iloc[i]))
        
        # Check for double bottoms
        for i in range(len(local_minima) - 1):
            for j in range(i + 1, len(local_minima)):
                idx1, trough1 = local_minima[i]
                idx2, trough2 = local_minima[j]
                
                if idx2 - idx1 < min_distance:
                    continue
                    
                # Check similarity of troughs
                if abs(trough1 - trough2) / trough1 < similarity_threshold:
                    # Found double bottom
                    df.iloc[idx2, df.columns.get_loc('double_bottom')] = 1
                    
        return df
        
    except Exception as e:
        logger.error(f"Double bottom pattern detection failed: {e}")
        return df

def add_triple_top(df: pd.DataFrame) -> pd.DataFrame:
    """
    Detect Triple Top patterns with AI-driven parameters
    """
    try:
        df = df.copy()
        df['triple_top'] = 0
        
        if len(df) < 60:
            return df
            
        # Get AI-driven thresholds
        if ai_parameter_calculator:
            thresholds = ai_parameter_calculator.calculate_pattern_thresholds(df, 'triple_top')
            similarity_threshold = thresholds.get('similarity_threshold', 0.015)
            min_distance = thresholds.get('min_distance', 8)
        else:
            similarity_threshold = 0.015
            min_distance = 8
            
        # Find local maxima
        window = 5
        local_maxima = []
        
        for i in range(window, len(df) - window):
            if (df['high'].iloc[i] == df['high'].iloc[i-window:i+window+1].max()):
                local_maxima.append((i, df['high'].iloc[i]))
        
        # Check for triple tops
        for i in range(len(local_maxima) - 2):
            for j in range(i + 1, len(local_maxima) - 1):
                for k in range(j + 1, len(local_maxima)):
                    idx1, peak1 = local_maxima[i]
                    idx2, peak2 = local_maxima[j]
                    idx3, peak3 = local_maxima[k]
                    
                    if (idx2 - idx1 < min_distance or 
                        idx3 - idx2 < min_distance):
                        continue
                        
                    # Check similarity of all three peaks
                    avg_peak = (peak1 + peak2 + peak3) / 3
                    if (abs(peak1 - avg_peak) / avg_peak < similarity_threshold and
                        abs(peak2 - avg_peak) / avg_peak < similarity_threshold and
                        abs(peak3 - avg_peak) / avg_peak < similarity_threshold):
                        # Found triple top
                        df.iloc[idx3, df.columns.get_loc('triple_top')] = 1
                        
        return df
        
    except Exception as e:
        logger.error(f"Triple top pattern detection failed: {e}")
        return df

def add_triple_bottom(df: pd.DataFrame) -> pd.DataFrame:
    """
    Detect Triple Bottom patterns with AI-driven parameters
    """
    try:
        df = df.copy()
        df['triple_bottom'] = 0
        
        if len(df) < 60:
            return df
            
        # Get AI-driven thresholds
        if ai_parameter_calculator:
            thresholds = ai_parameter_calculator.calculate_pattern_thresholds(df, 'triple_bottom')
            similarity_threshold = thresholds.get('similarity_threshold', 0.015)
            min_distance = thresholds.get('min_distance', 8)
        else:
            similarity_threshold = 0.015
            min_distance = 8
            
        # Find local minima
        window = 5
        local_minima = []
        
        for i in range(window, len(df) - window):
            if (df['low'].iloc[i] == df['low'].iloc[i-window:i+window+1].min()):
                local_minima.append((i, df['low'].iloc[i]))
        
        # Check for triple bottoms
        for i in range(len(local_minima) - 2):
            for j in range(i + 1, len(local_minima) - 1):
                for k in range(j + 1, len(local_minima)):
                    idx1, trough1 = local_minima[i]
                    idx2, trough2 = local_minima[j]
                    idx3, trough3 = local_minima[k]
                    
                    if (idx2 - idx1 < min_distance or 
                        idx3 - idx2 < min_distance):
                        continue
                        
                    # Check similarity of all three troughs
                    avg_trough = (trough1 + trough2 + trough3) / 3
                    if (abs(trough1 - avg_trough) / avg_trough < similarity_threshold and
                        abs(trough2 - avg_trough) / avg_trough < similarity_threshold and
                        abs(trough3 - avg_trough) / avg_trough < similarity_threshold):
                        # Found triple bottom
                        df.iloc[idx3, df.columns.get_loc('triple_bottom')] = 1
                        
        return df
        
    except Exception as e:
        logger.error(f"Triple bottom pattern detection failed: {e}")
        return df

def add_rectangle(df: pd.DataFrame) -> pd.DataFrame:
    """
    Detect Rectangle patterns with AI-driven parameters
    """
    try:
        df = df.copy()
        df['rectangle'] = 0
        
        if len(df) < 30:
            return df
            
        # Get AI-driven thresholds
        if ai_parameter_calculator:
            thresholds = ai_parameter_calculator.calculate_pattern_thresholds(df, 'rectangle')
            horizontal_threshold = thresholds.get('horizontal_threshold', 0.005)
            min_touches = thresholds.get('min_touches', 4)
        else:
            horizontal_threshold = 0.005
            min_touches = 4
            
        window = 20
        
        for i in range(window, len(df)):
            subset = df.iloc[i-window:i]
            
            # Calculate resistance and support levels
            resistance = subset['high'].max()
            support = subset['low'].min()
            
            # Check for horizontal levels
            high_trend = np.polyfit(range(len(subset)), subset['high'], 1)[0]
            low_trend = np.polyfit(range(len(subset)), subset['low'], 1)[0]
            
            # Count touches of resistance and support
            resistance_touches = sum(abs(subset['high'] - resistance) / resistance < 0.01)
            support_touches = sum(abs(subset['low'] - support) / support < 0.01)
            
            # Rectangle pattern detection
            if (abs(high_trend) < horizontal_threshold and
                abs(low_trend) < horizontal_threshold and
                resistance_touches >= min_touches/2 and
                support_touches >= min_touches/2):
                df.iloc[i, df.columns.get_loc('rectangle')] = 1
                
        return df
        
    except Exception as e:
        logger.error(f"Rectangle pattern detection failed: {e}")
        return df

def compute_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute technical indicators with AI-driven parameters
    """
    try:
        df = df.copy()
        
        # Get AI-driven parameters
        if ai_parameter_calculator:
            params = ai_parameter_calculator.calculate_indicator_parameters(df)
            rsi_period = params.get('rsi_period', 14)
            ma_fast = params.get('ma_fast', 10)
            ma_slow = params.get('ma_slow', 50)
        else:
            rsi_period = 14
            ma_fast = 10
            ma_slow = 50
        
        # RSI
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=rsi_period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=rsi_period).mean()
        rs = gain / loss
        df['rsi'] = 100 - (100 / (1 + rs))
        
        # Moving averages
        df[f'ma_{ma_fast}'] = df['close'].rolling(window=ma_fast).mean()
        df[f'ma_{ma_slow}'] = df['close'].rolling(window=ma_slow).mean()
        
        # MACD
        ema12 = df['close'].ewm(span=12).mean()
        ema26 = df['close'].ewm(span=26).mean()
        df['macd'] = ema12 - ema26
        df['macd_signal'] = df['macd'].ewm(span=9).mean()
        df['macd_histogram'] = df['macd'] - df['macd_signal']
        
        return df
        
    except Exception as e:
        logger.error(f"Indicator computation failed: {e}")
        return df

# Pattern list for consistent feature columns
PATTERN_TYPES = [
    "Head and Shoulders", "Inverse Head and Shoulders", "Double Top", "Double Bottom",
    "Ascending Triangle", "Descending Triangle", "Symmetrical Triangle",
    "Bullish Flag", "Bearish Flag", "Rising Wedge", "Falling Wedge",
    "Triple Top", "Triple Bottom", "Rectangle"
]

def get_all_patterns(df: pd.DataFrame, symbol: str = "BTCUSDT") -> pd.DataFrame:
    """
    Apply all pattern detection functions to DataFrame
    """
    try:
        logger.info(f"🔍 Detecting patterns for {symbol} with {len(df)} rows")
        
        # Apply all pattern functions
        df = add_triangle(df, symbol)
        df = add_flag(df, symbol)
        df = add_pennant(df)
        df = add_rising_wedge(df)
        df = add_falling_wedge(df)
        df = add_double_top(df, symbol)
        df = add_double_bottom(df)
        df = add_triple_top(df)
        df = add_triple_bottom(df)
        df = add_rectangle(df)
        df = compute_indicators(df)
        
        logger.info(f"✅ Pattern detection completed for {symbol}")
        return df
        
    except Exception as e:
        logger.error(f"❌ Pattern detection failed: {e}")
        return df

def get_all_patterns_memory_safe(df_or_path, symbol: str = "BTCUSDT", batch_size: int = 100_000, use_gpu: bool = True, max_ram_usage: float = 0.9, wait_time: int = 180, **kwargs):
    """
    Memory-safe, multi-threaded, GPU-ready pattern detection for large DataFrames or file paths.
    - df_or_path: DataFrame hoặc đường dẫn file (csv/parquet)
    - batch_size: số dòng mỗi batch
    - use_gpu: ưu tiên GPU nếu có
    - max_ram_usage: ngưỡng RAM tối đa
    - wait_time: thời gian chờ khi thiếu RAM
    """
    resource_manager = get_resource_manager()
    logger.info(f"🔍 [MemorySafe] Bắt đầu nhận diện patterns cho {symbol} (batch={batch_size}, GPU={use_gpu})")

    def process_batch(batch_df):
        # Nếu có GPU và cuDF, chuyển sang GPU để tính toán
        try:
            if use_gpu:
                try:
                    import cudf
                    batch_df = cudf.DataFrame.from_pandas(batch_df)
                    # Nếu muốn, có thể chuyển lại về pandas sau khi tính toán
                except ImportError:
                    pass  # Không có cuDF, fallback pandas
        except Exception as e:
            logger.warning(f"Không thể chuyển batch sang GPU: {e}")
        # Áp dụng pattern detection bình thường
        batch_df = add_triangle(batch_df, symbol)
        batch_df = add_flag(batch_df, symbol)
        batch_df = add_pennant(batch_df)
        batch_df = add_rising_wedge(batch_df)
        batch_df = add_falling_wedge(batch_df)
        batch_df = add_double_top(batch_df, symbol)
        batch_df = add_double_bottom(batch_df)
        batch_df = add_triple_top(batch_df)
        batch_df = add_triple_bottom(batch_df)
        batch_df = add_rectangle(batch_df)
        batch_df = compute_indicators(batch_df)
        # Nếu là cuDF, chuyển lại về pandas
        if 'cudf' in str(type(batch_df)):
            batch_df = batch_df.to_pandas()
        return batch_df

    # Xử lý batch nhỏ, memory-safe, đa luồng
    results = resource_manager.safe_process_batches(
        df_or_path,
        process_func=process_batch,
        batch_size=batch_size,
        max_ram_usage=max_ram_usage,
        wait_time=wait_time,
        **kwargs
    )
    # Gộp lại kết quả
    if results:
        final_df = pd.concat(results, axis=0, ignore_index=True)
        logger.info(f"✅ [MemorySafe] Pattern detection hoàn tất cho {symbol}, shape={final_df.shape}")
        return final_df
    else:
        logger.error(f"❌ [MemorySafe] Không có batch nào được xử lý thành công!")
        return None
