"""
🚀 AI TRAINER - 30 BƯỚC HUẤN LUYỆN CAO CẤP 🚀
Module huấn luyện AI crypto chuyên nghiệp với 30 bước tối ưu
GPU-enabled và Multi-threading optimized
"""

import os
import logging
import numpy as np
import pandas as pd
from typing import Dict, List
from datetime import datetime
import pickle
import gzip
from pathlib import Path
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
import psutil

# GPU support
try:
    import torch
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    torch = None

# Import các module hiện có
from ai_models.feature_engineering import UnifiedFeatureEngineer
from ai_models.unified_ensemble import UnifiedEnsembleManager, create_individual_model
from ai_models.unified_metrics import calculate_metrics_from_predictions, UnifiedMetrics
from ai_models.unified_results_manager import UnifiedResultsManager
from ai_optimizer.unified_optimizer import UnifiedOptimizer
from ai_optimizer.unified_resource_manager import get_resource_manager, training_status
from data_processing.unified_data_loader import UnifiedDataLoader
from data_processing.unified_data_validator import UnifiedDataValidator, ValidationConfig
from backtesting.walk_forward import WalkForwardBacktester

logger = logging.getLogger(__name__)

# ========================================================================================
# RESOURCE MANAGEMENT - Sử dụng UnifiedResourceManager thay vì tự tạo class mới
# ========================================================================================


class UnifiedTrainer:
    """🎯 AI Trainer - 30 bước huấn luyện cao cấp cho crypto trading với GPU support"""
    def __init__(self, config: Dict):
        self.config = config
        self.symbol = config.get('symbol', 'BTCUSDT')
        self.timeframe = config.get('timeframe', '1h')  # Backward compatibility
        self.progress_callback = None  # Progress callback từ app_handlers
        
        # **RESOURCE MANAGEMENT INTEGRATION** - Sử dụng UnifiedResourceManager
        self.resource_mgr = get_resource_manager()
        self.gpu_info = self.resource_mgr.get_gpu_metrics()
        self.device = self.resource_mgr.get_optimal_device()
        self.use_gpu = self.device != 'cpu'
        
        # **CHÍNH SỬA:** Xác định timeframes theo training_mode
        self.training_mode = config.get('training_mode', 'standard')
        self.timeframes = self._determine_timeframes()
        
        # Trạng thái huấn luyện
        self.state = {
            'step': 0,
            'phase': 'init',
            'status': 'ready',
            'start_time': None,
            'metrics': {},
            'gpu_enabled': self.use_gpu,
            'device_info': self.gpu_info,
            'device': self.device
        }
        
        # Containers - **CHỈNH SỬA:** Hỗ trợ multiple timeframes
        self.raw_data = {}  # Dict[timeframe, DataFrame]
        self.clean_data = {}  # Dict[timeframe, DataFrame]
        self.features = {}  # Dict[timeframe, DataFrame]
        self.models = {}
        self.ensemble = None
        self.results = {}
        
        # Training optimizations
        self.scalers = {}  # Dict[timeframe, scaler] - Cache scalers for reuse
        self.feature_cache = {}  # Cache processed features
          # Khởi tạo modules
        self._init_modules()
        
        # Log GPU/CPU configuration
        device_type = "GPU" if self.use_gpu else "CPU"
        logger.info(f"🚀 UnifiedTrainer initialized with {device_type} acceleration")
        logger.info(f"💾 Max workers: {self.resource_mgr.get_optimal_workers()}")
        if self.use_gpu:
            logger.info(f"🔥 GPU info: {self.gpu_info}")
    def _determine_timeframes(self) -> List[str]:
        """Xác định timeframes theo training_mode"""
        # Mapping từ training_mode sang timeframes
        TIMEFRAME_MAPPINGS = {
            'quick': ['5m', '15m'],  # 7 ngày - nhanh chóng
            'standard': ['15m', '1h', '4h'],  # 30 ngày - chuẩn
            'deep': ['5m', '15m', '30m', '1h', '4h', '12h', '1d'],  # 365 ngày - chuyên sâu
            'test': ['15m']  # Test mode - chỉ 1 timeframe
        }
        
        # Nếu có timeframe cụ thể trong config, ưu tiên timeframe đó
        if self.timeframe and self.training_mode not in TIMEFRAME_MAPPINGS:
            logger.info(f"🎯 Sử dụng timeframe đơn lẻ: {self.timeframe}")
            return [self.timeframe]
        
        # Lấy timeframes theo training_mode
        selected_timeframes = TIMEFRAME_MAPPINGS.get(self.training_mode, TIMEFRAME_MAPPINGS['standard'])
        logger.info(f"🎯 Training mode: {self.training_mode} -> Timeframes: {selected_timeframes}")
        
        return selected_timeframes
    
    def _init_modules(self):
        """Khởi tạo tất cả modules với Resource Manager support"""
        try:
            # Extract training_mode for UnifiedDataLoader
            training_mode = self.config.get('training_mode', 'standard')
              # Initialize data modules
            self.data_loader = UnifiedDataLoader(training_mode)
            self.data_validator = UnifiedDataValidator(ValidationConfig())
            
            # Feature engineering với resource management
            feature_config = dict(self.config)
            feature_config.update({
                'use_gpu': self.use_gpu,
                'device': self.device,
                'max_workers': self.resource_mgr.get_optimal_workers(task_type='feature_engineering')            })
            self.feature_eng = UnifiedFeatureEngineer(feature_config)
            self.feature_engineer = self.feature_eng  # Alias for backward compatibility
            
            # Ensemble system với resource management
            ensemble_config = dict(self.config)
            ensemble_config.update({
                'gpu_available': self.use_gpu,
                'device': self.device,
                'max_workers': self.resource_mgr.get_optimal_workers(task_type='model_training')
            })
            self.ensemble_sys = UnifiedEnsembleManager(ensemble_config)
            
            # Other modules
            self.results_mgr = UnifiedResultsManager()
            self.optimizer = UnifiedOptimizer()
            self.walk_forward = WalkForwardBacktester(self.config)
            self.metrics = UnifiedMetrics()
            
            logger.info("✅ Tất cả modules đã sẵn sàng với Resource Manager optimization")
            
            # Log resource allocation từ resource manager
            logger.info(f"🔧 Resource allocation (from ResourceManager):")
            logger.info(f"   - Device: {self.device}")
            logger.info(f"   - GPU Available: {self.use_gpu}")
            logger.info(f"   - Data loading workers: {self.resource_mgr.get_optimal_workers(task_type='data_loading')}")
            logger.info(f"   - Feature engineering workers: {self.resource_mgr.get_optimal_workers(task_type='feature_engineering')}")
            logger.info(f"   - Model training workers: {self.resource_mgr.get_optimal_workers(task_type='model_training')}")
            logger.info(f"   - Validation workers: {self.resource_mgr.get_optimal_workers(task_type='validation')}")
            
        except Exception as e:
            logger.error(f"❌ Lỗi khởi tạo modules: {e}")
            raise
    
    def train(self, progress_callback=None) -> Dict:
        """🚀 MAIN: Thực hiện 30 bước huấn luyện hoàn chỉnh"""
        if progress_callback:
            self.progress_callback = progress_callback
            
        try:
            self._start()
            
            # PHASE 1: Chuẩn bị dữ liệu (1-8)
            self._prep_data()
            
            # PHASE 2: Kỹ thuật đặc trưng (9-15) 
            self._eng_features()
            
            # PHASE 3: Huấn luyện models (16-22)
            self._train_models()
            
            # PHASE 4: Kiểm định (23-28)
            self._validate()
            
            # PHASE 5: Tối ưu hóa (29-30)
            self._optimize()
            
            return self._finish()
            
        except Exception as e:
            logger.error(f"❌ Lỗi huấn luyện: {e}")
            self._save_emergency()
            raise
    
    def _start(self):
        """Bước 1: Khởi tạo trạng thái, resource, log, validate"""
        self.state['start_time'] = datetime.now()
        self._update(1, 'init', 'Khởi tạo pipeline huấn luyện')
        
        # Initialize training status for ETA tracking
        from ai_optimizer.unified_resource_manager import training_status
        training_status.update({
            'train_running': True,
            'train_start_time': self.state['start_time'].isoformat(),
            'train_progress': 0.0,
            'current_step': 'Khởi tạo',
            'step_number': 1,
            'total_steps': 30
        })        # Validate config
        if not self.symbol or not self.timeframes:
            logger.error("❌ Config thiếu symbol/timeframes!")
            raise ValueError("Config thiếu symbol/timeframes!")
        
        # Log trạng thái khởi tạo
        logger.info(f"🔄 Bắt đầu huấn luyện {self.symbol}@{self.timeframes} - {self.training_mode}")
        logger.info("✅ Modules đã validate xong!")    
        
    def _prep_data(self):
        """PHASE 1: Chuẩn bị dữ liệu với resource manager, cache thông minh, không duplicate"""
        self._update(2, 'data', f'Load dữ liệu market cho {len(self.timeframes)} timeframes (parallel)')
        tasks = [(self.data_loader.load_and_process_data, (self.symbol, tf), {'apply_labels': True, 'force_reload': self.config.get('force_reload', False)}) for tf in self.timeframes]
        futures = self.resource_mgr.submit_tasks(tasks, task_type='io')
        future_to_tf = {futures[i]: self.timeframes[i] for i in range(len(futures))}
        with self.resource_mgr.managed_execution('io'):
            for future in as_completed(futures):
                tf = future_to_tf[future]
                try:
                    raw_data_tf = future.result(timeout=180)
                    if raw_data_tf is not None and not raw_data_tf.empty:
                        self.raw_data[tf] = raw_data_tf
                except Exception as e:
                    logger.error(f"❌ Data loading failed for {tf}: {e}")
        if not self.raw_data:
            raise ValueError(f"❌ Cannot load data for {self.symbol}@{self.timeframes}")
        # Validation & cleaning (cache)
        self._update(3, 'validation', f'Validate và clean dữ liệu cho {len(self.raw_data)} timeframes (parallel)')
        tasks = [(self.data_validator.validate_comprehensive, (df,), {'symbol': self.symbol, 'timeframe': tf, 'validation_types': ['nan_safety', 'timestamp', 'quality']}) for tf, df in self.raw_data.items()]
        futures = self.resource_mgr.submit_tasks(tasks, task_type='processing')
        with self.resource_mgr.managed_execution('processing'):
            for i, future in enumerate(as_completed(futures)):
                tf = list(self.raw_data.keys())[i]
                try:
                    result = future.result(timeout=120)
                    clean_data_tf = result.cleaned_data if hasattr(result, 'cleaned_data') else result
                    if clean_data_tf is not None and not clean_data_tf.empty:
                        self.clean_data[tf] = clean_data_tf
                except Exception as e:
                    logger.error(f"❌ Validation failed for {tf}: {e}")
        if not self.clean_data:
            raise ValueError("❌ Không có dữ liệu sạch nào!")
        self._update(8, 'data', f'Dữ liệu đã sẵn sàng cho {len(self.clean_data)} timeframes')
        for tf, clean_data_tf in self.clean_data.items():
            if 'timestamp' in clean_data_tf.columns:
                clean_data_tf.set_index('timestamp', inplace=True)
        logger.info(f"🎯 Data preparation completed: {len(self.clean_data)} timeframes ready for feature engineering")

    def _eng_features(self):
        """PHASE 2: Feature engineering với cache thông minh, chỉ phối hợp module"""
        self._update(9, 'features', f'Feature engineering cho {len(self.clean_data)} timeframes')
        
        for tf, clean_data_tf in self.clean_data.items():
            cache_key = f"features_{tf}_{len(clean_data_tf)}_{hash(tuple(clean_data_tf.columns))}"
            
            if cache_key in self.feature_cache:
                self.features[tf] = self.feature_cache[cache_key]
                continue
            features_tf = self.feature_eng.engineer_features(
                df=clean_data_tf,
                include_technical=True,
                include_statistical=True,
                include_sentiment=False,
                include_advanced=True
            )
            if features_tf is not None and not features_tf.empty:
                self.features[tf] = features_tf
                self.feature_cache[cache_key] = features_tf
        if not self.features:
            raise ValueError("❌ Feature engineering thất bại cho tất cả timeframes!")
        self._update(15, 'features', f'✅ {len(self.features)} timeframes ready với cached features')

    def _train_models(self):
        """PHASE 3: Huấn luyện models với resource manager, cache thông minh, chỉ phối hợp module"""
        self._update(16, 'train', f'Chuẩn bị training data cho {len(self.features)} timeframes')
        all_trained_models = {}
        base_models = self._get_ai_models_config_gpu()
        selected_models = self._select_optimal_models(base_models)
        def train_timeframe(tf, features_tf):
            cache_key = f"train_data_{tf}_{len(features_tf)}_{hash(str(features_tf.columns.tolist()))}"
            if cache_key in self.feature_cache:
                X_train, y_train, X_val, y_val, feature_cols = self.feature_cache[cache_key]
            else:
                X_train, y_train, X_val, y_val = self._get_train_val_data(features_tf)
                feature_cols = [col for col in features_tf.columns if col not in ['target', 'open_time', 'close_time', 'timestamp']]
                self.feature_cache[cache_key] = (X_train, y_train, X_val, y_val, feature_cols)
            scaler_key = f"{tf}_scaler_{len(feature_cols)}"
            if scaler_key not in self.scalers:
                from sklearn.preprocessing import StandardScaler
                self.scalers[scaler_key] = StandardScaler().fit(X_train)
            X_train_scaled = self.scalers[scaler_key].transform(X_train)
            X_val_scaled = self.scalers[scaler_key].transform(X_val)
            X_train_df = pd.DataFrame(X_train_scaled, columns=feature_cols)
            X_val_df = pd.DataFrame(X_val_scaled, columns=feature_cols)
            y_train_series = pd.Series(y_train)
            y_val_series = pd.Series(y_val)
            trained_models_tf = {}
            for model_name, model_config in selected_models.items():
                # Truyền device nếu model_type hỗ trợ, tránh lỗi với model không nhận device
                model_type = model_config['type']
                model_params = {
                    'model_name': model_name,
                    'model_type': model_type,
                    'params': model_config['params'],
                    'X_train': X_train_df,
                    'y_train': y_train_series,
                    'X_test': X_val_df,
                    'y_test': y_val_series,
                    'timeout': 600,
                    'gpu_available': self.use_gpu,
                    'resource_manager': self.resource_mgr
                }
                # Chỉ truyền device cho các model hỗ trợ (xgboost, lightgbm, catboost, neural_network)
                if model_type in ['xgboost', 'lightgbm', 'catboost', 'neural_network']:
                    model_params['device'] = self.device
                result = create_individual_model(**model_params)
                if result:
                    trained_models_tf[model_name] = result
            return tf, trained_models_tf
        # Tối ưu số lượng worker: lấy tối đa từ resource manager, không giới hạn nhỏ nếu máy còn dư tài nguyên
        max_workers = self.resource_mgr.get_optimal_workers(task_type='model_training')
        if max_workers < 1:
            max_workers = 1
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [executor.submit(train_timeframe, tf, features_tf) for tf, features_tf in self.features.items()]
            for future in as_completed(futures):
                tf, trained_models_tf = future.result(timeout=1800)
                if trained_models_tf:
                    all_trained_models[tf] = trained_models_tf
        # Ensemble
        self._update(19, 'train', f'Creating ensembles cho {len(all_trained_models)} timeframes')
        final_ensembles = {}
        for tf, trained_models_tf in all_trained_models.items():
            if len(trained_models_tf) >= 2:
                ensemble_result = self.ensemble_sys.create_advanced_ensemble(
                    all_results=trained_models_tf,
                    ensemble_method='voting',
                    optimization_metric='f1_score'
                )
                if ensemble_result:
                    final_ensembles[tf] = ensemble_result
        self.models = final_ensembles
        if not self.models:
            raise ValueError("❌ Không có model nào được huấn luyện thành công!")
        self._update(22, 'train', f'Training hoàn thành cho {len(final_ensembles)} timeframes')

    def _validate(self):
        """PHASE 4: Kiểm định toàn diện sử dụng modules có sẵn (Steps 23-28)"""
        
        # Step 23: Chuẩn bị validation data cho tất cả timeframes
        self._update(23, 'validate', f'Chuẩn bị validation data cho {len(self.models)} timeframes')
        
        validation_results = {}
        
        # **ENHANCED VALIDATION:** Sử dụng UnifiedMetrics và WalkForwardBacktester
        for tf, ensemble_model in self.models.items():
            logger.info(f"🔍 Comprehensive validation cho {tf}")
            
            try:
                # Lấy features cho timeframe này
                features_tf = self.features.get(tf)
                if features_tf is None or features_tf.empty:
                    logger.warning(f"⚠️ No features for validation of {tf}")
                    continue
                
                # Chuẩn bị test data với intelligent caching
                cache_key = f"val_data_{tf}_{len(features_tf)}"
                if cache_key in self.feature_cache:
                    logger.info(f"🚀 Using cached validation data for {tf}")
                    X_train, y_train, X_val, y_val = self.feature_cache[cache_key]
                else:
                    X_train, y_train, X_val, y_val = self._get_train_val_data(features_tf)
                    self.feature_cache[cache_key] = (X_train, y_train, X_val, y_val)
                
                if X_val is None or len(X_val) == 0:
                    logger.warning(f"⚠️ No validation data for {tf}")
                    continue
                
                # Step 24: Cross-validation sử dụng UnifiedMetrics
                self._update(24, 'validate', f'Cross-validation cho {tf} sử dụng UnifiedMetrics')
                
                try:
                    if hasattr(ensemble_model, 'predict'):
                        # Scale validation data using cached scaler
                        feature_cols = [col for col in features_tf.columns 
                                      if col not in ['target', 'open_time', 'close_time', 'timestamp'] 
                                      and features_tf[col].dtype in ['int64', 'float64', 'int32', 'float32']]
                        
                        # Use cached scaler để tránh duplicate computation
                        scaler_key = f"{tf}_scaler_{len(feature_cols)}"
                        if scaler_key in self.scalers:
                            scaler = self.scalers[scaler_key]
                            X_val_scaled = scaler.transform(X_val)
                        else:
                            # Fallback to basic scaling
                            from sklearn.preprocessing import StandardScaler
                            scaler = StandardScaler()
                            scaler.fit(X_train)
                            X_val_scaled = scaler.transform(X_val)
                        
                        # **ENHANCED:** Get predictions với confidence scores
                        y_pred = ensemble_model.predict(X_val_scaled)
                        
                        # Get probability predictions nếu có
                        if hasattr(ensemble_model, 'predict_proba'):
                            y_pred_proba = ensemble_model.predict_proba(X_val_scaled)
                        else:
                            y_pred_proba = None
                          # **COMPREHENSIVE METRICS:** Sử dụng UnifiedMetrics
                        comprehensive_metrics = calculate_metrics_from_predictions(
                            y_true=y_val,
                            y_pred=y_pred
                        )
                        
                        # Step 25: Walk-forward validation sử dụng WalkForwardBacktester
                        self._update(25, 'validate', f'Walk-forward validation cho {tf}')
                        
                        try:
                            # Prepare data for walk-forward validation
                            backtest_data = features_tf.copy()
                            
                            # Ensure proper datetime index
                            if 'timestamp' in backtest_data.columns:
                                backtest_data.set_index('timestamp', inplace=True)
                            
                            # Run walk-forward backtest
                            walk_forward_results = self.walk_forward.run_backtest(
                                data=backtest_data,
                                model=ensemble_model,
                                scaler=scaler,
                                feature_cols=feature_cols
                            )
                            
                            logger.info(f"✅ Walk-forward validation completed for {tf}")
                            
                        except Exception as wf_error:
                            logger.warning(f"⚠️ Walk-forward validation failed for {tf}: {wf_error}")
                            walk_forward_results = {'error': str(wf_error)}
                        
                        # Step 26-27: Out-of-sample testing và statistical validation  
                        self._update(26, 'validate', f'Out-of-sample testing cho {tf}')
                        self._update(27, 'validate', f'Statistical validation cho {tf}')
                        
                        # **ADDITIONAL STATISTICAL TESTS**
                        try:
                            # Performance consistency check
                            from sklearn.model_selection import cross_val_score
                            if len(X_train) > 100:  # Enough data for CV
                                cv_scores = cross_val_score(ensemble_model, X_train, y_train, cv=3, scoring='f1_weighted')
                                cv_mean = cv_scores.mean()
                                cv_std = cv_scores.std()
                                
                                statistical_validation = {
                                    'cv_scores': cv_scores.tolist(),
                                    'cv_mean': cv_mean,
                                    'cv_std': cv_std,
                                    'cv_stability': cv_std < 0.1  # Low variance indicates stable performance
                                }
                            else:
                                statistical_validation = {'note': 'Insufficient data for cross-validation'}
                                
                        except Exception as stat_error:
                            logger.warning(f"⚠️ Statistical validation failed for {tf}: {stat_error}")
                            statistical_validation = {'error': str(stat_error)}
                        
                        # **COMBINE ALL VALIDATION RESULTS**
                        validation_results[tf] = {
                            **comprehensive_metrics,
                            'walk_forward': walk_forward_results,
                            'statistical': statistical_validation,
                            'validation_samples': len(X_val),
                            'feature_count': len(feature_cols),
                            'ensemble_type': getattr(ensemble_model, 'type', 'unknown')
                        }
                        
                        # Log summary metrics
                        accuracy = comprehensive_metrics.get('accuracy', 0.0)
                        f1 = comprehensive_metrics.get('f1_score', 0.0)
                        logger.info(f"✅ {tf} comprehensive validation - Accuracy: {accuracy:.4f}, F1: {f1:.4f}")
                        
                    else:
                        logger.warning(f"⚠️ Model for {tf} has no predict method")
                        validation_results[tf] = {'error': 'No predict method'}
                        
                except Exception as val_error:
                    logger.error(f"❌ Validation error for {tf}: {val_error}")
                    validation_results[tf] = {'error': str(val_error)}
                
            except Exception as e:
                logger.error(f"❌ Validation setup failed for {tf}: {e}")
                validation_results[tf] = {'error': str(e)}
        
        # Step 28: Tổng hợp validation results
        self._update(28, 'validate', f'Tổng hợp comprehensive validation cho {len(validation_results)} timeframes')
        
        # **ADVANCED AGGREGATION:** Tính toán metrics tổng hợp
        if validation_results:
            valid_results = {tf: res for tf, res in validation_results.items() if 'error' not in res}
            
            if valid_results:
                # Calculate weighted averages based on validation samples
                total_samples = sum(res.get('validation_samples', 0) for res in valid_results.values())
                
                if total_samples > 0:
                    weighted_avg_accuracy = sum(
                        res.get('accuracy', 0.0) * res.get('validation_samples', 0) 
                        for res in valid_results.values()
                    ) / total_samples
                    
                    weighted_avg_f1 = sum(
                        res.get('f1_score', 0.0) * res.get('validation_samples', 0) 
                        for res in valid_results.values()
                    ) / total_samples
                    
                    weighted_avg_precision = sum(
                        res.get('precision', 0.0) * res.get('validation_samples', 0) 
                        for res in valid_results.values()
                    ) / total_samples
                    
                    weighted_avg_recall = sum(
                        res.get('recall', 0.0) * res.get('validation_samples', 0) 
                        for res in valid_results.values()
                    ) / total_samples
                else:
                    # Simple average fallback
                    weighted_avg_accuracy = sum(res.get('accuracy', 0.0) for res in valid_results.values()) / len(valid_results)
                    weighted_avg_f1 = sum(res.get('f1_score', 0.0) for res in valid_results.values()) / len(valid_results)
                    weighted_avg_precision = sum(res.get('precision', 0.0) for res in valid_results.values()) / len(valid_results)
                    weighted_avg_recall = sum(res.get('recall', 0.0) for res in valid_results.values()) / len(valid_results)
                
                # Performance consistency analysis
                accuracies = [res.get('accuracy', 0.0) for res in valid_results.values()]
                performance_consistency = {
                    'accuracy_std': np.std(accuracies),
                    'accuracy_range': max(accuracies) - min(accuracies),
                    'consistent_performance': np.std(accuracies) < 0.05  # Less than 5% std deviation
                }
                
                logger.info(f"📊 Comprehensive validation metrics:")
                logger.info(f"   Weighted Accuracy: {weighted_avg_accuracy:.4f}")
                logger.info(f"   Weighted F1 Score: {weighted_avg_f1:.4f}")
                logger.info(f"   Weighted Precision: {weighted_avg_precision:.4f}")
                logger.info(f"   Weighted Recall: {weighted_avg_recall:.4f}")
                logger.info(f"   Performance Consistency: {performance_consistency['consistent_performance']}")
                
            else:
                weighted_avg_accuracy = weighted_avg_f1 = weighted_avg_precision = weighted_avg_recall = 0.0
                performance_consistency = {'error': 'No valid results'}
                logger.warning("⚠️ No valid validation results")
        else:
            weighted_avg_accuracy = weighted_avg_f1 = weighted_avg_precision = weighted_avg_recall = 0.0
            performance_consistency = {'error': 'No validation results'}
            logger.warning("⚠️ No validation results")
        
        # **ENHANCED RESULTS STORAGE**
        self.results['validation'] = {
            'multi_timeframe_results': validation_results,
            'weighted_accuracy': weighted_avg_accuracy,
            'weighted_f1_score': weighted_avg_f1,
            'weighted_precision': weighted_avg_precision,
            'weighted_recall': weighted_avg_recall,
            'performance_consistency': performance_consistency,
            'total_timeframes_validated': len(validation_results),
            'successful_validations': len([res for res in validation_results.values() if 'error' not in res]),
            'validation_summary': {
                'best_timeframe': max(valid_results.keys(), key=lambda tf: valid_results[tf].get('f1_score', 0)) if valid_results else None,
                'worst_timeframe': min(valid_results.keys(), key=lambda tf: valid_results[tf].get('f1_score', 0)) if valid_results else None,
                'average_features_per_tf': sum(res.get('feature_count', 0) for res in valid_results.values()) / len(valid_results) if valid_results else 0
            }
        }
        
        logger.info(f"✅ Comprehensive validation hoàn thành cho {len(validation_results)} timeframes với weighted metrics")
        logger.info(f"🏆 Best performing timeframe: {self.results['validation']['validation_summary']['best_timeframe']}")
    
    def _optimize(self):
        """PHASE 5: Tối ưu hóa toàn diện sử dụng UnifiedOptimizer (Steps 29-30)"""
        
        # Step 29: Tối ưu cấu hình sử dụng UnifiedOptimizer
        self._update(29, 'optimize', 'Tối ưu cấu hình model với UnifiedOptimizer')
        
        try:
            # **ENHANCED OPTIMIZATION:** Sử dụng UnifiedOptimizer với validation results
            optimization_data = {
                'models': self.models,
                'validation_results': self.results.get('validation', {}),
                'features': self.features,
                'config': self.config,
                'system_info': {
                    'gpu_available': self.use_gpu,
                    'device': self.device,
                    'memory_usage': self._get_memory_usage()
                }
            }
            
            # Get optimal configuration from UnifiedOptimizer
            optimal_config = self.optimizer.recommend_configuration(
                training_data=optimization_data,
                optimization_targets=['accuracy', 'speed', 'memory_efficiency']
            )
            
            logger.info(f"🎯 UnifiedOptimizer recommendations:")
            if optimal_config:
                for key, value in optimal_config.items():
                    logger.info(f"   - {key}: {value}")
            else:
                logger.warning("⚠️ No optimization recommendations generated")
                optimal_config = {'status': 'no_recommendations'}
            
        except Exception as opt_error:
            logger.error(f"❌ UnifiedOptimizer failed: {opt_error}")
            optimal_config = {'error': str(opt_error)}
        
        # Step 30: Lưu model cuối cùng cho tất cả timeframes với optimizations
        self._update(30, 'optimize', f'Lưu optimized models cho {len(self.models)} timeframes')
        
        # **ENHANCED MODEL SAVING:** Include optimization results
        try:
            # Save với optimization metadata
            self._save_multi_timeframe_model_enhanced(optimal_config)
            
            # **RESULTS MANAGER INTEGRATION:** Use UnifiedResultsManager để lưu kết quả
            results_summary = {
                'training_summary': {
                    'symbol': self.symbol,
                    'timeframes': self.timeframes,
                    'training_mode': self.training_mode,
                    'successful_timeframes': list(self.models.keys()),
                    'total_duration': self.state.get('duration', 'N/A'),
                    'device_used': 'GPU' if self.use_gpu else 'CPU'
                },
                'performance_summary': self.results.get('validation', {}),
                'optimization_results': optimal_config,
                'system_performance': {
                    'final_memory_usage': self._get_memory_usage(),
                    'gpu_info': self.gpu_info if self.use_gpu else None,
                    'resource_efficiency': self.resource_mgr.get_resource_efficiency()
                }
            }
            
            # Save comprehensive results using ResultsManager
            self.results_mgr.save_training_results(
                results=results_summary,
                model_type='multi_timeframe_ensemble',
                symbol=self.symbol,
                timestamp=datetime.now()
            )
            
            logger.info("✅ Comprehensive results saved via UnifiedResultsManager")
            
        except Exception as save_error:
            logger.error(f"❌ Enhanced model saving failed: {save_error}")
            # Fallback to basic saving
            self._save_multi_timeframe_model()
        
        # Store optimization results
        self.results['optimization'] = {
            'optimal_config': optimal_config,
            'optimization_applied': True,
            'optimizer_used': 'UnifiedOptimizer'
        }
        
        logger.info(f"✅ Multi-timeframe optimization completed with {len(self.models)} timeframes")
        
    def _save_multi_timeframe_model_enhanced(self, optimal_config: Dict):
        """Enhanced model saving với optimization metadata"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        # Tính toán metrics tổng hợp từ validation results
        validation_results = self.results.get('validation', {})
        all_timeframe_results = []
        
        for tf, ensemble_model in self.models.items():
            # Get validation metrics for this timeframe
            tf_validation = validation_results.get('multi_timeframe_results', {}).get(tf, {})
            
            tf_result = {
                'timeframe': tf,
                'type': getattr(ensemble_model, 'type', 'ensemble'),
                'accuracy': tf_validation.get('accuracy', 0.0),
                'f1_score': tf_validation.get('f1_score', 0.0),
                'precision': tf_validation.get('precision', 0.0),
                'recall': tf_validation.get('recall', 0.0),
                'feature_count': tf_validation.get('feature_count', 0),
                'validation_samples': tf_validation.get('validation_samples', 0),
                'model_count': getattr(ensemble_model, 'model_count', 0),
                'training_time': getattr(ensemble_model, 'training_time', 0.0)
            }
            all_timeframe_results.append(tf_result)
        
        # Calculate weighted averages
        total_samples = sum(result['validation_samples'] for result in all_timeframe_results)
        if total_samples > 0:
            weighted_accuracy = sum(
                result['accuracy'] * result['validation_samples'] 
                for result in all_timeframe_results
            ) / total_samples
            weighted_f1 = sum(
                result['f1_score'] * result['validation_samples'] 
                for result in all_timeframe_results
            ) / total_samples
        else:
            weighted_accuracy = sum(result['accuracy'] for result in all_timeframe_results) / len(all_timeframe_results) if all_timeframe_results else 0.0
            weighted_f1 = sum(result['f1_score'] for result in all_timeframe_results) / len(all_timeframe_results) if all_timeframe_results else 0.0
        
        # Enhanced model data với optimization info
        device_suffix = "gpu" if self.use_gpu else "cpu"
        model_path = f"models/{self.symbol}_multi_timeframe_optimized_{device_suffix}_{timestamp}.pkl.gz"
        os.makedirs('models', exist_ok=True)
        
        enhanced_model_data = {
            'models': self.models,
            'features': self.features,
            'scalers': self.scalers,  # Include scalers for prediction
            'config': self.config,
            'timeframes': self.timeframes,
            'training_mode': self.training_mode,
            'optimization_config': optimal_config,
            'validation_results': validation_results,
            'performance_metrics': {
                'weighted_accuracy': weighted_accuracy,
                'weighted_f1_score': weighted_f1,
                'timeframe_results': all_timeframe_results,
                'performance_consistency': validation_results.get('performance_consistency', {})
            },
            'system_info': {
                'device_used': 'GPU' if self.use_gpu else 'CPU',
                'gpu_info': self.gpu_info if self.use_gpu else None,
                'training_duration': self.state.get('duration', 'N/A'),
                'resource_efficiency': self.resource_mgr.get_resource_efficiency()
            },
            'metadata': {
                'version': '2.0',
                'optimized': True,
                'timestamp': datetime.now().isoformat(),
                'feature_cache_size': len(self.feature_cache),
                'total_features': sum(len(df.columns) for df in self.features.values()),
                'total_training_samples': sum(len(df) for df in self.clean_data.values())
            }
        }
        
        try:
            with gzip.open(model_path, 'wb') as f:
                pickle.dump(enhanced_model_data, f)
            logger.info(f"💾 Enhanced multi-timeframe model saved: {model_path}")
            
            # Also save a lightweight version for quick loading
            lightweight_path = f"models/{self.symbol}_lightweight_{device_suffix}_{timestamp}.pkl"
            lightweight_data = {
                'models': self.models,
                'scalers': self.scalers,
                'timeframes': self.timeframes,
                'feature_columns': {tf: [col for col in df.columns if col != 'target'] 
                                 for tf, df in self.features.items()},
                'performance_summary': {
                    'weighted_accuracy': weighted_accuracy,
                    'weighted_f1_score': weighted_f1
                },
                'metadata': enhanced_model_data['metadata']
            }
            
            with open(lightweight_path, 'wb') as f:
                pickle.dump(lightweight_data, f)
            logger.info(f"💾 Lightweight model saved: {lightweight_path}")
            
        except Exception as e:
            logger.warning(f"⚠️ Could not save enhanced model: {e}")
            # Fallback to basic saving
            return self._save_multi_timeframe_model()
        
        # Update results with enhanced info
        self.results['multi_timeframe'] = {
            'total_timeframes': len(self.models),
            'successful_timeframes': list(self.models.keys()),
            'weighted_accuracy': weighted_accuracy,
            'weighted_f1_score': weighted_f1,
            'timeframe_results': all_timeframe_results,
            'model_path': model_path,
            'lightweight_path': lightweight_path,
            'optimization_applied': True
        }
    
    def _clean_data(self, raw_data: pd.DataFrame) -> pd.DataFrame:
        """Clean và preprocess raw data"""
        try:
            if raw_data is None or raw_data.empty:
                return pd.DataFrame()
            
            # Basic cleaning
            cleaned = raw_data.copy()
            
            # Remove duplicates
            cleaned = cleaned.drop_duplicates()
            
            # Handle missing values
            cleaned = cleaned.fillna(method='ffill').fillna(method='bfill')
            
            # Ensure required columns exist
            required_cols = ['open', 'high', 'low', 'close', 'volume']
            missing_cols = [col for col in required_cols if col not in cleaned.columns]
            if missing_cols:
                logger.warning(f"Missing required columns: {missing_cols}")
                return pd.DataFrame()
            
            # Basic data validation
            if (cleaned[required_cols] <= 0).any().any():
                logger.warning("Found non-positive values in OHLCV data")
                cleaned[required_cols] = cleaned[required_cols].clip(lower=1e-8)
            
            return cleaned
            
        except Exception as e:
            logger.error(f"Data cleaning failed: {e}")
            return pd.DataFrame()
    def _update(self, step: int, phase: str, desc: str):
        """Cập nhật trạng thái với ETA tracking"""
        self.state.update({
            'step': step,
            'phase': phase,
            'status': 'running',
            'description': desc
        })
        
        progress = (step / 30) * 100
        
        # Update training status for ETA tracking
        from ai_optimizer.unified_resource_manager import training_status
        training_status.update({
            'train_progress': progress / 100.0,
            'current_step': desc,
            'step_number': step,
            'total_steps': 30
        })
        
        # Tính ETA thông minh
        eta_info = self.resource_mgr.get_training_eta(
            step_name=desc,
            step_number=step,
            total_steps=30
        )
        
        eta_str = eta_info.get('eta_formatted', 'N/A')
        self.state['eta'] = eta_info
        
        logger.info(f"📊 Step {step}/30 ({progress:.1f}%) - {phase}: {desc} | ⏱️ ETA: {eta_str}")
        
        # Gọi progress callback nếu có
        if self.progress_callback:
            try:
                callback_info = {
                    'current_model': f"Step {step}: {desc}",
                    'step': step,
                    'total_steps': 30,
                    'phase': phase,
                    'eta_info': eta_info
                }
                self.progress_callback(progress / 100.0, callback_info)
            except Exception as e:
                logger.warning(f"Progress callback error: {e}")
    
    def _finish(self) -> Dict:
        """Hoàn thành huấn luyện cho multiple timeframes với GPU stats"""        # Cleanup resources trước khi finish
        self._cleanup_resources()
        
        self.state.update({
            'status': 'completed',
            'end_time': datetime.now(),
            'duration': str(datetime.now() - self.state['start_time'])
        })
        
        # Cập nhật training status hoàn thành
        training_status.update({
            'training': False,
            'train_running': False,
            'step_number': 30,
            'train_progress': 1.0,
            'current_step': 'Hoàn thành!'
        })
        
        # Get final memory usage
        final_memory = self._get_memory_usage()
        
        # Tính toán metrics tổng hợp
        all_timeframe_results = []
        total_accuracy = 0
        total_f1 = 0
        successful_timeframes = list(self.models.keys())
        
        for tf in successful_timeframes:
            # Lấy metrics từ validation results nếu có
            validation_results = self.results.get('validation', {}).get('multi_timeframe_results', {})
            tf_metrics = validation_results.get(tf, {})
            
            tf_result = {
                'timeframe': tf,
                'type': 'ensemble',
                'accuracy': tf_metrics.get('accuracy', 0.0),
                'f1_score': tf_metrics.get('f1_score', 0.0),
                'precision': tf_metrics.get('precision', 0.0),
                'recall': tf_metrics.get('recall', 0.0),
                'validation_samples': tf_metrics.get('validation_samples', 0)
            }
            all_timeframe_results.append(tf_result)
            total_accuracy += tf_result['accuracy']
            total_f1 += tf_result['f1_score']
        
        # Tính average metrics
        avg_accuracy = total_accuracy / len(successful_timeframes) if successful_timeframes else 0.0
        avg_f1 = total_f1 / len(successful_timeframes) if successful_timeframes else 0.0
        
        # Tạo báo cáo cuối cùng với GPU info
        final_report = {
            'type': 'multi_timeframe_ensemble',
            'summary': {
                'symbol': self.symbol,
                'training_mode': self.training_mode,
                'timeframes': self.timeframes,
                'successful_timeframes': successful_timeframes,
                'duration': self.state['duration'],
                'total_steps': 30,
                'status': 'success',
                'device_used': 'GPU' if self.use_gpu else 'CPU',
                'gpu_info': self.gpu_info if self.use_gpu else None
            },
            'performance': {
                'average_accuracy': avg_accuracy,
                'average_f1_score': avg_f1,
                'timeframe_results': all_timeframe_results,
                'total_timeframes_trained': len(self.models)
            },
            'data_info': {
                'total_timeframes_loaded': len(self.clean_data),
                'features_per_timeframe': {tf: len(features_df.columns) - 1 
                                         for tf, features_df in self.features.items()}
            },
            'system_info': {                'device_config': self.gpu_info,
                'threading_workers': self.resource_mgr.get_optimal_workers(),
                'final_memory_usage': final_memory,
                'gpu_enabled': self.use_gpu
            },
            'validation': self.results.get('validation', {}),
            'state': self.state
        }
        
        # Lưu báo cáo
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        device_suffix = "gpu" if self.use_gpu else "cpu"
        report_path = f"pipeline_results/multi_timeframe_report_{self.symbol}_{device_suffix}_{timestamp}.json"
        
        os.makedirs('pipeline_results', exist_ok=True)
        import json
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(final_report, f, indent=2, ensure_ascii=False, default=str)
          # Enhanced logging
        device_type = "GPU" if self.use_gpu else "CPU"
        logger.info(f"🎉 Multi-timeframe {device_type} training hoàn thành!")
        logger.info(f"📊 Timeframes trained: {len(self.models)}/{len(self.timeframes)}")
        logger.info(f"📈 Average accuracy: {avg_accuracy:.4f}")
        logger.info(f"🔥 Device used: {device_type}")
        if self.use_gpu and self.gpu_info:
            for i, gpu in enumerate(self.gpu_info):
                logger.info(f"   GPU {i}: {gpu.get('name', 'Unknown')} ({gpu.get('memory_total', 0):.1f}GB)")
        logger.info(f"🧵 Max workers used: {self.resource_mgr.get_optimal_workers()}")
        logger.info(f"📋 Báo cáo: {report_path}")
        
        return final_report
    
    def predict(self, data: pd.DataFrame, timeframe: str = None) -> Dict[str, np.ndarray]:
        """Dự đoán với multi-timeframe models"""
        if not self.models:
            raise ValueError("❌ Models chưa được train!")
        
        # Nếu chỉ định timeframe cụ thể
        if timeframe:
            if timeframe not in self.models:
                raise ValueError(f"❌ Timeframe {timeframe} chưa được train!")
            
            # Predict cho timeframe cụ thể
            ensemble_model = self.models[timeframe]            
            features_tf = self.features.get(timeframe)
            
            if features_tf is None:
                raise ValueError(f"❌ Không có features cho {timeframe}")
            
            # Engineer features cho input data
            input_features = self.feature_eng.engineer_features(
                df=data,
                include_technical=True,
                include_statistical=True,
                include_sentiment=False,
                include_advanced=True
            )
            
            # Scale và predict
            feature_cols = [col for col in input_features.columns 
                          if col not in ['target', 'open_time', 'close_time', 'timestamp']]
            X = input_features[feature_cols].fillna(0).values
            
            # Sử dụng scaler cho timeframe này
            scaler_key = f"{timeframe}_scaler"
            if scaler_key in self.scalers:
                X_scaled = self.scalers[scaler_key].transform(X)
            else:
                logger.warning(f"No scaler found for {timeframe}, using raw features")
                X_scaled = X
            
            predictions = ensemble_model.predict(X_scaled)
            return {timeframe: predictions}
        
        # Predict cho tất cả timeframes
        all_predictions = {}
        for tf, ensemble_model in self.models.items():
            try:                # Engineer features cho input data
                input_features = self.feature_eng.engineer_features(
                    df=data,
                    include_technical=True,
                    include_statistical=True,
                    include_sentiment=False,
                    include_advanced=True
                )
                
                # Scale và predict
                feature_cols = [col for col in input_features.columns 
                              if col not in ['target', 'open_time', 'close_time', 'timestamp']]
                X = input_features[feature_cols].fillna(0).values
                
                # Sử dụng scaler cho timeframe này
                scaler_key = f"{tf}_scaler"
                if scaler_key in self.scalers:
                    X_scaled = self.scalers[scaler_key].transform(X)
                else:
                    logger.warning(f"No scaler found for {tf}, using raw features")
                    X_scaled = X
                
                predictions = ensemble_model.predict(X_scaled)
                all_predictions[tf] = predictions
                
            except Exception as e:
                logger.error(f"❌ Prediction failed for {tf}: {e}")
                all_predictions[tf] = np.array([])
        
        return all_predictions
    def get_progress(self) -> Dict:
        """Lấy tiến độ hiện tại với ETA chi tiết"""
        if self.state['start_time']:
            elapsed = datetime.now() - self.state['start_time']
            progress = (self.state['step'] / 30) * 100
        else:
            elapsed = 0
            progress = 0
        
        # Lấy ETA thông tin
        eta_info = self.resource_mgr.get_training_eta(
            step_name=self.state.get('description', ''),
            step_number=self.state['step'],
            total_steps=30
        )
        
        return {
            'step': self.state['step'],
            'total_steps': 30,
            'progress': f"{progress:.1f}%",
            'phase': self.state['phase'],
            'status': self.state['status'],
            'elapsed': str(elapsed),
            'description': self.state.get('description', 'N/A'),
            'eta': eta_info.get('eta_formatted', 'N/A'),
            'eta_seconds': eta_info.get('eta_seconds', 0),
            'eta_completion': eta_info.get('completion_time', 'N/A'),
            'speed': f"{eta_info.get('steps_per_second', 0):.3f} steps/sec"
        }
    
    def get_eta_display(self) -> str:
        """Hiển thị ETA dạng user-friendly"""
        progress = self.get_progress()
        
        if progress['status'] == 'completed':
            return "✅ Hoàn thành!"
        elif progress['status'] == 'failed':
            return "❌ Thất bại"
        elif progress['eta_seconds'] > 0:
            eta_mins = progress['eta_seconds'] // 60
            eta_secs = progress['eta_seconds'] % 60
            
            if eta_mins > 60:
                eta_hours = eta_mins // 60
                eta_mins = eta_mins % 60
                return f"⏱️ Còn ~{eta_hours}h{eta_mins}m - {progress['description']}"
            elif eta_mins > 0:
                return f"⏱️ Còn ~{eta_mins}m{eta_secs}s - {progress['description']}"
            else:
                return f"⏱️ Còn ~{eta_secs}s - {progress['description']}"
        else:
            return f"🔄 {progress['description']}"
    
    def print_progress_bar(self):
        """In progress bar với ETA"""
        progress = self.get_progress()
        step = progress['step']
        total = progress['total_steps']
        percent = float(progress['progress'].replace('%', ''))
        
        # Tạo progress bar
        bar_length = 30
        filled_length = int(bar_length * percent / 100)
        bar = '█' * filled_length + '░' * (bar_length - filled_length)        
        eta_display = self.get_eta_display()
        
        print(f"\r🚀 [{bar}] {percent:.1f}% ({step}/{total}) | {eta_display}", end='', flush=True)
    
    def get_summary(self) -> Dict:
        """Lấy tổng quan multi-timeframe model"""
        if not self.models:
            return {"status": "❌ Models chưa train"}
        
        # Tính toán tổng quan
        successful_timeframes = list(self.models.keys())
        total_timeframes = len(self.timeframes)
        
        # Lấy validation metrics nếu có
        validation_results = self.results.get('validation', {})
        avg_accuracy = validation_results.get('average_accuracy', 0.0)
        avg_f1 = validation_results.get('average_f1_score', 0.0)
        
        return {
            'model_type': 'MultiTimeframeEnsemble',
            'symbol': self.symbol,
            'training_mode': self.training_mode,
            'timeframes': self.timeframes,
            'successful_timeframes': successful_timeframes,
            'status': self.state['status'],
            'success_rate': f"{len(successful_timeframes)}/{total_timeframes}",
            'average_accuracy': avg_accuracy,
            'average_f1_score': avg_f1,
            'features_per_timeframe': {tf: len(features_df.columns) - 1 
                                     for tf, features_df in self.features.items()},
            'training_samples_per_timeframe': {tf: len(clean_df) 
                                             for tf, clean_df in self.clean_data.items()},
            'performance': self.results,
            'last_training': self.state.get('start_time')
        }
    
    def _get_ai_models_config(self):
        """Get configuration for all AI models"""
        return {
            'RandomForest': {
                'type': 'random_forest',
                'params': {
                    'n_estimators': 200, 'max_depth': 15, 'min_samples_split': 5,
                    'min_samples_leaf': 2, 'max_features': 'sqrt', 'random_state': 42, 
                    'n_jobs': -1, 'class_weight': 'balanced'
                }
            },
            'ExtraTrees': {
                'type': 'extra_trees',
                'params': {
                    'n_estimators': 200, 'max_depth': 15, 'min_samples_split': 5,
                    'min_samples_leaf': 2, 'max_features': 'sqrt', 'random_state': 42,
                    'n_jobs': -1, 'class_weight': 'balanced'
                }
            },
            'GradientBoosting': {
                'type': 'gradient_boosting',
                'params': {
                    'n_estimators': 150, 'max_depth': 8, 'learning_rate': 0.1,
                    'subsample': 0.8, 'random_state': 42
                }
            },
            'XGBoost': {
                'type': 'xgboost', 
                'params': {
                    'n_estimators': 200, 'max_depth': 8, 'learning_rate': 0.1,
                    'subsample': 0.8, 'colsample_bytree': 0.8, 'random_state': 42,
                    'n_jobs': -1, 'eval_metric': 'logloss', 'use_label_encoder': False
                }
            },
            'LightGBM': {
                'type': 'lightgbm',
                'params': {
                    'n_estimators': 200, 'max_depth': 8, 'learning_rate': 0.1,
                    'subsample': 0.8, 'colsample_bytree': 0.8, 'random_state': 42,
                    'n_jobs': -1, 'class_weight': 'balanced', 'verbosity': -1
                }
            },
            'CatBoost': {
                'type': 'catboost',
                'params': {
                    'iterations': 200, 'depth': 8, 'learning_rate': 0.1,
                    'random_state': 42, 'verbose': False, 'thread_count': -1,
                    'class_weights': [1, 1], 'eval_metric': 'Accuracy'
                }
            },
            'LogisticRegression': {
                'type': 'logistic_regression',
                'params': {
                    'C': 1.0, 'penalty': 'l2', 'solver': 'liblinear',
                    'random_state': 42, 'max_iter': 1000, 'class_weight': 'balanced'
                }
            },
            'SVM': {
                'type': 'svm',
                'params': {
                    'C': 1.0, 'kernel': 'rbf', 'probability': True,
                    'random_state': 42, 'class_weight': 'balanced'
                }
            },
            'NeuralNetwork': {
                'type': 'neural_network',
                'params': {
                    'hidden_layer_sizes': (100, 50), 'alpha': 0.001,
                    'random_state': 42, 'max_iter': 500
                }
            },
            'AdaBoost': {
                'type': 'adaboost',
                'params': {
                    'n_estimators': 100, 'learning_rate': 1.0,
                    'random_state': 42
                }
            }
        }
    
    def _get_ai_models_config_gpu(self):
        """Get GPU-optimized configuration for all AI models"""
        base_config = self._get_ai_models_config()
        
        if self.use_gpu:
            # GPU optimizations
            logger.info("🔥 Applying GPU optimizations to model configs")
            
            # XGBoost GPU optimization
            if 'XGBoost' in base_config:
                base_config['XGBoost']['params'].update({
                    'tree_method': 'gpu_hist',
                    'gpu_id': 0,
                    'n_estimators': min(300, base_config['XGBoost']['params'].get('n_estimators', 200) * 1.5),
                })
                logger.info("✅ XGBoost GPU acceleration enabled")
            
            # LightGBM GPU optimization
            if 'LightGBM' in base_config:
                base_config['LightGBM']['params'].update({
                    'device': 'gpu',
                    'gpu_platform_id': 0,
                    'gpu_device_id': 0,
                    'n_estimators': min(300, base_config['LightGBM']['params'].get('n_estimators', 200) * 1.5),
                })
                logger.info("✅ LightGBM GPU acceleration enabled")
            
            # CatBoost GPU optimization
            if 'CatBoost' in base_config:
                base_config['CatBoost']['params'].update({
                    'task_type': 'GPU',
                    'devices': '0',
                    'iterations': min(300, base_config['CatBoost']['params'].get('iterations', 200) * 1.5),
                })
                logger.info("✅ CatBoost GPU acceleration enabled")
            
            # Neural Network optimizations
            if 'NeuralNetwork' in base_config:
                base_config['NeuralNetwork']['params'].update({
                    'hidden_layer_sizes': (200, 100, 50),  # Larger network for GPU
                    'max_iter': 2000,  # More iterations on GPU
                    'early_stopping': True,
                    'validation_fraction': 0.1
                })
                logger.info("✅ Neural Network GPU optimizations applied")
        else:
            # CPU optimizations
            logger.info("💻 Applying CPU optimizations to model configs")
              # Optimize for CPU efficiency
            for model_name, model_config in base_config.items():
                if 'n_jobs' in model_config['params']:
                    model_config['params']['n_jobs'] = self.resource_mgr.get_optimal_workers(task_type='model_training')
                
                # Reduce complexity for CPU training
                if 'n_estimators' in model_config['params']:
                    model_config['params']['n_estimators'] = min(150, model_config['params']['n_estimators'])
                
                if 'max_iter' in model_config['params']:
                    model_config['params']['max_iter'] = min(1000, model_config['params']['max_iter'])
        
        return base_config
    
    def _select_optimal_models(self, all_models: Dict) -> Dict:
        """
        **ADAPTIVE MODEL SELECTION:** Chọn models tối ưu dựa trên system resources và dataset size
        
        Strategy:
        1. GPU mode: Prioritize GPU-friendly models (XGBoost, LightGBM, CatBoost, NN)
        2. CPU mode: Balance between speed và accuracy
        3. Large dataset: Prefer tree-based models
        4. Small dataset: Include linear models for diversity
        5. Memory constrained: Skip memory-heavy models
        """
        try:
            # Get system metrics
            memory_info = self._get_memory_usage()
            available_memory_gb = (psutil.virtual_memory().total - psutil.virtual_memory().used) / (1024**3)
            
            # Get dataset characteristics
            total_samples = sum(len(df) for df in self.clean_data.values() if df is not None)
            total_features = sum(len(df.columns) for df in self.features.values() if df is not None)
            avg_features_per_tf = total_features / len(self.features) if self.features else 0
            
            logger.info(f"🔍 System Analysis for Model Selection:")
            logger.info(f"   - Available Memory: {available_memory_gb:.1f}GB")
            logger.info(f"   - Total Samples: {total_samples:,}")
            logger.info(f"   - Avg Features per TF: {avg_features_per_tf:.0f}")
            logger.info(f"   - GPU Available: {self.use_gpu}")
            
            selected_models = {}
            priority_models = []
            fallback_models = []
            
            # **STRATEGY 1: GPU-优先策略**
            if self.use_gpu and available_memory_gb > 4.0:
                # GPU mode với đủ memory - chọn GPU-native models
                priority_models = ['XGBoost', 'LightGBM', 'CatBoost', 'NeuralNetwork']
                fallback_models = ['RandomForest', 'GradientBoosting']
                max_models = 6
                logger.info("🔥 GPU Priority Strategy: Focus on GPU-accelerated models")
                
            elif self.use_gpu and available_memory_gb <= 4.0:
                # GPU mode nhưng memory hạn chế
                priority_models = ['XGBoost', 'LightGBM'] 
                fallback_models = ['LogisticRegression', 'RandomForest']
                max_models = 4
                logger.info("🔥 GPU Memory-Constrained Strategy: Limited to efficient GPU models")
                
            # **STRATEGY 2: CPU-最优策略**
            elif available_memory_gb > 8.0:
                # CPU mode với memory dồi dào
                priority_models = ['RandomForest', 'ExtraTrees', 'XGBoost', 'GradientBoosting']
                fallback_models = ['LogisticRegression', 'AdaBoost', 'SVM']
                max_models = 7
                logger.info("💻 CPU High-Memory Strategy: Full model ensemble")
                
            elif available_memory_gb > 4.0:
                # CPU mode với memory trung bình
                priority_models = ['RandomForest', 'XGBoost', 'LogisticRegression']
                fallback_models = ['GradientBoosting', 'AdaBoost']
                max_models = 5
                logger.info("💻 CPU Standard Strategy: Balanced model selection")
                
            else:
                # Memory thấp - chỉ chọn lightweight models
                priority_models = ['LogisticRegression', 'RandomForest']
                fallback_models = ['AdaBoost']
                max_models = 3
                logger.info("⚠️ CPU Low-Memory Strategy: Lightweight models only")
            
            # **STRATEGY 3: Dataset Size Adaptation**
            if total_samples < 1000:
                # Small dataset - prefer simpler models
                priority_models = [m for m in priority_models if m in ['LogisticRegression', 'RandomForest', 'AdaBoost']]
                fallback_models = [m for m in fallback_models if m in ['SVM', 'GradientBoosting']]
                max_models = min(max_models, 4)
                logger.info("📊 Small Dataset Adaptation: Simplified model selection")
                
            elif total_samples > 100000:
                # Large dataset - prefer scalable models
                priority_models = [m for m in priority_models if m not in ['SVM']]  # SVM không scale tốt
                max_models = min(max_models, 8)  # Có thể train nhiều models hơn
                logger.info("📊 Large Dataset Adaptation: Scalable model focus")
            
            # **SELECTION PROCESS**
            model_count = 0
            
            # Add priority models first
            for model_name in priority_models:
                if model_name in all_models and model_count < max_models:
                    selected_models[model_name] = all_models[model_name]
                    model_count += 1
            
            # Add fallback models if needed
            for model_name in fallback_models:
                if model_name in all_models and model_count < max_models:
                    selected_models[model_name] = all_models[model_name]
                    model_count += 1
            
            # **FALLBACK**: Ensure minimum models
            if len(selected_models) < 2:
                # Emergency fallback - select at least 2 models
                safe_models = ['LogisticRegression', 'RandomForest']
                for model_name in safe_models:
                    if model_name in all_models and model_name not in selected_models:
                        selected_models[model_name] = all_models[model_name]
                        if len(selected_models) >= 2:
                            break
                logger.warning(f"⚠️ Emergency fallback activated: {list(selected_models.keys())}")
            
            logger.info(f"✅ Model Selection Complete: {len(selected_models)}/{len(all_models)} models selected")
            logger.info(f"   Selected: {list(selected_models.keys())}")
            
            return selected_models
            
        except Exception as e:
            logger.error(f"❌ Model selection failed: {e}")
            # Emergency fallback - return safe models
            safe_selection = {
                'LogisticRegression': all_models.get('LogisticRegression'),
                'RandomForest': all_models.get('RandomForest')
            }
            safe_selection = {k: v for k, v in safe_selection.items() if v is not None}
            logger.warning(f"🚨 Using emergency safe selection: {list(safe_selection.keys())}")
            return safe_selection
    
    def _get_train_val_data(self, features_df):
        """Chia dữ liệu train/validation cho một timeframe"""
        try:
            if features_df is None or features_df.empty:
                return None, None, None, None
            
            # Tách features và target
            if 'target' not in features_df.columns:
                logger.error("Target column not found in features")
                return None, None, None, None
            
            feature_cols = [col for col in features_df.columns 
                          if col not in ['target', 'open_time', 'close_time', 'timestamp'] 
                          and features_df[col].dtype in ['int64', 'float64', 'int32', 'float32']]
            
            X = features_df[feature_cols].fillna(0)
            y = features_df['target'].fillna(0)
            
            # **FIX**: Convert target to integer classes for classification
            unique_targets = sorted(y.unique())
            target_mapping = {val: i for i, val in enumerate(unique_targets)}
            y_encoded = y.map(target_mapping).astype(int)
            
            logger.info(f"Target mapping: {target_mapping}")
            logger.info(f"Target distribution: {y_encoded.value_counts().to_dict()}")
            
            # Chia train/val (80/20)
            split_idx = int(len(X) * 0.8)
            
            X_train = X.iloc[:split_idx]
            X_val = X.iloc[split_idx:]
            y_train = y_encoded.iloc[:split_idx]
            y_val = y_encoded.iloc[split_idx:]
            
            logger.info(f"Data split: Train={len(X_train)}, Val={len(X_val)}")
            
            return X_train.values, y_train.values, X_val.values, y_val.values
            
        except Exception as e:
            logger.error(f"Error in train/val split: {e}")
            return None, None, None, None

    def _save_multi_timeframe_model(self):
        """Lưu models cho tất cả timeframes"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        # Tính toán metrics tổng hợp
        all_timeframe_results = []
        total_accuracy = 0
        total_f1 = 0
        
        for tf, ensemble_model in self.models.items():
            tf_result = {
                'timeframe': tf,
                'type': ensemble_model.type if hasattr(ensemble_model, 'type') else 'ensemble',
                'accuracy': getattr(ensemble_model, 'accuracy', 0.0),
                'f1_score': getattr(ensemble_model, 'f1_score', 0.0),
                'model_count': getattr(ensemble_model, 'model_count', 0),
                'training_time': getattr(ensemble_model, 'training_time', 0.0)
            }
            all_timeframe_results.append(tf_result)
            total_accuracy += tf_result['accuracy']
            total_f1 += tf_result['f1_score']
        
        # Tính average metrics
        avg_accuracy = total_accuracy / len(self.models) if self.models else 0.0
        avg_f1 = total_f1 / len(self.models) if self.models else 0.0
        
        # Lưu model data
        model_path = f"models/{self.symbol}_multi_timeframe_{timestamp}.pkl.gz"
        os.makedirs('models', exist_ok=True)
        
        model_data = {
            'models': self.models,
            'features': self.features,
            'config': self.config,
            'timeframes': self.timeframes,
            'training_mode': self.training_mode,
            'average_accuracy': avg_accuracy,
            'average_f1_score': avg_f1,
            'timeframe_results': all_timeframe_results,
            'timestamp': datetime.now().isoformat()
        }
        
        try:
            with gzip.open(model_path, 'wb') as f:
                pickle.dump(model_data, f)
            logger.info(f"💾 Multi-timeframe model saved: {model_path}")
        except Exception as e:
            logger.warning(f"⚠️ Could not save model: {e}")
        
        # Cập nhật self.results với thông tin tổng hợp
        self.results['multi_timeframe'] = {
            'total_timeframes': len(self.models),
            'successful_timeframes': list(self.models.keys()),
            'average_accuracy': avg_accuracy,
            'average_f1_score': avg_f1,
            'timeframe_results': all_timeframe_results,
            'model_path': model_path
        }
    def _save_emergency(self):
        """Lưu emergency checkpoint cho multi-timeframe training"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = f"checkpoints/emergency_multi_{timestamp}.pkl"
        
        emergency_data = {
            'state': self.state,
            'config': self.config,
            'timeframes': self.timeframes,
            'training_mode': self.training_mode,
            'raw_data': self.raw_data,
            'clean_data': self.clean_data,
            'features': self.features,
            'models': self.models if hasattr(self, 'models') else {},
            'results': self.results if hasattr(self, 'results') else {}
        }        
        os.makedirs('checkpoints', exist_ok=True)
        with open(path, 'wb') as f:
            pickle.dump(emergency_data, f)
            
        logger.info(f"💾 Emergency checkpoint saved: {path}")
        return path
    
    def _cleanup_resources(self):
        """Cleanup GPU và system resources sử dụng Resource Manager"""
        try:
            # Sử dụng unified resource manager để cleanup
            self.resource_mgr.cleanup_resources(intensity='moderate')
            
            # Clear feature cache
            if hasattr(self, 'feature_cache'):
                self.feature_cache.clear()
                
            logger.info("🧹 System resources cleaned via Resource Manager")
            
        except Exception as e:
            logger.warning(f"⚠️ Resource cleanup warning: {e}")

    def _cleanup_gpu_memory(self):
        """Clean up GPU memory sau mỗi model training"""
        if self.use_gpu:
            import gc
            gc.collect()
            try:
                import torch
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
                    # Force GPU memory cleanup
                    torch.cuda.synchronize()
                logger.debug("🧹 GPU memory cleaned")
            except ImportError:
                pass
    
    def _get_memory_usage(self) -> Dict[str, float]:
        """Lấy thông tin sử dụng memory hiện tại"""
        import psutil
        process = psutil.Process()
        memory_info = process.memory_info()
        
        result = {
            'rss_mb': memory_info.rss / 1024 / 1024,  # Resident Set Size
            'vms_mb': memory_info.vms / 1024 / 1024,  # Virtual Memory Size
            'percent': process.memory_percent()
        }
        
        # GPU memory nếu có
        if self.use_gpu:
            try:
                import torch
                if torch.cuda.is_available():
                    gpu_memory = torch.cuda.memory_allocated() / 1024 / 1024
                    gpu_reserved = torch.cuda.memory_reserved() / 1024 / 1024
                    result.update({
                        'gpu_allocated_mb': gpu_memory,
                        'gpu_reserved_mb': gpu_reserved
                    })
            except ImportError:
                pass
        
        return result
    
    def _optimize_dataframe_memory(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Tối ưu memory sử dụng của DataFrame bằng cách downcast numeric types
        
        **QUAN TRỌNG:** Việc chuyển đổi từ int64 xuống int32/int8 có những ảnh hưởng:
        
        1. **Lợi ích:**
           - Giảm 50-87% memory usage (int64 -> int32: 50%, int64 -> int8: 87%)
           - Tăng tốc độ xử lý do cache hit tốt hơn
           - Cho phép load datasets lớn hơn vào RAM
        
        2. **Rủi ro:**
           - int32: Giới hạn giá trị [-2,147,483,648 đến 2,147,483,647]
           - int8: Giới hạn giá trị [-128 đến 127]
           - Overflow risk nếu giá trị vượt quá giới hạn
        
        3. **Phù hợp cho crypto data:**
           - Technical indicators: Thường trong khoảng [-100, 100] -> int8 OK
           - Price ratios: Thường < 1000 -> int32 OK  
           - Volume indicators: Cần kiểm tra range trước khi downcast
        
        Args:
            df: DataFrame cần tối ưu
            
        Returns:
            DataFrame đã được tối ưu memory
        """
        try:
            initial_memory = df.memory_usage(deep=True).sum() / 1024 / 1024  # MB
            
            # Tối ưu integer columns
            for col in df.select_dtypes(include=['int64', 'int32']).columns:
                col_min = df[col].min()
                col_max = df[col].max()
                
                # Skip target column để tránh vấn đề với ML algorithms
                if col == 'target':
                    continue
                
                # Downcast dựa trên range của data
                if col_min >= -128 and col_max <= 127:
                    df[col] = df[col].astype('int8')
                    logger.debug(f"📉 {col}: int64 -> int8 (range: {col_min} to {col_max})")
                elif col_min >= -32768 and col_max <= 32767:
                    df[col] = df[col].astype('int16')
                    logger.debug(f"📉 {col}: int64 -> int16 (range: {col_min} to {col_max})")
                elif col_min >= -2147483648 and col_max <= 2147483647:
                    df[col] = df[col].astype('int32')
                    logger.debug(f"📉 {col}: int64 -> int32 (range: {col_min} to {col_max})")
                else:
                    logger.warning(f"⚠️ {col}: Giữ int64 do range quá lớn ({col_min} to {col_max})")
            
            # Tối ưu float columns
            for col in df.select_dtypes(include=['float64']).columns:
                col_min = df[col].min()
                col_max = df[col].max()
                
                # Kiểm tra xem có thể dùng float32 không (6-7 decimal precision)
                if abs(col_min) < 3.4e38 and abs(col_max) < 3.4e38:
                    # Test conversion để đảm bảo không mất precision quan trọng
                    test_conversion = df[col].astype('float32')
                    
                    # Kiểm tra precision loss
                    precision_loss = abs(df[col] - test_conversion).max()
                    relative_loss = precision_loss / (abs(df[col]).max() + 1e-8)
                    
                    if relative_loss < 1e-6:  # Chấp nhận precision loss < 0.0001%
                        df[col] = test_conversion
                        logger.debug(f"📉 {col}: float64 -> float32 (precision loss: {relative_loss:.2e})")
                    else:
                        logger.warning(f"⚠️ {col}: Giữ float64 do precision loss quá cao ({relative_loss:.2e})")
                else:
                    logger.warning(f"⚠️ {col}: Giữ float64 do range quá lớn")
            
            final_memory = df.memory_usage(deep=True).sum() / 1024 / 1024  # MB
            memory_reduction = (1 - final_memory / initial_memory) * 100
            
            logger.info(f"💾 Memory optimization: {initial_memory:.1f}MB -> {final_memory:.1f}MB ({memory_reduction:.1f}% reduction)")
            
            return df
            
        except Exception as e:
            logger.error(f"❌ Memory optimization failed: {e}")
            return df  # Return original DataFrame nếu optimization thất bại
