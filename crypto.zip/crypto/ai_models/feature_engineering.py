"""
Feature Engineering Module - REFACTORED AND OPTIMIZED
Main orchestration class for crypto trading feature engineering.

Module này đã được tối ưu hóa và tách thành các modules chuyên biệt:
- feature_technical.py: Technical indicators và basic features
- feature_advanced.py: Advanced features và specialized analysis

Chỉ giữ lại core orchestration logic và utilities ở đây.
"""

import warnings
warnings.filterwarnings("ignore")
import os
os.environ['PYTHONWARNINGS'] = 'ignore'
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any, Union
from scipy import stats
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
from datetime import datetime, timedelta
from config.logging_config import get_logger

# Professional logger initialization
logger = get_logger('feature_engineering')

# Smart epsilon handling for small cryptocurrency values
def get_smart_eps(data_series: pd.Series = None, base_eps: float = 1e-12) -> float:
    if data_series is None or data_series.empty:
        return base_eps
    try:
        non_zero_data = data_series[data_series != 0]
        if non_zero_data.empty:
            return base_eps
        min_abs_value = abs(non_zero_data).min()
        smart_eps = min_abs_value / 1000
        smart_eps = max(smart_eps, 1e-18)
        smart_eps = min(smart_eps, 1e-8)
        return smart_eps
    except Exception:
        return base_eps

EPS = 1e-12

# Professional AI Calculator integration with lazy loading
AI_PARAMETER_CALCULATOR_AVAILABLE = False
ai_parameter_calculator = None
AIParameterCalculator = None

def _get_ai_calculator():
    """Professional lazy import to avoid circular dependencies"""
    global ai_parameter_calculator, AIParameterCalculator, AI_PARAMETER_CALCULATOR_AVAILABLE
    if ai_parameter_calculator is None and not AI_PARAMETER_CALCULATOR_AVAILABLE:
        try:
            from ai_models.ai_parameters import get_parameter_calculator, AIParameterCalculator as calc_class
            ai_parameter_calculator = get_parameter_calculator()
            AIParameterCalculator = calc_class
            AI_PARAMETER_CALCULATOR_AVAILABLE = True
            logger.info("🎯 Professional AI Parameter Calculator loaded for dynamic thresholds")
        except ImportError:
            logger.warning("⚠️ AI Parameter Calculator not available, using static thresholds")
    return ai_parameter_calculator

# Professional resource manager integration
try:
    from ai_optimizer.unified_resource_manager import get_resource_manager
    RESOURCE_MANAGER_AVAILABLE = True
    logger.info("🚀 Professional resource manager available for optimized multithreading")
except ImportError:
    RESOURCE_MANAGER_AVAILABLE = False
    logger.warning("⚠️ Resource manager not available, using default threading")

# Professional ML library imports
try:
    from sklearn.preprocessing import StandardScaler, RobustScaler, MinMaxScaler
    from sklearn.decomposition import PCA, FastICA
    from sklearn.cluster import KMeans, DBSCAN
    from sklearn.feature_selection import mutual_info_regression, SelectKBest, f_regression
    from sklearn.ensemble import IsolationForest
    SKLEARN_AVAILABLE = True
    logger.info("🎯 Professional ML libraries available")
except ImportError:
    SKLEARN_AVAILABLE = False
    logger.warning("⚠️ Scikit-learn not available. Advanced ML features disabled.")

# Import refactored modules
from ai_models.feature_technical import (
    add_technical_indicators, add_volume_indicators, add_price_patterns,
    add_volatility_features, add_momentum_features, add_trend_features, 
    add_composite_indicators
)
from ai_models.feature_advanced import (
    add_statistical_features, add_market_microstructure, add_adaptive_features,
    add_fractal_features, add_spectral_analysis_features, add_machine_learning_features,
    add_crypto_specific_features, add_defi_features, add_regime_detection_features,
    add_information_theory_features
)

class UnifiedFeatureEngineer:
    """
    💎 Professional Feature Engineering Orchestrator 💎
    Coordinates feature generation across specialized modules
    """

    def __init__(self, config: Optional[Dict] = None):
        """Professional initialization with advanced crypto-optimized configuration"""
        self.config = config or {}
        
        # Professional Enterprise Configuration
        self.default_config = {
            # === CORE FEATURE GROUPS ===
            'volume_indicators': True,
            'statistical_features': True,
            'market_microstructure': True,
            'volatility_features': True,
            'momentum_features': True,
            'trend_features': True,
            'crypto_specific_features': True,
            'defi_features': True,
            'regime_detection': True,
            'information_theory': True,
            'spectral_analysis': True,
            
            # === PROFESSIONAL TECHNICAL INDICATORS ===
            'sma_periods': [3, 5, 8, 13, 21, 34, 55, 89, 144, 233],  # Fibonacci sequence
            'ema_periods': [5, 8, 12, 21, 26, 34, 50, 100, 200],     # Professional EMA suite
            'rsi_periods': [7, 14, 21, 28],                           # Multi-timeframe RSI
            'macd_configs': [                                         # Professional MACD variants
                {'fast': 12, 'slow': 26, 'signal': 9},               # Standard
                {'fast': 5, 'slow': 35, 'signal': 5},                # Aggressive
                {'fast': 8, 'slow': 21, 'signal': 5}                 # Crypto-optimized
            ],
            'bb_periods': [10, 20, 30, 50],                          # Multi-scale Bollinger
            'bb_std_devs': [1.5, 2.0, 2.5],                         # Multiple standard deviations
            'atr_periods': [7, 14, 21, 28],                          # Volatility measurement
            'adx_periods': [14, 21, 28],                             # Trend strength
            'cci_periods': [14, 20, 30],                             # Commodity Channel Index
            'stoch_configs': [                                        # Stochastic variants
                {'k': 14, 'd': 3, 'smooth': 3},                     # Fast
                {'k': 21, 'd': 5, 'smooth': 5}                      # Slow
            ],
            
            # === PROFESSIONAL VOLUME ANALYSIS ===
            'vwap_periods': [20, 50, 100],                           # Multi-period VWAP
            'volume_ma_periods': [5, 10, 20, 50],                    # Volume moving averages
            'obv_smoothing': [5, 10, 20],                            # OBV smoothing periods
            'cmf_periods': [14, 21, 28],                             # Chaikin Money Flow
            'mfi_periods': [14, 21],                                 # Money Flow Index
            'fi_periods': [13, 21],                                  # Force Index
            'ease_of_movement_periods': [14, 28],                    # Ease of Movement
            
            # === ADVANCED STATISTICAL FEATURES ===
            'volatility_periods': [5, 10, 20, 30, 50, 100],         # Multi-scale volatility
            'returns_periods': [1, 3, 5, 10, 15, 20, 30, 60],       # Returns analysis
            'correlation_periods': [10, 20, 30, 50],                 # Rolling correlations
            'z_score_periods': [10, 20, 30, 50],                     # Z-score normalization
            'entropy_periods': [20, 50, 100],                        # Information entropy
            'skewness_periods': [10, 20, 30, 50],                    # Distribution skewness
            'kurtosis_periods': [10, 20, 30, 50],                    # Distribution kurtosis
            'higher_moments_periods': [20, 50, 100],                 # Higher-order moments
            
            # === CRYPTO-SPECIFIC CONFIGURATIONS ===
            'funding_rate_periods': [8, 24, 168],                    # 8h, 1d, 1w funding cycles
            'perpetual_spot_periods': [5, 15, 60],                   # Perpetual vs spot analysis
            'whale_detection_threshold': 0.95,                       # Volume spike threshold
            'liquidation_cascade_periods': [5, 15, 30],             # Liquidation detection
            'orderbook_imbalance_periods': [5, 10, 20],             # Order flow imbalance
            
            # === PROFESSIONAL PATTERN RECOGNITION ===
            'support_resistance_windows': [10, 20, 50],              # S/R level detection
            'pattern_lookback_periods': [5, 10, 20],                 # Pattern recognition
            'fractal_periods': [5, 13, 21],                          # Fractal analysis
            'fibonacci_levels': [0.236, 0.382, 0.5, 0.618, 0.786],  # Fibonacci retracements
            
            # === REGIME DETECTION PARAMETERS ===
            'regime_detection_periods': [50, 100, 200],              # Market regime analysis
            'volatility_regime_quantiles': [0.25, 0.75],            # Vol regime thresholds
            'trend_regime_periods': [20, 50, 100],                   # Trend regime detection
            'regime_transition_periods': [10, 20, 50],               # Regime transitions
            
            # === ADVANCED PROCESSING OPTIONS ===
            'wavelet_scales': [2, 4, 8, 16, 32, 64],                # Wavelet decomposition
            'spectral_analysis_windows': [50, 100, 200],             # FFT windows
            'pca_components': 10,                                     # Principal components
            'clustering_n_clusters': [3, 5, 8],                     # K-means clusters
            
            # === PROFESSIONAL DATA QUALITY ===
            'handle_missing_data': True,
            'interpolation_method': 'cubic',                         # Higher-order interpolation
            'remove_outliers': True,
            'outlier_method': 'isolation_forest',                    # Advanced outlier detection
            'outlier_threshold': 0.05,                               # 5% outlier threshold
            'normalize_features': True,
            'normalization_method': 'robust',                        # Robust scaling
            'max_missing_pct': 0.15                                  # 15% missing data tolerance
        }
        
        # Professional config merging
        self.config = {**self.default_config, **self.config}
        
        # Professional logger initialization
        self.logger = get_logger('professional_feature_engineering')
        
        # Professional performance tracking
        self.feature_stats = {
            'total_features': 0,
            'computation_time': 0,
            'memory_usage': 0,
            'features_generated': []
        }
        
        # Professional resource management
        self.resource_manager = None
        try:
            if RESOURCE_MANAGER_AVAILABLE:
                from ai_optimizer.unified_resource_manager import get_resource_manager
                self.resource_manager = get_resource_manager()
        except Exception:
            pass
    
    def engineer_features(self, df: pd.DataFrame,
                        include_technical: bool = True,
                        include_statistical: bool = True,
                        include_sentiment: bool = False,
                        include_advanced: bool = True,
                        batch_size: int = 50000,
                        task_type: str = 'processing') -> pd.DataFrame:
        """
        💎 Pipeline Kỹ Thuật Đa Luồng - Feature Engineering cho AI Crypto (Song song hóa, kiểm soát RAM triệt để, memory-safe, GPU-ready)
        """
        if df is None or df.empty:
            raise ValueError("Dữ liệu đầu vào bị rỗng hoặc không hợp lệ")
        required_cols = ['open', 'high', 'low', 'close', 'volume']
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            raise ValueError(f"Thiếu cột bắt buộc: {missing_cols}")
        start_time = datetime.now()
        logger.info(f"🚀 Bắt đầu tính toán feature (đa luồng, memory-safe, batch={batch_size}): {len(df)} dòng")
        # Hàm xử lý từng batch nhỏ, có thể chạy song song
        def process_batch(batch_df):
            try:
                if self.resource_manager:
                    with self.resource_manager.managed_execution(task_type=task_type):
                        return self._engineer_features_single(batch_df, include_technical, include_statistical, include_sentiment, include_advanced)
                else:
                    return self._engineer_features_single(batch_df, include_technical, include_statistical, include_sentiment, include_advanced)
            except Exception as e:
                logger.error(f"❌ Lỗi tính feature cho batch: {e}")
                return batch_df
        # Sử dụng safe_process_batches để chia nhỏ batch, kiểm soát RAM, đa luồng
        if self.resource_manager:
            results = self.resource_manager.safe_process_batches(
                df, process_batch, batch_size=batch_size, max_ram_usage=0.9
            )
        else:
            # Fallback: chia batch thủ công, không kiểm soát RAM
            results = []
            for i in range(0, len(df), batch_size):
                batch = df.iloc[i:i+batch_size]
                results.append(process_batch(batch))
        df_features = pd.concat(results, axis=0, ignore_index=True)
        computation_time = (datetime.now() - start_time).total_seconds()
        total_features = df_features.shape[1]
        self.feature_stats.update({
            'total_features': total_features,
            'computation_time': computation_time,
            'features_generated': list(df_features.columns)
        })
        if 'target' not in df_features.columns:
            df_features = self._create_target_column(df_features)
        logger.info(f"✅ Hoàn thành tính feature (đa luồng, memory-safe): {total_features} cột trong {computation_time:.2f}s")
        return df_features

    def _engineer_features_single(self, df: pd.DataFrame,
                        include_technical: bool = True,
                        include_statistical: bool = True,
                        include_sentiment: bool = False,
                        include_advanced: bool = True) -> pd.DataFrame:
        """
        Xử lý feature cho 1 batch nhỏ hoặc toàn bộ (không chia batch)
        """
        # ...existing code from old engineer_features, bắt đầu từ logger.info("🚀 Bắt đầu tính toán feature (đa luồng): ...") đến hết try block...
        logger.info(f"🚀 Bắt đầu tính toán feature (đa luồng): {len(df)} dòng")
        df_features = self._preprocess_data(df)
        feature_tasks = []
        if include_technical:
            feature_tasks.append(('technical', [
                (add_technical_indicators, self.config),
                (add_volume_indicators, self.config),
                (add_price_patterns, self.config)
            ]))
        if include_statistical:
            feature_tasks.append(('statistical', [
                (add_statistical_features, self.config),
                (add_volatility_features, self.config),
                (add_momentum_features, self.config),
                (add_trend_features, self.config)
            ]))
        if self.config.get('crypto_specific_features', True):
            feature_tasks.append(('crypto', [
                (add_crypto_specific_features, None)
            ]))
        if self.config.get('defi_features', True):
            feature_tasks.append(('defi', [
                (add_defi_features, None)
            ]))
        if include_advanced:
            feature_tasks.append(('advanced', [
                (add_market_microstructure, self.config),
                (add_adaptive_features, self.config),
                (add_fractal_features, self.config),
                (add_spectral_analysis_features, self.config),
                (add_machine_learning_features, self.config),
                (add_regime_detection_features, self.config),
                (add_information_theory_features, self.config),
                (add_composite_indicators, self.config)
            ]))
        results = {}
        if self.resource_manager:
            pool = self.resource_manager.thread_pool
        else:
            pool = ThreadPoolExecutor(max_workers=os.cpu_count() or 4)
        futures = {}
        for group, funcs in feature_tasks:
            def run_group(df_in, funcs=funcs, group=group):
                df_out = df_in.copy()
                for func, cfg in funcs:
                    try:
                        if cfg is not None:
                            df_out = func(df_out, cfg)
                        else:
                            df_out = func(df_out)
                    except Exception as e:
                        logger.warning(f"Lỗi khi tính feature nhóm {group}: {func.__name__}: {e}")
                return (group, df_out)
            futures[group] = pool.submit(run_group, df)
        for group, fut in futures.items():
            try:
                _, df_group = fut.result()
                for col in df_group.columns:
                    if col not in df_features.columns:
                        df_features[col] = df_group[col]
            except Exception as e:
                logger.warning(f"Lỗi khi lấy kết quả feature nhóm {group}: {e}")
        # Hậu xử lý, kiểm tra NaN, outlier, normalize, ...
        logger.debug("🔧 Giai đoạn hậu xử lý dữ liệu...")
        try:
            from data_processing.unified_data_validator import unified_validator
            nan_safety_result = unified_validator._validate_nan_safety(df_features)
            if nan_safety_result.get('is_valid', False):
                df_features = nan_safety_result.get('cleaned_data', df_features)
                logger.debug("✅ Kiểm tra NaN thành công")
            else:
                logger.warning(f"⚠️ Vấn đề NaN: {nan_safety_result.get('issues', [])}")
                df_features = nan_safety_result.get('cleaned_data', df_features)
        except:
            logger.debug("Dùng phương án dự phòng cho NaN")
            df_features = df_features.fillna(method='ffill').fillna(0)
        if self.config['handle_missing_data']:
            df_features = self._handle_missing_data(df_features)
        if self.config['remove_outliers']:
            df_features = self._remove_outliers(df_features)
        if self.config['normalize_features']:
            df_features = self._normalize_features(df_features)
        if df_features.empty or len(df_features) == 0:
            logger.error("❌ Lỗi nghiêm trọng: DataFrame rỗng sau khi tính feature!")
            logger.warning("🔄 Trả về DataFrame gốc với feature cơ bản")
            df_fallback = df.copy()
            if 'target' not in df_fallback.columns:
                df_fallback['target'] = (df_fallback['close'].pct_change(periods=12) > 0.003).astype(int)
            return df_fallback
        return df_features
    def _preprocess_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Pre-process data ONLY with real data - NO artificial filling, NO fake numbers."""
        try:
            logger.debug("🔧 Starting data preprocessing with REAL DATA ONLY...")
            
            # Identify OHLCV columns
            ohlcv_columns = ['open', 'high', 'low', 'close', 'volume']
            price_columns = ['open', 'high', 'low', 'close']
            
            # Calculate smart epsilon for this dataset
            if 'close' in df.columns and not df['close'].empty:
                global EPS
                original_eps = EPS
                EPS = get_smart_eps(df['close'])
                logger.debug(f"📊 Smart epsilon adjusted from {original_eps} to {EPS} for small prices")
            
            # Handle each OHLCV column with HIGH PRECISION - NO ARTIFICIAL DATA
            for col in ohlcv_columns:
                if col in df.columns:
                    # Convert to high precision float first
                    df[col] = pd.to_numeric(df[col], errors='coerce', downcast=None)
                    df[col] = df[col].astype(np.float64)  # Ensure high precision
                    
                    # CRITICAL: ONLY drop rows with NaN - DO NOT FILL WITH FAKE DATA
                    if df[col].isnull().any():
                        nan_count = df[col].isnull().sum()
                        logger.warning(f"Found {nan_count} NaN values in {col} - these rows indicate data quality issues")
                        # Drop problematic rows
                        df = df.dropna(subset=[col])
                    
                    # Ensure data integrity - keep original values, NO modification of real data
                    if col == 'volume':
                        # Check for negative volume (data error)
                        if (df[col] < 0).any():
                            logger.error(f"CRITICAL: Found negative volume in {col} - indicates data corruption")
                            # Drop rows with negative volume instead of forcing positive
                            df = df[df[col] >= 0]
                    else:
                        # Price columns - check for negative prices (data error)
                        if (df[col] <= 0).any():
                            logger.error(f"CRITICAL: Found non-positive prices in {col} - indicates data corruption")
                            # Drop rows with non-positive prices instead of forcing positive
                            df = df[df[col] > 0]
            
            # Validate OHLC relationships using REAL data only
            if all(col in df.columns for col in price_columns):
                logger.debug("🔍 Validating OHLC relationships using REAL data only...")
                
                # Validate OHLC relationships - DO NOT MODIFY real data
                invalid_high = df['high'] < df[['open', 'low', 'close']].max(axis=1)
                invalid_low = df['low'] > df[['open', 'high', 'close']].min(axis=1)
                
                if invalid_high.any() or invalid_low.any():
                    total_invalid = invalid_high.sum() + invalid_low.sum()
                    logger.error(f"CRITICAL: Found {total_invalid} rows with invalid OHLC relationships")
                    logger.error("This indicates corrupted source data - NOT fixing with fake data")
                    logger.warning("Keeping invalid OHLC rows for data volume - models must handle this")
            
            logger.debug("✅ Data preprocessing completed with REAL DATA ONLY")
            return df
            
        except Exception as e:
            logger.warning(f"Data preprocessing failed: {e}")
            return df

    def _handle_missing_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Handle missing data with forward fill only for recent values"""
        try:
            # Only forward fill very recent missing values (max 3 periods)
            df_filled = df.fillna(method='ffill', limit=3)
            
            # For remaining NaN values, use interpolation for numeric columns only
            numeric_cols = df_filled.select_dtypes(include=[np.number]).columns
            for col in numeric_cols:
                if df_filled[col].isnull().any():
                    df_filled[col] = df_filled[col].interpolate(method='linear', limit=5)
            
            # Final fallback: fill remaining NaN with 0
            df_filled = df_filled.fillna(0)
            
            return df_filled
        except Exception as e:
            logger.warning(f"Missing data handling failed: {e}")
            return df.fillna(0)

    def _remove_outliers(self, df: pd.DataFrame, threshold: float = 3.0) -> pd.DataFrame:
        """Remove outliers using IQR method for numerical columns"""
        try:
            if not SKLEARN_AVAILABLE:
                return df
            
            numeric_cols = df.select_dtypes(include=[np.number]).columns
            
            for col in numeric_cols:
                if col in ['open', 'high', 'low', 'close', 'volume']:
                    continue  # Don't remove outliers from OHLCV data
                
                Q1 = df[col].quantile(0.25)
                Q3 = df[col].quantile(0.75)
                IQR = Q3 - Q1
                
                lower_bound = Q1 - 1.5 * IQR
                upper_bound = Q3 + 1.5 * IQR
                
                # Cap outliers instead of removing rows
                df[col] = df[col].clip(lower=lower_bound, upper=upper_bound)
            
            return df
        except Exception as e:
            logger.warning(f"Outlier removal failed: {e}")
            return df

    def _normalize_features(self, df: pd.DataFrame, method: str = 'robust') -> pd.DataFrame:
        """Normalize features using robust scaling"""
        try:
            if not SKLEARN_AVAILABLE:
                return df
            
            # Don't normalize OHLCV and target columns
            exclude_cols = ['open', 'high', 'low', 'close', 'volume', 'target', 'label']
            numeric_cols = df.select_dtypes(include=[np.number]).columns
            cols_to_normalize = [col for col in numeric_cols if col not in exclude_cols]
            
            if not cols_to_normalize:
                return df
            
            if method == 'robust':
                scaler = RobustScaler()
            elif method == 'standard':
                scaler = StandardScaler()
            else:
                scaler = MinMaxScaler()
            
            df[cols_to_normalize] = scaler.fit_transform(df[cols_to_normalize])
            
            return df
        except Exception as e:
            logger.warning(f"Feature normalization failed: {e}")
            return df

    def _create_target_column(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create target column for supervised learning"""
        try:
            if 'target' in df.columns:
                return df
            
            if 'close' in df.columns:
                # Create target based on future price movement
                future_return = df['close'].pct_change(periods=12).shift(-12)
                df['target'] = (future_return > 0.003).astype(int)  # 0.3% threshold
                
                # Forward fill the last values to avoid NaN
                df['target'] = df['target'].fillna(method='ffill').fillna(0)
            
            return df
        except Exception as e:
            logger.warning(f"Target creation failed: {e}")
            if 'target' not in df.columns:
                df['target'] = 0
            return df

    def get_feature_summary(self, df: pd.DataFrame) -> Dict:
        """Get comprehensive feature summary"""
        try:
            summary = {
                'total_features': df.shape[1],
                'total_rows': df.shape[0],
                'feature_types': {},
                'missing_data': {},
                'data_quality': {}
            }
            
            # Feature types
            for dtype in df.dtypes.unique():
                summary['feature_types'][str(dtype)] = len(df.select_dtypes(include=[dtype]).columns)
            
            # Missing data analysis
            missing_counts = df.isnull().sum()
            summary['missing_data'] = {
                'total_missing': missing_counts.sum(),
                'columns_with_missing': len(missing_counts[missing_counts > 0]),
                'missing_percentage': (missing_counts.sum() / (df.shape[0] * df.shape[1])) * 100
            }
            
            # Data quality metrics
            numeric_df = df.select_dtypes(include=[np.number])
            if not numeric_df.empty:
                summary['data_quality'] = {
                    'infinite_values': np.isinf(numeric_df).sum().sum(),
                    'zero_variance_features': len(numeric_df.columns[numeric_df.var() == 0]),
                    'high_correlation_pairs': self._find_high_correlation_features(numeric_df)
                }
            
            return summary
        except Exception as e:
            logger.error(f"Feature summary failed: {e}")
            return {'error': str(e)}

    def _find_high_correlation_features(self, df: pd.DataFrame, threshold: float = 0.95) -> int:
        """Find highly correlated feature pairs"""
        try:
            if df.empty or len(df.columns) < 2:
                return 0
            
            corr_matrix = df.corr().abs()
            upper_triangle = corr_matrix.where(
                np.triu(np.ones(corr_matrix.shape), k=1).astype(bool)
            )
            
            high_corr_pairs = (upper_triangle > threshold).sum().sum()
            return high_corr_pairs
        except Exception:
            return 0

    def validate_and_clean_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Validate and clean features for model training"""
        try:
            logger.debug("🔧 Validating and cleaning features...")
            
            # Remove features with zero variance
            numeric_cols = df.select_dtypes(include=[np.number]).columns
            for col in numeric_cols:
                if df[col].var() == 0:
                    logger.debug(f"Removing zero variance feature: {col}")
                    df = df.drop(columns=[col])
            
            # Handle infinite values
            df = df.replace([np.inf, -np.inf], np.nan)
            df = df.fillna(method='ffill').fillna(0)
            
            # Ensure target column exists
            if 'target' not in df.columns:
                df = self._create_target_column(df)
            
            logger.debug("✅ Feature validation and cleaning completed")
            return df
            
        except Exception as e:
            logger.error(f"Feature validation failed: {e}")
            return df

# Safe utility functions
def _safe_log_calculation(ratio_series: pd.Series) -> pd.Series:
    """Safe logarithm calculation avoiding domain errors"""
    try:
        # Ensure positive values for log calculation
        ratio_series = ratio_series.replace([0, np.inf, -np.inf], 1)
        ratio_series = ratio_series.clip(lower=EPS)
        return np.log(ratio_series)
    except Exception:
        return pd.Series(0, index=ratio_series.index)

def _safe_divide(numerator: pd.Series, denominator: pd.Series) -> pd.Series:
    """Safe division avoiding division by zero"""
    try:
        return numerator / (denominator.replace(0, EPS))
    except Exception:
        return pd.Series(0, index=numerator.index)

def _safe_percentage_change(series: pd.Series) -> pd.Series:
    """Safe percentage change calculation"""
    try:
        return series.pct_change().replace([np.inf, -np.inf], 0).fillna(0)
    except Exception:
        return pd.Series(0, index=series.index)

# Export main components for backward compatibility 
__all__ = [
    'UnifiedFeatureEngineer',
    'get_smart_eps', '_safe_divide', '_safe_percentage_change',
    # Re-exported from feature_technical
    'add_bollinger_bands', 'add_rsi', 'add_macd', 'add_stochastic', 'add_williams_r',
    'add_atr', 'add_adx', 'add_cci', 'add_roc', 'add_momentum', 'add_sma', 'add_ema',
    'add_vwap', 'add_ichimoku', 'add_obv', 'add_chaikin_mf', 'add_mfi',
    'add_fibonacci_retracements', 'add_pivot_points', 'add_support_resistance',
    # Re-exported from feature_advanced  
    'add_fractal_dimension', 'add_hurst_exponent', 'add_entropy_features',
    'add_wavelet_features', 'add_regime_features', 'add_correlation_features',
    'add_seasonal_features', 'add_volatility_clustering', 'add_jump_detection',
    'add_liquidity_features', 'add_market_structure', 'add_orderbook_features'
]
