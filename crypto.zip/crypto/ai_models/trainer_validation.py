"""
Trainer Validation Module - REFACTORED
Contains validation, optimization, and metrics calculation for the unified trainer.

Module này chứa:
- Model validation and backtesting
- Hyperparameter optimization
- Performance metrics calculation
- Walk-forward analysis
- Risk management validation
"""

import os
import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any
from datetime import datetime, timedelta
import pickle
import gzip 
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

logger = logging.getLogger(__name__)

def validate_models(models: Dict, features: Dict, config: Dict) -> Dict:
    """Validate models using walk-forward analysis and multiple metrics"""
    try:
        logger.info("🔍 Starting comprehensive model validation...")
        
        validation_results = {}
        
        for timeframe, timeframe_models in models.items():
            if timeframe not in features:
                logger.warning(f"⚠️ No features available for timeframe {timeframe}")
                continue
            
            features_df = features[timeframe]
            if features_df.empty:
                continue
            
            logger.info(f"🎯 Validating models for {timeframe}...")
            
            timeframe_results = {}
            
            for model_name, model_data in timeframe_models.items():
                try:
                    model = model_data['model']
                    
                    # Perform validation
                    validation_metrics = perform_model_validation(
                        model, features_df, timeframe, model_name, config
                    )
                    
                    timeframe_results[model_name] = validation_metrics
                    
                    logger.debug(f"✅ {model_name} validated - Score: {validation_metrics.get('overall_score', 0):.3f}")
                    
                except Exception as e:
                    logger.warning(f"⚠️ Validation failed for {model_name}: {e}")
                    continue
            
            validation_results[timeframe] = timeframe_results
        
        logger.info("✅ Model validation completed")
        return validation_results
        
    except Exception as e:
        logger.error(f"❌ Model validation failed: {e}")
        return {}

def perform_model_validation(model, features_df: pd.DataFrame, timeframe: str, model_name: str, config: Dict) -> Dict:
    """Perform comprehensive validation for a single model"""
    try:
        # Split data for validation
        train_size = int(len(features_df) * 0.7)
        val_size = int(len(features_df) * 0.15)
        
        train_data = features_df.iloc[:train_size]
        val_data = features_df.iloc[train_size:train_size + val_size]
        test_data = features_df.iloc[train_size + val_size:]
        
        if test_data.empty:
            logger.warning(f"⚠️ No test data for {model_name}")
            return {}
        
        # Prepare features and targets
        feature_cols = [col for col in features_df.columns if col not in ['target', 'label']]
        
        X_test = test_data[feature_cols].values
        y_test = test_data['target'].values if 'target' in test_data.columns else test_data['label'].values
        
        # Make predictions
        y_pred = model.predict(X_test)
        
        # Calculate comprehensive metrics
        from ai_models.unified_metrics import calculate_metrics_from_predictions
        basic_metrics = calculate_metrics_from_predictions(y_test, y_pred)
        
        # Additional validation metrics
        validation_metrics = {
            **basic_metrics,
            'model_name': model_name,
            'timeframe': timeframe,
            'test_samples': len(y_test),
            'validation_date': datetime.now().isoformat()
        }
        
        # Walk-forward validation if enabled
        if config.get('walk_forward_validation', True):
            wf_metrics = perform_walk_forward_validation(
                model, features_df, feature_cols, config
            )
            validation_metrics.update(wf_metrics)
        
        # Risk metrics
        risk_metrics = calculate_risk_metrics(y_test, y_pred, test_data)
        validation_metrics.update(risk_metrics)
        
        # Calculate overall score
        validation_metrics['overall_score'] = calculate_overall_score(validation_metrics)
        
        return validation_metrics
        
    except Exception as e:
        logger.error(f"❌ Validation failed for {model_name}: {e}")
        return {}

def perform_walk_forward_validation(model, features_df: pd.DataFrame, feature_cols: List[str], config: Dict) -> Dict:
    """Perform walk-forward validation"""
    try:
        logger.debug("🚶 Performing walk-forward validation...")
        
        window_size = config.get('walk_forward_window', 500)
        step_size = config.get('walk_forward_step', 50)
        
        if len(features_df) < window_size * 2:
            logger.warning("⚠️ Insufficient data for walk-forward validation")
            return {'wf_score': 0, 'wf_windows': 0}
        
        scores = []
        window_count = 0
        
        for start_idx in range(0, len(features_df) - window_size - step_size, step_size):
            try:
                # Training window
                train_start = start_idx
                train_end = start_idx + window_size
                
                # Test window
                test_start = train_end
                test_end = min(test_start + step_size, len(features_df))
                
                if test_end <= test_start:
                    break
                
                # Prepare data
                train_window = features_df.iloc[train_start:train_end]
                test_window = features_df.iloc[test_start:test_end]
                
                X_train = train_window[feature_cols].values
                y_train = train_window['target'].values if 'target' in train_window.columns else train_window['label'].values
                X_test = test_window[feature_cols].values
                y_test = test_window['target'].values if 'target' in test_window.columns else test_window['label'].values
                
                # Clone and retrain model
                from sklearn.base import clone
                model_clone = clone(model)
                model_clone.fit(X_train, y_train)
                
                # Predict and score
                y_pred = model_clone.predict(X_test)
                score = model_clone.score(X_test, y_test)
                scores.append(score)
                window_count += 1
                
            except Exception as e:
                logger.debug(f"Walk-forward window failed: {e}")
                continue
        
        if scores:
            wf_score = np.mean(scores)
            wf_std = np.std(scores)
            logger.debug(f"✅ Walk-forward validation: {wf_score:.3f} ± {wf_std:.3f} ({window_count} windows)")
        else:
            wf_score = 0
            wf_std = 0
            window_count = 0
        
        return {
            'wf_score': wf_score,
            'wf_std': wf_std,
            'wf_windows': window_count
        }
        
    except Exception as e:
        logger.warning(f"⚠️ Walk-forward validation failed: {e}")
        return {'wf_score': 0, 'wf_windows': 0}

def calculate_risk_metrics(y_true: np.ndarray, y_pred: np.ndarray, test_data: pd.DataFrame) -> Dict:
    """Calculate risk-related metrics for trading"""
    try:
        risk_metrics = {}
        
        # Basic risk metrics
        if 'close' in test_data.columns:
            returns = test_data['close'].pct_change().dropna()
            
            if len(returns) > 0:
                # Volatility
                risk_metrics['volatility'] = returns.std() * np.sqrt(252)
                
                # Maximum drawdown simulation
                cumulative_returns = (1 + returns).cumprod()
                rolling_max = cumulative_returns.expanding().max()
                drawdown = (cumulative_returns - rolling_max) / rolling_max
                risk_metrics['max_drawdown'] = drawdown.min()
                
                # Sharpe ratio approximation
                excess_returns = returns - 0.02/252  # Assuming 2% risk-free rate
                if returns.std() > 0:
                    risk_metrics['sharpe_ratio'] = (excess_returns.mean() / returns.std()) * np.sqrt(252)
                else:
                    risk_metrics['sharpe_ratio'] = 0
        
        # Prediction stability
        if len(y_pred) > 10:
            # Prediction variance
            pred_variance = np.var(y_pred)
            risk_metrics['prediction_variance'] = pred_variance
            
            # Prediction consistency (how often predictions change)
            pred_changes = np.diff(y_pred)
            risk_metrics['prediction_stability'] = 1 - (np.count_nonzero(pred_changes) / len(pred_changes))
        
        return risk_metrics
        
    except Exception as e:
        logger.warning(f"⚠️ Risk metrics calculation failed: {e}")
        return {}

def calculate_overall_score(metrics: Dict) -> float:
    """Calculate overall score from various metrics"""
    try:
        # Weights for different metrics
        weights = {
            'accuracy': 0.25,
            'precision': 0.20,
            'recall': 0.20,
            'f1_score': 0.15,
            'wf_score': 0.10,
            'sharpe_ratio': 0.05,
            'prediction_stability': 0.05
        }
        
        score = 0.0
        total_weight = 0.0
        
        for metric, weight in weights.items():
            if metric in metrics:
                value = metrics[metric]
                
                # Normalize some metrics
                if metric == 'sharpe_ratio':
                    # Normalize Sharpe ratio to 0-1 scale
                    value = max(0, min(1, (value + 2) / 4))
                elif metric in ['accuracy', 'precision', 'recall', 'f1_score', 'wf_score', 'prediction_stability']:
                    # These should already be in 0-1 range
                    value = max(0, min(1, value))
                
                score += value * weight
                total_weight += weight
        
        # Normalize by actual weights used
        if total_weight > 0:
            score = score / total_weight
        
        return max(0, min(1, score))
        
    except Exception as e:
        logger.warning(f"⚠️ Overall score calculation failed: {e}")
        return 0.0

def optimize_hyperparameters(models: Dict, features: Dict, config: Dict) -> Dict:
    """Optimize hyperparameters for the best models"""
    try:
        logger.info("🎯 Starting hyperparameter optimization...")
        
        from ai_optimizer.unified_optimizer import UnifiedOptimizer
        optimizer = UnifiedOptimizer()
        
        optimized_models = {}
        
        for timeframe, timeframe_models in models.items():
            if timeframe not in features:
                continue
            
            features_df = features[timeframe]
            if features_df.empty:
                continue
            
            logger.info(f"🔧 Optimizing models for {timeframe}...")
            
            timeframe_optimized = {}
            
            for model_name, model_data in timeframe_models.items():
                try:
                    # Skip optimization for simpler models or if disabled
                    if not config.get('hyperparameter_optimization', True):
                        timeframe_optimized[model_name] = model_data
                        continue
                    
                    # Perform optimization
                    optimized_model = optimize_single_model(
                        model_data, features_df, model_name, optimizer
                    )
                    
                    if optimized_model:
                        timeframe_optimized[model_name] = optimized_model
                        logger.debug(f"✅ {model_name} optimized")
                    else:
                        # Fall back to original model
                        timeframe_optimized[model_name] = model_data
                        logger.debug(f"⚠️ {model_name} optimization failed, using original")
                    
                except Exception as e:
                    logger.warning(f"⚠️ Optimization failed for {model_name}: {e}")
                    timeframe_optimized[model_name] = model_data
            
            optimized_models[timeframe] = timeframe_optimized
        
        logger.info("✅ Hyperparameter optimization completed")
        return optimized_models
        
    except Exception as e:
        logger.error(f"❌ Hyperparameter optimization failed: {e}")
        return models  # Return original models on failure

def optimize_single_model(model_data: Dict, features_df: pd.DataFrame, model_name: str, optimizer) -> Optional[Dict]:
    """Optimize a single model's hyperparameters"""
    try:
        model = model_data['model']
        
        # Prepare data
        feature_cols = [col for col in features_df.columns if col not in ['target', 'label']]
        X = features_df[feature_cols].values
        y = features_df['target'].values if 'target' in features_df.columns else features_df['label'].values
        
        # Split for optimization
        train_size = int(len(X) * 0.8)
        X_train, X_val = X[:train_size], X[train_size:]
        y_train, y_val = y[:train_size], y[train_size:]
        
        # Define hyperparameter search space based on model type
        param_space = get_hyperparameter_space(model_name)
        
        if not param_space:
            return None
        
        # Perform optimization (simplified version)
        best_score = -np.inf
        best_params = None
        
        # Random search with limited iterations
        max_iterations = 10
        
        for _ in range(max_iterations):
            # Sample random parameters
            params = sample_hyperparameters(param_space)
            
            try:
                # Create model with new parameters
                from ai_models.unified_ensemble import create_individual_model
                test_model = create_individual_model(model_name, params)
                
                if test_model is None:
                    continue
                
                # Train and evaluate
                test_model.fit(X_train, y_train)
                score = test_model.score(X_val, y_val)
                
                if score > best_score:
                    best_score = score
                    best_params = params
                    
            except Exception:
                continue
        
        # Return optimized model if improvement found
        if best_params and best_score > model_data.get('metrics', {}).get('accuracy', 0):
            from ai_models.unified_ensemble import create_individual_model
            optimized_model = create_individual_model(model_name, best_params)
            
            if optimized_model:
                # Retrain on full training data
                optimized_model.fit(X_train, y_train)
                
                # Update metrics
                val_pred = optimized_model.predict(X_val)
                from ai_models.unified_metrics import calculate_metrics_from_predictions
                new_metrics = calculate_metrics_from_predictions(y_val, val_pred)
                
                return {
                    'model': optimized_model,
                    'metrics': new_metrics,
                    'optimized_params': best_params,
                    'improvement': best_score - model_data.get('metrics', {}).get('accuracy', 0)
                }
        
        return None
        
    except Exception as e:
        logger.warning(f"⚠️ Single model optimization failed: {e}")
        return None

def get_hyperparameter_space(model_name: str) -> Dict:
    """Get hyperparameter search space for different model types"""
    spaces = {
        'random_forest': {
            'n_estimators': [50, 100, 200],
            'max_depth': [5, 10, 15, None],
            'min_samples_split': [2, 5, 10],
            'min_samples_leaf': [1, 2, 4]
        },
        'extra_trees': {
            'n_estimators': [50, 100, 150],
            'max_depth': [5, 10, 15, None],
            'min_samples_split': [2, 5, 10],
            'min_samples_leaf': [1, 2, 4]
        },
        'xgboost': {
            'n_estimators': [50, 100, 200],
            'max_depth': [3, 6, 9],
            'learning_rate': [0.01, 0.1, 0.2],
            'subsample': [0.8, 0.9, 1.0]
        },
        'lightgbm': {
            'n_estimators': [50, 100, 200],
            'max_depth': [3, 6, 9],
            'learning_rate': [0.01, 0.1, 0.2],
            'subsample': [0.8, 0.9, 1.0]
        }
    }
    
    return spaces.get(model_name, {})

def sample_hyperparameters(param_space: Dict) -> Dict:
    """Sample random hyperparameters from the search space"""
    import random
    
    params = {}
    
    for param_name, param_values in param_space.items():
        if isinstance(param_values, list):
            params[param_name] = random.choice(param_values)
        elif isinstance(param_values, tuple) and len(param_values) == 2:
            # Assume it's a range (min, max)
            if isinstance(param_values[0], float):
                params[param_name] = random.uniform(param_values[0], param_values[1])
            else:
                params[param_name] = random.randint(param_values[0], param_values[1])
    
    return params

def perform_backtesting(models: Dict, features: Dict, config: Dict) -> Dict:
    """Perform backtesting on the models"""
    try:
        logger.info("📈 Starting backtesting analysis...")
        
        backtesting_results = {}
        
        try:
            from backtesting.walk_forward import WalkForwardBacktester
            backtester = WalkForwardBacktester(config.get('backtesting_config', {}))
        except ImportError:
            logger.warning("⚠️ Backtesting module not available")
            return {}
        
        for timeframe, timeframe_models in models.items():
            if timeframe not in features:
                continue
            
            features_df = features[timeframe]
            if features_df.empty:
                continue
            
            logger.info(f"📊 Backtesting models for {timeframe}...")
            
            timeframe_results = {}
            
            for model_name, model_data in timeframe_models.items():
                try:
                    model = model_data['model']
                    
                    # Perform backtesting
                    backtest_result = backtester.backtest_model(
                        model, features_df, timeframe, model_name
                    )
                    
                    timeframe_results[model_name] = backtest_result
                    
                    logger.debug(f"✅ {model_name} backtested - Return: {backtest_result.get('total_return', 0):.2%}")
                    
                except Exception as e:
                    logger.warning(f"⚠️ Backtesting failed for {model_name}: {e}")
                    continue
            
            backtesting_results[timeframe] = timeframe_results
        
        logger.info("✅ Backtesting completed")
        return backtesting_results
        
    except Exception as e:
        logger.error(f"❌ Backtesting failed: {e}")
        return {}

def generate_validation_report(validation_results: Dict, config: Dict) -> Dict:
    """Generate a comprehensive validation report"""
    try:
        logger.info("📋 Generating validation report...")
        
        report = {
            'summary': {},
            'detailed_results': validation_results,
            'recommendations': [],
            'generated_at': datetime.now().isoformat()
        }
        
        # Summary statistics
        all_scores = []
        model_count = 0
        
        for timeframe, timeframe_results in validation_results.items():
            for model_name, metrics in timeframe_results.items():
                overall_score = metrics.get('overall_score', 0)
                all_scores.append(overall_score)
                model_count += 1
        
        if all_scores:
            report['summary'] = {
                'total_models': model_count,
                'average_score': np.mean(all_scores),
                'best_score': np.max(all_scores),
                'worst_score': np.min(all_scores),
                'score_std': np.std(all_scores)
            }
        
        # Generate recommendations
        recommendations = []
        
        if report['summary'].get('average_score', 0) < 0.6:
            recommendations.append("Consider improving feature engineering or trying different algorithms")
        
        if report['summary'].get('score_std', 0) > 0.2:
            recommendations.append("High variance in model performance - consider ensemble methods")
        
        if model_count < 3:
            recommendations.append("Consider training more diverse models for better ensemble performance")
        
        report['recommendations'] = recommendations
        
        logger.info("✅ Validation report generated")
        return report
        
    except Exception as e:
        logger.error(f"❌ Validation report generation failed: {e}")
        return {'error': str(e)}
