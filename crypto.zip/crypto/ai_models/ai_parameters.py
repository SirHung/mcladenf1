"""
AI Parameter Calculator Module
Chứa tất cả logic tính toán parameters thông minh, loại bỏ hardcode.

Module này được tách từ ai_logic.py để tối ưu hóa và dễ bảo trì.
"""

import numpy as np
import pandas as pd
import time
from typing import Dict, Any, Optional, Tuple, Union
from config.logging_config import get_logger
from ai_optimizer.unified_resource_manager import get_resource_manager

logger = get_logger('ai_parameters') 

# Import AI modules khi available
try:
    from ai_optimizer.unified_optimizer import UnifiedOptimizer
    unified_optimizer = UnifiedOptimizer()
except ImportError:
    unified_optimizer = None

class AIParameterCalculator:
    """
    Centralized AI-driven parameter calculator
    Loại bỏ toàn bộ hardcode, thay thế bằng AI-driven calculations
    """
    
    def __init__(self, optimizer: Optional['UnifiedOptimizer'] = None):
        self.optimizer = optimizer or unified_optimizer
        self.logger = get_logger('ai_parameter_calculator')
        self.market_cache = {}
        self.parameter_cache = {}
        self.cache_timeout = 300  # 5 minutes cache timeout
        
    def calculate_confidence_threshold(self, market_data: pd.DataFrame, symbol: str, 
                                     timeframe: str, model_performance: Optional[Dict] = None) -> float:
        """Calculate dynamic confidence threshold based on market conditions and model performance"""
        try:
            cache_key = f"confidence_{symbol}_{timeframe}"
            if self._is_cache_valid(cache_key):
                return self.parameter_cache[cache_key]['value']
                
            # Base confidence calculation using market volatility
            if len(market_data) >= 20:
                returns = market_data['close'].pct_change().dropna()
                volatility = returns.std()
                volume_stability = 1.0 / (1.0 + market_data['volume'].pct_change().dropna().std())
            else:
                volatility = 0.02  # Default volatility
                volume_stability = 0.7
                
            # Base threshold inversely related to volatility
            base_threshold = 0.4 + (volatility * 5)  # Range: 0.4-0.9
            base_threshold = np.clip(base_threshold, 0.35, 0.85)
            
            # Adjust for timeframe (longer timeframes = lower threshold needed)
            timeframe_multiplier = self._get_timeframe_confidence_multiplier(timeframe)
            adjusted_threshold = base_threshold * timeframe_multiplier
            
            # Adjust for model performance if available
            if model_performance:
                avg_accuracy = np.mean([perf.get('accuracy', 0.5) for perf in model_performance.values()])
                performance_bonus = (avg_accuracy - 0.5) * 0.4  # Up to 0.2 bonus
                adjusted_threshold = max(0.3, adjusted_threshold - performance_bonus)
            
            # Adjust for volume stability
            final_threshold = adjusted_threshold * (0.8 + 0.4 * volume_stability)
            final_threshold = np.clip(final_threshold, 0.25, 0.9)
            
            self._cache_parameter(cache_key, final_threshold)
            self.logger.debug(f"Calculated confidence threshold for {symbol}@{timeframe}: {final_threshold:.3f}")
            return final_threshold
            
        except Exception as e:
            self.logger.warning(f"Failed to calculate confidence threshold: {e}")
            return 0.55  # Safe fallback
    
    def calculate_atr_multipliers(self, market_data: pd.DataFrame, direction: str, 
                                symbol: str) -> Tuple[float, float]:
        """Calculate dynamic ATR multipliers for TP and SL based on market conditions"""
        try:
            cache_key = f"atr_mult_{symbol}_{direction}"
            if self._is_cache_valid(cache_key):
                cached = self.parameter_cache[cache_key]['value']
                return cached['tp_mult'], cached['sl_mult']
                
            # Market regime analysis
            regime = self._analyze_market_regime(market_data)
            
            # Base multipliers based on volatility
            if regime['volatility'] == 'HIGH':
                base_tp_mult = 1.8 + (regime['vol_ratio'] - 1.5) * 0.5
                base_sl_mult = 1.3 + (regime['vol_ratio'] - 1.5) * 0.2
            elif regime['volatility'] == 'LOW':
                base_tp_mult = 2.5 - (1.0 - regime['vol_ratio']) * 0.3
                base_sl_mult = 1.0 + (1.0 - regime['vol_ratio']) * 0.3
            else:
                base_tp_mult = 2.2
                base_sl_mult = 1.2
                
            # Trend-based adjustments
            trend_strength = regime['trend_strength']
            if trend_strength > 0.7:  # Strong trend
                if (direction in ['LONG', 'BUY'] and regime['trend_direction'] > 0) or \
                   (direction in ['SHORT', 'SELL'] and regime['trend_direction'] < 0):
                    # Trading with trend
                    tp_mult = base_tp_mult * (1.0 + trend_strength * 0.3)
                    sl_mult = base_sl_mult * (1.0 - trend_strength * 0.2)
                else:
                    # Trading against trend
                    tp_mult = base_tp_mult * (1.0 - trend_strength * 0.2)
                    sl_mult = base_sl_mult * (1.0 + trend_strength * 0.3)
            else:
                tp_mult = base_tp_mult
                sl_mult = base_sl_mult
                
            # Volume confirmation adjustment
            if regime['volume_confirmation'] > 1.3:
                tp_mult *= 1.1  # More aggressive with volume confirmation
            elif regime['volume_confirmation'] < 0.8:
                tp_mult *= 0.95  # More conservative with low volume
                sl_mult *= 0.9
                
            # Clamp values to reasonable ranges
            tp_mult = np.clip(tp_mult, 1.2, 4.0)
            sl_mult = np.clip(sl_mult, 0.8, 2.5)
            
            result = {'tp_mult': tp_mult, 'sl_mult': sl_mult}
            self._cache_parameter(cache_key, result)
            
            self.logger.debug(f"Calculated ATR multipliers for {symbol} {direction}: TP={tp_mult:.2f}, SL={sl_mult:.2f}")
            return tp_mult, sl_mult
            
        except Exception as e:
            self.logger.warning(f"Failed to calculate ATR multipliers: {e}")
            return 2.0, 1.2  # Safe fallback
    
    def calculate_pattern_thresholds(self, market_data: Union[pd.DataFrame, Dict[Tuple[str, str], pd.DataFrame]], pattern_type: str) -> Union[Dict[str, float], Dict[Tuple[str, str], Dict[str, float]]]:
        """
        Calculate dynamic thresholds for pattern recognition.
        Hỗ trợ đa luồng qua resource_manager nếu market_data là dict nhiều symbol/timeframe.
        """
        try:
            resource_manager = get_resource_manager()
            if isinstance(market_data, dict):
                def process_func(args):
                    (symbol, timeframe), df = args
                    return (symbol, timeframe), self.calculate_pattern_thresholds(df, pattern_type)
                results = resource_manager.safe_process_batches(
                    list(market_data.items()),
                    process_func=process_func,
                    batch_size=1
                )
                return dict(results)
            # Xử lý bình thường nếu là DataFrame đơn
            cache_key = f"pattern_{pattern_type}_{len(market_data)}"
            if self._is_cache_valid(cache_key):
                return self.parameter_cache[cache_key]['value']
                
            regime = self._analyze_market_regime(market_data)
            volatility = regime['vol_ratio']
            
            # Base thresholds adjusted by volatility
            base_thresholds = {
                'triangle': {
                    'trend_threshold': 0.001 * (1 + volatility * 0.5)
                },
                'flag': {
                    'volume_threshold': 1.5 * (1 - min(volatility * 0.2, 0.3)),
                    'trend_strength': 0.02 * (1 + volatility * 0.3)
                },
                'pennant': {
                    'convergence_rate': 0.001 * (1 + volatility * 0.4)
                },
                'wedge': {
                    'wedge_threshold': 0.001 * (1 + volatility * 0.3)
                },
                'double_top': {
                    'similarity_threshold': 0.02 * (1 + volatility * 0.5),
                    'min_distance': max(8, int(15 / (1 + volatility)))
                },
                'double_bottom': {
                    'similarity_threshold': 0.02 * (1 + volatility * 0.5),
                    'min_distance': max(8, int(15 / (1 + volatility)))
                },
                'triple_top': {
                    'similarity_threshold': 0.015 * (1 + volatility * 0.4),
                    'min_distance': max(6, int(12 / (1 + volatility)))
                },
                'triple_bottom': {
                    'similarity_threshold': 0.015 * (1 + volatility * 0.4),
                    'min_distance': max(6, int(12 / (1 + volatility)))
                },
                'rectangle': {
                    'horizontal_threshold': 0.005 * (1 + volatility * 0.6),
                    'min_touches': max(3, int(5 / (1 + volatility * 0.3)))
                }
            }
            
            thresholds = base_thresholds.get(pattern_type, {})
            self._cache_parameter(cache_key, thresholds)
            
            return thresholds
            
        except Exception as e:
            self.logger.warning(f"Failed to calculate pattern thresholds for {pattern_type}: {e}")
            return {}
    
    def calculate_indicator_parameters(self, market_data: Union[pd.DataFrame, Dict[Tuple[str, str], pd.DataFrame]]) -> Union[Dict[str, int], Dict[Tuple[str, str], Dict[str, int]]]:
        """
        Calculate dynamic parameters for technical indicators.
        Hỗ trợ đa luồng qua resource_manager nếu market_data là dict nhiều symbol/timeframe.
        """
        try:
            resource_manager = get_resource_manager()
            if isinstance(market_data, dict):
                def process_func(args):
                    (symbol, timeframe), df = args
                    return (symbol, timeframe), self.calculate_indicator_parameters(df)
                results = resource_manager.safe_process_batches(
                    list(market_data.items()),
                    process_func=process_func,
                    batch_size=1
                )
                return dict(results)
            # Xử lý bình thường nếu là DataFrame đơn
            cache_key = f"indicators_{len(market_data)}"
            if self._is_cache_valid(cache_key):
                return self.parameter_cache[cache_key]['value']
                
            regime = self._analyze_market_regime(market_data)
            volatility = regime['vol_ratio']
            
            # Adjust periods based on volatility
            if volatility > 1.3:  # High volatility - shorter periods
                rsi_period = max(10, int(14 / (1 + (volatility - 1) * 0.3)))
                ma_fast = max(7, int(10 / (1 + (volatility - 1) * 0.2)))
                ma_slow = max(30, int(50 / (1 + (volatility - 1) * 0.2)))
            elif volatility < 0.8:  # Low volatility - longer periods
                rsi_period = min(21, int(14 * (1 + (1 - volatility) * 0.4)))
                ma_fast = min(15, int(10 * (1 + (1 - volatility) * 0.3)))
                ma_slow = min(70, int(50 * (1 + (1 - volatility) * 0.3)))
            else:
                rsi_period = 14
                ma_fast = 10
                ma_slow = 50
                
            params = {
                'rsi_period': rsi_period,
                'ma_fast': ma_fast,
                'ma_slow': ma_slow
            }
            
            self._cache_parameter(cache_key, params)
            return params
            
        except Exception as e:
            self.logger.warning(f"Failed to calculate indicator parameters: {e}")
            return {'rsi_period': 14, 'ma_fast': 10, 'ma_slow': 50}
    
    def _analyze_market_regime(self, market_data: pd.DataFrame) -> Dict[str, Any]:
        """Analyze current market regime"""
        try:
            # Volatility analysis
            returns = market_data['close'].pct_change().dropna()
            short_vol = returns.rolling(10).std().iloc[-1]
            long_vol = returns.rolling(50).std().iloc[-1]
            vol_ratio = short_vol / long_vol if long_vol > 0 else 1.0
            
            if vol_ratio > 1.5:
                volatility = 'HIGH'
            elif vol_ratio < 0.7:
                volatility = 'LOW'
            else:
                volatility = 'NORMAL'
                
            # Trend analysis
            if len(market_data) >= 20:
                trend_10 = (market_data['close'].iloc[-1] / market_data['close'].iloc[-10] - 1)
                trend_20 = (market_data['close'].iloc[-1] / market_data['close'].iloc[-20] - 1)
                trend_direction = (trend_10 + trend_20) / 2
                trend_strength = min(abs(trend_10) + abs(trend_20), 1.0)
            else:
                trend_direction = 0
                trend_strength = 0
                
            # Volume analysis
            if 'volume' in market_data.columns:
                recent_vol = market_data['volume'].tail(5).mean()
                avg_vol = market_data['volume'].tail(20).mean()
                volume_confirmation = recent_vol / (avg_vol + 1e-8)
            else:
                volume_confirmation = 1.0
                
            return {
                'volatility': volatility,
                'vol_ratio': vol_ratio,
                'trend_direction': trend_direction,
                'trend_strength': trend_strength,
                'volume_confirmation': volume_confirmation
            }
            
        except Exception as e:
            self.logger.warning(f"Market regime analysis failed: {e}")
            return self._get_default_regime()
    
    def _get_default_regime(self) -> Dict[str, Any]:
        """Get default market regime when analysis fails"""
        return {
            'volatility': 'NORMAL',
            'vol_ratio': 1.0,
            'trend_direction': 0.0,
            'trend_strength': 0.5,
            'volume_confirmation': 1.0
        }
    
    def _get_timeframe_confidence_multiplier(self, timeframe: str) -> float:
        """Get timeframe-specific confidence multiplier"""
        multipliers = {
            '1m': 1.3,   # Higher threshold for very short term
            '5m': 1.15,
            '15m': 1.0,  # Baseline
            '30m': 0.95,
            '1h': 0.9,
            '4h': 0.85,
            '1d': 0.8,   # Lower threshold for longer term
            '1w': 0.75
        }
        return multipliers.get(timeframe, 1.0)
    
    def _is_cache_valid(self, key: str) -> bool:
        """Check if cached parameter is still valid"""
        if key not in self.parameter_cache:
            return False
        cache_time = self.parameter_cache[key]['timestamp']
        return (time.time() - cache_time) < self.cache_timeout
    
    def _cache_parameter(self, key: str, value: Any) -> None:
        """Cache calculated parameter"""
        self.parameter_cache[key] = {
            'value': value,
            'timestamp': time.time()
        }

def get_timeframe_parameters(timeframe: str, market_data: pd.DataFrame = None, symbol: str = "BTCUSDT") -> Dict[str, Any]:
    """
    Get AI-driven parameters specific to timeframe
    Loại bỏ hardcode, tính toán dựa trên market data
    """
    try:
        # Initialize parameter calculator if available
        calculator = AIParameterCalculator()
        
        if market_data is not None and len(market_data) > 0:
            # Calculate based on market data
            regime = calculator._analyze_market_regime(market_data)
            volatility = regime['vol_ratio']
        else:
            volatility = 1.0  # Default
            
        # Base timeframe parameters
        base_params = {
            '1m': {'lookback': 60, 'prediction_window': 5},
            '5m': {'lookback': 288, 'prediction_window': 12},
            '15m': {'lookback': 192, 'prediction_window': 8},
            '30m': {'lookback': 144, 'prediction_window': 6},
            '1h': {'lookback': 168, 'prediction_window': 4},
            '4h': {'lookback': 180, 'prediction_window': 3},
            '1d': {'lookback': 90, 'prediction_window': 2},
            '1w': {'lookback': 52, 'prediction_window': 1}
        }
        
        params = base_params.get(timeframe, base_params['1h'])
        
        # Adjust for volatility
        if volatility > 1.3:  # High volatility
            params['lookback'] = int(params['lookback'] * 0.8)  # Shorter lookback
            params['prediction_window'] = max(1, int(params['prediction_window'] * 0.7))
        elif volatility < 0.8:  # Low volatility
            params['lookback'] = int(params['lookback'] * 1.2)  # Longer lookback
            params['prediction_window'] = int(params['prediction_window'] * 1.3)
            
        # Add AI-calculated confidence threshold
        if market_data is not None:
            params['confidence_threshold'] = calculator.calculate_confidence_threshold(
                market_data, symbol, timeframe
            )
        else:
            params['confidence_threshold'] = 0.55
            
        logger.debug(f"Timeframe parameters for {timeframe}: {params}")
        return params
        
    except Exception as e:
        logger.error(f"Failed to calculate timeframe parameters: {e}")
        # Fallback to safe defaults
        return {
            'lookback': 100,
            'prediction_window': 3,
            'confidence_threshold': 0.55
        }

def suggest_tp_sl(df: pd.DataFrame, direction: str, symbol: str = "BTCUSDT",
                  market_data: pd.DataFrame = None, use_dynamic: bool = True) -> Dict[str, Any]:
    """
    AI-DRIVEN Take Profit and Stop Loss Calculator
    Loại bỏ toàn bộ hardcode, sử dụng AI để tính toán mọi tham số
    """
    try:
        logger.info(f"🎯 AI-driven TP/SL calculation for {symbol} {direction}")
        
        # Use market data or fall back to df
        data_to_use = market_data if market_data is not None else df
        
        if len(data_to_use) < 14:
            logger.warning("Insufficient data for TP/SL calculation")
            return {
                "TP": None,
                "SL": None,
                "ATR": None,
                "error": "Insufficient data"
            }
            
        # Initialize AI parameter calculator
        calculator = AIParameterCalculator()
        
        # Current price
        current_price = data_to_use['close'].iloc[-1]
        
        # Calculate ATR with dynamic period
        regime = calculator._analyze_market_regime(data_to_use)
        volatility = regime['vol_ratio']
        
        # Dynamic ATR period based on volatility
        if volatility > 1.3:
            atr_period = max(10, int(14 / (1 + (volatility - 1) * 0.3)))
        elif volatility < 0.8:
            atr_period = min(21, int(14 * (1 + (1 - volatility) * 0.4)))
        else:
            atr_period = 14
            
        # Calculate ATR
        high_low = data_to_use['high'] - data_to_use['low']
        high_close = np.abs(data_to_use['high'] - data_to_use['close'].shift())
        low_close = np.abs(data_to_use['low'] - data_to_use['close'].shift())
        true_range = np.maximum(high_low, np.maximum(high_close, low_close))
        atr = true_range.rolling(window=atr_period).mean().iloc[-1]
        
        if np.isnan(atr) or atr <= 0:
            atr = current_price * 0.02  # 2% fallback
            
        # Get AI-calculated multipliers
        tp_mult, sl_mult = calculator.calculate_atr_multipliers(data_to_use, direction, symbol)
        
        # Calculate TP and SL
        if direction.upper() in ['LONG', 'BUY']:
            tp = current_price + (atr * tp_mult)
            sl = current_price - (atr * sl_mult)
        else:  # SHORT/SELL
            tp = current_price - (atr * tp_mult)
            sl = current_price + (atr * sl_mult)
            
        # Additional market-based adjustments
        if regime['volume_confirmation'] < 0.7:
            # Low volume - more conservative targets
            tp_distance = abs(tp - current_price) * 0.8
            sl_distance = abs(sl - current_price) * 1.1
            
            if direction.upper() in ['LONG', 'BUY']:
                tp = current_price + tp_distance
                sl = current_price - sl_distance
            else:
                tp = current_price - tp_distance
                sl = current_price + sl_distance
                
        # Risk-reward ratio check
        tp_distance = abs(tp - current_price)
        sl_distance = abs(sl - current_price)
        risk_reward = tp_distance / sl_distance if sl_distance > 0 else 2.0
        
        # Adjust if risk-reward is too low
        if risk_reward < 1.5:
            adjustment = 1.5 / risk_reward
            if direction.upper() in ['LONG', 'BUY']:
                tp = current_price + (tp_distance * adjustment)
            else:
                tp = current_price - (tp_distance * adjustment)
                
        result = {
            "TP": round(tp, 8),
            "SL": round(sl, 8),
            "ATR": round(atr, 8),
            "atr_period": atr_period,
            "tp_multiplier": tp_mult,
            "sl_multiplier": sl_mult,
            "risk_reward_ratio": round(tp_distance / sl_distance, 2),
            "market_regime": regime,
            "calculation_method": "AI-driven",
            "confidence": min(0.95, 0.7 + (risk_reward - 1.5) * 0.1)
        }
        
        logger.info(f"✅ TP/SL calculated: TP={tp:.4f}, SL={sl:.4f}, RR={result['risk_reward_ratio']}")
        return result
        
    except Exception as e:
        logger.error(f"❌ TP/SL calculation failed: {e}")
        return {
            "TP": None,
            "SL": None,
            "ATR": None,
            "error": str(e)
        }

def calculate_data_characteristics(data: Union[pd.DataFrame, Dict[str, pd.DataFrame]]) -> Dict[str, Any]:
    """
    Calculate comprehensive data characteristics for AI-driven parameter optimization
    (Đa luồng qua resource_manager nếu là dict nhiều timeframe)
    """
    try:
        resource_manager = get_resource_manager()
        if isinstance(data, dict):
            # Multi-timeframe data
            characteristics = {}
            total_samples = 0
            avg_volatility = 0
            timeframes = []

            def process_tf(args):
                tf, df = args
                if df is not None and len(df) > 0:
                    return tf, _calculate_single_df_characteristics(df)
                return tf, {}

            results = resource_manager.safe_process_batches(
                list(data.items()),
                process_func=process_tf,
                batch_size=1
            )
            for tf, tf_chars in results:
                if tf_chars:
                    characteristics[tf] = tf_chars
                    total_samples += tf_chars.get('samples', 0)
                    avg_volatility += tf_chars.get('volatility', 0)
                    timeframes.append(tf)
            avg_volatility = avg_volatility / len(timeframes) if timeframes else 0

            return {
                'type': 'multi_timeframe',
                'timeframes': timeframes,
                'total_samples': total_samples,
                'avg_volatility': avg_volatility,
                'timeframe_characteristics': characteristics
            }
        else:
            # Single DataFrame
            return {
                'type': 'single_timeframe',
                **_calculate_single_df_characteristics(data)
            }

    except Exception as e:
        logger.error(f"Failed to calculate data characteristics: {e}")
        return {'type': 'unknown', 'error': str(e)}

def _calculate_single_df_characteristics(df: pd.DataFrame) -> Dict[str, Any]:
    """Calculate characteristics for a single DataFrame"""
    try:
        if df is None or len(df) == 0:
            return {}
            
        characteristics = {
            'samples': len(df),
            'timespan_days': 0,
            'volatility': 0,
            'trend_strength': 0,
            'data_quality': 'unknown'
        }
        
        if 'close' in df.columns:
            # Volatility
            returns = df['close'].pct_change().dropna()
            characteristics['volatility'] = returns.std()
            
            # Trend strength
            if len(df) >= 20:
                trend = (df['close'].iloc[-1] / df['close'].iloc[-20] - 1)
                characteristics['trend_strength'] = abs(trend)
                
        # Timespan
        if 'timestamp' in df.columns:
            try:
                start_time = pd.to_datetime(df['timestamp'].iloc[0])
                end_time = pd.to_datetime(df['timestamp'].iloc[-1])
                characteristics['timespan_days'] = (end_time - start_time).days
            except:
                pass
                
        # Data quality assessment
        missing_ratio = df.isnull().sum().sum() / (len(df) * len(df.columns))
        if missing_ratio < 0.01:
            characteristics['data_quality'] = 'high'
        elif missing_ratio < 0.05:
            characteristics['data_quality'] = 'medium'
        else:
            characteristics['data_quality'] = 'low'
            
        return characteristics
        
    except Exception as e:
        logger.error(f"Failed to calculate single DataFrame characteristics: {e}")
        return {}

def calculate_data_characteristics_memory_safe(data: Union[pd.DataFrame, Dict[str, pd.DataFrame], str], batch_size: int = 100_000, use_gpu: bool = True, max_ram_usage: float = 0.9, wait_time: int = 180, **kwargs) -> Dict[str, Any]:
    """
    Memory-safe, multi-threaded, GPU-ready data characteristics calculation for large DataFrames or file paths.
    - data: DataFrame, dict of DataFrames, hoặc đường dẫn file (csv/parquet)
    - batch_size: số dòng mỗi batch
    - use_gpu: ưu tiên GPU nếu có
    - max_ram_usage: ngưỡng RAM tối đa
    - wait_time: thời gian chờ khi thiếu RAM
    """
    resource_manager = get_resource_manager()
    logger.info(f"🔍 [MemorySafe] Bắt đầu tính toán đặc trưng dữ liệu (batch={batch_size}, GPU={use_gpu})")

    def process_batch(batch_df):
        try:
            if use_gpu:
                try:
                    import cudf
                    batch_df = cudf.DataFrame.from_pandas(batch_df)
                except ImportError:
                    pass
        except Exception as e:
            logger.warning(f"Không thể chuyển batch sang GPU: {e}")
        # Tính toán đặc trưng từng batch
        return _calculate_single_df_characteristics(batch_df)

    # Nếu là dict multi-timeframe
    if isinstance(data, dict):
        characteristics = {}
        total_samples = 0
        avg_volatility = 0
        timeframes = []
        for tf, df in data.items():
            if df is not None and len(df) > 0:
                chars = calculate_data_characteristics_memory_safe(df, batch_size, use_gpu, max_ram_usage, wait_time, **kwargs)
                characteristics[tf] = chars
                total_samples += chars.get('samples', 0)
                avg_volatility += chars.get('volatility', 0)
                timeframes.append(tf)
        avg_volatility = avg_volatility / len(timeframes) if timeframes else 0
        return {
            'type': 'multi_timeframe',
            'timeframes': timeframes,
            'total_samples': total_samples,
            'avg_volatility': avg_volatility,
            'timeframe_characteristics': characteristics
        }
    # Nếu là file path hoặc DataFrame lớn
    results = resource_manager.safe_process_batches(
        data,
        process_func=process_batch,
        batch_size=batch_size,
        max_ram_usage=max_ram_usage,
        wait_time=wait_time,
        **kwargs
    )
    # Gộp lại đặc trưng các batch
    if results:
        # Gộp các đặc trưng lại (lấy trung bình, tổng, v.v.)
        total_samples = sum(r.get('samples', 0) for r in results)
        avg_volatility = np.mean([r.get('volatility', 0) for r in results if 'volatility' in r]) if results else 0
        trend_strength = np.mean([r.get('trend_strength', 0) for r in results if 'trend_strength' in r]) if results else 0
        data_quality = min([r.get('data_quality', 'high') for r in results]) if results else 'unknown'
        return {
            'type': 'single_timeframe',
            'samples': total_samples,
            'volatility': avg_volatility,
            'trend_strength': trend_strength,
            'data_quality': data_quality
        }
    else:
        logger.error(f"❌ [MemorySafe] Không có batch nào được xử lý thành công!")
        return {'type': 'unknown', 'error': 'No batch processed'}

def get_system_resources() -> Dict[str, Any]:
    """
    Get current system resource status for AI-driven resource optimization
    """
    try:
        import psutil
        import GPUtil
        
        # CPU info
        cpu_percent = psutil.cpu_percent(interval=1)
        cpu_count = psutil.cpu_count()
        
        # Memory info
        memory = psutil.virtual_memory()
        memory_percent = memory.percent
        memory_available_gb = memory.available / (1024**3)
        
        # GPU info
        gpu_info = []
        try:
            gpus = GPUtil.getGPUs()
            for gpu in gpus:
                gpu_info.append({
                    'id': gpu.id,
                    'name': gpu.name,
                    'memory_used': gpu.memoryUsed,
                    'memory_total': gpu.memoryTotal,
                    'memory_percent': (gpu.memoryUsed / gpu.memoryTotal) * 100,
                    'load': gpu.load * 100,
                    'temperature': gpu.temperature
                })
        except:
            pass
            
        # Disk info
        disk = psutil.disk_usage('/')
        disk_percent = (disk.used / disk.total) * 100
        
        return {
            'cpu': {
                'usage_percent': cpu_percent,
                'count': cpu_count,
                'available_cores': max(1, cpu_count - int(cpu_count * cpu_percent / 100))
            },
            'memory': {
                'usage_percent': memory_percent,
                'available_gb': memory_available_gb,
                'total_gb': memory.total / (1024**3)
            },
            'gpu': {
                'available': len(gpu_info) > 0,
                'count': len(gpu_info),
                'gpus': gpu_info
            },
            'disk': {
                'usage_percent': disk_percent,
                'free_gb': disk.free / (1024**3)
            },
            'recommendations': _get_resource_recommendations(cpu_percent, memory_percent, gpu_info)
        }
        
    except Exception as e:
        logger.error(f"Failed to get system resources: {e}")
        return {
            'cpu': {'usage_percent': 50, 'count': 4},
            'memory': {'usage_percent': 60, 'available_gb': 4},
            'gpu': {'available': False, 'count': 0},
            'error': str(e)
        }

def _get_resource_recommendations(cpu_percent: float, memory_percent: float, gpu_info: list) -> Dict[str, str]:
    """Generate resource usage recommendations"""
    recommendations = {}
    
    if cpu_percent > 80:
        recommendations['cpu'] = 'HIGH_USAGE - Consider reducing parallel workers'
    elif cpu_percent < 30:
        recommendations['cpu'] = 'LOW_USAGE - Can increase parallel workers'
    else:
        recommendations['cpu'] = 'OPTIMAL'
        
    if memory_percent > 85:
        recommendations['memory'] = 'HIGH_USAGE - Consider data batching or memory cleanup'
    elif memory_percent < 50:
        recommendations['memory'] = 'LOW_USAGE - Can load more data into memory'
    else:
        recommendations['memory'] = 'OPTIMAL'
        
    if gpu_info:
        max_gpu_usage = max(gpu['memory_percent'] for gpu in gpu_info)
        if max_gpu_usage > 90:
            recommendations['gpu'] = 'HIGH_USAGE - Consider reducing batch size'
        elif max_gpu_usage < 30:
            recommendations['gpu'] = 'LOW_USAGE - Can increase batch size or model complexity'
        else:
            recommendations['gpu'] = 'OPTIMAL'
    else:
        recommendations['gpu'] = 'NOT_AVAILABLE'
        
    return recommendations

def get_adaptive_model_config(data: Union[pd.DataFrame, Dict[str, pd.DataFrame]] = None,
                            system_resources: Dict[str, Any] = None,
                            training_mode: str = 'standard') -> Dict[str, Any]:
    """
    Get AI-driven adaptive model configuration based on data and system resources
    Completely removes hardcoded values, replaces with intelligent calculations
    """
    try:
        logger.info(f"🤖 Calculating adaptive model config for {training_mode} mode")
        
        # Get data characteristics
        data_chars = calculate_data_characteristics(data) if data else {}
        
        # Get system resources
        if system_resources is None:
            system_resources = get_system_resources()
            
        # Base configuration calculation
        config = _calculate_base_model_config(data_chars, system_resources, training_mode)
        
        # Apply intelligent adjustments
        config = _apply_intelligent_adjustments(config, data_chars, system_resources)
        
        logger.info(f"✅ Adaptive model config generated: {len(config.get('models', {}))} models selected")
        return config
        
    except Exception as e:
        logger.error(f"❌ Failed to generate adaptive model config: {e}")
        return _get_fallback_config()

def _calculate_base_model_config(data_chars: Dict, system_resources: Dict, training_mode: str) -> Dict[str, Any]:
    """Calculate base model configuration"""
    config = {
        'models': {},
        'training_params': {},
        'resource_allocation': {}
    }
    
    # Determine optimal model selection based on data size
    total_samples = data_chars.get('total_samples', data_chars.get('samples', 1000))
    
    # Model selection strategy
    if total_samples < 500:
        # Small dataset - simple models
        selected_models = ['LogisticRegression', 'RandomForest', 'AdaBoost']
        max_complexity = 'low'
    elif total_samples < 5000:
        # Medium dataset - balanced selection
        selected_models = ['LogisticRegression', 'RandomForest', 'XGBoost', 'LightGBM']
        max_complexity = 'medium'
    else:
        # Large dataset - full selection
        selected_models = ['RandomForest', 'XGBoost', 'LightGBM', 'CatBoost', 'NeuralNetwork']
        max_complexity = 'high'
        
    # Adjust for training mode
    if training_mode == 'quick':
        selected_models = selected_models[:2]  # Only top 2 models
    elif training_mode == 'deep':
        selected_models.extend(['ExtraTrees', 'GradientBoosting'])
        
    # GPU availability affects model selection
    gpu_available = system_resources.get('gpu', {}).get('available', False)
    if gpu_available:
        # Prioritize GPU-friendly models
        gpu_models = ['XGBoost', 'LightGBM', 'CatBoost', 'NeuralNetwork']
        selected_models = [m for m in gpu_models if m in selected_models] + \
                         [m for m in selected_models if m not in gpu_models]
                         
    config['selected_models'] = selected_models
    config['max_complexity'] = max_complexity
    
    return config

def _apply_intelligent_adjustments(config: Dict, data_chars: Dict, system_resources: Dict) -> Dict[str, Any]:
    """Apply intelligent adjustments based on data and system characteristics"""
    
    # Memory-based adjustments
    memory_available = system_resources.get('memory', {}).get('available_gb', 4)
    if memory_available < 2:
        # Low memory - reduce model complexity
        config['memory_constrained'] = True
        config['batch_processing'] = True
    elif memory_available > 8:
        # High memory - can afford more complex models
        config['memory_abundant'] = True
        config['parallel_processing'] = True
        
    # Volatility-based adjustments
    volatility = data_chars.get('volatility', data_chars.get('avg_volatility', 0.02))
    if volatility > 0.05:
        # High volatility - prefer ensemble methods
        config['ensemble_weight'] = 1.2
        config['stability_focus'] = True
    elif volatility < 0.01:
        # Low volatility - can use more sensitive models
        config['sensitivity_boost'] = True
        
    # CPU-based worker calculation
    cpu_info = system_resources.get('cpu', {})
    available_cores = cpu_info.get('available_cores', cpu_info.get('count', 4))
    config['optimal_workers'] = max(1, min(available_cores, 8))
    
    return config

def _get_fallback_config() -> Dict[str, Any]:
    """Get safe fallback configuration when AI calculation fails"""
    return {
        'selected_models': ['LogisticRegression', 'RandomForest'],
        'max_complexity': 'low',
        'optimal_workers': 2,
        'memory_constrained': True,
        'fallback': True
    }

# Initialize global AI parameter calculator
ai_parameter_calculator = None

def get_parameter_calculator() -> Optional[AIParameterCalculator]:
    """Get the global AI parameter calculator instance"""
    global ai_parameter_calculator
    if ai_parameter_calculator is None:
        ai_parameter_calculator = AIParameterCalculator()
        logger.info("✅ AI Parameter Calculator initialized")
    return ai_parameter_calculator

def set_parameter_calculator(calculator: AIParameterCalculator):
    """Set the global AI parameter calculator instance"""
    global ai_parameter_calculator
    ai_parameter_calculator = calculator
    logger.info("✅ AI Parameter Calculator set globally")
