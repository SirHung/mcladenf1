# ai_models/unified_metrics.py
"""
Unified Metrics Module
Consolidates all duplicate sklearn metrics imports and calculations
"""

import numpy as np
import pandas as pd
from typing import Dict, Any, Union
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score, 
    balanced_accuracy_score, precision_recall_curve, roc_auc_score
)
from config.logging_config import get_logger

logger = get_logger('unified_metrics')

# Centralized metric function mapping
METRIC_FUNCTIONS = {
    'accuracy': accuracy_score,
    'precision': precision_score,
    'recall': recall_score,
    'f1': f1_score,
    'balanced_accuracy': balanced_accuracy_score
}

def compute_comprehensive_metrics(model, X: pd.DataFrame, y: pd.Series, 
                                 threshold: float = None) -> Dict[str, Any]:
    """
    Unified comprehensive metrics computation function.
    Replaces duplicate compute_metrics functions across modules.
    """
    try:
        labels = np.unique(y)
        
        if len(labels) == 2 and hasattr(model, "predict_proba"):
            # Binary classification with probability
            y_proba = model.predict_proba(X)[:, 1]
            if threshold is None:
                threshold = optimize_simple_threshold(y, y_proba)
            y_pred = (y_proba >= threshold).astype(int)
        else:
            # Multiclass or binary without probability
            y_pred = model.predict(X)
            threshold = 0.5
          # Compute all metrics using centralized functions
        metrics = {
            "accuracy": METRIC_FUNCTIONS['accuracy'](y, y_pred),
            "precision": METRIC_FUNCTIONS['precision'](y, y_pred, average='weighted', zero_division=0),
            "recall": METRIC_FUNCTIONS['recall'](y, y_pred, average='weighted', zero_division=0),
            "f1": METRIC_FUNCTIONS['f1'](y, y_pred, average='weighted', zero_division=0),
            "balanced_accuracy": METRIC_FUNCTIONS['balanced_accuracy'](y, y_pred)
        }
        
        # Add AUC for binary classification with probabilities
        if len(labels) == 2 and hasattr(model, "predict_proba"):
            try:
                metrics["auc"] = roc_auc_score(y, y_proba)
            except Exception as e:
                logger.warning(f"AUC calculation failed: {e}") 
                metrics["auc"] = 0.0
            metrics["threshold"] = threshold
        else:
            metrics["auc"] = 0.0
            
        return metrics
        
    except Exception as e:
        logger.error(f"Unified metrics computation failed: {e}")
        return {"error": str(e)}

def optimize_simple_threshold(y_true: np.ndarray, y_proba: np.ndarray, 
                             metric: str = 'f1') -> float:
    """
    Simple threshold optimization using precision-recall curve.
    Consolidated from multiple duplicate implementations.
    """
    try:
        if metric not in METRIC_FUNCTIONS:
            metric = 'f1'
            
        precision, recall, thresholds = precision_recall_curve(y_true, y_proba)
        
        if metric == 'f1':
            f1_scores = [2 * p * r / (p + r) if (p + r) else 0 for p, r in zip(precision, recall)]
            if len(thresholds) > 0:
                optimal_idx = np.argmax(f1_scores[:-1])
                return float(thresholds[optimal_idx])
        elif metric == 'precision':
            if len(thresholds) > 0:
                optimal_idx = np.argmax(precision[:-1])
                return float(thresholds[optimal_idx])
        elif metric == 'recall':
            if len(thresholds) > 0:
                optimal_idx = np.argmax(recall[:-1])
                return float(thresholds[optimal_idx])
        
        return 0.5  # Default threshold
        
    except Exception as e:
        logger.warning(f"Simple threshold optimization failed: {e}")
        return 0.5

def calculate_metrics_from_predictions(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    """
    Calculate metrics from predictions arrays.
    Used by backtesting and comparison modules.
    """
    try:
        return {
            'accuracy': METRIC_FUNCTIONS['accuracy'](y_true, y_pred),
            'precision': METRIC_FUNCTIONS['precision'](y_true, y_pred, zero_division=0),
            'recall': METRIC_FUNCTIONS['recall'](y_true, y_pred, zero_division=0),
            'f1': METRIC_FUNCTIONS['f1'](y_true, y_pred, zero_division=0)
        }
    except Exception as e:
        logger.error(f"Metrics calculation from predictions failed: {e}")
        return {'accuracy': 0.0, 'precision': 0.0, 'recall': 0.0, 'f1': 0.0}

class UnifiedMetrics:
    """
    Unified Metrics Class for backward compatibility
    Provides centralized access to all metric functions
    """
    
    def __init__(self):
        self.logger = get_logger('unified_metrics')
    
    def compute_comprehensive_metrics(self, model, X: pd.DataFrame, y: pd.Series, 
                                     threshold: float = None) -> Dict[str, Any]:
        """Wrapper for global compute_comprehensive_metrics function"""
        return compute_comprehensive_metrics(model, X, y, threshold)
    
    def calculate_metrics_from_predictions(self, y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
        """Wrapper for global calculate_metrics_from_predictions function"""
        return calculate_metrics_from_predictions(y_true, y_pred)
    
    def optimize_simple_threshold(self, y_true: np.ndarray, y_proba: np.ndarray, 
                                  metric: str = 'f1') -> float:
        """Wrapper for global optimize_simple_threshold function"""
        return optimize_simple_threshold(y_true, y_proba, metric)


def get_metric_function(metric_name: str):
    """Get sklearn metric function by name"""
    return METRIC_FUNCTIONS.get(metric_name, METRIC_FUNCTIONS['accuracy'])

def calculate_prediction_confidence(ensemble_pred: float, individual_preds: list) -> float:
    """
    Calculate prediction confidence based on ensemble and individual predictions
    
    Args:
        ensemble_pred: Ensemble prediction value
        individual_preds: List of individual model predictions
        
    Returns:
        Confidence score between 0 and 1
    """
    try:
        if not individual_preds or len(individual_preds) == 0:
            return 0.5  # Default confidence
        
        # Calculate agreement between models
        individual_array = np.array(individual_preds)
        
        # Method 1: Standard deviation based (lower std = higher confidence)
        std_conf = 1.0 - min(np.std(individual_array), 0.5) / 0.5
        
        # Method 2: Distance from 0.5 (neutral prediction)
        distance_conf = abs(ensemble_pred - 0.5) * 2
        
        # Method 3: Consensus based (how many models agree with ensemble decision)
        ensemble_class = int(ensemble_pred > 0.5)
        individual_classes = (individual_array > 0.5).astype(int)
        consensus = np.mean(individual_classes == ensemble_class)
        
        # Combine all confidence measures
        combined_confidence = (std_conf * 0.3 + distance_conf * 0.4 + consensus * 0.3)
        
        return float(np.clip(combined_confidence, 0.0, 1.0))
        
    except Exception as e:
        logger.warning(f"⚠️ Confidence calculation failed: {e}")
        return 0.5
