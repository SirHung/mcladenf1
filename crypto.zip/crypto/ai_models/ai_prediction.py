"""
AI Prediction Module
Chứa EnsemblePredictor và tất cả logic prediction cho crypto trading.

Module này được tách từ ai_logic.py để tối ưu hóa và dễ bảo trì.
"""

import numpy as np
import pandas as pd
import gzip
import os 
import pickle
import time
from typing import Dict, List, Tuple, Optional, Union, Any
from config.logging_config import get_logger
from ai_models.ai_parameters import AIParameterCalculator, get_parameter_calculator

logger = get_logger('ai_prediction')

class EnsemblePredictor:
    """Advanced ensemble predictor combining all prediction capabilities"""
    
    def __init__(self, models_dir: str = "models"):
        self.models_dir = models_dir
        self.models = {}
        self.weights = {}
        self.performance_history = {}
        self.loaded_models = {}
        
        # Initialize AI-driven parameter calculator
        self.param_calculator = get_parameter_calculator()
        
        # Dynamic confidence threshold - will be calculated per prediction
        self.base_confidence_threshold = 0.5  # Will be overridden by AI calculations
        
        # Tích hợp UnifiedDataLoader để load dữ liệu nhanh hơn
        try:
            from data_processing.unified_data_loader import unified_loader
            self.data_loader = unified_loader
            logger.info("✅ EnsemblePredictor: Integrated with UnifiedDataLoader")
        except ImportError:
            self.data_loader = None
            logger.warning("⚠️ EnsemblePredictor: UnifiedDataLoader not available")
    
    def load_models(self, symbol: str) -> Dict:
        """Load all available models for a symbol, including ensemble models from unified_trainer"""
        models_loaded = {}
        
        if os.path.exists(self.models_dir):
            # Priority 1: Multi-timeframe optimized models
            for filename in os.listdir(self.models_dir):
                if f"{symbol}_multi_timeframe_optimized" in filename and filename.endswith('.pkl.gz'):
                    model_path = os.path.join(self.models_dir, filename)
                    try:
                        with gzip.open(model_path, 'rb') as f:
                            model_data = pickle.load(f)
                            
                            if isinstance(model_data, dict) and 'models' in model_data:
                                models_loaded['multi_timeframe_ensemble'] = {
                                    'model': model_data,
                                    'models': model_data.get('models', {}),
                                    'scalers': model_data.get('scalers', {}),
                                    'timeframes': model_data.get('timeframes', []),
                                    'accuracy': model_data.get('performance_metrics', {}).get('weighted_accuracy', 0.0),
                                    'f1_score': model_data.get('performance_metrics', {}).get('weighted_f1_score', 0.0),
                                    'threshold': 0.5,
                                    'path': model_path,
                                    'is_multi_timeframe': True,
                                    'is_ensemble': True
                                }
                                logger.info(f"✅ Loaded multi-timeframe ensemble with accuracy {model_data.get('performance_metrics', {}).get('weighted_accuracy', 0.0):.4f}")
                                return models_loaded  # Prioritize multi-timeframe models
                                
                    except Exception as e:
                        logger.warning(f"Failed to load multi-timeframe model {filename}: {e}")
            
            # Priority 2: Advanced ensemble models from unified_trainer
            ensemble_model_found = False
            for filename in os.listdir(self.models_dir):
                if f"{symbol}_optimized_ensemble" in filename and filename.endswith('.pkl.gz'):
                    model_path = os.path.join(self.models_dir, filename)
                    try:
                        with gzip.open(model_path, 'rb') as f:
                            ensemble_data = pickle.load(f)
                            
                            # Handle advanced ensemble model structure
                            if isinstance(ensemble_data, dict) and 'ensemble_predict' in ensemble_data:
                                models_loaded['advanced_ensemble'] = {
                                    'model': ensemble_data,
                                    'ensemble_predict': ensemble_data.get('ensemble_predict'),
                                    'accuracy': ensemble_data.get('performance', {}).get('best_accuracy', 0.0),
                                    'scaler': ensemble_data.get('feature_scaler'),
                                    'threshold': 0.5,
                                    'path': model_path,
                                    'weights': ensemble_data.get('weights', {}),
                                    'best_single': ensemble_data.get('best_single', ''),
                                    'all_models': ensemble_data.get('all_models', {}),
                                    'is_ensemble': True
                                }
                                logger.info(f"✅ Loaded advanced ensemble model with accuracy {ensemble_data.get('performance', {}).get('best_accuracy', 0.0):.4f}")
                                ensemble_model_found = True
                            else:
                                logger.warning(f"Invalid ensemble model structure in {filename}")
                                
                    except Exception as e:
                        logger.warning(f"Failed to load ensemble model {filename}: {e}")
            
            # Priority 3: Simple individual models
            simple_model_found = False
            for filename in os.listdir(self.models_dir):
                if filename.startswith(f"{symbol}_") and filename.endswith('.pkl.gz') and "ensemble" not in filename and "multi_timeframe" not in filename:
                    model_path = os.path.join(self.models_dir, filename)
                    try:
                        with gzip.open(model_path, 'rb') as f:
                            model_data = pickle.load(f)
                            model_name = filename.replace('.pkl.gz', '').split('_')[-1]
                            models_loaded[model_name] = {
                                'model': model_data.get('model'),
                                'accuracy': model_data.get('accuracy', 0.5),
                                'scaler': model_data.get('scaler'),
                                'threshold': model_data.get('threshold', 0.5),
                                'path': model_path,
                                'is_ensemble': False
                            }
                            logger.info(f"✅ Loaded simple model {model_name} with accuracy {model_data.get('accuracy', 0.5):.4f}")
                            simple_model_found = True
                    except Exception as e:
                        logger.warning(f"Failed to load model {filename}: {e}")
            
            # Priority 4: Fallback to base symbol models if no specific models found
            if not ensemble_model_found and not simple_model_found:
                base_symbol = symbol.replace('USDT', '').replace('USD', '')
                for filename in os.listdir(self.models_dir):
                    if filename.startswith(f"{base_symbol}_") and filename.endswith('.pkl.gz'):
                        model_path = os.path.join(self.models_dir, filename)
                        try:
                            with gzip.open(model_path, 'rb') as f:
                                model_data = pickle.load(f)
                                model_name = filename.replace('.pkl.gz', '').split('_')[-1]
                                models_loaded[model_name] = {
                                    'model': model_data.get('model'),
                                    'accuracy': model_data.get('accuracy', 0.5),
                                    'scaler': model_data.get('scaler'),
                                    'threshold': model_data.get('threshold', 0.5),
                                    'path': model_path,
                                    'is_ensemble': False
                                }
                                logger.info(f"⚠️ Loaded fallback model {model_name} with accuracy {model_data.get('accuracy', 0.5):.4f}")
                        except Exception as e:
                            logger.warning(f"Failed to load model {filename}: {e}")
        
        self.models[symbol] = models_loaded
        self.loaded_models[symbol] = models_loaded
        logger.info(f"📋 Total models loaded for {symbol}: {len(models_loaded)}")
        return models_loaded
    
    def calculate_adaptive_weights(self, symbol: str, recent_performance: Optional[Dict] = None) -> Dict:
        """Calculate adaptive weights based on model performance"""
        if symbol not in self.models:
            return {}
        
        models = self.models[symbol]
        weights = {}
        total_weight = 0
        
        for model_name, model_info in models.items():
            accuracy = model_info.get('accuracy', np.nan)
            
            # Skip models with invalid accuracy or accuracy <= 0.5 (worse than random)
            if pd.isna(accuracy) or accuracy <= 0.5:
                logger.warning(f"Model {model_name} has poor accuracy {accuracy}, skipping")
                continue
                
            # Weight based on accuracy above random baseline
            weight = (accuracy - 0.5) ** 2  # Square the excess over random
            
            if recent_performance and model_name in recent_performance:
                recent_acc = recent_performance[model_name]
                if recent_acc > 0.5:
                    weight = 0.7 * weight + 0.3 * ((recent_acc - 0.5) ** 2)
                else:
                    continue  # Skip if recent performance is poor
            
            weights[model_name] = weight
            total_weight += weight
        
        if total_weight > 0:
            weights = {k: v/total_weight for k, v in weights.items()}
            logger.debug(f"Adaptive weights for {symbol}: {weights}")
        else:
            logger.warning(f"No viable models found for {symbol} - all models have accuracy ≤ 0.5")
            weights = {}
        
        self.weights[symbol] = weights
        return weights
    
    def predict_multi_timeframe(self, X: pd.DataFrame, symbol: str, timeframe: str = None,
                               market_data: pd.DataFrame = None, confidence_threshold: Optional[float] = None) -> Dict:
        """Make predictions using multi-timeframe ensemble model"""
        if symbol not in self.models:
            self.load_models(symbol)
        
        models = self.models.get(symbol, {})
        
        # Look for multi-timeframe ensemble model
        multi_tf_model = None
        for model_name, model_info in models.items():
            if model_info.get('is_multi_timeframe', False):
                multi_tf_model = model_info
                break
        
        if not multi_tf_model:
            logger.warning("No multi-timeframe model found, falling back to regular prediction")
            return self.predict_ensemble(X, symbol, market_data, confidence_threshold=confidence_threshold)
        
        try:
            # Calculate dynamic confidence threshold
            if confidence_threshold is None and self.param_calculator and market_data is not None:
                confidence_threshold = self.param_calculator.calculate_confidence_threshold(
                    market_data, symbol, timeframe or "15m"
                )
            elif confidence_threshold is None:
                confidence_threshold = self.base_confidence_threshold
            
            # Get timeframe-specific model and scaler
            timeframes = multi_tf_model.get('timeframes', [])
            models_dict = multi_tf_model.get('models', {})
            scalers_dict = multi_tf_model.get('scalers', {})
            
            # Select timeframe
            target_timeframe = timeframe if timeframe in timeframes else (timeframes[0] if timeframes else None)
            
            if not target_timeframe or target_timeframe not in models_dict:
                logger.warning(f"Timeframe {timeframe} not available, using ensemble prediction")
                return self.predict_ensemble(X, symbol, market_data, confidence_threshold=confidence_threshold)
            
            # Get model and scaler for the timeframe
            timeframe_model = models_dict[target_timeframe]
            timeframe_scaler = scalers_dict.get(f"{target_timeframe}_scaler")
            
            # Apply scaling
            X_scaled = X.copy()
            if timeframe_scaler:
                feature_cols = [col for col in X.columns if col not in ['target', 'timestamp', 'open_time', 'close_time']]
                X_scaled[feature_cols] = timeframe_scaler.transform(X[feature_cols])
            
            # Make prediction
            if hasattr(timeframe_model, 'predict_proba'):
                proba = timeframe_model.predict_proba(X_scaled)
                if proba.shape[1] > 1:
                    final_proba = proba[:, 1][-1]
                else:
                    final_proba = proba[-1]
            else:
                pred = timeframe_model.predict(X_scaled)
                final_proba = 0.7 if pred[-1] == 1 else 0.3
            
            final_pred = int(final_proba >= 0.5)
            confidence_score = abs(final_proba - 0.5) * 2
            high_confidence = confidence_score >= confidence_threshold
            
            logger.info(f"🎯 Multi-timeframe prediction for {target_timeframe}: {final_pred} (prob: {final_proba:.3f})")
            
            return {
                'prediction': final_pred,
                'probability': final_proba,
                'confidence': confidence_score,
                'timeframe_used': target_timeframe,
                'available_timeframes': timeframes,
                'high_confidence': high_confidence,
                'model_type': 'multi_timeframe_ensemble',
                'confidence_threshold_used': confidence_threshold
            }
            
        except Exception as e:
            logger.error(f"❌ Multi-timeframe prediction failed: {e}")
            return self.predict_ensemble(X, symbol, market_data, confidence_threshold=confidence_threshold)
    
    def predict_ensemble(self, X: pd.DataFrame, symbol: str, market_data: pd.DataFrame = None,
                        use_gpu: bool = False, confidence_threshold: Optional[float] = None) -> Dict:
        """Make ensemble predictions with AI-driven confidence scoring"""
        if symbol not in self.models:
            self.load_models(symbol)
        
        if not self.models.get(symbol):
            raise ValueError(f"No models available for {symbol}")
        
        # Calculate dynamic confidence threshold using AI
        if confidence_threshold is None and self.param_calculator and market_data is not None:
            confidence_threshold = self.param_calculator.calculate_confidence_threshold(
                market_data, symbol, "15m"  # Default timeframe
            )
        elif confidence_threshold is None:
            confidence_threshold = self.base_confidence_threshold
            
        models = self.models[symbol]
        
        # Check for multi-timeframe model first
        for model_name, model_info in models.items():
            if model_info.get('is_multi_timeframe', False):
                return self.predict_multi_timeframe(X, symbol, market_data=market_data, 
                                                  confidence_threshold=confidence_threshold)
        
        # PRIORITY: Check for advanced ensemble model
        for model_name, model_info in models.items():
            if model_info.get('is_ensemble', False) and 'ensemble_predict' in model_info:
                logger.info(f"🎭 Using advanced ensemble model: {model_name}")
                try:
                    ensemble_predict_func = model_info['ensemble_predict']
                    
                    # Apply scaling if available
                    X_scaled = X.copy()
                    if model_info.get('scaler'):
                        X_scaled = pd.DataFrame(
                            model_info['scaler'].transform(X),
                            columns=X.columns,
                            index=X.index
                        )
                    
                    # Get ensemble prediction
                    ensemble_proba = ensemble_predict_func(X_scaled.values)
                    
                    # Handle different output formats
                    if hasattr(ensemble_proba, '__len__') and len(ensemble_proba) > 0:
                        final_proba = float(ensemble_proba[0])
                    else:
                        final_proba = float(ensemble_proba)
                    
                    # Ensure probability is in valid range
                    final_proba = max(0.0, min(1.0, final_proba))
                    final_pred = int(final_proba >= 0.5)
                    
                    # Calculate confidence based on distance from neutral
                    confidence_score = abs(final_proba - 0.5) * 2
                    
                    # Enhanced confidence with ensemble metadata
                    all_models_count = len(model_info.get('all_models', {}))
                    ensemble_weights = model_info.get('weights', {})
                    
                    # Boost confidence if multiple models in ensemble
                    if all_models_count > 1:
                        confidence_score *= (1.0 + 0.1 * min(all_models_count, 5))
                    
                    high_confidence = confidence_score >= confidence_threshold
                    
                    logger.info(f"🎯 Advanced ensemble prediction: {final_pred} (prob: {final_proba:.3f})")
                    
                    return {
                        'prediction': final_pred,
                        'probability': final_proba,
                        'confidence': confidence_score,
                        'model_details': {
                            model_name: {
                                'prediction': final_pred,
                                'probability': final_proba,
                                'confidence': confidence_score,
                                'weight': 1.0,
                                'ensemble_models': all_models_count,
                                'best_single': model_info.get('best_single', ''),
                                'ensemble_weights': ensemble_weights
                            }
                        },
                        'total_weight_used': 1.0,
                        'models_used': 1,
                        'high_confidence': high_confidence,
                        'num_models': all_models_count,
                        'confidence_threshold_used': confidence_threshold,
                        'ensemble_type': 'advanced_unified'
                    }
                    
                except Exception as e:
                    logger.error(f"❌ Advanced ensemble prediction failed: {e}")
                    break
        
        # FALLBACK: Use individual models ensemble approach
        logger.info("📊 Using individual models ensemble approach")
        weights = self.weights.get(symbol, {})
        
        if not weights:
            weights = self.calculate_adaptive_weights(symbol)
        
        predictions = []
        probabilities = []
        model_confidences = {}
        total_weight_used = 0
        
        for model_name, model_info in models.items():
            if model_name not in weights:
                logger.debug(f"Skipping model {model_name} - no weight assigned")
                continue
                
            try:
                model = model_info['model']
                threshold = model_info.get('threshold', 0.5)
                
                X_scaled = X.copy()
                if model_info.get('scaler'):
                    X_scaled = pd.DataFrame(
                        model_info['scaler'].transform(X), 
                        columns=X.columns, 
                        index=X.index
                    )
                
                if hasattr(model, 'predict_proba'):
                    proba = model.predict_proba(X_scaled)[:, 1]
                    pred = (proba >= threshold).astype(int)
                else:
                    pred = model.predict(X_scaled)
                    proba = np.where(pred == 1, 0.7, 0.3)
                
                weight = weights[model_name]
                total_weight_used += weight
                
                predictions.append(pred * weight)
                probabilities.append(proba * weight)
                
                confidence = abs(proba[-1] - 0.5) * 2
                model_confidences[model_name] = {
                    'prediction': pred[-1],
                    'probability': proba[-1],
                    'confidence': confidence,
                    'weight': weight
                }
            except Exception as e:
                logger.warning(f"Failed to get prediction from {model_name}: {e}")
                continue
        
        if not predictions:
            return self._get_fallback_prediction(models, confidence_threshold)
        
        # Sum weighted predictions and probabilities
        ensemble_pred_raw = np.sum(predictions, axis=0)
        ensemble_proba_raw = np.sum(probabilities, axis=0)
        
        # Normalize by actual total weight used
        if total_weight_used > 0:
            ensemble_proba = ensemble_proba_raw / total_weight_used
            ensemble_pred = (ensemble_proba >= 0.5).astype(int)
        else:
            ensemble_pred = np.zeros_like(ensemble_pred_raw, dtype=int)
            ensemble_proba = np.zeros_like(ensemble_proba_raw)
        
        # Calculate confidence
        individual_probs = [info['probability'] for info in model_confidences.values()]
        if len(individual_probs) > 1:
            prob_std = np.std(individual_probs)
            confidence_score = abs(ensemble_proba[-1] - 0.5) * 2 * (1 - prob_std)
        else:
            confidence_score = abs(ensemble_proba[-1] - 0.5) * 2
        
        high_confidence = confidence_score >= confidence_threshold
        
        return {
            'prediction': ensemble_pred[-1],
            'probability': ensemble_proba[-1],
            'confidence': confidence_score,
            'model_details': model_confidences,
            'total_weight_used': total_weight_used,
            'models_used': len(model_confidences),
            'high_confidence': high_confidence,
            'num_models': len(model_confidences),
            'confidence_threshold_used': confidence_threshold
        }
    
    def _get_fallback_prediction(self, models: Dict, confidence_threshold: float) -> Dict:
        """Get fallback prediction when all models fail"""
        # Find model with highest accuracy even if <= 0.5
        best_model = None
        best_accuracy = 0
        best_model_name = None
        
        for model_name, model_info in models.items():
            accuracy = model_info.get('accuracy', 0)
            if accuracy > best_accuracy:
                best_accuracy = accuracy
                best_model = model_info.get('model')
                best_model_name = model_name
        
        if best_model is not None:
            try:
                logger.info(f"Using fallback model {best_model_name} with accuracy {best_accuracy:.3f}")
                return {
                    'prediction': 0,  # Conservative prediction
                    'probability': 0.5,
                    'confidence': max(0.1, best_accuracy * 0.5),
                    'model_details': {best_model_name: {
                        'prediction': 0,
                        'probability': 0.5,
                        'confidence': best_accuracy,
                        'weight': 1.0,
                        'fallback': True
                    }},
                    'total_weight_used': 1.0,
                    'models_used': 1,
                    'high_confidence': False,
                    'num_models': 1,
                    'fallback_mode': True
                }
            except Exception as e:
                logger.error(f"Fallback model {best_model_name} also failed: {e}")
        
        # Ultimate fallback - neutral prediction
        logger.warning("All models failed - returning neutral prediction")
        return {
            'prediction': 0,
            'probability': 0.5,
            'confidence': 0.0,
            'model_details': {},
            'high_confidence': False,
            'num_models': 0,
            'fallback_mode': True,
            'error': 'No viable models available'
        }
    
    def predict_best_model(self, X: pd.DataFrame, symbol: str, market_data: pd.DataFrame = None,
                          use_gpu: bool = False, confidence_threshold: Optional[float] = None) -> Dict[str, Any]:
        """Use the best performing model for prediction with AI-driven parameters"""
        try:
            # Calculate dynamic confidence threshold
            if confidence_threshold is None and self.param_calculator and market_data is not None:
                confidence_threshold = self.param_calculator.calculate_confidence_threshold(
                    market_data, symbol, "15m"
                )
            elif confidence_threshold is None:
                confidence_threshold = self.base_confidence_threshold
                
            # Load models if not already loaded
            if symbol not in self.models:
                self.load_models(symbol)
                
            models = self.models.get(symbol, {})
            if not models:
                raise ValueError(f"No models available for {symbol}")
            
            # Find best model by accuracy
            best_model_name = None
            best_accuracy = 0
            best_model_info = None
            
            for model_name, model_info in models.items():
                accuracy = model_info.get('accuracy', 0)
                if accuracy > best_accuracy:
                    best_accuracy = accuracy
                    best_model_name = model_name
                    best_model_info = model_info
            
            if best_model_info is None:
                raise ValueError("No valid models found")
            
            # Make prediction with best model
            model = best_model_info['model']
            threshold = best_model_info.get('threshold', 0.5)
            
            X_scaled = X.copy()
            if best_model_info.get('scaler'):
                X_scaled = pd.DataFrame(
                    best_model_info['scaler'].transform(X),
                    columns=X.columns,
                    index=X.index
                )
            
            if hasattr(model, 'predict_proba'):
                proba = model.predict_proba(X_scaled)[:, 1]
                pred = (proba >= threshold).astype(int)
            else:
                pred = model.predict(X_scaled)
                proba = np.where(pred == 1, 0.7, 0.3)
            
            confidence_score = abs(proba[-1] - 0.5) * 2
            high_confidence = confidence_score >= confidence_threshold
            
            return {
                'prediction': pred[-1],
                'probability': proba[-1],
                'confidence': confidence_score,
                'best_model': best_model_name,
                'model_accuracy': best_accuracy,
                'high_confidence': high_confidence,
                'confidence_threshold_used': confidence_threshold,
                'method': 'best_single_model'
            }
            
        except Exception as e:
            logger.error(f"❌ Best model prediction failed: {e}")
            return {
                'prediction': 0,
                'probability': 0.5,
                'confidence': 0.0,
                'error': str(e),
                'method': 'best_single_model'
            }
    
    def get_model_info(self, symbol: str) -> Dict[str, Any]:
        """Get information about loaded models for a symbol"""
        if symbol not in self.models:
            self.load_models(symbol)
        
        models = self.models.get(symbol, {})
        weights = self.weights.get(symbol, {})
        
        model_info = {}
        for model_name, model_data in models.items():
            model_info[model_name] = {
                'accuracy': model_data.get('accuracy', 0.0),
                'weight': weights.get(model_name, 0.0),
                'threshold': model_data.get('threshold', 0.5),
                'is_ensemble': model_data.get('is_ensemble', False),
                'is_multi_timeframe': model_data.get('is_multi_timeframe', False),
                'path': model_data.get('path', ''),
                'loaded': True
            }
        
        return {
            'total_models': len(models),
            'weighted_models': len([m for m in models.values() if weights.get(m, 0) > 0]),
            'best_accuracy': max([m.get('accuracy', 0) for m in models.values()], default=0),
            'models': model_info,
            'symbol': symbol
        }

# Global ensemble predictor instance
_global_predictor = None

def get_ensemble_predictor(models_dir: str = "models") -> EnsemblePredictor:
    """Get global ensemble predictor instance"""
    global _global_predictor
    if _global_predictor is None:
        _global_predictor = EnsemblePredictor(models_dir)
        logger.info("✅ Global EnsemblePredictor initialized")
    return _global_predictor

def predict_with_ensemble(X: pd.DataFrame, symbol: str, market_data: pd.DataFrame = None,
                         timeframe: str = None, use_gpu: bool = False, 
                         confidence_threshold: Optional[float] = None) -> Dict:
    """
    Convenience function for ensemble prediction
    """
    predictor = get_ensemble_predictor()
    return predictor.predict_ensemble(X, symbol, market_data, use_gpu, confidence_threshold)

def predict_multi_timeframe(X: pd.DataFrame, symbol: str, timeframe: str = None,
                           market_data: pd.DataFrame = None, 
                           confidence_threshold: Optional[float] = None) -> Dict:
    """
    Convenience function for multi-timeframe prediction
    """
    predictor = get_ensemble_predictor()
    return predictor.predict_multi_timeframe(X, symbol, timeframe, market_data, confidence_threshold)
