"""
Advanced Features Module - REFACTORED
Contains advanced and specialized feature calculation methods.

Module này chứa các advanced features:
- Adaptive features with AI-driven parameters
- Fractal and spectral analysis
- Machine learning features
- Statistical analysis
- Market microstructure
- Crypto-specific features
- DeFi features
- Regime detection
- Information theory features
"""

import warnings
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any
from scipy import stats
from scipy.signal import find_peaks
from scipy.fft import fft, fftfreq
from concurrent.futures import ThreadPoolExecutor, as_completed
from config.logging_config import get_logger

logger = get_logger('feature_advanced')

# Smart epsilon handling
def get_smart_eps(data_series: pd.Series = None, base_eps: float = 1e-12) -> float:
    if data_series is None or data_series.empty:
        return base_eps
    try:
        non_zero_data = data_series[data_series != 0]
        if non_zero_data.empty:
            return base_eps
        min_abs_value = abs(non_zero_data).min()
        smart_eps = min_abs_value / 1000
        smart_eps = max(smart_eps, 1e-18)
        smart_eps = min(smart_eps, 1e-8)
        return smart_eps
    except Exception:
        return base_eps

EPS = 1e-12

# Professional ML library imports
try:
    from sklearn.preprocessing import StandardScaler, RobustScaler, MinMaxScaler
    from sklearn.decomposition import PCA, FastICA
    from sklearn.cluster import KMeans, DBSCAN
    from sklearn.feature_selection import mutual_info_regression, SelectKBest, f_regression
    from sklearn.ensemble import IsolationForest
    SKLEARN_AVAILABLE = True
    logger.info("🎯 Professional ML libraries available")
except ImportError:
    SKLEARN_AVAILABLE = False
    logger.warning("⚠️ Scikit-learn not available. Advanced ML features disabled.")

def add_statistical_features(df: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """
    💎 Professional Statistical Features Suite 💎
    Advanced statistical analysis optimized for crypto market dynamics
    """
    try:
        logger.debug("📊 Computing advanced statistical features...")
        
        close = df['close'].astype(np.float64)
        volume = df['volume'].astype(np.float64)
        
        # === MULTI-TIMEFRAME RETURNS ANALYSIS ===
        for period in config['returns_periods']:
            # Safe percentage change
            shifted_close = close.shift(period).replace(0, EPS)
            returns = (close - shifted_close) / shifted_close
            df[f'return_{period}'] = returns
            
            # Log returns for better distribution properties
            if period <= 5:  # Only for short periods to avoid numerical issues
                # Safe log calculation
                price_ratio = close / shifted_close
                price_ratio = price_ratio.replace([0, np.inf, -np.inf], 1)  # Replace invalid values
                df[f'log_return_{period}'] = np.log(price_ratio.clip(lower=EPS))
        
        # Safe percentage change for returns_1
        shifted_close_1 = close.shift(1).replace(0, EPS)
        returns_1 = (close - shifted_close_1) / shifted_close_1
        
        # === ADVANCED DISTRIBUTION MOMENTS ===
        for period in config['skewness_periods']:
            returns_window = returns_1.rolling(period)
            df[f'skewness_{period}'] = returns_window.skew()
            df[f'kurtosis_{period}'] = returns_window.kurt()
            
            # Higher-order moments for fat-tail detection
            if period in [20, 50]:
                # Calculate excess kurtosis (kurtosis - 3)
                df[f'excess_kurtosis_{period}'] = df[f'kurtosis_{period}'] - 3
                
                # Jarque-Bera normality test statistic approximation
                jb_stat = (period/6) * (df[f'skewness_{period}']**2 + 
                                       df[f'excess_kurtosis_{period}']**2/4)
                df[f'jarque_bera_{period}'] = jb_stat
        
        # === PROFESSIONAL Z-SCORE ANALYSIS ===
        for period in config['z_score_periods']:
            # Price Z-scores with safe division
            price_mean = close.rolling(period).mean()
            price_std = close.rolling(period).std().replace(0, EPS)
            df[f'price_zscore_{period}'] = (close - price_mean) / price_std
            
            # Volume Z-scores with safe division
            volume_mean = volume.rolling(period).mean()
            volume_std = volume.rolling(period).std().replace(0, EPS)
            df[f'volume_zscore_{period}'] = (volume - volume_mean) / volume_std
            
            # Rolling Sharpe ratio approximation with safe division
            returns_mean = returns_1.rolling(period).mean()
            returns_std = returns_1.rolling(period).std().replace(0, EPS)
            df[f'sharpe_ratio_{period}'] = (returns_mean / returns_std) * np.sqrt(252)
        
        # === ADVANCED CORRELATION ANALYSIS ===
        for period in config['correlation_periods']:
            # Price-volume correlation
            df[f'price_volume_corr_{period}'] = close.rolling(period).corr(volume)
            
            # Auto-correlation for mean reversion detection
            df[f'price_autocorr_{period}'] = close.rolling(period).apply(
                lambda x: x.autocorr(lag=1) if len(x) > 1 else 0
            )
            
            # Cross-correlation with lagged volume
            if period >= 10:
                df[f'price_volume_lag_corr_{period}'] = close.rolling(period).corr(volume.shift(1))
        
        # === INFORMATION THEORY FEATURES ===
        for period in config['entropy_periods']:
            # Shannon entropy of returns distribution
            def shannon_entropy(series, bins=10):
                try:
                    if len(series) < 5:
                        return 0.0
                    data = series.dropna()
                    if len(data) == 0:
                        return 0.0
                    hist, _ = np.histogram(data, bins=bins)
                    hist = hist[hist > 0]
                    if len(hist) <= 1:
                        return 0.0
                    prob = hist / hist.sum()
                    return float(-np.sum(prob * np.log2(prob)))
                except:
                    return 0.0
            
            df[f'returns_entropy_{period}'] = returns_1.rolling(period).apply(shannon_entropy)
            df[f'price_entropy_{period}'] = close.rolling(period).apply(shannon_entropy)
        
        # === CRYPTO-SPECIFIC STATISTICAL FEATURES ===
        # Crash/pump detection via extreme value analysis
        returns_abs = abs(returns_1)
        for quantile in [0.95, 0.99]:
            threshold = returns_abs.rolling(100).quantile(quantile)
            df[f'extreme_move_{int(quantile*100)}'] = (returns_abs > threshold).astype(int)
        
        # Volatility clustering detection (GARCH-like)
        vol_5 = returns_1.rolling(5).std()
        vol_20 = returns_1.rolling(20).std()
        df['vol_clustering'] = (vol_5 > vol_20 * 1.5).astype(int)
        
        # Momentum persistence
        momentum_5 = returns_1.rolling(5).mean()
        df['momentum_persistence'] = (
            (momentum_5 > 0) & (momentum_5.shift(1) > 0) & (momentum_5.shift(2) > 0)
        ).astype(int)
        
        logger.debug("✅ Advanced statistical features computed successfully")
        return df
        
    except Exception as e:
        logger.error(f"❌ Statistical features computation failed: {e}")
        return df

def add_market_microstructure(df: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """Add market microstructure features with safe calculations for small coin prices."""
    try:
        # Safe helper functions
        def safe_divide(numerator, denominator):
            return numerator / (denominator.replace(0, EPS))
        
        def safe_percentage_change(series):
            return series.pct_change().replace([np.inf, -np.inf], 0).fillna(0)
        
        # Price impact measures with safe division
        returns = safe_percentage_change(df['close'])
        df['price_impact'] = safe_divide(abs(returns), df['volume'])
        
        # Bid-ask spread proxy (using high-low) with safe division
        df['spread_proxy'] = safe_divide(df['high'] - df['low'], df['close'])
        df['spread_ma'] = df['spread_proxy'].rolling(20).mean()
        
        # Liquidity measures with safe calculation
        df['illiquidity'] = safe_divide(abs(returns), df['volume'] * df['close'])
        df['amihud_illiq'] = df['illiquidity'].rolling(20).mean()
        
        # Order flow imbalance proxy with safe division
        df['ofi_proxy'] = safe_divide(df['close'] - df['open'], df['high'] - df['low'])
        
        # Trade intensity with safe division  
        df['trade_intensity'] = safe_divide(df['volume'], df['high'] - df['low'])
        
        return df
    except Exception as e:
        logger.error(f"❌ Market microstructure computation failed: {e}")
        return df

def add_adaptive_features(df: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """
    💎 Professional Adaptive Features 💎
    AI-driven parameters that adapt to market conditions
    """
    try:
        logger.debug("🤖 Computing AI-adaptive features...")
        
        close = df['close'].astype(np.float64)
        volume = df['volume'].astype(np.float64)
        
        # === AI-ADAPTIVE RSI ===
        def adaptive_rsi_calc(series):
            try:
                if len(series) < 20:
                    return np.nan
                
                # AI-driven period selection based on volatility
                volatility = series.pct_change().std()
                if volatility > 0.05:  # High volatility
                    period = 7
                elif volatility > 0.02:  # Medium volatility
                    period = 14
                else:  # Low volatility
                    period = 21
                
                delta = series.diff()
                gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
                loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
                rs = gain / (loss + EPS)
                rsi = 100 - (100 / (1 + rs))
                return rsi.iloc[-1] if not rsi.empty else np.nan
            except:
                return np.nan
        
        df['adaptive_rsi'] = close.rolling(50).apply(adaptive_rsi_calc)
        
        # === AI-ADAPTIVE MOVING AVERAGES ===
        def adaptive_ma_fast_calc(series):
            try:
                trend_strength = np.corrcoef(np.arange(len(series)), series)[0, 1]
                if abs(trend_strength) > 0.7:  # Strong trend
                    return series.ewm(span=5).mean().iloc[-1]
                else:  # Sideways market
                    return series.ewm(span=12).mean().iloc[-1]
            except:
                return series.mean()
        
        def adaptive_ma_slow_calc(series):
            try:
                volatility = series.pct_change().std()
                if volatility > 0.03:  # High volatility
                    return series.ewm(span=20).mean().iloc[-1]
                else:  # Low volatility
                    return series.ewm(span=50).mean().iloc[-1]
            except:
                return series.mean()
        
        df['adaptive_ma_fast'] = close.rolling(30).apply(adaptive_ma_fast_calc)
        df['adaptive_ma_slow'] = close.rolling(50).apply(adaptive_ma_slow_calc)
        df['adaptive_ma_signal'] = np.where(df['adaptive_ma_fast'] > df['adaptive_ma_slow'], 1, -1)
        
        logger.debug("✅ AI-adaptive features computed successfully")
        return df
        
    except Exception as e:
        logger.error(f"❌ Adaptive features computation failed: {e}")
        return df

def add_fractal_features(df: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """Professional fractal analysis suite"""
    try:
        logger.debug("📐 Computing fractal features...")
        
        close = df['close'].astype(np.float64)
        high = df['high'].astype(np.float64)
        low = df['low'].astype(np.float64)
        
        def find_fractals(series, window=5):
            """Find fractal patterns in price series"""
            try:
                fractals = []
                for i in range(window, len(series) - window):
                    # Fractal high
                    if series.iloc[i] == series.iloc[i-window:i+window+1].max():
                        fractals.append(1)
                    # Fractal low
                    elif series.iloc[i] == series.iloc[i-window:i+window+1].min():
                        fractals.append(-1)
                    else:
                        fractals.append(0)
                return [0] * window + fractals + [0] * window
            except:
                return [0] * len(series)
        
        for period in config['fractal_periods']:
            df[f'fractal_high_{period}'] = find_fractals(high, period)
            df[f'fractal_low_{period}'] = find_fractals(low, period)
        
        # Fractal dimension estimation
        def hurst_exponent(series, max_lag=20):
            """Estimate Hurst exponent for fractal dimension"""
            try:
                lags = range(2, max_lag)
                tau = [np.sqrt(np.std(np.subtract(series[lag:], series[:-lag]))) for lag in lags]
                poly = np.polyfit(np.log(lags), np.log(tau), 1)
                return poly[0] * 2.0
            except:
                return 0.5
        
        df['hurst_exponent'] = close.rolling(100).apply(lambda x: hurst_exponent(x.values))
        
        return df
    except Exception as e:
        logger.error(f"❌ Fractal features computation failed: {e}")
        return df

def add_spectral_analysis_features(df: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """Professional spectral analysis suite using FFT"""
    try:
        logger.debug("🌊 Computing spectral analysis features...")
        
        close = df['close'].astype(np.float64)
        
        for window in config['spectral_analysis_windows']:
            if window <= len(df):
                def spectral_analysis(series):
                    try:
                        if len(series) < 10:
                            return 0.0, 0.0, 0.0
                        
                        # Detrend the series
                        detrended = series - np.linspace(series.iloc[0], series.iloc[-1], len(series))
                        
                        # Apply FFT
                        fft_values = fft(detrended.values)
                        freqs = fftfreq(len(detrended))
                        
                        # Spectral power
                        power = np.abs(fft_values) ** 2
                        
                        # Dominant frequency
                        dominant_freq_idx = np.argmax(power[1:len(power)//2]) + 1
                        dominant_freq = float(freqs[dominant_freq_idx])
                        
                        # Spectral entropy
                        power_norm = power / np.sum(power)
                        power_norm = power_norm[power_norm > 0]
                        spectral_entropy = float(-np.sum(power_norm * np.log2(power_norm)))
                        
                        # Spectral centroid
                        spectral_centroid = float(np.sum(freqs[:len(freqs)//2] * power[:len(power)//2]) / (np.sum(power[:len(power)//2]) + EPS))
                        
                        return dominant_freq, spectral_entropy, spectral_centroid
                    except:
                        return 0.0, 0.0, 0.0
                
                # Sửa lỗi rolling.apply trả về list: tách từng feature
                df[f'dominant_freq_{window}'] = close.rolling(window).apply(lambda x: spectral_analysis(x)[0], raw=False)
                df[f'spectral_entropy_{window}'] = close.rolling(window).apply(lambda x: spectral_analysis(x)[1], raw=False)
                df[f'spectral_centroid_{window}'] = close.rolling(window).apply(lambda x: spectral_analysis(x)[2], raw=False)
        
        return df
    except Exception as e:
        logger.error(f"❌ Spectral analysis computation failed: {e}")
        return df

# Ví dụ sử dụng đúng:
# df = add_spectral_analysis_features(df, config)
# print(df[[f'dominant_freq_64', f'spectral_entropy_64', f'spectral_centroid_64']].tail())

def add_machine_learning_features(df: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """Advanced ML-based feature engineering"""
    try:
        if not SKLEARN_AVAILABLE:
            logger.warning("Scikit-learn not available, skipping ML features")
            return df
            
        logger.debug("🤖 Computing ML-based features...")
        
        close = df['close'].astype(np.float64)
        
        # PCA features for dimensionality reduction patterns
        window = 50
        if len(df) > window:
            def pca_features(series):
                try:
                    if len(series) < 10:
                        return [0, 0]
                    
                    # Create a matrix of lagged values
                    lags = 5
                    matrix = np.column_stack([series.shift(i).iloc[lags:] for i in range(lags)])
                    matrix = matrix[~np.isnan(matrix).any(axis=1)]
                    
                    if len(matrix) < 5:
                        return [0, 0]
                    
                    pca = PCA(n_components=2)
                    components = pca.fit_transform(matrix)
                    
                    return [pca.explained_variance_ratio_[0], pca.explained_variance_ratio_[1]]
                except:
                    return [0, 0]
            
            pca_results = close.rolling(window).apply(
                lambda x: pd.Series(pca_features(x)), raw=False
            )
            
            if isinstance(pca_results, pd.DataFrame) and len(pca_results.columns) >= 2:
                df[f'pca_var_1_{window}'] = pca_results.iloc[:, 0]
                df[f'pca_var_2_{window}'] = pca_results.iloc[:, 1]
        
        return df
    except Exception as e:
        logger.error(f"❌ ML features computation failed: {e}")
        return df

def add_crypto_specific_features(df: pd.DataFrame) -> pd.DataFrame:
    """Crypto-specific features like funding rates, perpetual premiums, etc."""
    try:
        logger.debug("🚀 Computing crypto-specific features...")
        
        close = df['close'].astype(np.float64)
        volume = df['volume'].astype(np.float64)
        
        # Funding rate simulation (based on premium)
        # In real implementation, this would use actual funding rate data
        premium_proxy = close.pct_change().rolling(24).mean()  # 24-period proxy
        df['funding_rate_proxy'] = premium_proxy * 100
        
        # Whale detection (large volume spikes)
        volume_ma = volume.rolling(20).mean()
        volume_ratio = volume / (volume_ma + EPS)
        df['whale_detection'] = (volume_ratio > 5.0).astype(int)
        
        # Liquidation cascade proxy
        large_moves = abs(close.pct_change()) > 0.05  # 5% moves
        volume_spike = volume_ratio > 3.0
        df['liquidation_cascade_proxy'] = (large_moves & volume_spike).astype(int)
        
        # Perpetual-spot basis proxy
        # In real implementation, this would compare perpetual vs spot prices
        df['basis_proxy'] = close.rolling(8).mean() - close  # 8-hour funding period
        
        # Fear & Greed proxy based on volatility and momentum
        volatility = close.pct_change().rolling(20).std()
        momentum = close.pct_change(20)
        
        # Normalize to 0-100 scale
        vol_norm = (volatility - volatility.rolling(100).min()) / (volatility.rolling(100).max() - volatility.rolling(100).min() + EPS)
        mom_norm = (momentum - momentum.rolling(100).min()) / (momentum.rolling(100).max() - momentum.rolling(100).min() + EPS)
        
        df['fear_greed_proxy'] = ((1 - vol_norm) + mom_norm) * 50  # Scale to 0-100
        
        return df
    except Exception as e:
        logger.error(f"❌ Crypto-specific features computation failed: {e}")
        return df

def add_defi_features(df: pd.DataFrame) -> pd.DataFrame:
    """DeFi-specific features"""
    try:
        logger.debug("💎 Computing DeFi features...")
        
        close = df['close'].astype(np.float64)
        volume = df['volume'].astype(np.float64)
        
        # TVL proxy (Total Value Locked simulation)
        df['tvl_proxy'] = (close * volume).rolling(24).mean()
        
        # Yield farming activity proxy
        volume_volatility = volume.pct_change().rolling(20).std()
        df['yield_farming_activity'] = volume_volatility
        
        # Impermanent loss proxy
        price_change_20 = close.pct_change(20)
        df['impermanent_loss_proxy'] = abs(price_change_20) * 0.25  # Simplified IL calculation
        
        # Governance token behavior proxy
        momentum_short = close.pct_change(5)
        momentum_long = close.pct_change(30)
        df['governance_momentum'] = momentum_short - momentum_long
        
        return df
    except Exception as e:
        logger.error(f"❌ DeFi features computation failed: {e}")
        return df

def add_regime_detection_features(df: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """Market regime detection features"""
    try:
        logger.debug("🎯 Computing regime detection features...")
        
        close = df['close'].astype(np.float64)
        volume = df['volume'].astype(np.float64)
        
        # Volatility regime
        volatility = close.pct_change().rolling(20).std()
        vol_quantiles = volatility.rolling(100).quantile([0.25, 0.75])
        
        if isinstance(vol_quantiles, pd.DataFrame):
            df['vol_regime'] = np.where(
                volatility > vol_quantiles.iloc[:, 1], 2,  # High vol
                np.where(volatility < vol_quantiles.iloc[:, 0], 0, 1)  # Low vol, Medium vol
            )
        else:
            df['vol_regime'] = 1  # Default to medium
        
        # Trend regime
        for period in config['trend_regime_periods']:
            trend_strength = close.rolling(period).apply(
                lambda x: np.corrcoef(np.arange(len(x)), x)[0, 1] if len(x) > 1 else 0
            )
            df[f'trend_regime_{period}'] = np.where(
                trend_strength > 0.5, 1,    # Uptrend
                np.where(trend_strength < -0.5, -1, 0)  # Downtrend, Sideways
            )
        
        return df
    except Exception as e:
        logger.error(f"❌ Regime detection computation failed: {e}")
        return df

def add_information_theory_features(df: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """Information theory based features"""
    try:
        logger.debug("📊 Computing information theory features...")
        
        close = df['close'].astype(np.float64)
        returns = close.pct_change()
        
        # Mutual information between price and volume
        for period in [20, 50]:
            def mutual_info_calc(price_series, volume_series):
                try:
                    if len(price_series) < 10 or len(volume_series) < 10:
                        return 0
                    
                    # Discretize the data
                    price_bins = pd.cut(price_series, bins=5, labels=False)
                    volume_bins = pd.cut(volume_series, bins=5, labels=False)
                    
                    # Remove NaN values
                    valid_mask = ~(pd.isna(price_bins) | pd.isna(volume_bins))
                    if not valid_mask.any():
                        return 0
                    
                    price_bins = price_bins[valid_mask]
                    volume_bins = volume_bins[valid_mask]
                    
                    # Calculate mutual information
                    from collections import Counter
                    
                    n = len(price_bins)
                    if n == 0:
                        return 0
                    
                    # Joint distribution
                    joint_counts = Counter(zip(price_bins, volume_bins))
                    joint_probs = {k: v/n for k, v in joint_counts.items()}
                    
                    # Marginal distributions
                    price_counts = Counter(price_bins)
                    volume_counts = Counter(volume_bins)
                    price_probs = {k: v/n for k, v in price_counts.items()}
                    volume_probs = {k: v/n for k, v in volume_counts.items()}
                    
                    # Mutual information calculation
                    mi = 0
                    for (p, v), joint_prob in joint_probs.items():
                        if joint_prob > 0:
                            mi += joint_prob * np.log2(joint_prob / (price_probs[p] * volume_probs[v]))
                    
                    return mi
                except:
                    return 0
            
            price_rolling = close.rolling(period)
            volume_rolling = df['volume'].rolling(period)
            
            df[f'mutual_info_{period}'] = pd.Series(
                [mutual_info_calc(p, v) for p, v in zip(price_rolling, volume_rolling)],
                index=df.index
            )
        
        return df
    except Exception as e:
        logger.error(f"❌ Information theory features computation failed: {e}")
        return df
