"""
Technical Features Module - REFACTORED
Contains all technical indicator calculation methods for feature engineering.

Module này chứa các technical indicators cơ bản:
- Moving averages (SMA, EMA)
- RSI, MACD, Bollinger Bands
- Volume indicators
- Price patterns
- Volatility & momentum features
- Trend analysis
- Composite indicators
"""

import warnings 
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any
from scipy import stats
from scipy.signal import find_peaks
from concurrent.futures import ThreadPoolExecutor, as_completed
from config.logging_config import get_logger

logger = get_logger('feature_technical')

# Smart epsilon handling for small cryptocurrency values
def get_smart_eps(data_series: pd.Series = None, base_eps: float = 1e-12) -> float:
    if data_series is None or data_series.empty:
        return base_eps
    try:
        non_zero_data = data_series[data_series != 0]
        if non_zero_data.empty:
            return base_eps
        min_abs_value = abs(non_zero_data).min()
        smart_eps = min_abs_value / 1000
        smart_eps = max(smart_eps, 1e-18)
        smart_eps = min(smart_eps, 1e-8)
        return smart_eps
    except Exception:
        return base_eps

EPS = 1e-12

# Professional TA-Lib integration
try:
    import talib
    TALIB_AVAILABLE = True
    logger.info("🎯 Professional TA-Lib available for advanced indicators")
except ImportError:
    TALIB_AVAILABLE = False
    logger.warning("⚠️ TA-Lib not available. Using custom implementations.")

def add_technical_indicators(df: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """
    💎 Professional Technical Indicators Suite 💎
    Optimized for crypto trading with advanced vectorization
    """
    try:
        logger.debug("🎯 Computing advanced technical indicators with maximum vectorization...")
        
        # Professional optimization setup
        import os
        os.environ['OMP_NUM_THREADS'] = str(os.cpu_count() or 8)
        os.environ['MKL_NUM_THREADS'] = str(os.cpu_count() or 8)
        
        # Pre-compute series for efficiency
        close = df['close'].astype(np.float64)
        high = df['high'].astype(np.float64)
        low = df['low'].astype(np.float64)
        volume = df['volume'].astype(np.float64)
        
        # === PROFESSIONAL MOVING AVERAGES SUITE ===
        # Simple Moving Averages - fully vectorized
        for period in config['sma_periods']:
            df[f'sma_{period}'] = close.rolling(period, min_periods=1).mean()
            
        # Exponential Moving Averages - fully vectorized
        for period in config['ema_periods']:
            df[f'ema_{period}'] = close.ewm(span=period, min_periods=1).mean()
            
        # === PROFESSIONAL RSI SUITE ===
        for period in config['rsi_periods']:
            if TALIB_AVAILABLE:
                try:
                    df[f'rsi_{period}'] = talib.RSI(close.values, timeperiod=period)
                except:
                    # Simple RSI calculation using pandas
                    delta = close.diff()
                    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
                    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
                    rs = gain / (loss + EPS)
                    df[f'rsi_{period}'] = 100 - (100 / (1 + rs))
            else:
                # Simple RSI calculation using pandas
                delta = close.diff()
                gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
                loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
                rs = gain / (loss + EPS)
                df[f'rsi_{period}'] = 100 - (100 / (1 + rs))
                
        # === PROFESSIONAL MACD SUITE ===
        for macd_config in config['macd_configs']:
            fast, slow, signal = macd_config['fast'], macd_config['slow'], macd_config['signal']
            suffix = f"_{fast}_{slow}_{signal}"
            
            if TALIB_AVAILABLE:
                try:
                    macd, macd_signal, macd_hist = talib.MACD(
                        close.values, fastperiod=fast, slowperiod=slow, signalperiod=signal
                    )
                    df[f'macd{suffix}'] = macd
                    df[f'macd_signal{suffix}'] = macd_signal
                    df[f'macd_histogram{suffix}'] = macd_hist
                except:
                    # Simple MACD calculation using pandas
                    ema_fast = close.ewm(span=fast).mean()
                    ema_slow = close.ewm(span=slow).mean()
                    macd_line = ema_fast - ema_slow
                    signal_line = macd_line.ewm(span=signal).mean()
                    histogram = macd_line - signal_line
                    df[f'macd{suffix}'] = macd_line
                    df[f'macd_signal{suffix}'] = signal_line
                    df[f'macd_histogram{suffix}'] = histogram
            else:
                # Simple MACD calculation using pandas
                ema_fast = close.ewm(span=fast).mean()
                ema_slow = close.ewm(span=slow).mean()
                macd_line = ema_fast - ema_slow
                signal_line = macd_line.ewm(span=signal).mean()
                histogram = macd_line - signal_line
                df[f'macd{suffix}'] = macd_line
                df[f'macd_signal{suffix}'] = signal_line
                df[f'macd_histogram{suffix}'] = histogram
                
        # === PROFESSIONAL BOLLINGER BANDS SUITE ===
        for period in config['bb_periods']:
            for std_dev in config['bb_std_devs']:
                suffix = f"_{period}_{std_dev}"
                
                if TALIB_AVAILABLE:
                    try:
                        bb_upper, bb_middle, bb_lower = talib.BBANDS(
                            close.values, timeperiod=period, nbdevup=std_dev, nbdevdn=std_dev
                        )
                        df[f'bb_upper{suffix}'] = bb_upper
                        df[f'bb_middle{suffix}'] = bb_middle
                        df[f'bb_lower{suffix}'] = bb_lower
                    except:
                        # Simple Bollinger Bands calculation using pandas
                        sma = close.rolling(period).mean()
                        std = close.rolling(period).std()
                        df[f'bb_upper{suffix}'] = sma + (std * std_dev)
                        df[f'bb_middle{suffix}'] = sma
                        df[f'bb_lower{suffix}'] = sma - (std * std_dev)
                else:
                    # Simple Bollinger Bands calculation using pandas
                    sma = close.rolling(period).mean()
                    std = close.rolling(period).std()
                    df[f'bb_upper{suffix}'] = sma + (std * std_dev)
                    df[f'bb_middle{suffix}'] = sma
                    df[f'bb_lower{suffix}'] = sma - (std * std_dev)
                # Professional BB-derived features
                bb_range = df[f'bb_upper{suffix}'] - df[f'bb_lower{suffix}']
                # Safe divide for bb_width
                denominator = df[f'bb_middle{suffix}'].replace(0, EPS)
                df[f'bb_width{suffix}'] = bb_range / denominator
                # Safe divide for bb_position  
                bb_range_safe = bb_range.replace(0, EPS)
                df[f'bb_position{suffix}'] = (close - df[f'bb_lower{suffix}']) / bb_range_safe
        
        # === PROFESSIONAL ATR AND ADX ===
        for period in config['atr_periods']:
            if TALIB_AVAILABLE:
                try:
                    df[f'atr_{period}'] = talib.ATR(high.values, low.values, close.values, timeperiod=period)
                except:
                    # Simple ATR calculation
                    tr1 = high - low
                    tr2 = abs(high - close.shift(1))
                    tr3 = abs(low - close.shift(1))
                    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
                    df[f'atr_{period}'] = tr.rolling(period).mean()
            else:
                # Simple ATR calculation
                tr1 = high - low
                tr2 = abs(high - close.shift(1))
                tr3 = abs(low - close.shift(1))
                tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
                df[f'atr_{period}'] = tr.rolling(period).mean()
        
        for period in config['adx_periods']:
            if TALIB_AVAILABLE:
                try:
                    df[f'adx_{period}'] = talib.ADX(high.values, low.values, close.values, timeperiod=period)
                except:
                    # Simplified ADX calculation
                    dm_plus = np.where((high.diff() > 0) & (high.diff() > low.diff().abs()), high.diff(), 0)
                    dm_minus = np.where((low.diff() < 0) & (low.diff().abs() > high.diff()), low.diff().abs(), 0)
                    tr1 = high - low
                    tr2 = abs(high - close.shift(1))
                    tr3 = abs(low - close.shift(1))
                    tr = pd.concat([pd.Series(tr1), pd.Series(tr2), pd.Series(tr3)], axis=1).max(axis=1)
                    dm_plus_smooth = pd.Series(dm_plus).rolling(period).mean()
                    dm_minus_smooth = pd.Series(dm_minus).rolling(period).mean()
                    tr_smooth = tr.rolling(period).mean()
                    di_plus = 100 * dm_plus_smooth / (tr_smooth + EPS)
                    di_minus = 100 * dm_minus_smooth / (tr_smooth + EPS)
                    dx = 100 * abs(di_plus - di_minus) / (di_plus + di_minus + EPS)
                    df[f'adx_{period}'] = dx.rolling(period).mean()
        
        # === PROFESSIONAL STOCHASTIC OSCILLATOR ===
        for stoch_config in config['stoch_configs']:
            k, d, smooth = stoch_config['k'], stoch_config['d'], stoch_config['smooth']
            suffix = f"_{k}_{d}_{smooth}"
            
            if TALIB_AVAILABLE:
                try:
                    slowk, slowd = talib.STOCH(high.values, low.values, close.values, 
                                            fastk_period=k, slowk_period=d, slowd_period=smooth)
                    df[f'stoch_k{suffix}'] = slowk
                    df[f'stoch_d{suffix}'] = slowd
                except:
                    # Custom stochastic calculation
                    lowest_low = low.rolling(k).min()
                    highest_high = high.rolling(k).max()
                    k_percent = 100 * ((close - lowest_low) / (highest_high - lowest_low + EPS))
                    df[f'stoch_k{suffix}'] = k_percent.rolling(d).mean()
                    df[f'stoch_d{suffix}'] = df[f'stoch_k{suffix}'].rolling(smooth).mean()
            else:
                # Custom stochastic calculation
                lowest_low = low.rolling(k).min()
                highest_high = high.rolling(k).max()
                k_percent = 100 * ((close - lowest_low) / (highest_high - lowest_low + EPS))
                df[f'stoch_k{suffix}'] = k_percent.rolling(d).mean()
                df[f'stoch_d{suffix}'] = df[f'stoch_k{suffix}'].rolling(smooth).mean()
        
        # === PROFESSIONAL CCI ===
        for period in config['cci_periods']:
            if TALIB_AVAILABLE:
                try:
                    df[f'cci_{period}'] = talib.CCI(high.values, low.values, close.values, timeperiod=period)
                except:
                    # Custom CCI calculation
                    tp = (high + low + close) / 3
                    sma_tp = tp.rolling(period).mean()
                    mad = tp.rolling(period).apply(lambda x: np.mean(abs(x - x.mean())))
                    df[f'cci_{period}'] = (tp - sma_tp) / (0.015 * mad + EPS)
            else:
                # Custom CCI calculation
                tp = (high + low + close) / 3
                sma_tp = tp.rolling(period).mean()
                mad = tp.rolling(period).apply(lambda x: np.mean(abs(x - x.mean())))
                df[f'cci_{period}'] = (tp - sma_tp) / (0.015 * mad + EPS)
        
        logger.debug("✅ Advanced technical indicators computed successfully")
        return df
        
    except Exception as e:
        logger.error(f"❌ Technical indicators computation failed: {e}")
        return df

def add_volume_indicators(df: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """
    💎 Professional Volume Analysis Suite 💎
    Advanced volume-based indicators optimized for crypto trading
    """
    try:
        logger.debug("📊 Computing professional volume indicators...")
        
        close = df['close'].astype(np.float64)
        high = df['high'].astype(np.float64)
        low = df['low'].astype(np.float64)
        volume = df['volume'].astype(np.float64)
        
        # === PROFESSIONAL VWAP SUITE ===
        for period in config['vwap_periods']:
            if period <= len(df):
                # Traditional VWAP calculation
                typical_price = (high + low + close) / 3
                volume_price = typical_price * volume
                df[f'vwap_{period}'] = volume_price.rolling(period).sum() / (volume.rolling(period).sum() + EPS)
                
                # VWAP deviation bands
                vwap_dev = abs(close - df[f'vwap_{period}'])
                df[f'vwap_dev_{period}'] = vwap_dev.rolling(period).mean()
                df[f'vwap_upper_{period}'] = df[f'vwap_{period}'] + 2 * df[f'vwap_dev_{period}']
                df[f'vwap_lower_{period}'] = df[f'vwap_{period}'] - 2 * df[f'vwap_dev_{period}']
        
        # === PROFESSIONAL VOLUME MOVING AVERAGES ===
        for period in config['volume_ma_periods']:
            df[f'volume_ma_{period}'] = volume.rolling(period).mean()
            volume_ratio = volume / (df[f'volume_ma_{period}'] + EPS)
            df[f'volume_ratio_{period}'] = volume_ratio
            
            # Volume spikes detection
            df[f'volume_spike_{period}'] = (volume_ratio > 2.0).astype(int)
        
        # === PROFESSIONAL OBV AND VARIATIONS ===
        # On-Balance Volume
        obv = (volume * np.sign(close.diff())).cumsum()
        df['obv'] = obv
        
        for smooth_period in config['obv_smoothing']:
            df[f'obv_ma_{smooth_period}'] = obv.rolling(smooth_period).mean()
            df[f'obv_signal_{smooth_period}'] = np.where(obv > df[f'obv_ma_{smooth_period}'], 1, -1)
        
        # Volume-Price Trend (VPT)
        price_change_pct = close.pct_change()
        vpt = (volume * price_change_pct).cumsum()
        df['vpt'] = vpt
        
        # === PROFESSIONAL CHAIKIN MONEY FLOW ===
        for period in config['cmf_periods']:
            # Money Flow Multiplier
            mfm = ((close - low) - (high - close)) / (high - low + EPS)
            money_flow_volume = mfm * volume
            df[f'cmf_{period}'] = money_flow_volume.rolling(period).sum() / (volume.rolling(period).sum() + EPS)
        
        # === PROFESSIONAL MONEY FLOW INDEX ===
        for period in config['mfi_periods']:
            if TALIB_AVAILABLE:
                try:
                    df[f'mfi_{period}'] = talib.MFI(high.values, low.values, close.values, volume.values, timeperiod=period)
                except:
                    # Custom MFI calculation
                    typical_price = (high + low + close) / 3
                    raw_money_flow = typical_price * volume
                    positive_flow = np.where(typical_price > typical_price.shift(1), raw_money_flow, 0)
                    negative_flow = np.where(typical_price < typical_price.shift(1), raw_money_flow, 0)
                    positive_flow_sum = pd.Series(positive_flow).rolling(period).sum()
                    negative_flow_sum = pd.Series(negative_flow).rolling(period).sum()
                    money_ratio = positive_flow_sum / (negative_flow_sum + EPS)
                    df[f'mfi_{period}'] = 100 - (100 / (1 + money_ratio))
            else:
                # Custom MFI calculation
                typical_price = (high + low + close) / 3
                raw_money_flow = typical_price * volume
                positive_flow = np.where(typical_price > typical_price.shift(1), raw_money_flow, 0)
                negative_flow = np.where(typical_price < typical_price.shift(1), raw_money_flow, 0)
                positive_flow_sum = pd.Series(positive_flow).rolling(period).sum()
                negative_flow_sum = pd.Series(negative_flow).rolling(period).sum()
                money_ratio = positive_flow_sum / (negative_flow_sum + EPS)
                df[f'mfi_{period}'] = 100 - (100 / (1 + money_ratio))
        
        # === PROFESSIONAL FORCE INDEX ===
        for period in config['fi_periods']:
            force_index = volume * (close - close.shift(1))
            df[f'force_index_{period}'] = force_index.rolling(period).mean()
        
        # === PROFESSIONAL EASE OF MOVEMENT ===
        for period in config['ease_of_movement_periods']:
            distance_moved = (high + low) / 2 - (high.shift(1) + low.shift(1)) / 2
            box_height = volume / (high - low + EPS)
            one_period_eom = distance_moved / (box_height + EPS)
            df[f'ease_of_movement_{period}'] = one_period_eom.rolling(period).mean()
        
        # === PROFESSIONAL ACCUMULATION/DISTRIBUTION LINE ===
        mfm = ((close - low) - (high - close)) / (high - low + EPS)
        ad_line = (mfm * volume).cumsum()
        df['ad_line'] = ad_line
        df['ad_line_ma_20'] = ad_line.rolling(20).mean()
        
        # === PROFESSIONAL VOLUME PROFILE APPROXIMATIONS ===
        # Volume-weighted average price deviation
        for period in [20, 50]:
            typical_price = (high + low + close) / 3
            volume_weighted_price = (typical_price * volume).rolling(period).sum() / (volume.rolling(period).sum() + EPS)
            df[f'vwap_dev_{period}'] = (close - volume_weighted_price) / (volume_weighted_price + EPS)
        
        # Volume rate of change
        for period in [5, 10, 20]:
            df[f'volume_roc_{period}'] = volume.pct_change(periods=period) * 100
        
        logger.debug("✅ Professional volume indicators computed successfully")
        return df
        
    except Exception as e:
        logger.error(f"❌ Volume indicators computation failed: {e}")
        return df

def add_price_patterns(df: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """
    💎 Professional Price Pattern Recognition 💎
    Advanced pattern detection optimized for crypto markets
    """
    try:
        logger.debug("🎯 Computing professional price patterns...")
        
        close = df['close'].astype(np.float64)
        high = df['high'].astype(np.float64)
        low = df['low'].astype(np.float64)
        
        # === PROFESSIONAL SUPPORT/RESISTANCE LEVELS ===
        for window in config['support_resistance_windows']:
            # Local highs and lows
            highs = high.rolling(window, center=True).max()
            lows = low.rolling(window, center=True).min()
            
            df[f'resistance_{window}'] = np.where(high == highs, high, np.nan)
            df[f'support_{window}'] = np.where(low == lows, low, np.nan)
            
            # Distance to nearest support/resistance
            df[f'dist_to_resistance_{window}'] = (df[f'resistance_{window}'].fillna(method='ffill') - close) / close
            df[f'dist_to_support_{window}'] = (close - df[f'support_{window}'].fillna(method='ffill')) / close
        
        # === PROFESSIONAL FRACTALS ===
        for period in config['fractal_periods']:
            # Fractal up (resistance)
            df[f'fractal_up_{period}'] = np.where(
                (high == high.rolling(period*2+1, center=True).max()) & 
                (high.shift(period) < high) & (high.shift(-period) < high), 
                high, np.nan
            )
            
            # Fractal down (support)
            df[f'fractal_down_{period}'] = np.where(
                (low == low.rolling(period*2+1, center=True).min()) & 
                (low.shift(period) > low) & (low.shift(-period) > low), 
                low, np.nan
            )
        
        # === PROFESSIONAL FIBONACCI LEVELS ===
        for window in [20, 50, 100]:
            period_high = high.rolling(window).max()
            period_low = low.rolling(window).min()
            price_range = period_high - period_low
            
            for level in config['fibonacci_levels']:
                df[f'fib_{level}_{window}'] = period_low + (price_range * level)
                df[f'fib_dist_{level}_{window}'] = (close - df[f'fib_{level}_{window}']) / close
        
        # === PROFESSIONAL PATTERN RECOGNITION ===
        # Higher highs and lower lows
        for period in config['pattern_lookback_periods']:
            df[f'higher_high_{period}'] = (high > high.shift(period)).astype(int)
            df[f'lower_low_{period}'] = (low < low.shift(period)).astype(int)
            df[f'higher_low_{period}'] = (low > low.shift(period)).astype(int)
            df[f'lower_high_{period}'] = (high < high.shift(period)).astype(int)
            
            # Trend patterns
            df[f'uptrend_{period}'] = (df[f'higher_high_{period}'] & df[f'higher_low_{period}']).astype(int)
            df[f'downtrend_{period}'] = (df[f'lower_high_{period}'] & df[f'lower_low_{period}']).astype(int)
        
        logger.debug("✅ Professional price patterns computed successfully")
        return df
        
    except Exception as e:
        logger.error(f"❌ Price patterns computation failed: {e}")
        return df

def add_volatility_features(df: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """Professional volatility analysis suite"""
    try:
        logger.debug("📊 Computing volatility features...")
        close = df['close'].astype(np.float64)
        
        # Safe percentage change for returns_1
        shifted_close_1 = close.shift(1).replace(0, EPS)
        returns_1 = (close - shifted_close_1) / shifted_close_1
        
        for period in config['volatility_periods']:
            # Classical volatility
            vol = returns_1.rolling(period).std()
            df[f'volatility_{period}'] = vol
            df[f'realized_vol_{period}'] = vol * np.sqrt(252)  # Annualized
            
            # Downside volatility
            downside_returns = returns_1.where(returns_1 < 0, 0)
            df[f'downside_vol_{period}'] = downside_returns.rolling(period).std() * np.sqrt(252)
            
            # Upside volatility 
            upside_returns = returns_1.where(returns_1 > 0, 0)
            df[f'upside_vol_{period}'] = upside_returns.rolling(period).std() * np.sqrt(252)
            
            # Volatility asymmetry with safe division
            downside_vol_safe = df[f'downside_vol_{period}'].replace(0, EPS)
            df[f'vol_asymmetry_{period}'] = df[f'upside_vol_{period}'] / downside_vol_safe
        
        return df
    except Exception as e:
        logger.error(f"❌ Volatility features computation failed: {e}")
        return df

def add_momentum_features(df: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """Professional momentum analysis suite"""
    try:
        logger.debug("🚀 Computing momentum features...")
        close = df['close'].astype(np.float64)
        
        # Rate of Change
        for period in [5, 10, 20, 30]:
            df[f'roc_{period}'] = close.pct_change(periods=period) * 100
        
        # Momentum oscillator
        for period in [10, 20, 50]:
            df[f'momentum_{period}'] = close / close.shift(period)
        
        return df
    except Exception as e:
        logger.error(f"❌ Momentum features computation failed: {e}")
        return df

def add_trend_features(df: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """Professional trend analysis suite"""
    try:
        logger.debug("📈 Computing trend features...")
        close = df['close'].astype(np.float64)
        
        # Trend strength function
        def trend_strength(series):
            try:
                if len(series) < 3:
                    return 0
                x = np.arange(len(series))
                y = series.values
                correlation = np.corrcoef(x, y)[0, 1]
                return correlation if not np.isnan(correlation) else 0
            except:
                return 0
        
        for period in config['trend_regime_periods']:
            df[f'trend_strength_{period}'] = close.rolling(period).apply(trend_strength)
        
        return df
    except Exception as e:
        logger.error(f"❌ Trend features computation failed: {e}")
        return df

def add_composite_indicators(df: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """Professional composite indicators combining multiple signals"""
    try:
        logger.debug("🎯 Computing composite indicators...")
        
        # Composite momentum score
        momentum_cols = [col for col in df.columns if 'rsi_' in col or 'momentum_' in col]
        if momentum_cols:
            df['composite_momentum'] = df[momentum_cols].mean(axis=1)
        
        # Composite volume signal
        volume_cols = [col for col in df.columns if 'volume_ratio_' in col or 'mfi_' in col]
        if volume_cols:
            df['composite_volume'] = df[volume_cols].mean(axis=1)
        
        # Composite trend signal
        trend_cols = [col for col in df.columns if 'trend_strength_' in col or 'adx_' in col]
        if trend_cols:
            df['composite_trend'] = df[trend_cols].mean(axis=1)
        
        return df
    except Exception as e:
        logger.error(f"❌ Composite indicators computation failed: {e}")
        return df

def add_technical_features_memory_safe(df, config, resource_manager=None, batch_size=50000, task_type='processing'):
    """
    Memory-safe, multi-threaded technical feature engineering for large DataFrames.
    """
    def process_batch(batch_df):
        try:
            if resource_manager:
                with resource_manager.managed_execution(task_type=task_type):
                    out = add_technical_indicators(batch_df, config)
                    out = add_volume_indicators(out, config)
                    out = add_price_patterns(out, config)
                    out = add_volatility_features(out, config)
                    out = add_momentum_features(out, config)
                    out = add_trend_features(out, config)
                    out = add_composite_indicators(out, config)
                    return out
            else:
                out = add_technical_indicators(batch_df, config)
                out = add_volume_indicators(out, config)
                out = add_price_patterns(out, config)
                out = add_volatility_features(out, config)
                out = add_momentum_features(out, config)
                out = add_trend_features(out, config)
                out = add_composite_indicators(out, config)
                return out
        except Exception as e:
            logger.error(f"❌ Lỗi tính technical features cho batch: {e}")
            return batch_df

    if resource_manager:
        results = resource_manager.safe_process_batches(df, process_batch, batch_size=batch_size, max_ram_usage=0.9)
    else:
        # Đa luồng cho các batch
        batches = [df.iloc[i:i+batch_size] for i in range(0, len(df), batch_size)]
        results = []
        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = [executor.submit(process_batch, batch) for batch in batches]
            for future in as_completed(futures):
                results.append(future.result())
        # Đảm bảo thứ tự batch nếu cần
        results = sorted(results, key=lambda x: x.index[0])
    return pd.concat(results, axis=0, ignore_index=True)
