"""
Unified Results Manager - Quản lý tất cả kết quả huấn luyện và dự đoán
Lưu trữ tập trung và cập nhật kết quả mới nhất
"""

import os
import json
import pandas as pd
import pickle
import gzip
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
import threading
from pathlib import Path

from config.settings import MODEL_DIR, DATA_DIR
from config.logging_config import get_logger

logger = get_logger(__name__)

@dataclass
class TrainingResult:
    """Cấu trúc dữ liệu cho kết quả huấn luyện"""
    symbol: str
    timeframe: str
    model_type: str
    accuracy: float
    precision: float
    recall: float
    f1_score: float
    auc_score: float
    training_time: float
    timestamp: str
    model_path: str
    feature_count: int
    data_points: int
    cv_scores: List[float]
    hyperparameters: Dict[str, Any]
    
@dataclass 
class PredictionResult:
    """Cấu trúc dữ liệu cho kết quả dự đoán"""
    symbol: str
    timeframe: str
    signal: str
    probability: float
    entry_price: float
    take_profit: Optional[float]
    stop_loss: Optional[float]
    timestamp: str
    signal_quality: str
    model_confidence: float
    analysis_time: float
    multi_threading_used: bool

@dataclass
class TradeResult:
    """Cấu trúc dữ liệu cho kết quả giao dịch thực tế"""
    timestamp: str
    symbol: str
    timeframe: str
    signal: str  # 'LONG', 'SHORT'
    entry_price: float
    exit_price: Optional[float]
    take_profit: float
    stop_loss: float
    result: str  # 'win', 'loss', 'breakeven', 'open'
    pnl: float
    pnl_percentage: float
    hold_time: float  # hours
    model_confidence: float
    sentiment_score: float
    volatility_regime: str
    prediction_id: str  # Link to original prediction
    exit_reason: str  # 'TP', 'SL', 'manual', 'timeout'

class UnifiedResultsManager:
    """Quản lý kết quả huấn luyện và dự đoán tập trung"""
    
    def __init__(self):
        self.results_dir = os.path.join(DATA_DIR, "unified_results")
        self.training_results_file = os.path.join(self.results_dir, "training_results.json")
        self.prediction_results_file = os.path.join(self.results_dir, "prediction_results.json")
        self.trade_results_file = os.path.join(self.results_dir, "trade_results.json")
        self.accuracy_cache_file = os.path.join(self.results_dir, "accuracy_cache.json")
        self.performance_log_file = os.path.join(self.results_dir, "performance_log.csv")
        
        # Create directories
        os.makedirs(self.results_dir, exist_ok=True)
        
        # Thread lock for safe concurrent access
        self._lock = threading.Lock()
        
    def save_training_result(self, result: TrainingResult) -> bool:
        """Lưu kết quả huấn luyện"""
        try:
            with self._lock:
                # Load existing results
                existing_results = self._load_training_results()
                
                # Add new result
                result_dict = asdict(result)
                existing_results.append(result_dict)
                
                # Keep only last 1000 results to prevent file from growing too large
                if len(existing_results) > 1000:
                    existing_results = existing_results[-1000:]
                
                # Save back to file
                with open(self.training_results_file, 'w') as f:
                    json.dump(existing_results, f, indent=2, ensure_ascii=False)
                
                # Update accuracy cache
                self._update_accuracy_cache(result)
                
                logger.info(f"💾 Training result saved: {result.symbol}@{result.timeframe} - {result.model_type} - {result.accuracy:.3f}")
                return True
                
        except Exception as e:
            logger.error(f"Failed to save training result: {e}")
            return False
    
    def save_prediction_result(self, result: PredictionResult) -> bool:
        """Lưu kết quả dự đoán"""
        try:
            with self._lock:
                # Load existing predictions
                existing_predictions = self._load_prediction_results()
                
                # Add new prediction
                result_dict = asdict(result)
                existing_predictions.append(result_dict)
                
                # Keep only last 10000 predictions
                if len(existing_predictions) > 10000:
                    existing_predictions = existing_predictions[-10000:]
                
                # Save back to file
                with open(self.prediction_results_file, 'w') as f:
                    json.dump(existing_predictions, f, indent=2, ensure_ascii=False)
                
                # Update performance log
                self._update_performance_log(result)
                
                logger.debug(f"📈 Prediction result saved: {result.symbol}@{result.timeframe} - {result.signal}")
                return True
                
        except Exception as e:
            logger.error(f"Failed to save prediction result: {e}")
            return False
    
    def save_trade_result(self, result: TradeResult) -> bool:
        """Lưu kết quả giao dịch thực tế"""
        try:
            with self._lock:
                # Load existing trade results
                existing_trades = self._load_trade_results()
                
                # Add new trade result
                result_dict = asdict(result)
                existing_trades.append(result_dict)
                
                # Keep only last 5000 trades
                if len(existing_trades) > 5000:
                    existing_trades = existing_trades[-5000:]
                
                # Save back to file
                with open(self.trade_results_file, 'w') as f:
                    json.dump(existing_trades, f, indent=2, ensure_ascii=False)
                
                # Update performance analytics
                self._update_trade_analytics(result)
                
                logger.info(f"💰 Trade result saved: {result.symbol}@{result.timeframe} - {result.result} - PnL: {result.pnl_percentage:.2f}%")
                return True
                
        except Exception as e:
            logger.error(f"Failed to save trade result: {e}")
            return False
    
    def get_latest_accuracy(self, symbol: str = None, timeframe: str = None, model_type: str = None) -> Dict[str, Any]:
        """Lấy độ chính xác mới nhất"""
        try:
            with open(self.accuracy_cache_file, 'r') as f:
                cache = json.load(f)
            
            # Filter results based on criteria
            filtered_results = cache
            if symbol:
                filtered_results = {k: v for k, v in filtered_results.items() if symbol in k}
            if timeframe:
                filtered_results = {k: v for k, v in filtered_results.items() if timeframe in k}
            if model_type:
                filtered_results = {k: v for k, v in filtered_results.items() if model_type in k}
            
            if not filtered_results:
                return {}
            
            # Return the most recent result
            latest_key = max(filtered_results.keys(), key=lambda k: filtered_results[k]['timestamp'])
            return {latest_key: filtered_results[latest_key]}
            
        except Exception as e:
            logger.warning(f"Could not load accuracy cache: {e}")
            return {}
    
    def get_training_history(self, symbol: str = None, days: int = 30) -> List[Dict[str, Any]]:
        """Lấy lịch sử huấn luyện"""
        try:
            results = self._load_training_results()
            
            # Filter by symbol if provided
            if symbol:
                results = [r for r in results if r.get('symbol') == symbol]
            
            # Filter by time
            cutoff_time = datetime.now() - timedelta(days=days)
            recent_results = []
            
            for result in results:
                try:
                    result_time = datetime.fromisoformat(result.get('timestamp', '2000-01-01'))
                    if result_time >= cutoff_time:
                        recent_results.append(result)
                except:
                    continue
            
            # Sort by timestamp descending
            recent_results.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
            return recent_results
            
        except Exception as e:
            logger.error(f"Failed to get training history: {e}")
            return []
    
    def get_prediction_performance(self, symbol: str = None, hours: int = 24) -> Dict[str, Any]:
        """Lấy hiệu suất dự đoán"""
        try:
            predictions = self._load_prediction_results()
            
            # Filter by symbol if provided
            if symbol:
                predictions = [p for p in predictions if p.get('symbol') == symbol]
            
            # Filter by time
            cutoff_time = datetime.now() - timedelta(hours=hours)
            recent_predictions = []
            
            for pred in predictions:
                try:
                    pred_time = datetime.fromisoformat(pred.get('timestamp', '2000-01-01'))
                    if pred_time >= cutoff_time:
                        recent_predictions.append(pred)
                except:
                    continue
            
            if not recent_predictions:
                return {"total_predictions": 0, "avg_confidence": 0, "avg_analysis_time": 0}
            
            # Calculate performance metrics
            total_predictions = len(recent_predictions)
            avg_confidence = sum(p.get('model_confidence', 0) for p in recent_predictions) / total_predictions
            avg_analysis_time = sum(p.get('analysis_time', 0) for p in recent_predictions) / total_predictions
            multi_threading_usage = sum(1 for p in recent_predictions if p.get('multi_threading_used', False)) / total_predictions
            
            signal_distribution = {}
            for pred in recent_predictions:
                signal = pred.get('signal', 'UNKNOWN')
                signal_distribution[signal] = signal_distribution.get(signal, 0) + 1
            
            return {
                "total_predictions": total_predictions,
                "avg_confidence": avg_confidence,
                "avg_analysis_time": avg_analysis_time,
                "multi_threading_usage": multi_threading_usage,
                "signal_distribution": signal_distribution,
                "time_range_hours": hours
            }
            
        except Exception as e:
            logger.error(f"Failed to get prediction performance: {e}")
            return {}
    
    def cleanup_old_results(self, days_to_keep: int = 90) -> bool:
        """Dọn dẹp kết quả cũ"""
        try:
            cutoff_time = datetime.now() - timedelta(days=days_to_keep)
            
            # Clean training results
            results = self._load_training_results()
            filtered_results = []
            for result in results:
                try:
                    result_time = datetime.fromisoformat(result.get('timestamp', '2000-01-01'))
                    if result_time >= cutoff_time:
                        filtered_results.append(result)
                except:
                    continue
            
            with open(self.training_results_file, 'w') as f:
                json.dump(filtered_results, f, indent=2)
            
            # Clean prediction results
            predictions = self._load_prediction_results()
            filtered_predictions = []
            for pred in predictions:
                try:
                    pred_time = datetime.fromisoformat(pred.get('timestamp', '2000-01-01'))
                    if pred_time >= cutoff_time:
                        filtered_predictions.append(pred)
                except:
                    continue
            
            with open(self.prediction_results_file, 'w') as f:
                json.dump(filtered_predictions, f, indent=2)
            
            logger.info(f"🧹 Cleaned up results older than {days_to_keep} days")
            return True
            
        except Exception as e:
            logger.error(f"Failed to cleanup old results: {e}")
            return False
    
    def _load_training_results(self) -> List[Dict[str, Any]]:
        """Load training results from file"""
        try:
            if os.path.exists(self.training_results_file):
                with open(self.training_results_file, 'r') as f:
                    return json.load(f)
            return []
        except Exception as e:
            logger.warning(f"Could not load training results: {e}")
            return []
    
    def _load_prediction_results(self) -> List[Dict[str, Any]]:
        """Load prediction results from file"""
        try:
            if os.path.exists(self.prediction_results_file):
                with open(self.prediction_results_file, 'r') as f:
                    return json.load(f)
            return []
        except Exception as e:
            logger.warning(f"Could not load prediction results: {e}")
            return []
    
    def _load_trade_results(self) -> List[Dict[str, Any]]:
        """Load trade results from file"""
        try:
            if os.path.exists(self.trade_results_file):
                with open(self.trade_results_file, 'r') as f:
                    return json.load(f)
            return []
        except Exception as e:
            logger.warning(f"Could not load trade results: {e}")
            return []
    
    def _update_accuracy_cache(self, result: TrainingResult):
        """Update accuracy cache with new training result"""
        try:
            # Load existing cache
            cache = {}
            if os.path.exists(self.accuracy_cache_file):
                with open(self.accuracy_cache_file, 'r') as f:
                    cache = json.load(f)
            
            # Create cache key
            cache_key = f"{result.symbol}@{result.timeframe}_{result.model_type}"
            
            # Update cache
            cache[cache_key] = {
                "accuracy": result.accuracy,
                "precision": result.precision,
                "recall": result.recall,
                "f1_score": result.f1_score,
                "auc_score": result.auc_score,
                "timestamp": result.timestamp,
                "model_path": result.model_path,
                "feature_count": result.feature_count,
                "data_points": result.data_points
            }
            
            # Save cache
            with open(self.accuracy_cache_file, 'w') as f:
                json.dump(cache, f, indent=2)
                
        except Exception as e:
            logger.error(f"Failed to update accuracy cache: {e}")
    
    def _update_performance_log(self, result: PredictionResult):
        """Update performance log CSV"""
        try:
            # Create DataFrame row
            row_data = {
                'timestamp': result.timestamp,
                'symbol': result.symbol,
                'timeframe': result.timeframe,
                'signal': result.signal,
                'probability': result.probability,
                'signal_quality': result.signal_quality,
                'model_confidence': result.model_confidence,
                'analysis_time': result.analysis_time,
                'multi_threading_used': result.multi_threading_used
            }
            
            # Append to CSV
            df_new = pd.DataFrame([row_data])
            
            if os.path.exists(self.performance_log_file):
                df_existing = pd.read_csv(self.performance_log_file)
                df_combined = pd.concat([df_existing, df_new], ignore_index=True)
                
                # Keep only last 50000 rows
                if len(df_combined) > 50000:
                    df_combined = df_combined.tail(50000)
            else:
                df_combined = df_new
            
            df_combined.to_csv(self.performance_log_file, index=False)
            
        except Exception as e:
            logger.error(f"Failed to update performance log: {e}")
    
    def _update_trade_analytics(self, result: TradeResult):
        """Update trade performance analytics"""
        try:
            # Basic analytics update
            analytics_file = os.path.join(self.results_dir, "trade_analytics.json")
            
            # Load existing analytics
            analytics = {}
            if os.path.exists(analytics_file):
                with open(analytics_file, 'r') as f:
                    analytics = json.load(f)
            
            # Initialize if not exists
            symbol_key = f"{result.symbol}_{result.timeframe}"
            if symbol_key not in analytics:
                analytics[symbol_key] = {
                    'total_trades': 0,
                    'wins': 0,
                    'losses': 0,
                    'total_pnl': 0.0,
                    'win_rate': 0.0,
                    'avg_pnl': 0.0
                }
            
            # Update analytics
            stats = analytics[symbol_key]
            stats['total_trades'] += 1
            stats['total_pnl'] += result.pnl_percentage
            
            if result.result == 'win':
                stats['wins'] += 1
            elif result.result == 'loss':
                stats['losses'] += 1
                
            # Calculate rates
            stats['win_rate'] = stats['wins'] / stats['total_trades'] * 100
            stats['avg_pnl'] = stats['total_pnl'] / stats['total_trades']
            
            # Save analytics
            with open(analytics_file, 'w') as f:
                json.dump(analytics, f, indent=2)
                
        except Exception as e:
            logger.error(f"Failed to update trade analytics: {e}")
    
    def get_trade_performance(self, symbol: str = None, timeframe: str = None) -> Dict:
        """Lấy thống kê hiệu suất giao dịch"""
        try:
            analytics_file = os.path.join(self.results_dir, "trade_analytics.json")
            
            if not os.path.exists(analytics_file):
                return {"error": "No trade analytics available"}
            
            with open(analytics_file, 'r') as f:
                analytics = json.load(f)
            
            if symbol and timeframe:
                key = f"{symbol}_{timeframe}"
                return analytics.get(key, {"error": f"No data for {symbol}@{timeframe}"})
            else:
                # Return overall statistics
                total_stats = {
                    'total_trades': 0,
                    'total_wins': 0,
                    'total_losses': 0,
                    'total_pnl': 0.0,
                    'symbols': list(analytics.keys())
                }
                
                for stats in analytics.values():
                    total_stats['total_trades'] += stats.get('total_trades', 0)
                    total_stats['total_wins'] += stats.get('wins', 0)
                    total_stats['total_losses'] += stats.get('losses', 0)
                    total_stats['total_pnl'] += stats.get('total_pnl', 0.0)
                
                if total_stats['total_trades'] > 0:
                    total_stats['overall_win_rate'] = total_stats['total_wins'] / total_stats['total_trades'] * 100
                    total_stats['overall_avg_pnl'] = total_stats['total_pnl'] / total_stats['total_trades']
                
                return total_stats
                
        except Exception as e:
            logger.error(f"Failed to get trade performance: {e}")
            return {"error": str(e)}
    
    def check_ensemble_model_exists(self, symbol: str) -> bool:
        """
        Kiểm tra xem có mô hình ensemble cho symbol không
        
        Args:
            symbol: Mã giao dịch cần kiểm tra
            
        Returns:
            bool: True nếu có mô hình ensemble, False nếu không
        """
        try:            # FIXED: Kiểm tra các đường dẫn mô hình với cả .pkl.gz và .pkl để đồng bộ
            model_extensions = ['.pkl.gz', '.pkl']  # Ưu tiên .pkl.gz trước
            model_paths = []
            
            base_paths = [
                os.path.join(os.path.dirname(os.path.dirname(__file__)), "models", f"{symbol}_unified"),
                os.path.join(os.path.dirname(os.path.dirname(__file__)), "models", f"{symbol}_ensemble"),
                os.path.join(os.path.dirname(os.path.dirname(__file__)), "cache", f"{symbol}_ensemble_models")
            ]
            
            # Tạo danh sách paths với tất cả extensions
            for base_path in base_paths:
                for ext in model_extensions:
                    model_paths.append(base_path + ext) 
            
            # Thêm kiểm tra kết quả huấn luyện gần đây
            training_results = self._load_training_results()
            recent_ensemble_results = [
                r for r in training_results 
                if r.get('symbol') == symbol and 
                r.get('model_type', '').lower() in ['ensemble', 'unified', 'optimized']
            ]
            
            # Kiểm tra cả 2 điều kiện: tập tin mô hình và kết quả huấn luyện
            has_model_file = any(os.path.exists(path) for path in model_paths)
            has_ensemble_results = len(recent_ensemble_results) > 0
            
            logger.debug(f"Ensemble model check for {symbol}: files={has_model_file}, results={has_ensemble_results}")
            return has_model_file or has_ensemble_results
            
        except Exception as e:
            logger.warning(f"Failed to check ensemble model: {e}")
            return False
    
    def get_latest_prediction(self, symbol: str, timeframe: str = None) -> Optional[Dict[str, Any]]:
        """
        Lấy kết quả dự đoán gần nhất cho một symbol và timeframe
        
        Args:
            symbol: Mã giao dịch
            timeframe: Khung thời gian (tùy chọn)
            
        Returns:
            Dict chứa kết quả dự đoán gần nhất hoặc None nếu không có
        """
        try:
            predictions = self._load_prediction_results()
            
            # Lọc theo symbol và timeframe nếu cần
            filtered = [p for p in predictions if p.get('symbol') == symbol]
            if timeframe:
                filtered = [p for p in filtered if p.get('timeframe') == timeframe]
                
            if not filtered:
                return None
                
            # Sắp xếp theo thời gian và lấy gần nhất
            filtered.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
            return filtered[0]
            
        except Exception as e:
            logger.warning(f"Failed to get latest prediction: {e}")
            return None
    
    def calculate_prediction_accuracy(self, symbol: str = None, days: int = 30) -> Dict[str, Any]:
        """
        Tính toán độ chính xác của các dự đoán dựa trên kết quả thực tế
        
        Args:
            symbol: Mã giao dịch cần lọc (tùy chọn)
            days: Số ngày lấy dữ liệu để tính toán
            
        Returns:
            Dict chứa thông tin về độ chính xác
        """
        try:
            # Lấy dữ liệu dự đoán và giao dịch
            predictions = self._load_prediction_results()
            trades = self._load_trade_results()
            
            # Lọc theo thời gian
            cutoff_time = datetime.now() - timedelta(days=days)
            
            def filter_by_time(items):
                result = []
                for item in items:
                    try:
                        timestamp = datetime.fromisoformat(item.get('timestamp', '2000-01-01'))
                        if timestamp >= cutoff_time:
                            result.append(item)
                    except:
                        continue
                return result
                
            recent_predictions = filter_by_time(predictions)
            recent_trades = filter_by_time(trades)
            
            # Lọc theo symbol nếu có
            if symbol:
                recent_predictions = [p for p in recent_predictions if p.get('symbol') == symbol]
                recent_trades = [t for t in recent_trades if t.get('symbol') == symbol]
            
            # Nếu không có dữ liệu, trả về kết quả trống
            if not recent_predictions or not recent_trades:
                return {
                    "accuracy": 0,
                    "total_predictions": len(recent_predictions),
                    "total_trades": len(recent_trades),
                    "insufficient_data": True
                }
                
            # Khớp dự đoán với giao dịch thực tế
            matched_results = []
            
            for pred in recent_predictions:
                # Tìm giao dịch gần nhất sau dự đoán
                pred_time = datetime.fromisoformat(pred.get('timestamp', '2000-01-01'))
                
                matching_trades = [
                    t for t in recent_trades
                    if t.get('symbol') == pred.get('symbol') and
                    t.get('timeframe') == pred.get('timeframe') and
                    datetime.fromisoformat(t.get('timestamp', '2000-01-01')) > pred_time and
                    datetime.fromisoformat(t.get('timestamp', '2000-01-01')) < pred_time + timedelta(days=2)
                ]
                
                if matching_trades:
                    # Lấy giao dịch gần nhất
                    matching_trades.sort(key=lambda x: x.get('timestamp', ''))
                    closest_trade = matching_trades[0]
                    
                    # So sánh dự đoán và kết quả
                    pred_signal = pred.get('signal', 'UNKNOWN')
                    trade_result = closest_trade.get('result', 'UNKNOWN')
                    
                    is_correct = (
                        (pred_signal in ['LONG', 'BUY'] and trade_result == 'WIN') or
                        (pred_signal in ['SHORT', 'SELL'] and trade_result == 'WIN') or
                        (pred_signal == 'NEUTRAL' and trade_result == 'SKIP')
                    )
                    
                    matched_results.append({
                        "prediction": pred_signal,
                        "trade_result": trade_result,
                        "is_correct": is_correct,
                        "confidence": pred.get('confidence', 0)
                    })
            
            # Tính toán các chỉ số hiệu suất
            if not matched_results:
                return {
                    "accuracy": 0,
                    "total_predictions": len(recent_predictions),
                    "total_trades": len(recent_trades),
                    "matched_count": 0,
                    "insufficient_data": True
                }
                
            correct_count = sum(1 for r in matched_results if r.get('is_correct', False))
            accuracy = correct_count / len(matched_results)
            
            # Phân tích theo mức độ tin cậy
            high_confidence_results = [r for r in matched_results if r.get('confidence', 0) >= 0.7]
            high_confidence_accuracy = sum(1 for r in high_confidence_results if r.get('is_correct', False)) / len(high_confidence_results) if high_confidence_results else 0
            
            return {
                "accuracy": accuracy,
                "high_confidence_accuracy": high_confidence_accuracy,
                "total_predictions": len(recent_predictions),
                "total_trades": len(recent_trades),
                "matched_count": len(matched_results),
                "correct_count": correct_count,
                "high_confidence_count": len(high_confidence_results),
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Failed to calculate prediction accuracy: {e}")
            return {
                "accuracy": 0,
                "error": str(e),
                "insufficient_data": True
            }

# Global instance
unified_results_manager = UnifiedResultsManager()
