import numpy as np
import pandas as pd
from typing import Dict, Any, Callable
from ai_models.ai_logic import get_ensemble_predictor
import functools
import asyncio
from concurrent.futures import ThreadPoolExecutor
from ai_optimizer.unified_optimizer import SHAPExplainer

import logging
logger = logging.getLogger(__name__)

def _default_metric(y_true, y_pred):
    return float(np.mean(np.abs(np.array(y_true) - np.array(y_pred))))

async def _async_predict(predictor, symbol, tf, periods, model, explain):
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(
        None, functools.partial(predictor.predict, symbol=symbol, timeframe=tf, periods=periods, model=model, explain=explain)
    )

def get_best_model_name(predictor, symbol: str) -> str:
    """Lấy tên model tốt nhất theo accuracy từ predictor"""
    info = predictor.get_model_info(symbol)
    best = None
    best_acc = 0
    for name, data in info.get('models', {}).items():
        if data.get('accuracy', 0) > best_acc:
            best = name
            best_acc = data.get('accuracy', 0)
    return best

def explain_model_shap(model, X_sample, explainer_type='auto', top_n=10):
    """Trả về top feature importance bằng SHAP cho model bất kỳ"""
    try:
        explainer = SHAPExplainer(model, X_sample, explainer_type)
        explainer.explain()
        return explainer.top_features(top_n=top_n).to_dict()
    except Exception as e:
        logger.warning(f"[LongTermForecast] SHAP explain error: {e}")
        return {}

def handle_long_term_forecast(
    symbol: str = 'BTCUSDT',
    timeframes=None,
    periods: int = 90,
    model_name: str = None,
    return_df: bool = False,
    explain: bool = True,
    aggregate: bool = True,
    visualize: bool = False,
    stats: bool = True,
    rolling_window: int = 7,
    viz_types: list = None,
    top_features: int = 5,
    cache: dict = None,
    custom_metric: Callable = None,
    alert_threshold: float = None,
    api_mode: bool = False,
    log_level: str = 'INFO',
    selftest: bool = False
) -> Dict[str, Any]:
    """
    Dự báo dài hạn nâng cao cho crypto: async, cache, custom metric, alert, API ready, logging, self-test, extensible explain, rolling/statistics/visualization.
    Args:
        symbol: Mã giao dịch (mặc định BTCUSDT)
        timeframes: List các timeframe cần dự báo (mặc định ['1d', '3d', '1w'])
        periods: Số bước dự báo (mặc định 90)
        model_name: Tùy chọn tên mô hình (nếu None sẽ tự động chọn tốt nhất cho từng timeframe)
        return_df: Trả về kết quả dạng DataFrame nếu True
        explain: Bật giải thích mô hình (SHAP, feature importance)
        aggregate: Tổng hợp xu hướng, xác suất, confidence
        visualize: Trả về biểu đồ dự báo nếu True
        stats: Trả về thống kê volatility, min/max, autocorr nếu True
        rolling_window: Số bước cho rolling mean/std
        viz_types: List các loại biểu đồ ['line', 'hist', 'corr']
        top_features: Số feature importance hàng đầu trả về
        cache: dict để cache kết quả dự báo (nếu có)
        custom_metric: hàm metric(y_true, y_pred) để đánh giá dự báo
        alert_threshold: ngưỡng cảnh báo (nếu có)
        api_mode: chuẩn hóa output cho API
        log_level: mức log ('DEBUG', 'INFO', ...)
        selftest: chạy test nội bộ
    Returns:
        Dict kết quả dự báo, bao gồm prediction, confidence, model, explain, v.v.
    """
    logger.setLevel(getattr(logging, log_level.upper(), logging.INFO))
    if timeframes is None:
        timeframes = ['1d', '3d', '1w']
    if viz_types is None:
        viz_types = ['line']
    if cache is None:
        cache = {}
    if custom_metric is None:
        custom_metric = _default_metric
    try:
        predictor = get_ensemble_predictor()
        forecast_results = {}
        explain_results = {}
        trend_summary = []
        stats_results = {}
        all_feature_importance = {}
        tasks = []
        loop = asyncio.get_event_loop() if asyncio.get_event_loop().is_running() else asyncio.new_event_loop()
        # Async predict cho từng timeframe, có cache
        for tf in timeframes:
            cache_key = f"{symbol}_{tf}_{periods}_{model_name}_{explain}"
            if cache_key in cache:
                pred = cache[cache_key]
            else:
                best_model = model_name or get_best_model_name(predictor, symbol)
                pred = loop.run_until_complete(_async_predict(predictor, symbol, tf, periods, best_model, explain))
                cache[cache_key] = pred
            forecast_results[tf] = pred
            # Explain SHAP nếu chưa có
            if explain:
                model_obj = None
                X_sample = None
                try:
                    # Lấy model object và sample features nếu có
                    info = predictor.get_model_info(symbol)
                    if best_model in info['models']:
                        model_obj = info['models'][best_model].get('model')
                        # Lấy sample features từ scaler nếu có
                        if info['models'][best_model].get('scaler'):
                            X_sample = info['models'][best_model]['scaler'].mean_.reshape(1, -1)
                except Exception:
                    pass
                if model_obj is not None:
                    shap_feat = explain_model_shap(model_obj, pd.DataFrame(X_sample), top_n=top_features)
                    if shap_feat:
                        explain_results[tf] = {'shap_feature_importance': shap_feat}
            if 'trend' in pred:
                trend_summary.append(pred['trend'])
            if stats and 'prediction' in pred:
                arr = np.array(pred['prediction'])
                stats_results[tf] = {
                    'min': float(np.min(arr)),
                    'max': float(np.max(arr)),
                    'mean': float(np.mean(arr)),
                    'std': float(np.std(arr)),
                    'volatility': float(np.std(np.diff(arr))),
                    'autocorr': float(pd.Series(arr).autocorr(lag=1)) if len(arr) > 1 else None
                }
        summary = {
            'symbol': symbol,
            'timeframes': timeframes,
            'periods': periods,
            'models': {tf: (model_name or predictor.get_best_model(symbol, [tf])) for tf in timeframes},
            'results': forecast_results,
            'status': 'success'
        }
        if stats_results:
            summary['stats'] = stats_results
        if aggregate:
            try:
                all_probs = [pred.get('probabilities') for pred in forecast_results.values() if 'probabilities' in pred]
                all_conf = [pred.get('confidence') for pred in forecast_results.values() if 'confidence' in pred]
                summary['aggregate'] = {
                    'mean_probability': float(np.mean([p for sub in all_probs if sub is not None for p in sub.values()])) if all_probs else None,
                    'mean_confidence': float(np.mean([c for c in all_conf if c is not None])) if all_conf else None,
                    'trend_counts': {t: trend_summary.count(t) for t in set(trend_summary)} if trend_summary else None
                }
            except Exception as agg_e:
                logger.warning(f"[LongTermForecast] Aggregate error: {agg_e}")
        if explain_results:
            summary['explain'] = explain_results
        if all_feature_importance:
            try:
                all_feat = pd.concat([
                    pd.Series(fi).sort_values(ascending=False).head(top_features)
                    for fi in all_feature_importance.values()
                ], axis=1).fillna(0)
                all_feat['mean_importance'] = all_feat.mean(axis=1)
                summary['top_feature_importance'] = all_feat['mean_importance'].sort_values(ascending=False).head(top_features).to_dict()
            except Exception as feat_e:
                logger.warning(f"[LongTermForecast] Feature importance error: {feat_e}")
        if return_df:
            try:
                df = pd.DataFrame({tf: forecast_results[tf]['prediction'] for tf in forecast_results if 'prediction' in forecast_results[tf]})
                if rolling_window > 1:
                    for tf in df:
                        df[f'{tf}_rollmean'] = df[tf].rolling(rolling_window).mean()
                        df[f'{tf}_rollstd'] = df[tf].rolling(rolling_window).std()
                summary['df'] = df
            except Exception as df_e:
                logger.warning(f"[LongTermForecast] DataFrame error: {df_e}")
        if visualize:
            try:
                import matplotlib.pyplot as plt
                import io
                import base64
                figs = {}
                if 'line' in viz_types:
                    fig, ax = plt.subplots(figsize=(10, 5))
                    for tf in forecast_results:
                        if 'prediction' in forecast_results[tf]:
                            ax.plot(forecast_results[tf]['prediction'], label=tf)
                    ax.set_title(f"Long-term Forecast for {symbol}")
                    ax.legend()
                    buf = io.BytesIO()
                    plt.savefig(buf, format='png')
                    buf.seek(0)
                    figs['line'] = base64.b64encode(buf.read()).decode('utf-8')
                    plt.close(fig)
                if 'hist' in viz_types:
                    fig, ax = plt.subplots(figsize=(10, 5))
                    for tf in forecast_results:
                        if 'prediction' in forecast_results[tf]:
                            ax.hist(forecast_results[tf]['prediction'], bins=20, alpha=0.5, label=tf)
                    ax.set_title(f"Forecast Histogram for {symbol}")
                    ax.legend()
                    buf = io.BytesIO()
                    plt.savefig(buf, format='png')
                    buf.seek(0)
                    figs['hist'] = base64.b64encode(buf.read()).decode('utf-8')
                    plt.close(fig)
                if 'corr' in viz_types and return_df and 'df' in summary:
                    fig, ax = plt.subplots(figsize=(8, 6))
                    corr = summary['df'].corr()
                    im = ax.imshow(corr, cmap='coolwarm', interpolation='nearest')
                    ax.set_xticks(range(len(corr.columns)))
                    ax.set_yticks(range(len(corr.columns)))
                    ax.set_xticklabels(corr.columns, rotation=45, ha='right')
                    ax.set_yticklabels(corr.columns)
                    fig.colorbar(im, ax=ax)
                    ax.set_title(f"Correlation Heatmap for {symbol}")
                    buf = io.BytesIO()
                    plt.savefig(buf, format='png')
                    buf.seek(0)
                    figs['corr'] = base64.b64encode(buf.read()).decode('utf-8')
                    plt.close(fig)
                summary['visualization'] = figs
            except Exception as vis_e:
                logger.warning(f"[LongTermForecast] Visualization error: {vis_e}")
        # Alert/trigger nếu vượt ngưỡng
        if alert_threshold is not None and stats_results:
            try:
                alert = {tf: s for tf, s in stats_results.items() if s['volatility'] > alert_threshold}
                if alert:
                    summary['alert'] = alert
            except Exception as alert_e:
                logger.warning(f"[LongTermForecast] Alert error: {alert_e}")
        # Custom metric đánh giá dự báo nếu có ground truth
        if custom_metric is not None and 'df' in summary:
            try:
                # Giả sử có ground_truth trong forecast_results (nếu có)
                for tf in summary['df']:
                    gt = forecast_results[tf].get('ground_truth')
                    if gt is not None:
                        summary.setdefault('metrics', {})[tf] = custom_metric(gt, summary['df'][tf])
            except Exception as metric_e:
                logger.warning(f"[LongTermForecast] Custom metric error: {metric_e}")
        # API mode: chuẩn hóa output
        if api_mode:
            import json
            try:
                summary = json.loads(json.dumps(summary, default=str))
            except Exception as api_e:
                logger.warning(f"[LongTermForecast] API mode error: {api_e}")
        # Self-test nội bộ
        if selftest:
            try:
                assert summary['status'] == 'success'
                assert 'results' in summary
                logger.info('[LongTermForecast] Self-test passed')
            except Exception as st_e:
                logger.error(f'[LongTermForecast] Self-test failed: {st_e}')
        return summary
    except Exception as e:
        logger.error(f"[LongTermForecast] Error: {e}")
        return {'status': 'error', 'error': str(e)}
