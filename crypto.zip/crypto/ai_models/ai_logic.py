"""
AI Logic Module for Crypto Trading System - REFACTORED
Manages AI prediction, model loading, and trading signal generation.

Module này đã được tối ưu hóa và chia nhỏ thành các modules chuyên biệt:
- ai_prediction.py: EnsemblePredictor và logic prediction
- ai_patterns.py: Pattern recognition functions
- ai_parameters.py: AIParameterCalculator và parameter functions

Chỉ giữ lại core logic và MetaAI class ở đây.
"""

# Apply import fixes first
try:
    from config.logging_config import apply_compatibility_fixes
    apply_compatibility_fixes()
except:
    pass

# Import config to ensure TensorFlow environment variables are set
from config import settings

import numpy as np
import pandas as pd
import gzip, os, json
import pickle
import time
import gc
import importlib

# Safe sklearn imports
try:
    from sklearn.linear_model import LogisticRegression
    from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
    from sklearn.neural_network import MLPClassifier
    from sklearn.svm import SVC
    from sklearn.model_selection import RandomizedSearchCV, StratifiedKFold
except ImportError as e:
    print(f"Warning: Some sklearn imports failed: {e}")

from typing import Dict, List, Tuple, Optional, Union, Any, Callable
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from textblob import TextBlob
from collections import Counter
from concurrent.futures import ThreadPoolExecutor, as_completed, Future
import threading
import asyncio
from functools import partial
from config.logging_config import get_logger
from config.settings import DATA_DIR

# Gradient boosting imports
try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False

try:
    from lightgbm import LGBMClassifier
    LIGHTGBM_AVAILABLE = True
except ImportError:
    LIGHTGBM_AVAILABLE = False

try:
    from catboost import CatBoostClassifier
    CATBOOST_AVAILABLE = True
except ImportError:
    CATBOOST_AVAILABLE = False

# Import advanced features
try:
    import joblib
    from ai_optimizer.unified_optimizer import UnifiedOptimizer, HyperparameterOptimizer, DriftDetector
    from ai_optimizer.unified_resource_manager import get_resource_manager
    from backtesting.walk_forward import WalkForwardBacktester
    from ai_models.unified_metrics import UnifiedMetrics
    from ai_models.unified_results_manager import UnifiedResultsManager
    from data_processing.unified_data_validator import UnifiedDataValidator, ValidationConfig
    ADVANCED_AVAILABLE = True
except ImportError as e:
    logger = get_logger('ai_logic')
    logger.warning(f"Advanced features not available: {e}")
    ADVANCED_AVAILABLE = False

logger = get_logger('ai_logic')

# Initialize AI modules if available
if ADVANCED_AVAILABLE:
    try:
        resource_manager = get_resource_manager()
        unified_optimizer = UnifiedOptimizer()
        unified_metrics = UnifiedMetrics()
        unified_results_manager = UnifiedResultsManager()
        unified_data_validator = UnifiedDataValidator(ValidationConfig())
    except Exception as e:
        logger.warning(f"Failed to initialize AI modules: {e}")
        resource_manager = None
        unified_optimizer = None
        unified_metrics = None
        unified_results_manager = None
        unified_data_validator = None
else:
    resource_manager = None
    unified_optimizer = None
    unified_metrics = None
    unified_results_manager = None
    unified_data_validator = None

# ==================== IMPORT REFACTORED MODULES ====================
# Import các modules đã được tách ra để tối ưu hóa và loại bỏ code trùng lặp
from ai_models.ai_prediction import EnsemblePredictor, get_ensemble_predictor, predict_with_ensemble
from ai_models.ai_patterns import get_all_patterns, get_all_patterns_memory_safe, PATTERN_TYPES
from ai_models.ai_parameters import (
    AIParameterCalculator, get_parameter_calculator, get_timeframe_parameters,
    suggest_tp_sl, calculate_data_characteristics, calculate_data_characteristics_memory_safe, get_system_resources,
    get_adaptive_model_config
)

# Use UnifiedFeatureEngineer instead of deprecated FeatureEngineer
from ai_models.feature_engineering import UnifiedFeatureEngineer

# ==================== TRAINING CONFIGURATION IMPORTED ====================
# Import training configuration from unified_trainer
try:
    from ai_models.unified_trainer import TrainingResult, ModelConfig
except ImportError:
    # Fallback minimal config if import fails
    from dataclasses import dataclass
    @dataclass
    class TrainingResult:
        model: Any = None
        model_name: str = ""
        accuracy: float = 0.0
        f1_score: float = 0.0
        threshold: float = 0.5
        backtest_results: Any = None
        training_time: float = 0.0
        error: Optional[str] = None

# ==================== META AI CLASS ====================
class MetaAI:
    """
    Meta-AI điều phối tất cả các AI modules và tự động tối ưu hóa
    Loại bỏ hardcode, sử dụng AI để điều chỉnh mọi tham số
    """
    
    def __init__(self):
        self.logger = get_logger('meta_ai')
        self.predictor = get_ensemble_predictor()
        self.param_calculator = get_parameter_calculator()
        self.feature_engineer = UnifiedFeatureEngineer()
        
        # Tích hợp với tất cả AI modules
        self.optimizer = unified_optimizer
        self.metrics = unified_metrics
        self.results_manager = unified_results_manager
        self.resource_manager = resource_manager
        
        # Dynamic state tracking
        self.prediction_history = {}
        self.performance_cache = {}
        self.market_regime_cache = {}
        
        self.logger.info("🤖 MetaAI initialized with all refactored modules")
    
    def predict_smart(self, data: pd.DataFrame, symbol: str, timeframe: str = "15m",
                     use_patterns: bool = True, use_ensemble: bool = True) -> Dict[str, Any]:
        """
        Thực hiện prediction thông minh với tự động tối ưu hóa mọi tham số
        """
        try:
            self.logger.info(f"🎯 Smart prediction for {symbol}@{timeframe}")
            
            # 1. Feature engineering với AI-driven parameters
            if use_patterns:
                data_with_patterns = get_all_patterns(data, symbol)
            else:
                data_with_patterns = data.copy()
            
            # Engineer features using UnifiedFeatureEngineer
            features_data = self.feature_engineer.engineer_features(
                df=data_with_patterns,
                include_technical=True,
                include_statistical=True,
                include_sentiment=False,
                include_advanced=True
            )
            
            if features_data is None or features_data.empty:
                raise ValueError("Feature engineering failed")
            
            # 2. Tính toán dynamic parameters
            timeframe_params = get_timeframe_parameters(timeframe, data, symbol)
            confidence_threshold = timeframe_params.get('confidence_threshold', 0.55)
            
            # 3. Prepare features for prediction
            feature_cols = [col for col in features_data.columns 
                          if col not in ['target', 'timestamp', 'open_time', 'close_time']]
            X = features_data[feature_cols].fillna(0)
            
            # 4. Make prediction với dynamic model selection
            if use_ensemble:
                prediction_result = self.predictor.predict_ensemble(
                    X, symbol, data, confidence_threshold=confidence_threshold
                )
            else:
                prediction_result = self.predictor.predict_best_model(
                    X, symbol, data, confidence_threshold=confidence_threshold
                )
            
            # 5. Calculate AI-driven TP/SL
            direction = "LONG" if prediction_result['prediction'] == 1 else "SHORT"
            tp_sl_result = suggest_tp_sl(
                df=data,
                direction=direction,
                symbol=symbol,
                market_data=data,
                use_dynamic=True
            )
            
            # 6. Generate signal explanation
            signal_explanation = self._generate_signal_explanation(
                direction, prediction_result['confidence'], prediction_result, tp_sl_result
            )
            
            # 7. Compile final result
            final_result = {
                'prediction': prediction_result['prediction'],
                'direction': direction,
                'probability': prediction_result['probability'],
                'confidence': prediction_result['confidence'],
                'high_confidence': prediction_result.get('high_confidence', False),
                'tp_sl': tp_sl_result,
                'model_info': prediction_result.get('model_details', {}),
                'signal_explanation': signal_explanation,
                'timeframe_params': timeframe_params,
                'features_count': len(feature_cols),
                'ai_driven': True,
                'timestamp': datetime.now().isoformat()
            }
            
            # 8. Update prediction history for learning
            self._update_prediction_history(symbol, timeframe, final_result)
            
            self.logger.info(f"✅ Smart prediction completed: {direction} with {prediction_result['confidence']:.3f} confidence")
            return final_result
            
        except Exception as e:
            self.logger.error(f"❌ Smart prediction failed: {e}")
            return {
                'prediction': 0,
                'direction': 'HOLD',
                'probability': 0.5,
                'confidence': 0.0,
                'error': str(e),
                'ai_driven': False,
                'timestamp': datetime.now().isoformat()
            }
    
    def predict_smart_memory_safe(self, data_or_path, symbol: str, timeframe: str = "15m",
                                 use_patterns: bool = True, use_ensemble: bool = True,
                                 batch_size: int = 100_000, use_gpu: bool = True, max_ram_usage: float = 0.9, wait_time: int = 180, **kwargs) -> Dict[str, Any]:
        """
        Memory-safe, multi-threaded, GPU-ready smart prediction for large DataFrames or file paths.
        """
        try:
            self.logger.info(f"🎯 [MemorySafe] Smart prediction for {symbol}@{timeframe} (batch={batch_size}, GPU={use_gpu})")
            # 1. Feature engineering + pattern detection memory-safe
            if use_patterns:
                data_with_patterns = get_all_patterns_memory_safe(data_or_path, symbol, batch_size, use_gpu, max_ram_usage, wait_time, **kwargs)
            else:
                data_with_patterns = data_or_path
            # 2. Feature engineering (giả sử UnifiedFeatureEngineer đã memory-safe)
            features_data = self.feature_engineer.engineer_features(
                df=data_with_patterns,
                include_technical=True,
                include_statistical=True,
                include_sentiment=False,
                include_advanced=True
            )
            if features_data is None or features_data.empty:
                raise ValueError("Feature engineering failed")
            # 3. Tính toán dynamic parameters
            timeframe_params = get_timeframe_parameters(timeframe, features_data, symbol)
            confidence_threshold = timeframe_params.get('confidence_threshold', 0.55)
            # 4. Chuẩn bị features cho prediction
            feature_cols = [col for col in features_data.columns if col not in ['target', 'timestamp', 'open_time', 'close_time']]
            X = features_data[feature_cols].fillna(0)
            # 5. Dự báo memory-safe
            if use_ensemble:
                prediction_results = predict_ensemble_memory_safe(
                    X,
                    symbol,
                    features_data,
                    batch_size=batch_size,
                    use_gpu=use_gpu,
                    confidence_threshold=confidence_threshold,
                    max_ram_usage=max_ram_usage,
                    wait_time=wait_time,
                    **kwargs
                )
                # Lấy kết quả cuối cùng của batch cuối cùng (hoặc tổng hợp)
                prediction_result = prediction_results[-1] if prediction_results else {}
            else:
                prediction_result = self.predictor.predict_best_model(
                    X, symbol, features_data, use_gpu=use_gpu, confidence_threshold=confidence_threshold
                )
            # 6. Tính toán TP/SL
            direction = "LONG" if prediction_result.get('prediction', 0) == 1 else "SHORT"
            tp_sl_result = suggest_tp_sl(
                df=features_data,
                direction=direction,
                symbol=symbol,
                market_data=features_data,
                use_dynamic=True
            )
            # 7. Compile final result
            final_result = {
                'prediction': prediction_result.get('prediction', 0),
                'direction': direction,
                'probability': prediction_result.get('probability', 0.5),
                'confidence': prediction_result.get('confidence', 0.0),
                'high_confidence': prediction_result.get('high_confidence', False),
                'tp_sl': tp_sl_result,
                'model_info': prediction_result.get('model_details', {}),
                'timeframe_params': timeframe_params,
                'features_count': len(feature_cols),
                'ai_driven': True,
                'timestamp': datetime.now().isoformat()
            }
            self.logger.info(f"✅ [MemorySafe] Smart prediction completed: {direction} with {prediction_result.get('confidence', 0.0):.3f} confidence")
            return final_result
        except Exception as e:
            self.logger.error(f"❌ [MemorySafe] Smart prediction failed: {e}")
            return {
                'prediction': 0,
                'direction': 'HOLD',
                'probability': 0.5,
                'confidence': 0.0,
                'error': str(e),
                'ai_driven': False,
                'timestamp': datetime.now().isoformat()
            }

    def analyze_market_regime(self, data: pd.DataFrame, symbol: str) -> Dict[str, Any]:
        """
        Phân tích market regime với AI để tự động điều chỉnh strategies
        """
        try:
            cache_key = f"{symbol}_{len(data)}"
            if cache_key in self.market_regime_cache:
                cached_time = self.market_regime_cache[cache_key]['timestamp']
                if time.time() - cached_time < 300:  # 5 minutes cache
                    return self.market_regime_cache[cache_key]['data']
            
            # Sử dụng AI parameter calculator để phân tích
            regime_data = self.param_calculator._analyze_market_regime(data)
            
            # Enhanced analysis với additional metrics
            if len(data) >= 50:
                # Trend analysis
                short_ma = data['close'].rolling(10).mean()
                long_ma = data['close'].rolling(50).mean()
                trend_signal = 1 if short_ma.iloc[-1] > long_ma.iloc[-1] else 0
                
                # Momentum analysis
                roc = (data['close'].iloc[-1] / data['close'].iloc[-10] - 1) * 100
                
                # Volume analysis
                if 'volume' in data.columns:
                    volume_trend = data['volume'].rolling(10).mean().iloc[-1] / data['volume'].rolling(50).mean().iloc[-1]
                else:
                    volume_trend = 1.0
                    
                regime_data.update({
                    'trend_signal': trend_signal,
                    'momentum_roc': roc,
                    'volume_trend': volume_trend,
                    'market_state': self._classify_market_state(regime_data)
                })
            
            # Cache result
            self.market_regime_cache[cache_key] = {
                'data': regime_data,
                'timestamp': time.time()
            }
            
            return regime_data
            
        except Exception as e:
            self.logger.error(f"Market regime analysis failed: {e}")
            return {'volatility': 'NORMAL', 'trend_direction': 0, 'error': str(e)}
    
    def analyze_market_regime_memory_safe(self, data_or_path, symbol: str, batch_size: int = 100_000, use_gpu: bool = True, max_ram_usage: float = 0.9, wait_time: int = 180, **kwargs) -> Dict[str, Any]:
        """
        Memory-safe, multi-threaded, GPU-ready market regime analysis for large DataFrames or file paths.
        """
        try:
            chars = calculate_data_characteristics_memory_safe(data_or_path, batch_size, use_gpu, max_ram_usage, wait_time, **kwargs)
            return chars
        except Exception as e:
            self.logger.error(f"❌ [MemorySafe] Market regime analysis failed: {e}")
            return {'error': str(e)}

    def _classify_market_state(self, regime_data: Dict) -> str:
        """Classify market state based on regime analysis"""
        volatility = regime_data.get('volatility', 'NORMAL')
        trend_strength = regime_data.get('trend_strength', 0.5)
        volume_confirmation = regime_data.get('volume_confirmation', 1.0)
        
        if volatility == 'HIGH' and trend_strength > 0.7:
            return 'TRENDING_VOLATILE'
        elif volatility == 'LOW' and trend_strength < 0.3:
            return 'SIDEWAYS_CALM'
        elif trend_strength > 0.6 and volume_confirmation > 1.2:
            return 'STRONG_TREND'
        elif volatility == 'HIGH' and trend_strength < 0.4:
            return 'CHOPPY_VOLATILE'
        else:
            return 'NORMAL_MARKET'
    
    def _generate_signal_explanation(self, direction: str, confidence: float, 
                                   prediction_result: Dict, tp_sl_result: Dict) -> str:
        """Generate human-readable signal explanation"""
        try:
            # Base explanation
            conf_level = "high" if confidence > 0.7 else "medium" if confidence > 0.5 else "low"
            
            explanation = f"{direction} signal with {conf_level} confidence ({confidence:.3f}). "
            
            # Model info
            models_used = prediction_result.get('models_used', 0)
            if models_used > 1:
                explanation += f"Consensus from {models_used} models. "
            
            # TP/SL info
            if tp_sl_result.get('TP') and tp_sl_result.get('SL'):
                rr_ratio = tp_sl_result.get('risk_reward_ratio', 0)
                explanation += f"R/R ratio: {rr_ratio:.2f}. "
            
            # Market regime
            if hasattr(tp_sl_result, 'market_regime'):
                regime = tp_sl_result.get('market_regime', {})
                volatility = regime.get('volatility', 'NORMAL')
                explanation += f"Market: {volatility.lower()} volatility. "
            
            return explanation
            
        except Exception as e:
            return f"{direction} signal generated (explanation generation failed: {e})"
    
    def _update_prediction_history(self, symbol: str, timeframe: str, result: Dict):
        """Update prediction history for learning purposes"""
        try:
            key = f"{symbol}_{timeframe}"
            if key not in self.prediction_history:
                self.prediction_history[key] = []
            
            # Keep only last 100 predictions
            self.prediction_history[key].append({
                'timestamp': time.time(),
                'prediction': result['prediction'],
                'confidence': result['confidence'],
                'direction': result['direction']
            })
            
            if len(self.prediction_history[key]) > 100:
                self.prediction_history[key] = self.prediction_history[key][-100:]
                
        except Exception as e:
            self.logger.warning(f"Failed to update prediction history: {e}")
    
    def get_adaptive_config(self, data: Union[pd.DataFrame, Dict[str, pd.DataFrame]], 
                          training_mode: str = 'standard') -> Dict[str, Any]:
        """
        Get adaptive configuration for training/prediction based on data characteristics
        """
        try:
            # Get system resources
            system_resources = get_system_resources()
            
            # Get adaptive model config
            config = get_adaptive_model_config(data, system_resources, training_mode)
            
            # Add MetaAI specific optimizations
            config['meta_ai_optimizations'] = {
                'dynamic_confidence': True,
                'pattern_recognition': True,
                'regime_adaptation': True,
                'resource_optimization': True
            }
            
            return config
            
        except Exception as e:
            self.logger.error(f"Failed to get adaptive config: {e}")
            return {'error': str(e)}

    def get_adaptive_config_memory_safe(self, data_or_path, training_mode: str = 'standard', batch_size: int = 100_000, use_gpu: bool = True, max_ram_usage: float = 0.9, wait_time: int = 180, **kwargs) -> Dict[str, Any]:
        """
        Memory-safe, multi-threaded, GPU-ready adaptive config for large DataFrames or file paths.
        """
        try:
            chars = calculate_data_characteristics_memory_safe(data_or_path, batch_size, use_gpu, max_ram_usage, wait_time, **kwargs)
            system_resources = get_system_resources()
            config = get_adaptive_model_config(chars, system_resources, training_mode)
            config['meta_ai_optimizations'] = {
                'dynamic_confidence': True,
                'pattern_recognition': True,
                'regime_adaptation': True,
                'resource_optimization': True
            }
            return config
        except Exception as e:
            self.logger.error(f"❌ [MemorySafe] Adaptive config failed: {e}")
            return {'error': str(e)}

# ==================== UTILITY FUNCTIONS ====================

def _get_ai_calculator():
    """Get AI parameter calculator instance"""
    return get_parameter_calculator()

# Initialize global MetaAI instance
meta_ai = None

def get_meta_ai() -> MetaAI:
    """Get global MetaAI instance"""
    global meta_ai
    if meta_ai is None:
        meta_ai = MetaAI()
        logger.info("✅ Global MetaAI initialized")
    return meta_ai

# ==================== BACKWARDS COMPATIBILITY ====================
# Các function wrapper để đảm bảo backwards compatibility

def get_ensemble_predictor_legacy() -> EnsemblePredictor:
    """Legacy function for backwards compatibility"""
    return get_ensemble_predictor()

def predict_ensemble_legacy(X: pd.DataFrame, symbol: str, **kwargs) -> Dict:
    """Legacy function for backwards compatibility"""
    return predict_with_ensemble(X, symbol, **kwargs)

# ==================== MODULE INITIALIZATION ====================

# Initialize parameter calculator và set cho các modules
try:
    ai_parameter_calculator = get_parameter_calculator()
    
    # Set parameter calculator cho pattern recognition module
    from ai_models.ai_patterns import set_parameter_calculator
    set_parameter_calculator(ai_parameter_calculator)
    
    logger.info("✅ AI Logic module initialized with refactored architecture")
    
except Exception as e:
    logger.error(f"❌ Failed to initialize AI Logic module: {e}")
    ai_parameter_calculator = None

# Export main components
__all__ = [
    'MetaAI', 'get_meta_ai',
    'EnsemblePredictor', 'get_ensemble_predictor', 'predict_with_ensemble',
    'get_all_patterns', 'PATTERN_TYPES',
    'AIParameterCalculator', 'get_parameter_calculator', 'get_timeframe_parameters',
    'suggest_tp_sl', 'calculate_data_characteristics', 'get_system_resources',
    'get_adaptive_model_config'
]
